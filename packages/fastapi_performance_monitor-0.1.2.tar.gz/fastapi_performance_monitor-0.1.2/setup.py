from setuptools import setup

# This file is required for editable installs.
# It defers all configuration to pyproject.toml.
setup()
