NDEBUG = False


class CodegenError(Exception): ...


class ValidationError(CodegenError): ...
