from quick import gui_it

from .cli import gr1 as cli_main


def main():
    gui_it(cli_main)


if __name__ == "__main__":
    main()
