class QueryCacher:
    pass
