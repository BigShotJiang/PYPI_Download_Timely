To deploy: `uv run modal deploy vllm_inference.py`
