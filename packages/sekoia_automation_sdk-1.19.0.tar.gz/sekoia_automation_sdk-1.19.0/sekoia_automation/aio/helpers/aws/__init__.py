"""
Utilities and wrappers to work with aws.

To use this package you need to install additional libraries:

* aiobotocore (https://github.com/aio-libs/aiobotocore)
"""
