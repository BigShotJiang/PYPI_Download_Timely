"""
Configure LOGURU logger.

https://github.com/Delgan/loguru
"""
