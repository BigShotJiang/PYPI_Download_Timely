from pydantic import BaseModel


class SoftwareOCSFModel(BaseModel):
    pass
