"""context-llemur: collaborative memory for humans and LLMs"""

__version__ = "0.1.0" 