from .spectrogram import spectrogram, animate_spectrogram
from .spectrum import plot_spectrum, animate_spectrum
