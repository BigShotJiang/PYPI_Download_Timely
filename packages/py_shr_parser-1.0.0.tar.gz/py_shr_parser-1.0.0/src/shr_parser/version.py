import importlib.metadata

__version__ = importlib.metadata.version("py-shr-parser")
