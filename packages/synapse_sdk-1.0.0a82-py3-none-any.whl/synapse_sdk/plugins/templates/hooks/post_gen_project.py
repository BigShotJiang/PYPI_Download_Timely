from synapse_sdk.plugins.categories.templates import copy_project_category_template

copy_project_category_template('{{ cookiecutter.category }}')
