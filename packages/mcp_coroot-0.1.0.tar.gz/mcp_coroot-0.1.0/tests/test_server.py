"""Legacy test file - tests moved to more specific files.

This file is kept for backward compatibility but all tests have been
moved to more specific test files:
- test_server_tools.py: Tool implementation tests
- test_main.py: Main function and initialization tests
"""

# All tests have been moved to more specific files
