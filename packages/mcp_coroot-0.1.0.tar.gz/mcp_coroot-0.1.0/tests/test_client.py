"""Legacy test file - tests moved to more specific files.

This file is kept for backward compatibility but all tests have been
moved to more specific test files:
- test_client_auth.py: Authentication and initialization tests
- test_client_api.py: API functionality tests
"""

# All tests have been moved to more specific files
