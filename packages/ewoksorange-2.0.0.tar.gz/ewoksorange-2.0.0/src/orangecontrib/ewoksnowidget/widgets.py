# This module will contain during runtime default orange widget (for Task having no Orange widget already defined).
# See default_owwidget_class(task_class) function.
