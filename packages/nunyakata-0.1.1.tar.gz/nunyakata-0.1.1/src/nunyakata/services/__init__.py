"""
Service modules for various Ghana-based APIs.
"""

from .nalo_solutions import NaloSolutionsClient

__all__ = [
    "NaloSolutionsClient",
]
