# Reference API
This is the reference documentation for `iplotx`. This is split into separate sections:

- <project:api/plotting.md> for the plotting API
- <project:api/style.md> for the styling API
- <project:api/artists.md> for the artist hierarchy
- <project:api/providers.md> for the data providers API
