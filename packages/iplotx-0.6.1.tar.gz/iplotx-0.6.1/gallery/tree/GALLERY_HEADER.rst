Trees
+++++
The general styling options for networks also work for trees. However, trees have a different
approach for layouting (including **orientation**, **angular**, and **angle span**) and
support additional styling elements such as **cascades**, **subtree styling**, and **leaf
labels**.
