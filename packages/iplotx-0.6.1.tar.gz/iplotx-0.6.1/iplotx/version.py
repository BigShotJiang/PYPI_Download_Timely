"""
iplotx version information module.
"""

__version__ = "0.6.1"
