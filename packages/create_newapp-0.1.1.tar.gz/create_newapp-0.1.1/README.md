# Create Django App

Un outil pour générer une application Django complète avec les fichiers nécessaires : `views.py`, `models.py`, `urls.py`, etc.

## Installation

```bash
pip install create-Newapp
```

## Utilisation

```bash
create-django nom_de_mon_app
```

---