"""Orchestration components for Claude MPM (legacy)."""

# Most orchestration components have been simplified and moved to core.simple_runner
# This module is kept for backwards compatibility

__all__ = []