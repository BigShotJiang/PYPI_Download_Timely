def main():
    print("Hello from gyllm!")


if __name__ == "__main__":
    main()
