# Python-Learn-Gamble
The repo/project is based on learning how to code in python with a touch of experience and creating a game at the end to show my still (Gambling Game).

### As of for now this is my steps to successding this project:

1. Learn the basics on how to code
2. Make a small little game to show my understanding
3. Learn the more difficult parts on how to code
4. Try to make the gambling game
5. Make it better
6. Possibly make it into a Desktop game

### Working
1) My whole learning explanation is in my learn.py file but here I'm going to explain, and show my understanding here. P.S. I realised that it will take way too long and it won't be interesting so I'm going to jsut do a few, the very baiscs.
### Basic Functions:
**print()** - A command that prints out what ever is in the '()' or brackets. This can be anything

**Example:**

        print("This is how you print messages")

**If statment** - A statement which adds a condition to use a block of code. This can be done by writing 'if' on a new line followed by the condition and lastly the action.

**Example:** 

    if x > 5 
        print("This is how you use if statments")

**Comments** - A feature where you can write notes that won't effect the code. You can do this by using a '#' then your message. You can also make multi-line comments by surounding the text in triple quotes ,""", or ,''',. 

    # Comment

    '''
    Multi
    line
    comment
    '''

**Variables** - A statement, connecting a certain name to a value. **Variables** has rules to naming variabales. It must only include letters a-z, A-Z, 0-9 and '_'. When naming variables, variables are case sensitive to a is different to A. If you use symbols like '*' or '#', will cause an error as well as naming your variable a special word in Python like 'if' or 'else'. You can assign multiple values to multiple variables by adding commas or ',' between every value or variable. With the print command, you can use a variable in it. You can also combine variables using '+' or ',', This can be done with all kinds of variabale. If a variable is not inside any function or code (code with indent or '   ') they are considered global variables where any code can use it. Code that is defined in a function or in another code is called a local variable and other blocks of code, outside of the code defining it, can't use it.

Example:

    x = 54

    HackClub_SummerOfMaking = "yay"

    Bob, Kyle, Lisa = 1, 2, 3

    y = 65
    print(y)

    print(x + y)


**Global** - A command that will classify, mainly, defining variables, as a global variables no matter where it is.

    global

**type()** - A command that you can use to find the type of data type a variable holds

    x = 65
    print(type(x))

**Data type:** Int or Integer - A data type, which is under the catagory numbers, which values or output can only be in integers (or whole number)

**Data type:** Float - A data type, which is under that catagory numbers, which can contain any amount of decimals.

**Data type:** Complex = A data type, which is under the catagory numbers, which contains complex number like 'j'

**Data type:** str or string - A data type, under the word catagory, is the only data type that hold a word.

2) I want to try to make a small simple game to show my understanding. I'm thinking of making a simgle shop where you can buy stuff or making a 
simpler gamble game like coin flip, dice roll, guess number or guess card.

I've created the mini game in the MiniGame.py which I like to call, Luck Room. I used many features I would like to use for my main game. I'm also hopping that I'm able to use pygame and pygbag to make the game on a website.


3) Learning the difficult parts of th game is going to be conected with my 4th goal which is to make a gambaling game


4) My end projct is a gambaling game. Now I'm not really planning to create a new gambaling game so I'm going to just recreate gambaling games 
that there already is. For my game I'm planning to have a game where you can access all kind of gambaling games. For those games I'm planning 
to have: Blackjack, roulette, slots and ride the bus. If I can, I want to try to create some other games liks, poker, liar's dice and liar's 
deck. These games are more difficult because I would need to create a computor player or an AI or the player to verse (for make it connect to real life people but I ain't that good).

I have reserched into my next game where I'm going to add common casino games. I also need to figure out how to use pygame and pygbag.

I have concluded my reaserch to figure out a key part of my game. Due to me writing in python, I couldn't easily make my game for a website because pythons is more fit for desktop and terminals games. This caused me to think long and hard about what I was going to do. I decided tha t I should learn how to code in all, Javascript, html and css. This is so I can create my project on the web and design each function exactly how I want it. I want to create a game which includes the popular gambaling. I also wanted to try make this game high quality but I might rush things os I just want to take my time.