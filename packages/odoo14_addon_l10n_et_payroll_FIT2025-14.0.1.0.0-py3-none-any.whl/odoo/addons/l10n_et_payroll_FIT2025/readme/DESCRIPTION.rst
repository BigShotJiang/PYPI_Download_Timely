Federal Income Tax Withholding tables for Ethiopia (revised 2017 EC).
