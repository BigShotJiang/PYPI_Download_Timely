"""Colors for the Launchpad Mini MK3.
"""

from ._colors import ColorPalette  # noqa
from .web_color import WebColor  # noqa
