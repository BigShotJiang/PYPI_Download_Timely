# DevRemind1 🧠⏰

A Python CLI tool that reminds developers to take breaks during long coding sessions.

## Features

- Custom interval reminders
- System notifications (Windows/macOS/Linux)
- Simple CLI interface

## Installation

```bash
pip install -e .
