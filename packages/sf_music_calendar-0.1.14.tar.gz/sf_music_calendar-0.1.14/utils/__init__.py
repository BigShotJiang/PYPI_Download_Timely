"""
Utility functions for sf-music-calendar package
"""
