# Tokker CLI

A fast, simple CLI tool for tokenizing text using OpenAI's `tiktoken` library. Get accurate token counts for GPT models with a single command.

---

## Features

- **Simple Usage**: Just `tok "your text"` - that's it!
- **Multiple Tokenizers**: Support for `cl100k_base` (GPT-4) and `o200k_base` (GPT-4o) tokenizers
- **Flexible Output**: JSON, plain text, and summary output formats
- **Configuration**: Persistent configuration for default tokenizer settings
- **Text Analysis**: Token count, word count, character count, and token frequency analysis
- **Cross-platform**: Works on Windows, macOS, and Linux

---

## Installation

Install from PyPI with pip:

```bash
pip install tokker
```

That's it! The `tok` command is now available in your terminal.

---

## Quick Start

```bash
# Basic usage
tok "Hello world"

# Get plain token output
tok "Hello world" --format plain

# Get summary stats
tok "Hello world" --format summary

# Use a different tokenizer
tok "Hello world" --tokenizer o200k_base
```

---

## Usage Examples

### Basic Tokenization

```bash
$ tok 'Hello world'
{
  "converted": "Hello⎮ world",
  "token_strings": ["Hello", " world"],
  "token_ids": [15339, 1917],
  "token_count": 2,
  "word_count": 2,
  "char_count": 11,
  "pivot": {
    "Hello": 1,
    " world": 1
  },
  "tokenizer": "cl100k_base"
}
```

### Plain Text Output

```bash
$ tok 'Hello world' --format plain
Hello⎮ world
```

### Summary Statistics

```bash
$ tok 'Hello world' --format summary
{
  "token_count": 2,
  "word_count": 2,
  "char_count": 11,
  "tokenizer": "cl100k_base"
}
```

### Using Different Tokenizers

```bash
$ tok 'Hello world' --tokenizer o200k_base
```

### Configuration

Set your default tokenizer to avoid specifying it every time:

```bash
$ tok --set-default-tokenizer o200k_base
✓ Default tokenizer set to: o200k_base
Configuration saved to: ~/.config/tokker/tokenizer_config.json
```

---

## Command Options

```
usage: tok [-h] [--tokenizer {cl100k_base,o200k_base}]
           [--format {json,plain,summary}]
           [--set-default-tokenizer {cl100k_base,o200k_base}]
           [text]

positional arguments:
  text                  Text to tokenize

options:
  --tokenizer           Tokenizer to use (cl100k_base, o200k_base)
  --format              Output format (json, plain, summary)
  --set-default-tokenizer  Set default tokenizer
  -h, --help           Show help message
```

---

## Tokenizers

### cl100k_base (Default)
- **Used by**: GPT-4, GPT-3.5-turbo
- **Description**: OpenAI's standard tokenizer for GPT-4 models
- **Vocabulary size**: ~100,000 tokens

### o200k_base
- **Used by**: GPT-4o, GPT-4o-mini
- **Description**: Newer tokenizer with improved efficiency
- **Vocabulary size**: ~200,000 tokens

---

## Configuration

Tokker stores your preferences in `~/.config/tokker/tokenizer_config.json`:

```json
{
  "default_tokenizer": "cl100k_base",
  "delimiter": "⎮"
}
```

- `default_tokenizer`: Default tokenizer to use
- `delimiter`: Character used to separate tokens in plain text output

---

## Programmatic Usage

You can also use tokker in your Python code:

```python
import tokker

# Count tokens
count = tokker.count_tokens("Hello world")
print(f"Token count: {count}")

# Full tokenization
result = tokker.tokenize_text("Hello world", "cl100k_base")
print(result["token_count"])
```

---

## Tips

- Use single quotes to avoid shell interpretation: `tok 'Hello world!'`
- Pipe text from other commands: `echo "Hello world" | xargs tok`
- Set your preferred tokenizer once: `tok --set-default-tokenizer o200k_base`

---

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## Contributing

Issues and pull requests are welcome! Visit the [GitHub repository](https://github.com/igoakulov/tokker).

---

## Acknowledgments

- OpenAI for the tiktoken library
