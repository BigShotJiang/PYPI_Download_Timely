from atscale.client.client import Client

__all__ = ["client"]
