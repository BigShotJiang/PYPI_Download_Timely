from atscale.data_model.data_model import DataModel

__all__ = ["data_model"]
