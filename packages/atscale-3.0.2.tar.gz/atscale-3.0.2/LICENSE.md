AI Link is a python connector between AtScale's semantic layer and various 
third party data and analytics tools. Use of AI Link is permitted solely 
under and is subject to the terms contained in the AtScale Cloud or 
Enterprise Agreement (the "Agreement"). You may also contact your Customer Success Manager 
if you need help finding this Agreement. You must not use or access AI Link unless you have 
reviewed and agreed to the terms of the Agreement. All technical terms related to requirements, 
installation, and usage of AI Link can be found in the AI Link User Guide; additional documentation 
related to AtScale usage can be found in the Documentation section of your customer portal.