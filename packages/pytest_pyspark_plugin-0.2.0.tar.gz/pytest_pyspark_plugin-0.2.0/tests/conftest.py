import logging

logging.getLogger('py4j').setLevel(logging.ERROR)

pytest_plugins = ['pytester']
