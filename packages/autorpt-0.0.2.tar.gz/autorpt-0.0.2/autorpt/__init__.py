"""Top-level package for autorpt."""

__author__ = """Vance Russell"""
__email__ = 'vance@3point.xyz'
__version__ = '0.0.2'
