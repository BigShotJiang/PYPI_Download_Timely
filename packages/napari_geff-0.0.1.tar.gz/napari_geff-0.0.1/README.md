# napari-geff

[![License BSD-3](https://img.shields.io/pypi/l/napari-geff.svg?color=green)](https://github.com/live-image-tracking-tools/napari-geff/raw/main/LICENSE)
[![PyPI](https://img.shields.io/pypi/v/napari-geff.svg?color=green)](https://pypi.org/project/napari-geff)
[![Python Version](https://img.shields.io/pypi/pyversions/napari-geff.svg?color=green)](https://python.org)
[![tests](https://github.com/live-image-tracking-tools/napari-geff/workflows/tests/badge.svg)](https://github.com/live-image-tracking-tools/napari-geff/actions)
[![codecov](https://codecov.io/gh/live-image-tracking-tools/napari-geff/branch/main/graph/badge.svg)](https://codecov.io/gh/live-image-tracking-tools/napari-geff)
[![napari hub](https://img.shields.io/endpoint?url=https://api.napari-hub.org/shields/napari-geff)](https://napari-hub.org/plugins/napari-geff)
[![npe2](https://img.shields.io/badge/plugin-npe2-blue?link=https://napari.org/stable/plugins/index.html)](https://napari.org/stable/plugins/index.html)
[![Copier](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/copier-org/copier/master/img/badge/badge-grayscale-inverted-border-purple.json)](https://github.com/copier-org/copier)

A reader and writer for the graph exchange file format (geff)

----------------------------------

This [napari] plugin was generated with [copier] using the [napari-plugin-template].

<!--
Don't miss the full getting started guide to set up your new package:
https://github.com/napari/napari-plugin-template#getting-started

and review the napari docs for plugin developers:
https://napari.org/stable/plugins/index.html
-->

![geff-read](https://github.com/user-attachments/assets/bd3d510e-a9c8-490a-b499-47093f15105d)


## Installation

You can install `napari-geff` via [pip]:

```
pip install napari-geff
```

If napari is not already installed, you can install `napari-geff` with napari and Qt via:

```
pip install "napari-geff[all]"
```

## Usage

`napari-geff` supports loading directed graphs stored as [GEFF](https://live-image-tracking-tools.github.io/geff/latest/) files into
`napari` as `Tracks` layers, and saving them back out to GEFF format.

To use `napari-geff` after installation, simply drag a GEFF file into the viewer and select `GEFF IO` from the
plugin selection dialog, if required. The file will be loaded as a `Tracks` layer.

Any node properties defined on your graph will be stored as features on your tracks layer. Edge properties
will be available under `layer.metadata['edge_properties']` as a dictionary, but cannot currently be displayed
or used for visualization in `napari`.

If your file contains `image` or `labels` related objects as per the GEFF
[spec](https://live-image-tracking-tools.github.io/geff/v0.4.0/specification/#geff_related_objects),
these will also be loaded alongside your `Tracks` layer.

If you wish to open your geff file into layers **programmatically**, you can do so using the `viewer.open` method:

```python
import napari
path = 'path/to/top_level_zarr.zarr/my-geff-group/

viewer = napari.Viewer()
layers = viewer.open(path, plugin='napari-geff')
```


## Contributing

Contributions are very welcome. Tests can be run with [tox], please ensure
the coverage at least stays the same before you submit a pull request.

## License

Distributed under the terms of the [BSD-3] license,
"napari-geff" is free and open source software

## Issues

If you encounter any problems, please [file an issue] along with a detailed description.

[napari]: https://github.com/napari/napari
[copier]: https://copier.readthedocs.io/en/stable/
[@napari]: https://github.com/napari
[MIT]: http://opensource.org/licenses/MIT
[BSD-3]: http://opensource.org/licenses/BSD-3-Clause
[GNU GPL v3.0]: http://www.gnu.org/licenses/gpl-3.0.txt
[GNU LGPL v3.0]: http://www.gnu.org/licenses/lgpl-3.0.txt
[Apache Software License 2.0]: http://www.apache.org/licenses/LICENSE-2.0
[Mozilla Public License 2.0]: https://www.mozilla.org/media/MPL/2.0/index.txt
[napari-plugin-template]: https://github.com/napari/napari-plugin-template

[napari]: https://github.com/napari/napari
[tox]: https://tox.readthedocs.io/en/latest/
[pip]: https://pypi.org/project/pip/
[PyPI]: https://pypi.org/
