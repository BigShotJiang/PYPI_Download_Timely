def test_imports():
    from pytest_jubilant import pack, pack_charm, get_resources

    assert pack and pack_charm and get_resources
