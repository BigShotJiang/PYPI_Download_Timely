"""Singleton module."""

from dbt_toolbox.utils.utils import utils

__all__ = [
    "utils",
]
