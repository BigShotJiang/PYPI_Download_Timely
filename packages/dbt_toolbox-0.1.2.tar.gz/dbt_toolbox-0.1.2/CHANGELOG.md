# Changelog

## [0.1.2](https://github.com/erikmunkby/dbt-toolbox/compare/v0.1.1...v0.1.2) (2025-07-25)


### Bug Fixes

* pyproject description ([6a85b92](https://github.com/erikmunkby/dbt-toolbox/commit/6a85b92d43ac2d316e5aaa401b01e365250e9529))

## [0.1.1](https://github.com/erikmunkby/dbt-toolbox/compare/v0.1.0...v0.1.1) (2025-07-25)


### Bug Fixes

* link description to pypi ([bb4f629](https://github.com/erikmunkby/dbt-toolbox/commit/bb4f6294f04ab30c3474beba0ea0756f95f5c634))

## 0.1.0 (2025-07-25)


### Bug Fixes

* make methods public ([f6a30ba](https://github.com/erikmunkby/dbt-toolbox/commit/f6a30ba99b4502f7702275af7dd4251bb77b9b8f))
* **settings:** change toml lib to support python 3.10 ([6c38116](https://github.com/erikmunkby/dbt-toolbox/commit/6c38116656e042e9ac81fc46b235a544a8e78841))


### Documentation

* fix incorrect readme ([a05bc7b](https://github.com/erikmunkby/dbt-toolbox/commit/a05bc7be5090b3f92165f6f21b7b89fd1989afbb))
