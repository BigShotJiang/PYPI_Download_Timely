.. SPDX-FileCopyrightText: 2021-2024 Jeff Epler
..
.. SPDX-License-Identifier: GPL-3.0-only

wwvbpy |version|
================

.. mdinclude:: ../README.md

.. toctree::
   :maxdepth: 2
   :caption: Contents:

wwvb module
===========

.. automodule:: wwvb
   :members:

uwwvb module
============

.. automodule:: uwwvb
   :members:
