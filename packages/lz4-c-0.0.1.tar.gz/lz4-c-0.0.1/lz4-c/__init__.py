# Safe dummy package: lz4-c
