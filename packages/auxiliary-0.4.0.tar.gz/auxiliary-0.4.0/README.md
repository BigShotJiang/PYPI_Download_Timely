[![PyPI version panoptica](https://badge.fury.io/py/auxiliary.svg)](https://pypi.python.org/pypi/auxiliary/)
[![Documentation Status](https://readthedocs.org/projects/auxiliary/badge/?version=latest)](http://auxiliary.readthedocs.io/?badge=latest)
[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)

# auxiliary

TODO

## Installation

### PyPi

```sh
pip install auxiliary
```

### Conda

```sh
conda install conda-forge::auxiliary
```

## deploy

### build

```
python -m build
poetry build
```

### upload to pypi

```
twine upload dist/*
```
