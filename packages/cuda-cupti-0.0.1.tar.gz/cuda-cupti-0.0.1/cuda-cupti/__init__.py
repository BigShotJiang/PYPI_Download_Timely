# Safe dummy package: cuda-cupti
