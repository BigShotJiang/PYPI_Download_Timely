# cuda-cupti
This is a safe dummy PoC package.