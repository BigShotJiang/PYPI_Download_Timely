import runpy

runpy.run_module("openmarkets.__main__", run_name="__main__", alter_sys=True)
