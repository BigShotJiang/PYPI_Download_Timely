# Converter

Un petit package Python pour convertir un montant selon un taux fixe.

## Installation

```bash
pip install convert-aram

convert-currrency
