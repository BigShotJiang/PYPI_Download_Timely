"""Diffsync Definitions for SSoT Network Integration."""
