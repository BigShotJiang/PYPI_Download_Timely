wann2J.py --posfile abinit.in --efermi 6.15 --kmesh 5 5 5 --elements Mn --prefix_up abinito_w90_up --prefix_down abinito_w90_down 
