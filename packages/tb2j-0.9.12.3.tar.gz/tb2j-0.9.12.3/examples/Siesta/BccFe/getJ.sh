#!/usr/bin/env bash
siesta2J.py --fdf_fname siesta.fdf --elements Fe --kmesh 9 9 9  --nz 100 --emax -0.005
