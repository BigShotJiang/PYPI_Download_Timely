from TB2J.plot import plot_magnon_band

plot_magnon_band(fname="exchange.xml", npoints=400, knames="GNPGHN", show=True)
