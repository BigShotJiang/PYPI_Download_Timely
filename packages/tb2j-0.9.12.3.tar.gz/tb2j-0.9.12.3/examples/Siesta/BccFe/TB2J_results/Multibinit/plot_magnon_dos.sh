TB2J_magnon_dos.py --show -s 10 -k 25 25 25 -f magnon_dos.png --show
