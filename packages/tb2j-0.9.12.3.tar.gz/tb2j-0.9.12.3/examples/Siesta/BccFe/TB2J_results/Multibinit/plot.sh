TB2J_magnon.py --qpath GNPGHN --show
