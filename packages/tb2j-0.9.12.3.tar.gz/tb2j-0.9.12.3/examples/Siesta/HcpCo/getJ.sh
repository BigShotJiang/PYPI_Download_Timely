siesta2J.py --fdf_fname siesta.fdf --elements Co 
