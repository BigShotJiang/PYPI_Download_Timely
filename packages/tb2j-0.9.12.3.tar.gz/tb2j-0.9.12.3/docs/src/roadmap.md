### Roadmap of TB2J

#### Features to be implemented
- [ ] Magnon band structure for non-FM structures.
- [ ] Downfolding of ligand-contribution in non-collinear case.
- [ ] Generalize the merge method.
- [ ] Spin-lattice coupling.
- [ ] Single-ion anisotropy.
