## Development

Note: This page is currently under development.

This tutorial gives a few guidelines on how to develop in TB2J. 

We hope to make TB2J easily accessible to developers.  





### Code 

#### Writting documenation

The documents are in the directory docs, and written in markdown and restructed text (rst) format. 

In the docs/index.rst, the main page of the documentation and the links to the table of contents in the sidebar are defined.  

In the docs/src, each topic is written in a rst or md file. 

