"""This is a django app for providing content management system functionality."""
