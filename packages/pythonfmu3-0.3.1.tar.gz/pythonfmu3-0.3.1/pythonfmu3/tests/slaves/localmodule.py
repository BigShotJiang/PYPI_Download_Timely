

def get_amplitude():
    return 5.


def get_time_constant():
    return 0.1
