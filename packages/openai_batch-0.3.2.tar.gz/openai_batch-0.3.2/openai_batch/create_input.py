"""
Backwards compatibility module for create_batch_input
"""

from .create_batch_input import *

if __name__ == "__main__":
    main()
