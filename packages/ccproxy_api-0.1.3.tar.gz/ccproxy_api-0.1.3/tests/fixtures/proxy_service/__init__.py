"""Proxy Service testing fixtures.

This module provides fixtures for testing ProxyService integration through various mocking strategies.
Includes both internal service mocks and OAuth-related HTTP mocks.
"""
