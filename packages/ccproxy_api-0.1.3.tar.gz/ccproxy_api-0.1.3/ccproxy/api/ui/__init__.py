"""UI components for CCProxy API."""

from .terminal_permission_handler import TerminalPermissionHandler


__all__ = ["TerminalPermissionHandler"]
