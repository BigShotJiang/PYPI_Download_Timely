python -m pysmarthashtag.cli status
