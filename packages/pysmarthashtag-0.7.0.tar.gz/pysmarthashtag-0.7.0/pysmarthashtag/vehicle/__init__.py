"""Methods and classes around the vehicle."""

from .vehicle import SmartVehicle  # noqa: F401
