"""Library to read data from the Smart API."""

from importlib.metadata import version

__version__ = version("pySmartHashtag")
