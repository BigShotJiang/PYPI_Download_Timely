"""Connection to the Smart API."""
