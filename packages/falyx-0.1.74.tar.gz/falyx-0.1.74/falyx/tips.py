from falyx.themes import OneColors

tips = [
    "Tip: '{program}[#E5C07B]?[KEY][/]' to preview a command "
]