.. _libdoc_graph_op:

===========================================
:mod:`op` -- Objects that define operations
===========================================

.. automodule:: pytensor.graph.op
   :members:
