(libdoc_xtensor_linalg)=
# `xtensor.linalg` -- Linear algebra operations

```{eval-rst}
.. automodule:: pytensor.xtensor.linalg
   :members:
```
