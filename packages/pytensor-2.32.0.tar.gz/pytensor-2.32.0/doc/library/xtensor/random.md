(libdoc_xtensor_random)=
# `xtensor.random` Random number generator operations

```{eval-rst}
.. automodule:: pytensor.xtensor.random
   :members:
```
