========================================================
:mod:`tensor.optimize` -- Symbolic Optimization Routines
========================================================

.. module:: tensor.conv
   :platform: Unix, Windows
   :synopsis: Symbolic Optimization Routines
.. moduleauthor:: LISA, PyMC Developers, PyTensor Developers

.. automodule:: pytensor.tensor.optimize
    :members:
