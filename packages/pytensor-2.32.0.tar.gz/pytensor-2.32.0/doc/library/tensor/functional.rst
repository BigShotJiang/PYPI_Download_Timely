.. automodule:: pytensor.tensor.functional
    :members: vectorize
