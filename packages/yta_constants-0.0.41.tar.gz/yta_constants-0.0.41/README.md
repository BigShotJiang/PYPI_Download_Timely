# Youtube Autonomous general Constants add-on

The way to store all the enums and constants in one place only.