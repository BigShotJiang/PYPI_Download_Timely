from abc import ABC

from .onefun import Onefun


class Smoothfun(Onefun, ABC):
    pass
