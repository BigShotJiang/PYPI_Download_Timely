from .classicfun import Classicfun


class Bndfun(Classicfun):
    """Class to approximate functions on bounded intervals [a,b]"""

    pass
