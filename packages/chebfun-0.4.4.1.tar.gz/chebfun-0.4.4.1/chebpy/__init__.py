__version__ = "0.4.3.3"

from .api import chebfun, pwc
from .core.settings import ChebPreferences as UserPreferences
