ALL_DATA = {
    "haste_time_reduction": {
        90: {"6.55": {"MNK": 0.2}},
        100: {"6.55": {"MNK": 0.2}, "7.0": {"MNK": 0.2, "NIN": 0.15}},
    },
    "auto_attack_delay_reduction": {
        90: {"6.55": {"MNK": 0.2}},
        100: {"6.55": {"MNK": 0.2}, "7.0": {"MNK": 0.2, "NIN": 0.15}},
    },
}
