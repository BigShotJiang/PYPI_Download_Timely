#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (C) 2018-2025, earthobservations developers.
# Distributed under the MIT License. See LICENSE for more info.

# This is a shim to hopefully allow GitHub to detect the package.
# The build is done with Poetry.

import setuptools

if __name__ == "__main__":
    setuptools.setup(name="wetterdienst")
