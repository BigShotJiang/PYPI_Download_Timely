# Observation

## Overview

```{toctree}
:hidden:

hourly.md
daily.md
monthly.md
annual.md
```