# Geosphere

Previously: Zentralanstalt für Meteorologie und Geodynamik / Zentral Agency for Meteorology and Geodynamics

## Overview

## License

When using Geosphere data you need to give notice to them at your service.
Check out [Geosphere Nutzungsbedingungen](https://data.hub.zamg.ac.at/about) for further information.

```{toctree}
:hidden:

observation/index.md
```