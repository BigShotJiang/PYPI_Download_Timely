# WSV (Wasserstraßen- und Schifffahrtsverwaltung des Bundes)

## Overview

## License

The data provided by WSV is open and free to use. See the following urls for more information:

- [overview](https://www.pegelonline.wsv.de/webservice/ueberblick)
- [terms of use](https://www.pegelonline.wsv.de/gast/nutzungsbedingungen)
- [privacy policy](https://www.pegelonline.wsv.de/gast/datenschutzhinweise)
- [imprint](https://www.pegelonline.wsv.de/gast/impressum)

For further questions you may write a [mail](https://www.pegelonline.wsv.de/adminmail).

```{toctree}
:hidden:

pegel/index.md
```