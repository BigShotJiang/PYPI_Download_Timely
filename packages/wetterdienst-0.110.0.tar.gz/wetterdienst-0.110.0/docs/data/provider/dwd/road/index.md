# Road

## Overview

- weather data from German highway "road" stations.
- 15 minute resolution
- historical period

```{toctree}
:hidden:

15_minutes.md
```