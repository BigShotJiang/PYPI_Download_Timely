# License

```{include} ../LICENSE.md
:start-line: 1
:relative-docs: docs/
```

Cite us with

[![DOI](https://zenodo.org/badge/160953150.svg)](https://zenodo.org/badge/latestdoi/160953150)