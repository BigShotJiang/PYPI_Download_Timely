# Overview

```{include} ../README.md
:relative-docs: docs/
:start-line: 1
```

```{toctree}
:hidden:

data/index.md
usage/index.md
library/index.md
license.md
contribution/index.md
known_issues.md
changelog.md
```