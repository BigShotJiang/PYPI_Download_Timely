This is a list of the people who directly contributed to wetterdienst in one way or another.

* Benjamin Gutzmann ([github](https://github.com/gutzbenj), [mail](mailto:gutzemann@gmail.com))
* Andreas Motl ([github](https://github.com/amotl), [mail](mailto:andreas.motl@panodata.org))
* Daniel Lassahn ([github](https://github.com/meteoDaniel))
    - UI/Browser interface
    - Road Weather API
* Trevor James Smith ([github](https://github.com/Zeitsperre))
    - Contribution of Environment and Climate Change Canada adapter - Thanks!
* Niclas Hoyer ([github](https://github.com/niclashoyer))
    - Change mosmix parser to xml stream events
* Nico Neumann ([github](https://github.com/neumann-nico))
    - Added interpolation feature
    - Improved testing
