#!/usr/bin/env python3
import sys

from eof.cli import cli

sys.exit(cli())
