import importlib.metadata

from . import download, parsing  # noqa

__version__ = importlib.metadata.version("sentineleof")
