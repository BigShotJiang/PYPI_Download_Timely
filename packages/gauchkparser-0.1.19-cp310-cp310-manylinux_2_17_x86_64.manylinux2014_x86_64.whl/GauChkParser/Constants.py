Bohr2Ang = 0.529177249
""" Bohr to Angstrom constant, the value used in Gaussian """

