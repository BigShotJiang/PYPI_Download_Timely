.. _meal_component-api:

Meal Component
==============

This module defines the ``MealComponent`` class, representing a single component within a larger meal.

.. automodule:: meal_generator.meal_component
   :members:
   :undoc-members:
   :show-inheritance: