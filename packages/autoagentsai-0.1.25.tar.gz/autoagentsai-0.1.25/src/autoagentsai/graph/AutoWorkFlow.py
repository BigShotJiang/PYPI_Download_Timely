class AutoWorkFlow:

    def __init__(self):
        pass


    def run(self,prompt,filePath,):
        pass