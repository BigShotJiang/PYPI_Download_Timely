# mulch/__init__.py

from .workspace_factory import WorkspaceFactory, load_scaffold

__all__ = ["WorkspaceFactory", "load_scaffold"]
