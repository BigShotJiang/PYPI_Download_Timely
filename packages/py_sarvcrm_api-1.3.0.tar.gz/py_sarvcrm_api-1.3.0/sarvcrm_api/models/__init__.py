from ._base import BaseModel


__all__ = [
    'BaseModel',
]