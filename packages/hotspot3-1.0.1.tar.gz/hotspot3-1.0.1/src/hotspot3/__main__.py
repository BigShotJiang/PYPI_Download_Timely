from hotspot3.cli import main as start_main

if __name__ == '__main__':
    start_main()