"""Storage module initialization."""
