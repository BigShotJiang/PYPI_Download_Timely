# Author:
#         Bill Sousa
#
# License: BSD 3 clause
#



from ._is_classifier import is_classifier



__all__ = [
    'is_classifier',
]









