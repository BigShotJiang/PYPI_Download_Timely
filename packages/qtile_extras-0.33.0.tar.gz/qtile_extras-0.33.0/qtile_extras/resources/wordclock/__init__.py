LANGUAGES = sorted(["english", "french", "spanish", "portuguese", "dutch", "swedish", "finnish"])
