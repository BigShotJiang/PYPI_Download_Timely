"""
Visualization package for CARLA driving simulator.
"""
