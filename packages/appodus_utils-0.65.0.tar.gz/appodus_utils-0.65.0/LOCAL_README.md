## ENV
* PYPI_API_TOKEN: pypi-AgEIcHlwaS5vcmcCJDdkMjAwNWYwLTE1MzItNDhkNi1hZDU3LWQ1MDBhODVlZDRhMgACKlszLCJhMTYwODJiZi1iY2I1LTQ4ZWEtOTA5ZC1iMTQ1ODJlMTI4MDIiXQAABiADRpgacGrGEKj3-zONLOI1D_jNaye2l4jaH5YQK6gFxA

## COMMIT, TAG, and PUSH
* git add .
* git commit -m "Add feature XYZ and prepare for release"
* git tag v0.3.0 -m "Release version 0.3.0"
* git push origin main
* git push origin v0.3.0


## Cred
[pypi]
 * username = __token__
 * password = PYPI_API_TOKEN