Homer CLI
=========

.. argparse::
   :module: homer.cli
   :func: argument_parser
   :prog: homer
