Homer |release| documentation
=============================

Configuration manager for network devices.

.. toctree::
   :maxdepth: 3

   introduction
   configuration
   homer
   api/index

.. toctree::
   :maxdepth: 2

   release


Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
