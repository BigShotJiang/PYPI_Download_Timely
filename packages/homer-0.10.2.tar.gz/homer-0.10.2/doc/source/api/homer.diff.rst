diff
====

.. automodule:: homer.diff
