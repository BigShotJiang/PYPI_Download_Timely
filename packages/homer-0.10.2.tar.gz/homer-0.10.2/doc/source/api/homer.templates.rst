templates
=========

.. automodule:: homer.templates
