"""Transports module."""
DEFAULT_TIMEOUT = 30
"""Default timeout in seconds to use when interacting with the devices."""
DEFAULT_PORT = 22
"""Default port to use when interacting with the devices."""
