# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from .simple import SimpleDetector
from .spectrum import SpectrumDetector
from .period_detect import period_detection
