Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/fakerequests_simpletest.py
    :caption: examples/fakerequests_simpletest.py
    :linenos:

Advanced I2C test
-----------------

Uses the fakerequests capabilities to create a small I2C temperature sensors database, and
look for the correct one.I

.. literalinclude:: ../examples/fakerequests_advancedtest.py
    :caption: examples/fakerequests_advancedtest.py
    :linenos:
