

API Reference
#############

.. automodule:: adafruit_fakerequests
   :members:
