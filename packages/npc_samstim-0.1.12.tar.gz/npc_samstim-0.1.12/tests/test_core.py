import npc_samstim


def test_import_package():
    pass
