"""
Configuration management for zmp-knowledge-store-mcp-server

Handles environment variables and application settings
"""

import os


class Config:
    """Configuration management for the knowledge store"""

    # Server configuration
    SERVER_NAME = "zmp-knowledge-store-mcp-server"
    SERVER_VERSION = "1.0.0"
    SERVER_HOST = os.getenv("HOST", "0.0.0.0")
    SERVER_PORT = int(os.getenv("PORT", "5371"))

    # ChromaDB configuration
    CHROMA_HOST = os.getenv("CHROMADB_HOST", "chroma-chromadb.aiops.svc.cluster.local")
    CHROMA_PORT = int(os.getenv("CHROMADB_PORT", "8000"))
    CHROMA_TOKEN = os.getenv("CHROMADB_TOKEN")
    CLUSTER_MODE = os.getenv("ZMP_CLUSTER_MODE", "true").lower() == "true"

    # Qdrant configuration
    QDRANT_HOST = os.getenv("QDRANT_HOST", "localhost")
    QDRANT_PORT_RAW = os.getenv("QDRANT_PORT", "6333")
    # Handle case where QDRANT_PORT might be a full URL like "tcp://172.20.231.180:6333"
    if "://" in QDRANT_PORT_RAW:
        # Extract port from URL like "tcp://172.20.231.180:6333"
        QDRANT_PORT = int(QDRANT_PORT_RAW.split(":")[-1])
    else:
        QDRANT_PORT = int(QDRANT_PORT_RAW)
    QDRANT_API_KEY = os.getenv("QDRANT_API_KEY")
    QDRANT_URL = os.getenv("QDRANT_URL", f"http://{QDRANT_HOST}:{QDRANT_PORT}")

    # Collection configuration
    DOCUMENT_COLLECTION = os.getenv("DOCUMENT_COLLECTION", "solution-docs")
    CHAT_HISTORY_COLLECTION = os.getenv("CHAT_HISTORY_COLLECTION", "chat-history")
    CHROMA_TENANT = os.getenv("CHROMA_TENANT", "zmp")
    CHROMA_DATABASE = os.getenv("CHROMA_DATABASE", "manual")
    COLLECTION = DOCUMENT_COLLECTION  # For backward compatibility

    # Supported values
    SOLUTIONS = ["zcp", "amdp", "apim"]

    # Search configuration
    DEFAULT_RESULTS = 5
    MAX_RESULTS = 20

    # Logging configuration
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()

    @classmethod
    def validate(cls) -> bool:
        """Validate required configuration"""
        if not cls.CHROMA_TOKEN:
            raise ValueError("CHROMA_TOKEN environment variable is required")
        return True

    @classmethod
    def get_chroma_config(cls) -> dict:
        """Get ChromaDB configuration"""
        return {
            "host": cls.CHROMA_HOST,
            "port": cls.CHROMA_PORT,
            "token": cls.CHROMA_TOKEN,
            "cluster_mode": cls.CLUSTER_MODE,
            "tenant": cls.CHROMA_TENANT,
            "database": cls.CHROMA_DATABASE,
            "collection": cls.COLLECTION,
        }

    @classmethod
    def get_server_config(cls) -> dict:
        """Get server configuration"""
        return {
            "name": cls.SERVER_NAME,
            "version": cls.SERVER_VERSION,
            "host": cls.SERVER_HOST,
            "port": cls.SERVER_PORT,
        }

    @classmethod
    def is_solution_valid(cls, solution: str) -> bool:
        """Check if solution is valid"""
        return solution.lower() in cls.SOLUTIONS
