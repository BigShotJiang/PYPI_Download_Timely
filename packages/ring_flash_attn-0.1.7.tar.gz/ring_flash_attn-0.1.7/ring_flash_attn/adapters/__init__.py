from .hf_adapter import (
    substitute_hf_flash_attn,
    update_ring_flash_attn_params,
)
