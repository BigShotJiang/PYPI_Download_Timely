# from fns import Fig, RandoPolicy, autoplay

# policy = RandoPolicy()
# g = autoplay(Fig(), policy)


def hello():
    print("Hello from World")