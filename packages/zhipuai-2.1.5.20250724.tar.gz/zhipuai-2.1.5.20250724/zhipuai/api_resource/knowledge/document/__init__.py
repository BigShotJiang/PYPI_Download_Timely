from .document import Document


__all__ = ['Document']