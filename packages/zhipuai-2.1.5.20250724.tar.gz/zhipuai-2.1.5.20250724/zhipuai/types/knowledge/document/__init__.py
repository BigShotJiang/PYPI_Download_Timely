
from .document import DocumentData, DocumentObject, DocumentSuccessinfo, DocumentFailedInfo


__all__ = [
    "DocumentData",
    "DocumentObject",
    "DocumentSuccessinfo",
    "DocumentFailedInfo",
]