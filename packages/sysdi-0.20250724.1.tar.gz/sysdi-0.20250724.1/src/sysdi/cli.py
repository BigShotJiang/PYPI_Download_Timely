def main():
    print('Hello from', __name__)
