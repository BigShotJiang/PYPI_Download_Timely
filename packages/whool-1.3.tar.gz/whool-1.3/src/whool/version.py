from .compat import importlib_metadata

version = importlib_metadata.version("whool")
