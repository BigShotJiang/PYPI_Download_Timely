bayesianbandits.LaplaceApproximator
===================================

.. currentmodule:: bayesianbandits

.. autoclass:: LaplaceApproximator

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~LaplaceApproximator.__init__
      ~LaplaceApproximator.update_posterior
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~LaplaceApproximator.n_iter
      ~LaplaceApproximator.tol
   
   