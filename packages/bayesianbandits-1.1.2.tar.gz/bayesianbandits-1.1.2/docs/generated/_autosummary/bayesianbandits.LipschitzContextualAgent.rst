bayesianbandits.LipschitzContextualAgent
========================================

.. currentmodule:: bayesianbandits

.. autoclass:: LipschitzContextualAgent

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~LipschitzContextualAgent.__init__
      ~LipschitzContextualAgent.add_arm
      ~LipschitzContextualAgent.arm
      ~LipschitzContextualAgent.decay
      ~LipschitzContextualAgent.pull
      ~LipschitzContextualAgent.remove_arm
      ~LipschitzContextualAgent.select_for_update
      ~LipschitzContextualAgent.update
   
   

   
   
   