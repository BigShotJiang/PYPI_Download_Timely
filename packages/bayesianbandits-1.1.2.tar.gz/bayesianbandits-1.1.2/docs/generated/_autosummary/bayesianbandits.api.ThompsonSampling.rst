bayesianbandits.api.ThompsonSampling
====================================

.. currentmodule:: bayesianbandits.api

.. autoclass:: ThompsonSampling

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ThompsonSampling.__init__
      ~ThompsonSampling.select
      ~ThompsonSampling.update
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~ThompsonSampling.samples_needed
   
   