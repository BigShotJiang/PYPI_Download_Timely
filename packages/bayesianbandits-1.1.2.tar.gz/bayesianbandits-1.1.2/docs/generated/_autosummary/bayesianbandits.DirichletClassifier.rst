bayesianbandits.DirichletClassifier
===================================

.. currentmodule:: bayesianbandits

.. autoclass:: DirichletClassifier

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~DirichletClassifier.__init__
      ~DirichletClassifier.decay
      ~DirichletClassifier.fit
      ~DirichletClassifier.get_metadata_routing
      ~DirichletClassifier.get_params
      ~DirichletClassifier.partial_fit
      ~DirichletClassifier.predict
      ~DirichletClassifier.predict_proba
      ~DirichletClassifier.sample
      ~DirichletClassifier.score
      ~DirichletClassifier.set_fit_request
      ~DirichletClassifier.set_params
      ~DirichletClassifier.set_partial_fit_request
      ~DirichletClassifier.set_score_request
   
   

   
   
   