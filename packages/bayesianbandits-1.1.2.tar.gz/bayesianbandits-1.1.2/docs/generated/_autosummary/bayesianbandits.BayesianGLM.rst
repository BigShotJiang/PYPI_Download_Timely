bayesianbandits.BayesianGLM
===========================

.. currentmodule:: bayesianbandits

.. autoclass:: BayesianGLM

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~BayesianGLM.__init__
      ~BayesianGLM.decay
      ~BayesianGLM.fit
      ~BayesianGLM.get_metadata_routing
      ~BayesianGLM.get_params
      ~BayesianGLM.partial_fit
      ~BayesianGLM.predict
      ~BayesianGLM.sample
      ~BayesianGLM.score
      ~BayesianGLM.set_fit_request
      ~BayesianGLM.set_params
      ~BayesianGLM.set_partial_fit_request
      ~BayesianGLM.set_score_request
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~BayesianGLM.cov_
   
   