bayesianbandits.GammaRegressor
==============================

.. currentmodule:: bayesianbandits

.. autoclass:: GammaRegressor

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GammaRegressor.__init__
      ~GammaRegressor.decay
      ~GammaRegressor.fit
      ~GammaRegressor.get_metadata_routing
      ~GammaRegressor.get_params
      ~GammaRegressor.partial_fit
      ~GammaRegressor.predict
      ~GammaRegressor.sample
      ~GammaRegressor.score
      ~GammaRegressor.set_fit_request
      ~GammaRegressor.set_params
      ~GammaRegressor.set_partial_fit_request
      ~GammaRegressor.set_score_request
   
   

   
   
   