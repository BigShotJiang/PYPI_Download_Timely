bayesianbandits.LearnerPipeline
===============================

.. currentmodule:: bayesianbandits

.. autoclass:: LearnerPipeline

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~LearnerPipeline.__init__
      ~LearnerPipeline.decay
      ~LearnerPipeline.partial_fit
      ~LearnerPipeline.predict
      ~LearnerPipeline.sample
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~LearnerPipeline.learner
      ~LearnerPipeline.named_steps
      ~LearnerPipeline.random_state
   
   