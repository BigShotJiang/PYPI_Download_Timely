bayesianbandits.ContextualAgent
===============================

.. currentmodule:: bayesianbandits

.. autoclass:: ContextualAgent

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ContextualAgent.__init__
      ~ContextualAgent.add_arm
      ~ContextualAgent.arm
      ~ContextualAgent.decay
      ~ContextualAgent.pull
      ~ContextualAgent.remove_arm
      ~ContextualAgent.select_for_update
      ~ContextualAgent.update
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~ContextualAgent.arms
   
   