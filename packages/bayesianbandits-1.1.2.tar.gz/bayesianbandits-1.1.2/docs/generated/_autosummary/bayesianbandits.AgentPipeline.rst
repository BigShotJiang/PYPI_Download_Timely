bayesianbandits.AgentPipeline
=============================

.. currentmodule:: bayesianbandits

.. autofunction:: AgentPipeline