============
Installation
============

Python 3.10+ is required.

Install with pip::

    pip install -U bayesianbandits