== PaaSTA FSM Template

This is a [cookiecutter](http://cookiecutter.readthedocs.io/en/latest/index.html) style
template to make it easier for you to create new services in PaaSTA.

Use the `paasta fsm` tool to read this template.

Only a very basic template is provided here.
