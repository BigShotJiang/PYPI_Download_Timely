# your_package/__init__.py
from .module import greet
