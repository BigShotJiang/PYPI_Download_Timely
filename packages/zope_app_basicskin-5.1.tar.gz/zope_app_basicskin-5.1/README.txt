A very simple skin for the original Zope 3 ZMI.
