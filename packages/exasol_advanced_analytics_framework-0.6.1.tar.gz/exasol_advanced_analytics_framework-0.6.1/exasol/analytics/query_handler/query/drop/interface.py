from exasol.analytics.query_handler.query.interface import Query


class DropQuery(Query):
    pass
