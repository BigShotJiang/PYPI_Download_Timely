import dataclasses


@dataclasses.dataclass(frozen=True)
class Parameter:
    pass
