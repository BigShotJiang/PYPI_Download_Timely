from exasol.analytics.query_handler.graph.execution_graph import ExecutionGraph
from exasol.analytics.query_handler.graph.stage.stage import Stage

StageGraph = ExecutionGraph[Stage]
