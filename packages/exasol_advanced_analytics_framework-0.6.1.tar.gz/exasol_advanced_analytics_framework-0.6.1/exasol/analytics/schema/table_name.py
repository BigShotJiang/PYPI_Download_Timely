from exasol.analytics.schema.table_like_name import TableLikeName


class TableName(TableLikeName):
    """A DBObjectName class which represents the name of a Table"""
