from exasol.analytics.schema.dbobject_name_with_schema import DBObjectNameWithSchema


class UDFName(DBObjectNameWithSchema):
    """A DBObjectName class which represents the name of a UDF"""
