from exasol.analytics.schema.exasol_identifier import ExasolIdentifier


class DBObjectName(ExasolIdentifier):
    """Abstract calls which represents the name of a DBObject"""
