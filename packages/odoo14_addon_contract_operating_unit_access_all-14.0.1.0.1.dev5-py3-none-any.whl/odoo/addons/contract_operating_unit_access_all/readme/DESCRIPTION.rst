This module allow a user to have Access all OUs' contract,
without having to add OUs in user setting.
