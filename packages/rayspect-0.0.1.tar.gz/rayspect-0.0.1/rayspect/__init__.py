# Placeholder module for the RaySpect project
__version__ = "0.0.1"
