STEPS = [
    "sample",
    "convert",
    "starsolo",
    "kb_python",
    "cells",
    "analysis",
]
__ASSAY__ = "mobiu"

REMOVE_FROM_MULTI = {
    "cells",
}
