from celescope.mobiu.__init__ import __ASSAY__
from celescope.tools.multi import Multi


class Multi_mobiu(Multi):
    """
    ## Usage
    ```
        multi_rna\\
        --mapfile ./rna.mapfile\\
        --genomeDir /SGRNJ/Public/Database/genome/homo_mus\\
        --thread 8\\
        --mod shell
    ```
    Work for both single cell RNA-Seq and single nuclei RNA-Seq.
    """

    def get_5p3p_fq(self, sample):
        arr = self.fq_dict[sample]
        arr["fq1_3p"] = []
        arr["fq2_3p"] = []
        arr["fq1_5p"] = []
        arr["fq2_5p"] = []
        for fq1, fq2, col4 in zip(arr["fq1"], arr["fq2"], arr["col4"]):
            if col4 not in ("5p", "3p"):
                raise Exception(
                    f"ERROR: The 4th column of mapfile must be 3p or 5p. But {col4} found."
                )
            arr[f"fq1_{col4}"].append(fq1)
            arr[f"fq2_{col4}"].append(fq2)
        return arr

    def convert(self, sample):
        step = "convert"
        arr = self.get_5p3p_fq(sample)
        cmd_line = self.get_cmd_line(step, sample)
        fq1_5p = ",".join(arr["fq1_5p"])
        fq1_3p = ",".join(arr["fq1_3p"])
        fq2_5p = ",".join(arr["fq2_5p"])
        fq2_3p = ",".join(arr["fq2_3p"])
        cmd = (
            f"{cmd_line} "
            f"--fq1_5p {fq1_5p} --fq1_3p {fq1_3p} "
            f"--fq2_5p {fq2_5p} --fq2_3p {fq2_3p} "
        )
        self.process_cmd(cmd, step, sample, m=self.args.starMem, x=1)

    def starsolo(self, sample):
        step = "starsolo"
        cmd_line = self.get_cmd_line(step, sample)
        p3_r1 = f'{self.outdir_dic[sample]["convert"]}/{sample}_3p_R1.fq.gz'
        p3_r2 = f'{self.outdir_dic[sample]["convert"]}/{sample}_3p_R2.fq.gz'
        p5_r1 = f'{self.outdir_dic[sample]["convert"]}/{sample}_5p_R1.fq.gz'
        p5_r2 = f'{self.outdir_dic[sample]["convert"]}/{sample}_5p_R2.fq.gz'
        cmd = f"{cmd_line} " f"--fq1 {p3_r1},{p5_r1} --fq2 {p3_r2},{p5_r2} "
        self.process_cmd(cmd, step, sample, m=self.args.starMem, x=self.args.thread)

    def kb_python(self, sample):
        step = "kb_python"
        cmd_line = self.get_cmd_line(step, sample)
        p3_r1 = f'{self.outdir_dic[sample]["convert"]}/{sample}_3p_R1.fq.gz'
        p3_r2 = f'{self.outdir_dic[sample]["convert"]}/{sample}_3p_R2.fq.gz'
        p5_r1 = f'{self.outdir_dic[sample]["convert"]}/{sample}_5p_R1.fq.gz'
        p5_r2 = f'{self.outdir_dic[sample]["convert"]}/{sample}_5p_R2.fq.gz'
        cmd = (
            f"{cmd_line} "
            f"--fq1 {p3_r1},{p5_r1} --fq2 {p3_r2},{p5_r2} "
            f"--barcodes_file {self.outdir_dic[sample]['outs']}/filtered/barcodes.tsv.gz "
        )
        self.process_cmd(cmd, step, sample, m=10, x=self.args.thread)

    def analysis(self, sample):
        step = "analysis"
        gene_matrix_file = f'{self.outdir_dic[sample]["outs"]}/filtered'
        transcript_matrix_file = (
            f'{self.outdir_dic[sample]["outs"]}/transcript.filtered'
        )
        cmd_line = self.get_cmd_line(step, sample)
        cmd = (
            f"{cmd_line} "
            f"--gene_matrix_file {gene_matrix_file} "
            f"--transcript_matrix_file {transcript_matrix_file} "
        )
        self.process_cmd(cmd, step, sample, m=10, x=1)


def main():
    multi = Multi_mobiu(__ASSAY__)
    multi.run()


if __name__ == "__main__":
    main()
