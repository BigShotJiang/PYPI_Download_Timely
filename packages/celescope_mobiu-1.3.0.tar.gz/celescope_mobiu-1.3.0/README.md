# Introduction
celescope-mobiu is a bioinfomatics analysis pipeline to process [MobiuSCOPE(3' + 5' scRNA-Seq)](https://singleron.bio/products/mobiuscope-full-length-single-cell-rna-sequencing-kit/) data.

# Documentation
[User guide](./doc/user_guide.md)

# Support
Please use the issue tracker for quesdions and malfunctions.



