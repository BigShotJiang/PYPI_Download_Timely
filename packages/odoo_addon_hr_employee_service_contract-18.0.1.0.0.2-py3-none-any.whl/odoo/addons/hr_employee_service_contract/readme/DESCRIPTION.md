This module computes employee service information based on employee's
contracts.
