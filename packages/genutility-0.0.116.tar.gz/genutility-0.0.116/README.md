# genutility

A collection of various Python utilities.

Requires Python 3.7+.
The last version which mostly worked with Python 2.7 was `0.0.59`.
The last version which mostly worked with Python 3.5 was `0.0.65`.
The last version which worked with Python 3.6 was `0.0.96`.

## Install
`pip install genutility`

## Notes

- currently requires `scipy<1.13` due to a incompatibility in `gensim`.
