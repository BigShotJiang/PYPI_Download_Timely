"""Use cases for sincpro_logger."""
