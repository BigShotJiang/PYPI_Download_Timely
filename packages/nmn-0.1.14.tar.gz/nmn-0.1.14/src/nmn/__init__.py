"""Neural-Matter Network (NMN) - beyond blinded neurons."""

__version__ = "0.1.0"
