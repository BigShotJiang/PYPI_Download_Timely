"""Map Engine init, holds version"""

__version__ = "3.0.1"
