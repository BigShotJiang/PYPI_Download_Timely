## usage

Generate config via configurator: https://configurator.yor.ovh/

```shell
pip install -g reline
reline -c config.json
```