# Changelog

## 3.2.0 (2025-07-24)

Full Changelog: [v3.1.0...v3.2.0](https://github.com/WorqHat/worqhat-python-sdk/compare/v3.1.0...v3.2.0)

### Features

* **api:** update via SDK Studio ([85ab7a2](https://github.com/WorqHat/worqhat-python-sdk/commit/85ab7a2e5c871ed5921ef6044c0f9926b939948d))
* **api:** update via SDK Studio ([1dca18a](https://github.com/WorqHat/worqhat-python-sdk/commit/1dca18acf452a7cc35c6e541d69b8a31ac90d29a))
* **api:** update via SDK Studio ([fbb6ab5](https://github.com/WorqHat/worqhat-python-sdk/commit/fbb6ab5d66c30d8ee3bd9328eab85304efd42614))


### Chores

* configure new SDK language ([c4d0258](https://github.com/WorqHat/worqhat-python-sdk/commit/c4d0258ea522088e0f6181228d1f04a64230b2d7))
* sync repo ([4766968](https://github.com/WorqHat/worqhat-python-sdk/commit/476696875aa8f142f588c4f016fa8110a0ec4e08))
* update SDK settings ([d605766](https://github.com/WorqHat/worqhat-python-sdk/commit/d605766da0d10451b716cbf715c96e6b4ccf90b9))
* update SDK settings ([29497ca](https://github.com/WorqHat/worqhat-python-sdk/commit/29497ca3d7fc8232a9b0cc0fb70cb963c4624b33))
* update SDK settings ([e386fb8](https://github.com/WorqHat/worqhat-python-sdk/commit/e386fb86761c1ef06bd99b5a85b2fd6710d17737))
* update SDK settings ([0dbf509](https://github.com/WorqHat/worqhat-python-sdk/commit/0dbf5097e700966f2546ea967d0669eae280dbb9))
* update SDK settings ([64384f2](https://github.com/WorqHat/worqhat-python-sdk/commit/64384f2c7f05b7a54d89881791857068c10f1250))
* update SDK settings ([6c05440](https://github.com/WorqHat/worqhat-python-sdk/commit/6c05440a6f753841abdac7153f9bc0cb7688f7d9))

## 3.1.0 (2025-07-24)

Full Changelog: [v3.1.0-alpha.3...v3.1.0](https://github.com/WorqHat/worqhat-python-sdk/compare/v3.1.0-alpha.3...v3.1.0)

## 3.1.0-alpha.3 (2025-07-24)

Full Changelog: [v3.1.0-alpha.2...v3.1.0-alpha.3](https://github.com/WorqHat/worqhat-python-sdk/compare/v3.1.0-alpha.2...v3.1.0-alpha.3)

## 3.1.0-alpha.2 (2025-07-24)

Full Changelog: [v3.1.0-alpha.1...v3.1.0-alpha.2](https://github.com/WorqHat/worqhat-python-sdk/compare/v3.1.0-alpha.1...v3.1.0-alpha.2)

### Features

* **api:** update via SDK Studio ([85ab7a2](https://github.com/WorqHat/worqhat-python-sdk/commit/85ab7a2e5c871ed5921ef6044c0f9926b939948d))

## 3.1.0-alpha.1 (2025-07-24)

Full Changelog: [v0.0.1-alpha.0...v3.1.0-alpha.1](https://github.com/WorqHat/worqhat-python-sdk/compare/v0.0.1-alpha.0...v3.1.0-alpha.1)

### Features

* **api:** update via SDK Studio ([1dca18a](https://github.com/WorqHat/worqhat-python-sdk/commit/1dca18acf452a7cc35c6e541d69b8a31ac90d29a))
* **api:** update via SDK Studio ([fbb6ab5](https://github.com/WorqHat/worqhat-python-sdk/commit/fbb6ab5d66c30d8ee3bd9328eab85304efd42614))


### Chores

* configure new SDK language ([c4d0258](https://github.com/WorqHat/worqhat-python-sdk/commit/c4d0258ea522088e0f6181228d1f04a64230b2d7))
* sync repo ([4766968](https://github.com/WorqHat/worqhat-python-sdk/commit/476696875aa8f142f588c4f016fa8110a0ec4e08))
* update SDK settings ([d605766](https://github.com/WorqHat/worqhat-python-sdk/commit/d605766da0d10451b716cbf715c96e6b4ccf90b9))
* update SDK settings ([29497ca](https://github.com/WorqHat/worqhat-python-sdk/commit/29497ca3d7fc8232a9b0cc0fb70cb963c4624b33))
* update SDK settings ([e386fb8](https://github.com/WorqHat/worqhat-python-sdk/commit/e386fb86761c1ef06bd99b5a85b2fd6710d17737))
* update SDK settings ([0dbf509](https://github.com/WorqHat/worqhat-python-sdk/commit/0dbf5097e700966f2546ea967d0669eae280dbb9))
* update SDK settings ([64384f2](https://github.com/WorqHat/worqhat-python-sdk/commit/64384f2c7f05b7a54d89881791857068c10f1250))
* update SDK settings ([6c05440](https://github.com/WorqHat/worqhat-python-sdk/commit/6c05440a6f753841abdac7153f9bc0cb7688f7d9))
