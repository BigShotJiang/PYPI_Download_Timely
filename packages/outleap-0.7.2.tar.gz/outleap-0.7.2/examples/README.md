# Examples

* [simple_leap_script.py](https://github.com/SaladDais/outleap/blob/master/examples/simple_leap_script.py)
* [complex_leap_script.py](https://github.com/SaladDais/outleap/blob/master/examples/complex_leap_script.py): A mish-mash of
  usages of different APIs. May be run either as a TCP daemon or as a typical LEAP script.
