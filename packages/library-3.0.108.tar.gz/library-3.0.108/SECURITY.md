# Coordinated Disclosure Form

## Reporting a Vulnerability

Please fill in this form: https://docs.google.com/forms/d/1KWf0RY6855_TDbbkin50d9riRFD3OIbVUBTNUr1KaAA/

If you choose to leave your email, expect a response in two weeks.
