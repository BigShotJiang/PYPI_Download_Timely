---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

**What is the problem that is being solved with the new feature?**



**Enumerate an unordered list of alternatives that you've thought about**



**If applicable, state your a preferred solution**
