# Copyright (c) 2013, 2018 National Technology and Engineering Solutions of Sandia, LLC . Under the terms of Contract
# DE-NA0003525 with National Technology and Engineering Solutions of Sandia, LLC, the U.S. Government
# retains certain rights in this software.

# Uploading a Dakota tabular file is available in the Slycat wizard, but has not yet
# been added to the Slypi tool.  If you want this functionality, let me know at
# smartin@sandia.gov.
