"""Main entry point for aceiot-models package."""


def main():
    """Entry point function for the aceiot-models package."""
    print("Hello from aceiot-models!")


if __name__ == "__main__":
    main()
