# ProgressStage


## Enum

* `StageInitializing` (value: `'initializing'`)

* `StageImporting` (value: `'importing'`)

* `StageDownloading` (value: `'downloading'`)

* `StageProcessing` (value: `'processing'`)

* `StageComplete` (value: `'complete'`)

* `StageError` (value: `'error'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


