# Filesystem reference

-----

::: dda.utils.fs.temp_directory

::: dda.utils.fs.Path
    options:
      show_bases: true
      show_if_no_docstring: false
