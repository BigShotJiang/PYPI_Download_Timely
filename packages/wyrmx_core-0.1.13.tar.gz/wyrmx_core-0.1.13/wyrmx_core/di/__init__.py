from wyrmx_core.di.scope import Scope
from wyrmx_core.di.container import Container