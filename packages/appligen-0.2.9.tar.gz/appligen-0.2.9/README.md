# appligen

Un générateur de base pour créer automatiquement des applications Django avec la structure standard (`models.py`, `views.py`, etc.).

## Installation

```bash
pip install appligen
python -m appligen.generator <nom_de_l_app>