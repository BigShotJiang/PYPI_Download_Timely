from flamapy_mcp import main

main()