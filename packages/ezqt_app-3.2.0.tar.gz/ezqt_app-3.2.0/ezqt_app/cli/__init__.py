# -*- coding: utf-8 -*-
# ///////////////////////////////////////////////////////////////

"""
EzQt_App CLI Package

Command-line interface for EzQt_App framework.
"""

from .main import cli

__all__ = ["cli"] 