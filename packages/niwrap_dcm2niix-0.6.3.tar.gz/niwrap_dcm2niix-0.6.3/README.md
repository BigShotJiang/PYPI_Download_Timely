# NiWrap wrappers for [dcm2niix](https://github.com/rordenlab/dcm2niix)

Chris Rorden's dcm2niiX - DICOM to NIfTI converter. Converts DICOM files to NIfTI format with optional BIDS sidecar generation.

dcm2niix is made by Chris Rorden.

This package contains wrappers only and has no affiliation with the original authors.
