#! /usr/bin/env python3
from testcloud import cli

cli.main()
