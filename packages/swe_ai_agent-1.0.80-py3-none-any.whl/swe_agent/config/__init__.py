"""
Configuration module for the SWE Agent system.
"""

from .settings import Settings

__all__ = ["Settings"]
