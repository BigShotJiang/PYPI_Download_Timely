"""
SWE Agent - Headless Agentic IDE
"""

__version__ = "1.0.50"
__author__ = "Harish SG"
__email__ = "harishsg993010@gmail.com"

from .main import main

__all__ = ["main"]