This file provides an overview of the package and usage examples. 
# Package 
`Package` is a simple Python package for Test. 
## Installation 
Install the package with pip: 
pip install Pacakge


from Package import ( 
add,sub,say_hello,mult
) 
# add 
print(add(5, 3))         
# Output: 8
print(sub(5, 3))    
# Output: 2
# say_hello 
print(say_hello("Amit"))   
# Output: Hello, Amit 
        
# mul 
print(mul(3,2))               
# Output: 6

# div
print(div(4,2))

# Output: 2

 