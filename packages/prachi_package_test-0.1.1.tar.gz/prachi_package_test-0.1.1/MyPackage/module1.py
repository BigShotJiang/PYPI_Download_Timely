def add(a,b):
    return f"sum of {a} and {b} is {a+b}"

def sub(a,b):
    return f"substraction of {a} and {b} is {a-b}"