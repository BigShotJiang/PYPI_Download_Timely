def test_add():
    assert 1 + 1 == 2
