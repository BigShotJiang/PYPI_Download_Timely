# Soia Python Client

Library imported from Python code generated from soia files.

Install with:
```shell
pip install soia-client
```

See:

*   [soia](https://github.com/gepheum/soia): home of the soia compiler
*   [soia-python-gen](https://github.com/gepheum/soia-python-gen): soia to Python code generator
*   [soia-python-example](https://github.com/gepheum/soia-python-example): example showing how to use soia's Python code generator in a project
