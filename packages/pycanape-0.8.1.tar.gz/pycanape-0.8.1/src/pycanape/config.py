from typing import Any, Final

RC: Final[dict[str, Any]] = {"ENCODING": "latin-1"}  # runtime config
