Module
------

.. autoclass:: pycanape.module.Module
    :members:
    :undoc-members:

.. autoclass:: pycanape.module.MeasurementListEntry
    :members:

.. autoclass:: pycanape.module.DatabaseInfo
    :members:
