Ecu Task
--------

.. autoclass:: pycanape.ecu_task.EcuTask
    :members:
    :undoc-members:

.. autoclass:: pycanape.ecu_task.Sample
    :members:
    :undoc-members:
