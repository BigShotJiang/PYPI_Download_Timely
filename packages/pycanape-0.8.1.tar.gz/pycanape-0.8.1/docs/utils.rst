Utils
-----

.. autoclass:: pycanape.utils.CANapeVersion
    :members:
    :undoc-members:

.. autofunction:: pycanape.utils.get_canape_versions
.. autofunction:: pycanape.utils.get_canape_path
.. autofunction:: pycanape.utils.get_canape_data_path
.. autofunction:: pycanape.utils.get_canape_dll_path
