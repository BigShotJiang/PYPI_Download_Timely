Recorder
--------

.. autoclass:: pycanape.recorder.Recorder
    :members:
    :undoc-members:
    :inherited-members:
