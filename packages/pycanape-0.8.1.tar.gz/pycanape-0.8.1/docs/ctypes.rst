Ctypes Wrapper
--------------

.. automodule:: pycanape.cnp_api.cnp_class
    :members:

.. automodule:: pycanape.cnp_api.cnp_constants
    :members:
    :undoc-members:

.. autoclass:: pycanape.cnp_api.cnp_prototype.CANapeDll
    :members:
    :undoc-members:
