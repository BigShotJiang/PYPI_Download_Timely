Exceptions
----------

.. autoexception:: pycanape.utils.CANapeError
    :members:
