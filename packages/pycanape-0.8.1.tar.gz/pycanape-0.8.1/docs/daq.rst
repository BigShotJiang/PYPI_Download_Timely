DAQ
---

.. autoclass:: pycanape.daq.FifoReader
    :members:
    :undoc-members:
