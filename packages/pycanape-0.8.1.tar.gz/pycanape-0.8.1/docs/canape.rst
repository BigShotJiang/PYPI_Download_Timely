CANape
------

.. autoclass:: pycanape.canape.CANape
    :members:
    :undoc-members:

.. autoclass:: pycanape.canape.AppVersion
    :members:

.. autoclass:: pycanape.canape.DllVersion
    :members:
