Script
------

.. autoclass:: pycanape.script.Script
    :members:
    :undoc-members:
