Calibration Objects
-------------------

.. autoclass:: pycanape.calibration_object.ScalarCalibrationObject
    :members:
    :undoc-members:
    :inherited-members:

.. autoclass:: pycanape.calibration_object.AxisCalibrationObject
    :members:
    :undoc-members:
    :inherited-members:

.. autoclass:: pycanape.calibration_object.CurveCalibrationObject
    :members:
    :undoc-members:
    :inherited-members:

.. autoclass:: pycanape.calibration_object.MapCalibrationObject
    :members:
    :undoc-members:
    :inherited-members:

.. autoclass:: pycanape.calibration_object.AsciiCalibrationObject
    :members:
    :undoc-members:
    :inherited-members:

.. autoclass:: pycanape.calibration_object.ValueBlockCalibrationObject
    :members:
    :undoc-members:
    :inherited-members:
