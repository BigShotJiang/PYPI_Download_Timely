This directory contains HuggingFace models produced by wrapping huggingface models for experimaestro IR.
