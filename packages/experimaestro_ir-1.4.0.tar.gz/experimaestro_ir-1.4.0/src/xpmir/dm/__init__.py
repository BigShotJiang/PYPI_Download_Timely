import datamaestro


class Repository(datamaestro.Repository):
    NAMESPACE = "ir"
    DESCRIPTION = "Information Retrieval repository"
