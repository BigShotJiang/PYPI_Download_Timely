from functools import cached_property as attrs_cached_property  # noqa: F401
from experimaestro.experiments import configuration, ConfigurationBase  # noqa: F401

# Renaming for compatibility
Experiment = ConfigurationBase
