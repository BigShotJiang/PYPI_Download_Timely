from experimaestro import deprecate
from .cross import CrossScorer


@deprecate
class JointClassifier(CrossScorer):
    pass
