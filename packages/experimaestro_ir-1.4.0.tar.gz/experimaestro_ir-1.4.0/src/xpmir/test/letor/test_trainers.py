def test_pointwise():
    # TODO: implement tests for trainers
    pass


def test_pairwise():
    # TODO: implement tests for trainers
    pass


def test_batchwise():
    # TODO: implement tests for trainers
    pass
