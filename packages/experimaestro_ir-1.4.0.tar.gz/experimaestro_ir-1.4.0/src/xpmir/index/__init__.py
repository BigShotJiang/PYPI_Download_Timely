from datamaestro_text.data.ir import AdhocIndex as Index
