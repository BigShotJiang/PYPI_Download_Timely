This directory contains the documentation for the experimaestro-IR library.

## Developping

You can use the `sphinx-reload` to have a livereload of documents.

```sh
sphinx-reload docs/
```
