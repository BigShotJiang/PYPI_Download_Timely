set -x
/usr/bin/sed -i -e '/SKIP_DOCBUILD/,$d' requirements.txt
