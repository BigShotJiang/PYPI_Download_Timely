Experimaestro-IR datasets
=========================

Beside the ir-datasets interface, Experimaestro-IR provides some datasets listed
below.


.. dm:repository:: ir
