Data
====

Experimaestro-IR extends datamaestro-text with new data *types*, *ir-datasets* collections
as well as its own datasets (e.g. hard negatives datasets).

.. toctree::
   :maxdepth: 2

   xpmir
   adapters
