Word vectors
============

.. autoxpmconfig:: xpmir.text.wordvec_vocab.WordvecVocab
.. autoxpmconfig:: xpmir.text.wordvec_vocab.WordvecHashVocab
.. autoxpmconfig:: xpmir.text.wordvec_vocab.WordvecUnkVocab
