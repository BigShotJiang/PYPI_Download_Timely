Alignment
*********

.. autoxpmconfig:: xpmir.letor.trainers.alignment.AlignmentLoss
.. autoxpmconfig:: xpmir.letor.trainers.alignment.AlignmentTrainer
.. autoxpmconfig:: xpmir.letor.trainers.alignment.MSEAlignmentLoss
.. autoxpmconfig:: xpmir.letor.trainers.alignment.CosineAlignmentLoss
