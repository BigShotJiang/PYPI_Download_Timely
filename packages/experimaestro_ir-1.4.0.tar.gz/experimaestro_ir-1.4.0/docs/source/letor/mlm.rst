Masked Language Model
*********************

Sampler
-------

.. autoxpmconfig:: xpmir.mlm.samplers.MLMSampler

Trainer
-------

.. autoxpmconfig:: xpmir.mlm.trainer.MLMTrainer

Losses
------

.. autoxpmconfig:: xpmir.mlm.trainer.MLMLoss
.. autoxpmconfig:: xpmir.mlm.trainer.CrossEntropyLoss
