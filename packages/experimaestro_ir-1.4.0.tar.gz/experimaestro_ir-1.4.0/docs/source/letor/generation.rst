Data Generation
===============

Synthetic topics
****************

.. autoxpmconfig:: xpmir.letor.samplers.synthetic.SyntheticQueryGeneration
