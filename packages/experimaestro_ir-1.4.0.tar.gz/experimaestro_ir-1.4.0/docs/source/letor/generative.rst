Generative
**********

The module ``xpmir.letor.trainers.generative`` contains trainers for
Generative neural IR models.


Losses
------

.. autoxpmconfig:: xpmir.letor.trainers.generative.PairwiseGenerativeLoss
