Command-Line Interface
======================


Running experiments
*******************

Experiments can be run using the ``run-experiment`` command.

HuggingFace
***********

Pre-loading a model into cache can be achieved using ``xpmir huggingface preload HF_ID``
