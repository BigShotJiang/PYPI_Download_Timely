.. autoxpmconfig:: xpmir.utils.convert.Converter
.. autoxpmconfig:: xpmir.misc.IDList
.. autoxpmconfig:: xpmir.misc.FileIDList