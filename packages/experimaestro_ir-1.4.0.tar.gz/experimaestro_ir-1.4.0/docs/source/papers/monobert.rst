monoBERT
========

Reproduction of monoBERT

    Passage Re-ranking with BERT (Rodrigo Nogueira, Kyunghyun Cho). 2019.
    https://arxiv.org/abs/1901.04085

It relies on the pipeline class :py:class:`xpmir.papers.helpers.msmarco.RerankerMSMarcoV1Experiment`

.. literalinclude:: ../../../src/xpmir/papers/monobert/experiment.py
