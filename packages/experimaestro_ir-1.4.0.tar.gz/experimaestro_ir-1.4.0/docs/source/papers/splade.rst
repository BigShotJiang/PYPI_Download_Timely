SPLADE
======

Reproduction of

    SPLADE v2: Sparse Lexical and Expansion Model for Information Retrieval
    (Thibault Formal, Carlos Lassance, Benjamin Piwowarski, Stéphane Clinchant).
    2021. https://arxiv.org/abs/2205.04733

.. literalinclude:: ../../../src/xpmir/papers/splade/experiment.py
