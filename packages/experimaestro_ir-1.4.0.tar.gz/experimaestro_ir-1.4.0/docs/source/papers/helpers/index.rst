Generic helpers
===============

.. currentmodule:: xpmir.experiments.helpers

.. autoclass:: PaperExperiment
    :members:

.. autoclass:: NeuralIRExperiment
    :members:

.. autoclass:: LauncherSpecification
    :members:
