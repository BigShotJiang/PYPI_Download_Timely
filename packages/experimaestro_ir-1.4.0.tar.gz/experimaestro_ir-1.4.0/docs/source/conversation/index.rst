Conversation
============


Learning
--------

.. autoxpmconfig:: xpmir.conversation.learning.DatasetConversationEntrySampler
.. autoxpmconfig:: xpmir.conversation.learning.reformulation.ConversationRepresentationEncoder
.. autoxpmconfig:: xpmir.conversation.learning.reformulation.DecontextualizedQueryConverter


.. autoxpmconfig:: xpmir.conversation.learning.DatasetConversationBase
.. autoxpmconfig:: xpmir.conversation.learning.DatasetConversationIterator

CoSPLADE
--------

.. autoxpmconfig:: xpmir.conversation.models.cosplade.AsymetricMSEContextualizedRepresentationLoss
.. autoxpmconfig:: xpmir.conversation.models.cosplade.CoSPLADE
