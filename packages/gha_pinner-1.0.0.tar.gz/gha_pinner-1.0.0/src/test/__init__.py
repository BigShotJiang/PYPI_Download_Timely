"""
Test package for gha-pinner.
"""
