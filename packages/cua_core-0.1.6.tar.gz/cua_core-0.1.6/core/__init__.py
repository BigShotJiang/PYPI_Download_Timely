"""Core functionality shared across Cua components."""

__version__ = "0.1.0"
