* Admin: In Debug Mode, Go to Settings->Technical->Email->Templates
* User: Create an email message and save as a template.
* You only see the Email of your operating units.
* It is assigned to your default operating unit.
