from shared_kernel.registries.service_event_registry import ServiceEventRegistry # noqa
