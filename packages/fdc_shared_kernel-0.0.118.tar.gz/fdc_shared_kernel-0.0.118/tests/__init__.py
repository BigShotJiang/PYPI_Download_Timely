"""
Test package for shared_kernel.
""" 