# License

Typed Settings is released under the [MIT] license:

```{literalinclude} ../LICENSE
:language: none
```

[mit]: https://choosealicense.com/licenses/mit/
