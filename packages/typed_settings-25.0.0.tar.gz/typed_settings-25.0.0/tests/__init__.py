"""
Tests for Typed Settings.
"""
