fn main() {
    println!("cargo:rustc-link-lib=python3.13");
    println!("cargo:rustc-link-search=/usr/lib");
}
