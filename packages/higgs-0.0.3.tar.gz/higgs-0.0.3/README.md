## higgs
install via pip/pip3
```
pip install higgs
```