from .data import GraphDataset

__all__ = ["GraphDataset"]
