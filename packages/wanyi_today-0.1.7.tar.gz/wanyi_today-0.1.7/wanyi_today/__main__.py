"""
允许使用 python -m wanyi_today 运行包
"""

from .main import main

if __name__ == "__main__":
    main()