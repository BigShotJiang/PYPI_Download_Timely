SELECT max(:version_column) AS :version_column FROM :schema_name.:table_name;
