ALTER TABLE data_update ADD COLUMN :column_name :column_type;
