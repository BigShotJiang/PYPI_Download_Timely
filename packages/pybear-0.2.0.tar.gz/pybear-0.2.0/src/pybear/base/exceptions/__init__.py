# Author:
#         Bill Sousa
#
# License: BSD 3 clause
#


from ._exceptions import NotFittedError




__all__ = [
    "NotFittedError"
]












