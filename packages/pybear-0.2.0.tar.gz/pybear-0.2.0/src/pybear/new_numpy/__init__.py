# Author:
#         Bill Sousa
#
# License: BSD 3 clause
#



from pybear.new_numpy import random



__all__ = [
    "random"
]




