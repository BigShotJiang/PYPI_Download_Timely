# Author:
#         Bill Sousa
#
# License: BSD 3 clause
#



from pybear.feature_extraction.text import Lexicon



if __name__ == '__main__':

    _words = [

    ]


    Lexicon().add_words(_words)















