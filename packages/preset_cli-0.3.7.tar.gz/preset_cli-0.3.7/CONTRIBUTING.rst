
============
Contributing
============

The ``preset-cli`` project is an all-rights-reserved project. If you would like
to contribute to the project, and you are not a member of the core development team
or a contributor with write access to the repository, you will be given the option 
to sign a Contributor License Agreement (CLA) when you submit any pull requests.

Issue Reports
=============

If you experience bugs or general issues with ``preset-cli``, please report them in the
`Preset Support Portal <https://preset.atlassian.net/servicedesk/customer/portal/1/group/1/create/1>`_.
