"""
Demo functions.
"""


def hello_world() -> str:
    """
    Simple demo function.
    """
    return "Hello, world!"
