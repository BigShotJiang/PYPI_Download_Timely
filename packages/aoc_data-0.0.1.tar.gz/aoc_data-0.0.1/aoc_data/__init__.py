"""Real data to test your Advent of Code solutions."""
