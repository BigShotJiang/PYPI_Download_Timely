"""Storage module for K8s-Gen DSL."""

from .config_map import ConfigMap

__all__ = ["ConfigMap"] 