from .sentence_splitter import init

__all__ = ("init",)
