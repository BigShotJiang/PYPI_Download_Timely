:orphan:

.. currentmodule:: weasyprint


Description
-----------

.. autofunction:: weasyprint.__main__.main(argv=sys.argv)
   :noindex:


About
-----

.. include:: ../README.rst
