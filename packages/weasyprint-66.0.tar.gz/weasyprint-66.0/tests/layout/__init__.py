"""Tests for layout.

Includes positioning and dimensioning of boxes, line breaks, page breaks.

"""
