"""Common helpers module for Core."""
