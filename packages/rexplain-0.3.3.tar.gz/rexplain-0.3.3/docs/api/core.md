# Core Modules

## Explainer Module

::: rexplain.core.explainer
    handler: python
    options:
      show_source: true
      show_root_heading: true

## Generator Module

::: rexplain.core.generator
    handler: python
    options:
      show_source: true
      show_root_heading: true

## Parser Module

::: rexplain.core.parser
    handler: python
    options:
      show_source: true
      show_root_heading: true

## Tester Module

::: rexplain.core.tester
    handler: python
    options:
      show_source: true
      show_root_heading: true 