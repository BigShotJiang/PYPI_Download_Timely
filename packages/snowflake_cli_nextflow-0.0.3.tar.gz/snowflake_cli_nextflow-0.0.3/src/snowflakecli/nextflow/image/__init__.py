# Nextflow image management module 
