"""Tests for SIA Alarm package."""
