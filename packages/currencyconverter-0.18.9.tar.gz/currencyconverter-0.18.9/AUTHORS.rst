
+ Alex Prengère (original author)
+ Jochem Oosterveen (S3 support)
+ Greg Pascale (missing rate fallback)
