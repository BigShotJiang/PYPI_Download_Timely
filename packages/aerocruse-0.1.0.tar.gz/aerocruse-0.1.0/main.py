def main():
    print("Hello from aerocruse!")


if __name__ == "__main__":
    main()
