from .rss import CollectorRSS  # noqa: F401
