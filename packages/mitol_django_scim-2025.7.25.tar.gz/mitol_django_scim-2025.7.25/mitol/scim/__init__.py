"""mitol.scim"""

default_app_config = "mitol.scim.apps.ScimApp"

__version__ = "2025.7.25"
__distributionname__ = "mitol-django-scim"
