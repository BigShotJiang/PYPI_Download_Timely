VERSION = '0.0.79'
PACKAGE_NAME = 'azureml-designer-pytorch-modules'
DESCRIPTION = 'Modules to train and inference image processing models ' \
              'based on pytorch framework.'
