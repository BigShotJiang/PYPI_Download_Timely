lammpskit.ecellmodel.read\_displacement\_data
=============================================

.. currentmodule:: lammpskit.ecellmodel

.. autofunction:: read_displacement_data