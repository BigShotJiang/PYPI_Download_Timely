lammpskit.io.read\_structure\_info
==================================

.. currentmodule:: lammpskit.io

.. autofunction:: read_structure_info