lammpskit.plotting.TimeSeriesPlotConfig
=======================================

.. currentmodule:: lammpskit.plotting

.. autoclass:: TimeSeriesPlotConfig

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TimeSeriesPlotConfig.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TimeSeriesPlotConfig.alpha
      ~TimeSeriesPlotConfig.fontsize_labels
      ~TimeSeriesPlotConfig.fontsize_legend
      ~TimeSeriesPlotConfig.fontsize_ticks
      ~TimeSeriesPlotConfig.fontsize_title
      ~TimeSeriesPlotConfig.format
      ~TimeSeriesPlotConfig.include_line
      ~TimeSeriesPlotConfig.include_scatter
      ~TimeSeriesPlotConfig.linewidth
      ~TimeSeriesPlotConfig.marker
      ~TimeSeriesPlotConfig.markersize
   
   