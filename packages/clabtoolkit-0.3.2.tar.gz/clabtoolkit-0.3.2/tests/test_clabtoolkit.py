#!/usr/bin/env python

"""Tests for `clabtoolkit` package."""


import unittest

from clabtoolkit import clabtoolkit


class TestClabtoolkit(unittest.TestCase):
    """Tests for `clabtoolkit` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
