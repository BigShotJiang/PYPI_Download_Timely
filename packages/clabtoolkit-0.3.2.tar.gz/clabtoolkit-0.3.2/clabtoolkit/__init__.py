"""Top-level package for Connectomics Lab Toolkit."""

__author__ = """Yasser Alemán-Gómez"""
__email__ = "yasseraleman@protonmail.com"
__version__ = "0.3.1"
