__version__ = '0.1.1'


def get_version() -> str:
    return __version__


__all__ = [
    'get_version',
]