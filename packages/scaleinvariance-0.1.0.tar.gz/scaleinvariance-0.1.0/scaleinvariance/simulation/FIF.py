def fractionally_integrated_flux(n_points, alpha, **kwargs):
    raise NotImplementedError