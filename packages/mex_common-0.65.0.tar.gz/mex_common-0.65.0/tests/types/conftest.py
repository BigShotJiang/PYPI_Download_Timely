from pathlib import Path

TESTDATA_DIR = Path(__file__).parent / "test_data"
