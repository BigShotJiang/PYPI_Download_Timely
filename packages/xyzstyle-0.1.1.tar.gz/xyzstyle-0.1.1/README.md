# xyzstyle

[![PyPI][pypi-badge]][pypi-link]
[![GitHub issues][issue-badge]][issue-link]
[![GitHub forks][fork-badge]][fork-link]
[![GitHub stars][star-badge]][star-link]
[![GitHub license][license-badge]][license-link]
[![contributors][contributor-badge]][contributor-link]
[![watcher][watcher-badge]][watcher-link]
[![Binder][binder-badge]][binder-link]
[![Downloads][download-badge]][download-link]
[![Documentation Status][status-badge]][status-link]
[![PyPI - Downloads][install-badge]][install-link]
![repo size](https://img.shields.io/github/repo-size/xinetzone/xyzstyle.svg)
[![Downloads Week](https://pepy.tech/badge/xyzstyle/week)](https://pepy.tech/project/xyzstyle)

学无止境！

[pypi-badge]: https://img.shields.io/pypi/v/xyzstyle.svg
[pypi-link]: https://pypi.org/project/xyzstyle/
[issue-badge]: https://img.shields.io/github/issues/xinetzone/xyzstyle
[issue-link]: https://github.com/xinetzone/xyzstyle/issues
[fork-badge]: https://img.shields.io/github/forks/xinetzone/xyzstyle
[fork-link]: https://github.com/xinetzone/xyzstyle/network
[star-badge]: https://img.shields.io/github/stars/xinetzone/xyzstyle
[star-link]: https://github.com/xinetzone/xyzstyle/stargazers
[license-badge]: https://img.shields.io/github/license/xinetzone/xyzstyle
[license-link]: https://github.com/xinetzone/xyzstyle/LICENSE
[contributor-badge]: https://img.shields.io/github/contributors/xinetzone/xyzstyle
[contributor-link]: https://github.com/xinetzone/xyzstyle/contributors
[watcher-badge]: https://img.shields.io/github/watchers/xinetzone/xyzstyle
[watcher-link]: https://github.com/xinetzone/xyzstyle/watchers
[binder-badge]: https://mybinder.org/badge_logo.svg
[binder-link]: https://mybinder.org/v2/gh/xinetzone/xyzstyle/main
[install-badge]: https://img.shields.io/pypi/dw/xyzstyle?label=pypi%20installs
[install-link]: https://pypistats.org/packages/xyzstyle
[status-badge]: https://readthedocs.org/projects/xyzstyle/badge/?version=latest
[status-link]: https://xyzstyle.readthedocs.io/zh-cn/latest/?badge=latest
[download-badge]: https://pepy.tech/badge/xyzstyle
[download-link]: https://pepy.tech/project/xyzstyle

## 支持 PyPI

需要安装 `xyzstyle` 包：

```shell
pip install xyzstyle
```
