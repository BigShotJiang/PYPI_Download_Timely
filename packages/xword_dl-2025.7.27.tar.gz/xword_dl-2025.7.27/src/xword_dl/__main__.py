from . import xword_dl

xword_dl.main()
