"""Harina v3 CLI - Receipt OCR package."""

__version__ = "3.1.0"