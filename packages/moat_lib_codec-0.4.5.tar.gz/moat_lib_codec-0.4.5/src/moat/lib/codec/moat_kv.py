"""
Alias for moat-kv legacy
"""

from __future__ import annotations
from moat.util.msgpack import Codec  # noqa:F401
