"""fown 패키지 초기화"""

__version__ = "0.1.9"
