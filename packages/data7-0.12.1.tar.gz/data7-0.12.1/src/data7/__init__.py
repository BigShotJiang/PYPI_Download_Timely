"""Data7 root module."""

from . import config

__all__ = ["config"]
