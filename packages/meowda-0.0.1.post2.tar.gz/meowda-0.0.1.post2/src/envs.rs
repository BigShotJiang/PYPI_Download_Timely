pub struct EnvVars;

impl EnvVars {
    pub const MEOWDA_VENV_DIR: &'static str = "MEOWDA_VENV_DIR";
}
