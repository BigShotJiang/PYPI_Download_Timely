"""Version information for folder2md4llms."""

__version__ = "0.4.40"
__version_tuple__ = (0, 4, 40)
