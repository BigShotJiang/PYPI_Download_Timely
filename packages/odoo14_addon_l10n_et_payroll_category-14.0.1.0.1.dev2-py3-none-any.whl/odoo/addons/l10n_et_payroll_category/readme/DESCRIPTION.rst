This module defines various payroll categories useful for Ethiopia.
