from .playdice import Dice, main
