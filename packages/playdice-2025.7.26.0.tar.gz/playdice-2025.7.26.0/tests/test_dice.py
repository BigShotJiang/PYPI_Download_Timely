#!/usr/bin/env --split-string=python -m pytest --verbose

import pytest

from playdice import Dice

class TestCaseDice_01:

    def test_import_works(self):

        # The statement is above...
        pass
