# License

```{literalinclude} ../LICENSE.txt
:language: text
```
