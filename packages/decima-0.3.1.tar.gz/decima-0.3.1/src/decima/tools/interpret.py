def find_attr_peaks(attr, tss_pos=None, n=5, min_dist=6):
    raise DeprecationWarning("This function is deprecated. Use Attribution.peaks instead.")


def scan_attributions(seq, attr, motifs, peaks, names=None, pthresh=1e-3, rc=True, window=18):
    raise DeprecationWarning("This function is deprecated. Use Attribution.scan_motifs instead.")
