DROP TABLE gqlite_uids;
DROP TABLE gqlite_labels;
