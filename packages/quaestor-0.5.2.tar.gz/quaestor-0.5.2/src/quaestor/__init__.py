"""Quaestor - AI-assisted development context management."""

__version__ = "0.5.2"
