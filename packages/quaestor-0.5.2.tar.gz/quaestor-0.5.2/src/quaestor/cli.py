"""Main CLI entry point - delegates to modular structure."""

from quaestor.cli.main import app

__all__ = ["app"]
