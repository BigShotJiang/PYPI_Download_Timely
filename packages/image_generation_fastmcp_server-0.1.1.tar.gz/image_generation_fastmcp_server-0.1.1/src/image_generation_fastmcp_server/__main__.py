from image_generation_fastmcp_server import main

main()