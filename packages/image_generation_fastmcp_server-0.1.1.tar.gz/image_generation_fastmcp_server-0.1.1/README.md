# mcp server for image generation
`maked by fastmcp`

## function
- image_generation(str: image_prompt) -> str:
    - prompt: your generation prompt
    - return: url