"""Generated Protocol Buffer code.

This module contains the generated Python code from the protocol buffer definitions. The files in this directory are auto-generated and should not be
edited manually.

Run 'make proto' to regenerate these files from the .proto definitions.
"""
