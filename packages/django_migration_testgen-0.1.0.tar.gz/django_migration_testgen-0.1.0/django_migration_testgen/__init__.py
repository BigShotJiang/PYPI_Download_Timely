"""
Django Migration Test Generator

Auto-generate test files for Django migration files.
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

default_app_config = 'django_migration_testgen.apps.DjangoMigrationTestgenConfig'
