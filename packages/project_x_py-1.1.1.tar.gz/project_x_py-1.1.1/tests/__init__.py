"""
Tests for the ProjectX Python client.

This package contains unit tests, integration tests, and test utilities
for the project_x_py package.
"""
