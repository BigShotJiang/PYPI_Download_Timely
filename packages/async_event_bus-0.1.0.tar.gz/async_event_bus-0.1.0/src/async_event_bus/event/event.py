from enum import Enum


class Event(Enum):
    pass

