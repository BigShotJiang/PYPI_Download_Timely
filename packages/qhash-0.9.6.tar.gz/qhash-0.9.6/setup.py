import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from setuptools import setup, find_packages
from pathlib import Path

# Read the contents of your README file
this_directory = Path(__file__).parent
long_discription = (this_directory / "README.md").read_text()

setup(
    name="qhash",
    version="0.9.4",
    packages=find_packages(),
    install_requires=["pandas"],
    author="Sardar",
    author_email="sbapan41@gmail.com",
    description="This is the qhash test version",
    long_description=long_discription,
    long_description_content_type="text/markdown",
    license="Apache",
    project_urls={"Source Repository": "https://github.com/MotoBwi/qhash"},
)
