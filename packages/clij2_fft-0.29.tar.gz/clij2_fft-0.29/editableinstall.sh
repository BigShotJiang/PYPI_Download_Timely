bash copylibsconda.sh

#!/bin/bash
pip install -e .
bash copylibsconda.sh
