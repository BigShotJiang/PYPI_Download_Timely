from clij2fft.libs import getlib

lib = getlib()

lib.print_platforms_and_devices()
