#ifndef _UTILS_H_
#define _UTILS_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

void print_uchar(FILE *fp, uint8_t *data, size_t len);

#endif