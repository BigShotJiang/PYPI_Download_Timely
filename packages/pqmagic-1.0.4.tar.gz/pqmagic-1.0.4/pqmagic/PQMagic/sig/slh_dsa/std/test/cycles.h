#ifndef SPX_CYCLES_H
#define SPX_CYCLES_H

void init_cpucycles(void);
unsigned long long cpucycles(void);

#endif
