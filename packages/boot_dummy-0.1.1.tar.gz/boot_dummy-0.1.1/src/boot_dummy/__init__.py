"""
Dummy data generator.

Creates a DataFrame with fake data.
"""

from .dummy import GenerateData

__version__ = "0.1.1"
__all__ = ["GenerateData"]
