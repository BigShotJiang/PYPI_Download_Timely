# boot-dummy
A python package to create dummy data. 

List of resources that I _heavily_ borrowed from to create this package.
* Real Python Publish Package https://realpython.com/pypi-publish-python-package/#get-to-know-python-packaging
* Data Camp Generate Data https://www.datacamp.com/tutorial/synthetic-data-generation
