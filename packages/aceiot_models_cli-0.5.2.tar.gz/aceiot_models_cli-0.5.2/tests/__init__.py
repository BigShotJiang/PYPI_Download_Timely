"""Test suite for aceiot-models-cli."""
