"""REPL module for aceiot-models-cli."""

from .core_new import AceIoTRepl

__all__ = ["AceIoTRepl"]
