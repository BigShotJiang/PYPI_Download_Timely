from .xwarning import warn, configure  # optional shortcut exports
