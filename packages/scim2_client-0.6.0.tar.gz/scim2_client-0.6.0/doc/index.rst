.. include:: ../README.md
   :parser: myst_parser.parsers.docutils_


Table of contents
-----------------

.. toctree::
    :maxdepth: 2

    tutorial
    reference
    contributing
    changelog
