# TRIZ AI package
