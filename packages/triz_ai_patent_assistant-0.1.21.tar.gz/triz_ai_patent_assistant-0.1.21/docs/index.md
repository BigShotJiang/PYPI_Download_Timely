# TRIZ‑AI Patent Assistant

Добро пожаловать в документацию проекта.
