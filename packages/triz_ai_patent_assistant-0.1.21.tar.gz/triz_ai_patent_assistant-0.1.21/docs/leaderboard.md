| Dataset | Author | Lang | Avg time (ms) | Avg dup_rate (%) | Date |
|-------|-------|------|--------------|-----------------|------|
|sample_ru.txt|maintainer|ru|0.69|38.9|2025-07-26|
|sample_ru.txt|CI|ru|0.10|2.8|2025-07-26|
