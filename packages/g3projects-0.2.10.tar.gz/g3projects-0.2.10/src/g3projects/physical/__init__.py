from ._physical import generate_physical_files


__all__ = ['generate_physical_files']
