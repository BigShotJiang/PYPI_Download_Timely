from ._logical import generate_logical_files


__all__ = ['generate_logical_files']
