# List of tool modules to be loaded dynamically
tool_list = ["local_transfer"]
# Enable these for debugging and testing
# tool_list = tool_list + ["check_platform_status", "debug"]
