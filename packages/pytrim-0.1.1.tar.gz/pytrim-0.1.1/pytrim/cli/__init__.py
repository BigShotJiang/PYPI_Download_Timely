"""Command line interface for PyTrim."""

from .cli import main

__all__ = ["main"]
