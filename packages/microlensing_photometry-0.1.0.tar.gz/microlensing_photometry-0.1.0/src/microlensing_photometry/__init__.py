from .example_module import greetings, meaning

__all__ = ["greetings", "meaning"]
