# -*- coding:utf-8 -*-
# Auth: denishuang

default_app_config = 'xyz_restful.apps.Config'


# autodiscover()
