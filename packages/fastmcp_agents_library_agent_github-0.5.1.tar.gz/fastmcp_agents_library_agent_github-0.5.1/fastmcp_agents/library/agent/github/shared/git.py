def get_repo_url(owner: str, repository: str) -> str:
    return f"https://github.com/{owner}/{repository}.git"
