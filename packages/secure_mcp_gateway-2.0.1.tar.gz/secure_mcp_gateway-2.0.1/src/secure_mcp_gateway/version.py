"""
Version of the Enkrypt Secure MCP Gateway package
"""

__version__ = "2.0.1"
