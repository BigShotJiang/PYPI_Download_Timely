# HTMLRunner

A simple Python package to instantly serve a local HTML file and open it in your browser.

## Installation

```bash
pip install htmlrunner
