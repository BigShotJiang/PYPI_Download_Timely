# data-sharing-between-pages

from dataclasses import dataclass
import cst_ui as ui
import flet as ft

app = ui.App(route_init="/send-data")


@dataclass
class Test:
    name: int
    version: str


# 1
@app.page("/send-data", title="send data", share_data=True)
def send_data_page(data: ui.DataAdmin):
    page = data.page

    data.share.set("test", Test("Flet-Easy", "0.2.0"))
    data.share.set("owner", "Daxexs")

    return ft.View(
        controls=[
            ft.Text(f"data keys: {data.share.get_keys()}"),
            ft.Text(f"data values: {data.share.get_values()}"),
            ft.Text(f"data dict: {data.share.get_all()}"),
            ft.ElevatedButton("View shared data", on_click=data.go("/data")),
        ],
        vertical_alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
    )


# 2
@app.page("/data", title="data", share_data=True)
def get_data_page(data: ui.DataAdmin):
    page = data.page

    # It is checked if there is data stored in the dictionary (data.share.set).
    if data.share.contains():
        x: Test = data.share.get("test")
        y: str = data.share.get("owner")
        res = ft.Text(f"Name: {x.name}\nVersion: {x.version}\n-----\nOwner: {y}")
    else:
        res = ft.Text("No value passed on the page!.")

    return ft.View(
        controls=[
            ft.Container(content=res, padding=20, border_radius=20, bgcolor=ft.Colors.BLACK26),
            ft.ElevatedButton("Check the following page for matched data", on_click=data.go("/info")),
        ],
        vertical_alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
    )


# 3
@app.page("/info", title="Information")
def info_page(data: ui.DataAdmin):
    page = data.page

    # It is checked if there is data stored in the dictionary (data.share.set).
    if data.share.contains():
        x: Test = data.share.get("test")
        y: str = data.share.get("owner")
        res = ft.Text(f"Name: {x.name}\nVersion: {x.version}\n-----\nOwner: {y}")
    else:
        res = ft.Text("No value passed on the page!.")

    return ft.View(
        controls=[
            ft.Text("Access to shared data?"),
            ft.Container(content=res, padding=20, border_radius=20, bgcolor=ft.Colors.BLACK26),
        ],
        vertical_alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
    )


app.run(view=ft.AppView.WEB_BROWSER)
