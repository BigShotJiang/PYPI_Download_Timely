VALID_METRIC_SYSTEM_UNITS = ["nm", "um", "mm", "cm", "m", "km", "Mm", "Gm", "Tm"]
