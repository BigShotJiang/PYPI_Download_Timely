"""NOTE: this module was moved to fonttools, it is kept here only for backward
compatibility. Please import it from the new location.
"""

from fontTools.otlLib.maxContextCalc import maxCtxFont

__all__ = ["maxCtxFont"]
