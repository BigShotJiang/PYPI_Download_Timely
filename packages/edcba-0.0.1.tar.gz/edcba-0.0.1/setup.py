from setuptools import setup, find_packages

setup(
    name="edcba",
    version="0.0.1",
    author="Your Name",
    author_email="your.email@example.com",
    description="EDCBA",
    long_description="'edcba' on PyPI.",
    long_description_content_type="text/plain",
    packages=find_packages(),
    python_requires=">=3.6",
    classifiers=[
        "Development Status :: 1 - Planning",
        "Programming Language :: Python :: 3",
    ],
)
