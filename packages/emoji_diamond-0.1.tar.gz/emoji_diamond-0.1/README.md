# Emoji Diamond Generator 💎

A Python class that prints colorful emoji diamonds.

## Usage

```python
from shape import Shape

star = Shape(5)
star.diamond()



## 🧪 Want to Later Upload to PyPI?

> Let me know after this and I’ll walk you through that too. For now, let’s focus on getting your GitHub project ready.


## 🔧 Need Help on Your Phone?

> If you’re doing this on your phone, let me know the app you use (e.g. GitHub app, Termux, Pydroid) so I can give you phone-friendly instructions.


> Would you like me to help write your `README.md` too?
