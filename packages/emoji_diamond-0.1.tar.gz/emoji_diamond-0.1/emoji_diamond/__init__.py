from .stars import Shape
