from .getter import get_worldbank_data, get_export, get_import,get_pib

__version__ = "1.0.0"
__author__ = "Jnanfack"