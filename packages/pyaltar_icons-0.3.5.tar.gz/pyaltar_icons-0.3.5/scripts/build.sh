rm -r dist
uv build
