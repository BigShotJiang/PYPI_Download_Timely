# Altar Icons

Beautiful & consistent icon toolkit made for Aether apps.