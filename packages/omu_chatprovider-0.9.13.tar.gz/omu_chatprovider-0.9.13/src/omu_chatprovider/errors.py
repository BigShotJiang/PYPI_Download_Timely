class ProviderError(Exception):
    """Base class for provider errors."""

    pass
