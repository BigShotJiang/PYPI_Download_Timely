from .chatprovider import omu

if __name__ == "__main__":
    omu.run()
