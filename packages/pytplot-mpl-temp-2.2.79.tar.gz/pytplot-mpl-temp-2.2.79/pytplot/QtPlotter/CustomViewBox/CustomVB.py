import pyqtgraph as pg


class CustomVB(pg.ViewBox):

    def mouseDragEvent(self, ev, axis=None):
        return
