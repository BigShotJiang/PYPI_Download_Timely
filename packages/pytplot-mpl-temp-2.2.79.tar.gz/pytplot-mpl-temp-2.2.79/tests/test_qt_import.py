import pytplot

# disabled by egrimes
# re-enable to test the Qt version
# def test_qt_import():
#     assert pytplot.using_graphics == True