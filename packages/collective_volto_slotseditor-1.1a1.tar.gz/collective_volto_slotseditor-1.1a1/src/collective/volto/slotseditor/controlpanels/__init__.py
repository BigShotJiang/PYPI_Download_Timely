from .slotseditor.controlpanel import (
    ICollectiveVoltoSlotsEditorControlPanel as ICollectiveVoltoSlotsEditorControlPanel,
)
