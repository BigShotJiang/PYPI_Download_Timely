================
collective.volto.slotseditor
================

User documentation
