::: xmllib.Resource
    options:
        members_order: source
