==========================================
Examples
==========================================

annofabcliを使った利用事例などを紹介します。


.. toctree::
   :maxdepth: 1
   :titlesonly:

   http_private_storage
   edit_annotation




