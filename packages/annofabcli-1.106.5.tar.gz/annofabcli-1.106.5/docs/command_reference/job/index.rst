==================================================
job
==================================================

Description
=================================
ジョブ関係のコマンドです。


Available Commands
=================================


.. toctree::
   :maxdepth: 1
   :titlesonly:

   delete
   list
   list_last
   wait

Usage Details
=================================

.. argparse::
   :ref: annofabcli.job.subcommand_job.add_parser
   :prog: annofabcli job
   :nosubcommands:
