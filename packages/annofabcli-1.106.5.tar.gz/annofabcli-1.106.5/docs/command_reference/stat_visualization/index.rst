==================================================
stat_visualization
==================================================

Description
=================================
``annofabcli statistics visualization`` コマンドの出力結果を利用するコマンドです。

``stat_visualization`` はアルファ版です。予告なく変更される場合があります。


Available Commands
=================================


.. toctree::
    :maxdepth: 1
    :titlesonly:

    mask_user_info
    merge
    summarize_whole_performance_csv
    write_performance_rating_csv
    write_graph

Usage Details
=================================

.. argparse::
   :ref: annofabcli.stat_visualization.subcommand_stat_visualization.add_parser
   :prog: annofabcli stat_visualization
   :nosubcommands:
