# mcping_nonebot2
[mcping](https://github.com/Coloryr/McPing)与nonebot2通信插件  

该插件装在nonebot2上