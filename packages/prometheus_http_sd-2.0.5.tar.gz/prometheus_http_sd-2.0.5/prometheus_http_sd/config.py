class Config:
    root_dir: str

    def __init__(self) -> None:
        self.root_dir = ""


config = Config
