"""Test suite for sdmxabs package."""
