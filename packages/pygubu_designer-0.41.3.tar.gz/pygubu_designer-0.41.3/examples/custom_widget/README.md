# Custom Widget Example

Simple app that shows howto use a custom widget with pygubu-designer.

Before you open the timerapp.ui file with pygubu-designer, you need to register
the builder. Open pygubu-designer go to Edit > Preferences > Custom Widgets
and add the module timerappwidgets.py to the custom widget builders panel.

The full process is explained [here](https://github.com/alejandroautalan/pygubu-designer/wiki/Design-Reuse)
