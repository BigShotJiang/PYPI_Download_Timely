# Pygubu simple tooltip example

Shows pygubu simpletooltip usage in designer.

File simpletooltips.ui uses Application template.
Entry point is demoapp.py

File simpletooltips_script.ui uses Code Script template.
Entry point is framescript.py


Requires pygubu-designer 0.41 or above.
