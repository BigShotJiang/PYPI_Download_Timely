# Hello world

Minimal tkinter app. A toplevel and label with "hello world" text.
