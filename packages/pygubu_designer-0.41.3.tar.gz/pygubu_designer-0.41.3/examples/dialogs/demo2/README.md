# Pygubu Dialog Example

Dialog example that simulates data loading with "update" tk function.
