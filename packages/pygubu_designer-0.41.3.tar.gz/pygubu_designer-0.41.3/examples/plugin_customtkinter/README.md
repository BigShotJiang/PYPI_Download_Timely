# CustomTkinter

This folder contains the default CustomTkinter
[examples](https://github.com/TomSchimansky/CustomTkinter/tree/master/examples)
created with pygubu-designer.
