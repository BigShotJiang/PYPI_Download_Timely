# EditableTreeview example with "connected" editors

A demo to show howto edit a line with custom "connected" editors.
