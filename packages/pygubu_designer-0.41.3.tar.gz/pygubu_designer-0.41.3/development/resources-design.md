resources:
  - image (name, filename, format, data)
  - font:
      family
      size
      modifiers
  - tkvariable:
        type
        value
  - OptionSet
      OptionDatabase:
            pattern
            value
            priority
            type?(string, image, color, dimension))
