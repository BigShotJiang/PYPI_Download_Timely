"""
Agent compilation and validation tests.

Tests for TypeScript agent compilation, JavaScript validation,
and agent functionality verification.
"""