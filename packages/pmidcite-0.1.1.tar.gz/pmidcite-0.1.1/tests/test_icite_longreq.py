#!/usr/bin/env python3
"""TBD: Test long request to https://icite.od.nih.gov/api/pubs"""


def test_icite_longreq():
    """TBD: Test long request to https://icite.od.nih.gov/api/pubs"""
    pmid = 17717599
    ## die


if __name__ == '__main__':
    test_icite_longreq()

# Copyright (C) 2021-present, DV Klopfenstein, PhD. All rights reserved.
