"""Download PubMed counts using the Entrez E-Utils"""
