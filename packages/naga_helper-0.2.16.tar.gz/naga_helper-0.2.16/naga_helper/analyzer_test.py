collected_testcases = [
    'https://naga.dmv.nico/htmls/dc0ec66517e3839933a81a53bd5b1fa7eec84fc390298a927cfd73957ca33eecv2_2.html',
    # 多个加杠杠材的情况
    'https://naga.dmv.nico/htmls/37148e0bfc81f8afdc48f8e093e19de427b3370202237c29fb17a387c5bcbb2fv2_2.html',  # 暗杠
    'https://naga.dmv.nico/htmls/de371e0a506d36aa8771d686f55ef651c1748514695c43acdbfdc194d8974befv2_2.html',
    # # 多个鸣牌判断，且都超过pass
    # [
    #     'https://naga.dmv.nico/htmls/40bc84247d1262b66ce3dd7d2ccb445bde6e08cdb5b7f7fd945101e1526f541av2_2.html',
    #     {'4.0': '823fe5d7f242a212'}
    # ],  # 七对听牌bug
    # [
    #     'https://naga.dmv.nico/htmls/4e3f9348ccbce5558e9218c80496e95f0e60cfca86496173fa4411d4bbb7700av2_2.html',
    #     {'4.0': 'd0d1e7dfcf6cf2c4'}
    # ],  # 鸣牌 a > b > pass
    # [
    #     'https://naga.dmv.nico/htmls/e2963d5dd109b8217acc1216fefb4c67f76412e1ca6012a4384da5f1243a9b65v2_2.html',
    #     {
    #         '4.0': 'e6f2773610ce0793',
    #         '4.1a': '007656314e52c514',
    #         '4.1b': '07001152cfc1e568',
    #         '4.1c': 'f56c8f3ceebda93e',
    #     }
    # ],  # 多个绑定
    [
        'https://naga.dmv.nico/htmls/03a30932f00f66758ff831cecdfaa29a4ffbe2010d17ec2c8568da6eb4efb607v2_2.html',
        {
            # '4.1a': ['c83fece607b02454'],
            '4.1a': ['c83fece607b02454', '1d81094e82eb40c9', 'c346776000e9b9e8', '571ae40287d93ee4'],
        }
    ]  # 单Mortal多视角
]
