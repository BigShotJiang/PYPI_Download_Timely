# -*- coding: utf-8 -*-

from .parallel import parallel_forgetting_attn

__all__ = [
    'parallel_forgetting_attn'
]
