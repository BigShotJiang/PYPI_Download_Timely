'''Database storing data for exclusive processes and more.'''

from gpddatabase.ExclusiveDatabase import ExclusiveDatabase
