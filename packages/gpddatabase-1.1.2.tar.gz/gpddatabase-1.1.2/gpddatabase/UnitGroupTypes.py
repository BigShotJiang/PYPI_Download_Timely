from gpddatabase.GenericTypes import GenericTypes

class UnitGroupTypes(GenericTypes):

	'''Class stroring unit group types.'''
