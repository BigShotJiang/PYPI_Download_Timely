from django.contrib import admin
from django.contrib import admin
from .models import Tache

admin.site.register(Tache)

# Register your models here.
