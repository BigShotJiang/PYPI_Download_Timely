class DBManager:
    def __init__(self):
        print("DBManager initialized")

    def greet():
        print("Hello from DBManager!")
