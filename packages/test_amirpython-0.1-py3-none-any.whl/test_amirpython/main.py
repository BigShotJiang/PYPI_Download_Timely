def test():
    print('HI')