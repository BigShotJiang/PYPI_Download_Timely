## Updating the code

Please make sure that introduced changes are consistent with the testing api and add additional tests if relevant.

## Updating the versioning

Please add to `changelog.yaml` and then run `make changelog` before committing the results ONCE in this PR.