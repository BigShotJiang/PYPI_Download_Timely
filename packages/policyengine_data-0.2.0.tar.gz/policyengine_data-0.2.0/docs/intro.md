## PolicyEngine Data

This is the documentation for PolicyEngine Data, the open-source Python package powering PolicyEngine's data processing and storing functionality. It is used by PolicyEngine UK Data and PolicyEngine US Data, which each define the custom logic specific to processing UK and US data sources.
