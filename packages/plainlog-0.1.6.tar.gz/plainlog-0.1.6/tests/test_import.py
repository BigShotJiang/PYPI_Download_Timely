from plainlog import logger

def test_logger_import():
    assert logger
