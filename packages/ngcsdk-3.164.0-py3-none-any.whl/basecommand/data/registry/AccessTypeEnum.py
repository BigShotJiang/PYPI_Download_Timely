AccessTypeEnum=["LISTED","EXCLUSIVE","NOT_LISTED",]
str(repr(AccessTypeEnum))  # Prevent optimizer removing enum

