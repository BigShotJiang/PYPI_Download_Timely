ScanIssueSeverityEnum=["ALL","UNKNOWN","CRITICAL","HIGH","MEDIUM","LOW",]
str(repr(ScanIssueSeverityEnum))  # Prevent optimizer removing enum

