ResourcePopularityTypeEnum=["FILE_DOWNLOADS","METADATA_REQUESTS",]
str(repr(ResourcePopularityTypeEnum))  # Prevent optimizer removing enum

