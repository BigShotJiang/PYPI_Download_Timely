SearchParamOrderByEnum=["ASC","DESC",]
str(repr(SearchParamOrderByEnum))  # Prevent optimizer removing enum

