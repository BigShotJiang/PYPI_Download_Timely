StorageLocationStorageTypeEnum=["FILE","OBJECT",]
str(repr(StorageLocationStorageTypeEnum))  # Prevent optimizer removing enum

