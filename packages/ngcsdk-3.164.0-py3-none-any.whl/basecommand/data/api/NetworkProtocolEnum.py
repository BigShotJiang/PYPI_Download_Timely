NetworkProtocolEnum=["TCP","UDP","HTTPS","GRPC",]
str(repr(NetworkProtocolEnum))  # Prevent optimizer removing enum

