StorageEngineTypeEnum=["CEPH","SWIFTSTACK","NETAPP","DDN",]
str(repr(StorageEngineTypeEnum))  # Prevent optimizer removing enum

