NetworkTypeEnum=["INFINIBAND","ETHERNET",]
str(repr(NetworkTypeEnum))  # Prevent optimizer removing enum

