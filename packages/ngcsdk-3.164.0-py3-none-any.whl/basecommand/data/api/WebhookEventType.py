WebhookEventTypeEnum=["JOB_CREATED","JOB_STATUS_CHANGED",]
str(repr(WebhookEventTypeEnum))  # Prevent optimizer removing enum

