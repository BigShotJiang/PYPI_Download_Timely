AceProviderEnum=["PC","AWS_WEST","AWS_EAST","NGN","NVIDIA",]
str(repr(AceProviderEnum))  # Prevent optimizer removing enum

