NodeTypeEnum=["COMPUTE","SCHEDULER","STORAGE_SERVICE","PROXY_SERVICE","JUMPBOX","VIRTUAL","PHYSICAL",]
str(repr(NodeTypeEnum))  # Prevent optimizer removing enum

