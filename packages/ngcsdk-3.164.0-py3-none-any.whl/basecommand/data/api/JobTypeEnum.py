JobTypeEnum=["BATCH","SERVICE",]
str(repr(JobTypeEnum))  # Prevent optimizer removing enum

