============
Installation
============


You can install e2x-exam-sheets from source or from the Python Package Index (PyPI).

Install from PyPI:
------------------

.. code-block:: sh

    pip install e2x-exam-sheets

Install from source:
--------------------

.. code-block:: sh

    pip install --no-cache-dir git+hhttps://github.com/Digiklausur/e2x-exam-sheets.git
    