# e2x_exam_sheets

[![PyPI - Version](https://img.shields.io/pypi/v/e2x-exam-sheets.svg)](https://pypi.org/project/e2x-exam-sheets)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/e2x-exam-sheets.svg)](https://pypi.org/project/e2x-exam-sheets)
[![Documentation Status](https://readthedocs.org/projects/e2x-exam-sheets/badge/?version=latest)](https://e2x-exam-sheets.readthedocs.io/en/latest/?badge=latest)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install e2x-exam-sheets
```

## License

`e2x-exam-sheets` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license

## Documentation

Please consult the official [documentation](https://e2x-exam-sheets.readthedocs.io/).