# SPDX-FileCopyrightText: 2024-present Tim Metzler <tim.metzler@h-brs.de>
#
# SPDX-License-Identifier: MIT
__version__ = "0.1.0"
