# TDAstro Test Data

- **passbands/:**
  - Please note that the transmission tables included in this repository are for unit testing purposes only. We do not guarantee that they will be kept up to date, so users are encouraged to download and store their own files.
  - Transmission files were downloaded from the following endpoint (where self.filter name is "u", "g", "r", "i", "z", "y")
    - "https://github.com/lsst/throughputs/blob/main/baseline/total_{self.filter_name}.dat?raw=true"
