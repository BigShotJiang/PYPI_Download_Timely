from .cli import makejinja_cli

makejinja_cli()
