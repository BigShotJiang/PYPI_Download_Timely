import example_service

example_service.main()
