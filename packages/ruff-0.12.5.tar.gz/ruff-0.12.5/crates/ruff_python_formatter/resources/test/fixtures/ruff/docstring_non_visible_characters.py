# Regression test for https://github.com/astral-sh/ruff/issues/11724

'''


'''
