# leading comment
while True:  # block comment
    # inside comment
    break  # break comment
    # post comment
