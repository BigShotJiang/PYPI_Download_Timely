class Plotter:
\
    pass

class AnotherCase:
  \
    """Some
    \
    Docstring
    """
