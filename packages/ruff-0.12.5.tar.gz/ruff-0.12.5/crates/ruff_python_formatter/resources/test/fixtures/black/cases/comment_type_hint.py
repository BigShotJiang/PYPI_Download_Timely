# split out from comments2 as it does not work with line-length=1, losing the comment
a = "type comment with trailing space"  # type: str
