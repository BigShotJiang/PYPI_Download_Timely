# No spacing
5 ** 5
5.0 ** 5.0
1e5 ** 2e5
True ** True
False ** False
None ** None

# Space
"a" ** "b"
