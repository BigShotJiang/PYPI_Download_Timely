# Regression test for https://github.com/astral-sh/ruff/issues/18667
f"{
1=
}"

t"{
1=
}"
