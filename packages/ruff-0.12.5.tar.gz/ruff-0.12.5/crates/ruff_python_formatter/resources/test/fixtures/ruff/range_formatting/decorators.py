def  test():

    print("before" )

    @<RANGE_START> decorator( aa)

    <RANGE_END>def  func ():
        print("Do not format this" )


<RANGE_START>@ decorator(  a)
def  test(   a):<RANGE_END>
    print(  "body")

print("after" )


<RANGE_START>@ decorator(  a)<RANGE_END>
def  test(   a):
    print(  "body")

print("after" )

