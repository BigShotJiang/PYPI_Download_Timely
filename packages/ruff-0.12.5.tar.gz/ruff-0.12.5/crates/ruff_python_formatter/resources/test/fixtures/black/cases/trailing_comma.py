e = {
    "a": fun(msg, "ts"),
    "longggggggggggggggid": ...,
    "longgggggggggggggggggggkey": ..., "created": ...
    # "longkey": ...
}
f = [
    arg1,
    arg2,
    arg3, arg4
    # comment
]
g = (
    arg1,
    arg2,
    arg3, arg4
    # comment
)
h = {
    arg1,
    arg2,
    arg3, arg4
    # comment
}
