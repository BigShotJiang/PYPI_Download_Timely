# {{cookiecutter.project_slug}}

{{cookiecutter.description}}

Created by {{cookiecutter.author_name}} <{{cookiecutter.author_email}}>
