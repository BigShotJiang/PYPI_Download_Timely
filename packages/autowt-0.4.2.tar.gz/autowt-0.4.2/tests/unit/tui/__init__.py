"""Tests for TUI layer functionality."""
