
To configure a user to have access to all OUs' expenses (without all OUs access):

* Go to *Settings / Users & Companies / Users*
* For a user, select checkbox "Access all OUs' expenses"
