This module allow a user to have Access all OUs' expenses,
without having to add OUs in user setting.

Example use case, a shared HR team under an OU
but need to work on Expenses of all OUs.
