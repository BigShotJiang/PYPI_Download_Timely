

lista:list = []

lista.append(("a","b","c"))
lista.append(("d","e","f"))
lista.append(("g","h","i"))


for i1, i2, i3  in lista:
    print(i1, i2, i3)