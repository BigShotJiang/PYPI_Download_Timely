from internutopia.core.task.metric import BaseMetric
from internutopia.core.task.task import BaseTask
