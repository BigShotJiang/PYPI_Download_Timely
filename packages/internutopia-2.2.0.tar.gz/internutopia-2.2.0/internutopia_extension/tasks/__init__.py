from internutopia_extension.tasks import (
    finite_step_task,
    manipulation_task,
    single_inference_task,
)
