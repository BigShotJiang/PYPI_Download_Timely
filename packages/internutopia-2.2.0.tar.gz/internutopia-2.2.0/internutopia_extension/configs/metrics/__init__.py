from internutopia_extension.configs.metrics.recording_metric import RecordingMetricCfg
from internutopia_extension.configs.metrics.traveled_distance_metric import (
    TraveledDistanceMetricCfg,
)
