from internutopia_extension.configs.tasks.finite_step_task import FiniteStepTaskCfg
from internutopia_extension.configs.tasks.manipulation_task import ManipulationTaskCfg
from internutopia_extension.configs.tasks.single_inference_task import (
    SingleInferenceTaskCfg,
)
