def import_extensions():
    import internutopia_extension.controllers
    import internutopia_extension.interactions
    import internutopia_extension.metrics
    import internutopia_extension.objects
    import internutopia_extension.robots
    import internutopia_extension.sensors
    import internutopia_extension.tasks
