weaviate.collections.backups
============================

.. automodule:: weaviate.collections.backups
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.backups.backups
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.backups.backups
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
