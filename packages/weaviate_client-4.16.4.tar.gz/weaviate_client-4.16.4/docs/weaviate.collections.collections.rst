weaviate.collections.collections
================================

.. automodule:: weaviate.collections.collections
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.collections.async\_
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.collections.async_
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.collections.base
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.collections.base
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:

weaviate.collections.collections.sync
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. automodule:: weaviate.collections.collections.sync
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
