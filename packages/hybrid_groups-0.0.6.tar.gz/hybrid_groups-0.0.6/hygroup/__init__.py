from pathlib import Path

PROJECT_ROOT_PATH = Path(__file__).parent.resolve()
