from pathlib import Path

APP_SETUP_ROOT_PATH = Path(__file__).parent.resolve()
