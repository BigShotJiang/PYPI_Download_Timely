var namespace_py_x_make_1_1_tools_1_1_error_handling =
[
    [ "Error", "class_py_x_make_1_1_tools_1_1_error_handling_1_1_error.html", null ],
    [ "InputError", "class_py_x_make_1_1_tools_1_1_error_handling_1_1_input_error.html", "class_py_x_make_1_1_tools_1_1_error_handling_1_1_input_error" ],
    [ "TransitionError", "class_py_x_make_1_1_tools_1_1_error_handling_1_1_transition_error.html", "class_py_x_make_1_1_tools_1_1_error_handling_1_1_transition_error" ]
];