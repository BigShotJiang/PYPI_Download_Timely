-----------------------------------------
Create and publish python platform wheels
-----------------------------------------

.. literalinclude:: ../../../templates/python-create-wheel-any/template.yml
   :language: yaml