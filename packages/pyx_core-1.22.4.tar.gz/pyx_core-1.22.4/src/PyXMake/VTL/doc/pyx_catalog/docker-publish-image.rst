--------------------------------
Build and publish a docker image
--------------------------------

.. literalinclude:: ../../../templates/docker-publish-image/template.yml
   :language: yaml