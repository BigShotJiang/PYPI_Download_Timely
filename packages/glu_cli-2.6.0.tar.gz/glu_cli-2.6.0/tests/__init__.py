from pathlib import Path

TESTS_DATA_DIR = Path(__file__).parent / "data"
