**Português** Esse módulo incluí a possibilidade de pesquisar uma Ordem
de Separação(Stock Picking) por CNPJ/CPF, Razão Social ou Inscrição
Estadual.

**English** This module included the possibilite to search Stock Picking
by  CNPJ/CPF, Razão Social or Inscrição Estadual.
