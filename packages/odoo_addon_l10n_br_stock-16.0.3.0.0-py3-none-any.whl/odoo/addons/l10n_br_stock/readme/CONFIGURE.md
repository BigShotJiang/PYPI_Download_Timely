**Português** Esse modulo não precisa de nenhuma configuração

**English** This module does not need any configuration.
