**Português** Nas Ordens de Separação é possível Pesquisar por
por CNPJ/CPF, Razão Social ou Inscrição Estadual.

**English** In Stock Picking it's possible to search by  CNPJ/CPF, Razão
Social or Inscrição Estadual.
