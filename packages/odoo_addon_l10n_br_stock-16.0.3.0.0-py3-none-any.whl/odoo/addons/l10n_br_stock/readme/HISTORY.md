## 14.0.2.0.0 (2022-06-07)

- \[REF\] Renomeado campo Inscrição Estadual de ie para inscr_est.

## 14.0.1.0.0 (2021-12-31)

- \[MIG\] Migração para a versão 14.0.
