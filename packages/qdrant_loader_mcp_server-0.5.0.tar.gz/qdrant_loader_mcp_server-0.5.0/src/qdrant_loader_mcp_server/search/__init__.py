"""Search functionality for RAG server."""
