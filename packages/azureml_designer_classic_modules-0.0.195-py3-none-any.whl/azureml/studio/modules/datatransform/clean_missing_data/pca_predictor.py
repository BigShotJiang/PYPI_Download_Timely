from azureml.studio.modules.datatransform.common.base_transform import BaseTransform


class ProbabilisticPcaMissingValuePredictor(BaseTransform):
    pass
