class BaseRecommender:
    # An empty base recommendation for binding the Input/Output ports.
    pass
