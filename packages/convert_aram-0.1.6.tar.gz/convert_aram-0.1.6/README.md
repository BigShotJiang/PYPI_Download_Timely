

Convert Aram est un package Django simple permettant de convertir un montant en appliquant un taux donné.

-FONCTIONNALITES

- Conversion d’un montant selon un taux spécifié.
- Interface simple avec une page d’accueil et une page résultat.
- Facile à intégrer dans un projet Django.

-INSTALLATION


```bash
- creer l environement virtuelle < python -m venv venv>
- active > source venv/
< pip install convert_aram > dans le projet
