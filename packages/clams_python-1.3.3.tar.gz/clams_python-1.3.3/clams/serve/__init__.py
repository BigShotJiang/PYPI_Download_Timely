
import warnings
warnings.warn("clams.serve module is deprecated, use clams.app instead", DeprecationWarning, stacklevel=2)
from clams.app import *

