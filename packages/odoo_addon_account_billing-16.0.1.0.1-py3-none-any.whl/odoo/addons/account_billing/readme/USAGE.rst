To use this module, you have 2 ways:

1. Create new billing directly
    Go to *Invoicing -> Customers or Vendors -> Billing*

2. Create billing from selected invoice(s)
    #. Go to *Invoicing -> Customers or Vendors -> Invoices or Bills*
    #. Create Invoice
    #. On tree view select invoice and go to *Action -> Create Billing*
