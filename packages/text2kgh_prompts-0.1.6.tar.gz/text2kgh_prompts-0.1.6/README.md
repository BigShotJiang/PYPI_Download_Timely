uv pip install -e .



main 

继续维持和改进单一文件prompt效果

Arch1 规则

1 单一文章独立生成

2 将生成后的内容进行融合

3 使用程序来整合和实现 大模型配合识别

