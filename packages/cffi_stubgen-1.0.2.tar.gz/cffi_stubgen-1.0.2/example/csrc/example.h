#ifndef EXAMPLE_H
#define EXAMPLE_H

int add(int a, int b);

int sub(int a, int b);

double addf(double a, double b);

double subf(double a, double b);

#endif /* EXAMPLE_H */
