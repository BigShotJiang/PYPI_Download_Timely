#include "example.h"

int add(int a, int b){
    return a + b;
}

int sub(int a, int b){
    return a - b;
}

double addf(double a, double b){
    return a + b;
}

double subf(double a, double b){
    return a - b;
}
