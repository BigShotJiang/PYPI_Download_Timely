"""
Import views scripts
"""

from . aaep_view import *
from . ap_view import *
from . bd_view import *
from . contract_filter_entry_view import *
from . contract_filter_view import *
from . contract_subject_view import *
from . contract_view import *
from . domain_view import *
from . epg_view import *
from . esg_view import *
from . ipg_view import *
from . l3out_view import *
from . policies_view import *
