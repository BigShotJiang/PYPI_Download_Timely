"""
Import tables scripts
"""

from . aaep_tables import *
from . ap_tables import *
from . bd_tables import *
from . contract_tables import *
from . domain_tables import *
from . epg_tables import *
from . ipg_tables import *
from . l3out_tables import *
from . policies_tables import *
