"""
Import forms scripts
"""

from . aaep_form import *
from . ap_form import *
from . bd_form import *
from . contract_filter_entry_form import *
from . contract_filter_form import *
from . contract_subject_form import *
from . contract_form import *
from . domain_form import *
from . epg_form import *
from . esg_form import *
from . ipg_form import *
from . l3out_form import *
from . policies_form import *
