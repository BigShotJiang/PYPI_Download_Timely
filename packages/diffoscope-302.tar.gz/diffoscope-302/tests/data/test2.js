function test(str) { alert(str);prompt(str,"TEST2")}x=1;y=3;z=/.*/;d=[2015,2016,2017]; //comment
