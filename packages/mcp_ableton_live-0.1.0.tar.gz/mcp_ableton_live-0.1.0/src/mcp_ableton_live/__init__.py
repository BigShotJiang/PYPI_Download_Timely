"""MCP Ableton Live Server."""

__version__ = "0.1.0"