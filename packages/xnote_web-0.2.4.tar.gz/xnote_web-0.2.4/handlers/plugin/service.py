# encoding=utf-8

from .plugin_config import CategoryService