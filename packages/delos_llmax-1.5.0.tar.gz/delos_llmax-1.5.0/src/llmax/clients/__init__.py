"""The client object."""

from .multi_ai_client import MultiAIClient

__all__ = [
    "MultiAIClient",
]
