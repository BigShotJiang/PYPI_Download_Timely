"""Messages type."""

from .message import Message

Messages = list[Message]
