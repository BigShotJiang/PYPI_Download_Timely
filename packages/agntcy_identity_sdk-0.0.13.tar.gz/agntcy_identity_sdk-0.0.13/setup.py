#!/usr/bin/env python
# Copyright 2025 Copyright AGNTCY Contributors (https://github.com/agntcy)
# SPDX-License-Identifier: Apache-2.0
"""Setup script for the package."""

import setuptools

if __name__ == "__main__":
    setuptools.setup()
