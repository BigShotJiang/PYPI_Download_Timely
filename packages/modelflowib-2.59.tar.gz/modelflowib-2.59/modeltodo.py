# -*- coding: utf-8 -*-
"""
Created on Wed Feb 19 08:43:25 2020

@author: bruger

allow tansposed lists to be inputted
Tlist a_list:
    a  a_1 a_1 = 
    a  b   c
    r  r   y $

makes list with many elements easier to read in editor 

revise pattern to be a class

try out plotly

implement cython again 

let attribution calculate on growth in addition to level 

For attribution allow a cutoff level for showing sub branches. 






"""

