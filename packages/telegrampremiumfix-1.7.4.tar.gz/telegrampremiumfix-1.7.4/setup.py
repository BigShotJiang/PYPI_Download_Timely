from setuptools import setup, find_packages

setup(
    name='TelegramPremiumFix',
    version='1.7.4',
    description='Use this library for add Premium to your telegram',
    author='MaksVavrik',
    packages=find_packages(),
    python_requires='>=3.6',
)
