# dagster-slack

The docs for `dagster-slack` can be found
[here](https://docs.dagster.io/api/python-api/libraries/dagster-slack).
