from .knowledge import Knowledge

__all__ = ['Knowledge']
