################################################################
# THIS FILE IS ONLY USED FOR TESTING PURPOSES
################################################################
from hostore.models import TimeseriesChunkStore


class MyTimeseriesChunkStore(TimeseriesChunkStore):
    pass

################################################################
# THIS FILE IS ONLY USED FOR TESTING PURPOSES
################################################################