"""
.. include:: ../../README.md
"""
import os


__version__ = "1.0.2"
JS_PATH = os.path.join(os.path.dirname(__file__), "js")
