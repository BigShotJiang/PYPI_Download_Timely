"""Python Dependency Tree Analyzer"""
__version__ = "0.3.19"