import nauert


def test_WeightedSearchTree___init___01():
    nauert.WeightedSearchTree()
