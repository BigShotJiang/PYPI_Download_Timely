﻿
---

# HoloAI 

---

## License

This project is licensed under the [MIT](LICENSE).
Copyright 2025 Tristan McBride Sr.

---

## Acknowledgements

Project by:
- Tristan McBride Sr.
- Sybil
