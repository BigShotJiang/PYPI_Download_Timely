This module provides Ethiopian localization of the "New Recruitment" wizard.
