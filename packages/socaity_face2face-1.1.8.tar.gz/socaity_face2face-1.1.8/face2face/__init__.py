from face2face.core.face2face import Face2Face
