.. _examples:

Examples
========

.. toctree::
   :maxdepth: 1

   examples/bayesmbar_for_harmonic_oscillators.ipynb
   examples/cbayesmbar_for_harmonic_oscillators.ipynb
   examples/cbayesmbar_for_protein_ligand/main.ipynb