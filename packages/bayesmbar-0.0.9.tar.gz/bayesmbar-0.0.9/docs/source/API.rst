API
===

.. automodule:: bayesmbar
   :members:
   :undoc-members:
   :show-inheritance:
