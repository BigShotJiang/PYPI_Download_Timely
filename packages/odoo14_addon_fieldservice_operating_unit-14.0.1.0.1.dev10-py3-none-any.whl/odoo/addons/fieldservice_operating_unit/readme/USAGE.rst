* Go to Field Service
* You only see the FSM orders of your operating units
* Create an order. It is assigned to your default operating unit.
