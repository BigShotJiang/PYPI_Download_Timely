This module adds operating unit information to Field Service orders.
