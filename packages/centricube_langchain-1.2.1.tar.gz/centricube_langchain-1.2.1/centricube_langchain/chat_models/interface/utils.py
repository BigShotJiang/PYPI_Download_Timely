import time


def get_ts():
    return round(time.time() * 1000)
