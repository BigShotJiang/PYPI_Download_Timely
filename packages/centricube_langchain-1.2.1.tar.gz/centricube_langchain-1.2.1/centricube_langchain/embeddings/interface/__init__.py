from .wenxin import EmbeddingClient as WenxinEmbeddingClient

__all__ = ['WenxinEmbeddingClient']
