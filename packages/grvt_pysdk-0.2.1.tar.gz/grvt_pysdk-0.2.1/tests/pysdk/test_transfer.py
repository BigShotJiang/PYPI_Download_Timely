from .test_grvt_raw_sync import test_transfer_with_signing

if __name__ == "__main__":
    test_transfer_with_signing()
