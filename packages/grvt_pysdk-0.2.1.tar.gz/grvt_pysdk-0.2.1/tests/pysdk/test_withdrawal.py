from .test_grvt_raw_sync import test_withdrawal_with_signing

if __name__ == "__main__":
    test_withdrawal_with_signing()
