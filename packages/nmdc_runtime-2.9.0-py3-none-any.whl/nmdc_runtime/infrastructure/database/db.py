"""
Database initialization
"""
