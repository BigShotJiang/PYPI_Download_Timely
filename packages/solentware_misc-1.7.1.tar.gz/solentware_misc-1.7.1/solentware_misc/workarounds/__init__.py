# __init__.py
# Copyright 2008 Roger Marsh
# Licence: See LICENCE (BSD licence)

"""Provide modules with workarounds for problems encountered using tkinter.

The workarounds were originally for Tkinter at Python 2.
"""
