# __init__.py
# Copyright 2008 Roger Marsh
# Licence: See LICENCE (BSD licence)

"""Miscellaneous modules for applications available at solentware.co.uk.

These do not belong in the solentware_base or solentware_grid packages,
siblings of solentware_misc.
"""
