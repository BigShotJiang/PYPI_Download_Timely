
# form-util

Une app Django avec un formulaire de bienvenue simple

## Installation

```bash

#soyez dans un environnement python env de preference 

pip install django-form-util

#utilisation


form_util nom_app
