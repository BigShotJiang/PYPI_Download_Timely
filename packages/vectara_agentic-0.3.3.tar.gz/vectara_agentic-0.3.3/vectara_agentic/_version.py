"""
Define the version of the package.
"""
__version__ = "0.3.3"
