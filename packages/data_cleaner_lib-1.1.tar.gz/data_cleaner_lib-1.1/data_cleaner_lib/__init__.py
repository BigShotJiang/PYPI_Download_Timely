__version__ = "1.1"

from .cleaner import DataCleaner
from .test_data import generate_test_dataset