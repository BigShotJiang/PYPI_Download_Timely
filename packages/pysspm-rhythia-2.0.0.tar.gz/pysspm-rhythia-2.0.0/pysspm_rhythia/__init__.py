from pysspm_rhythia.pysspm import read_sspm, SSPM
from pysspm_rhythia.__version__ import __version__