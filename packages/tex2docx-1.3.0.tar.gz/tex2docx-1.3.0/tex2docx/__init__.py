from .tex2docx import LatexToWordConverter

__all__ = ["LatexToWordConverter"]
