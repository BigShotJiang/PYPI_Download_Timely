from .contents import Contents
from .youtuberesponse import YoutubeResponse


class ytinitialdata(YoutubeResponse):
    contents: Contents
