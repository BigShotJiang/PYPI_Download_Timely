# -*- coding: UTF-8 -*-
"""
Created on 23.07.25

:author:     Martin Dočekal
"""
