from llama_cloud_services.parse.cli.main import parse

if __name__ == "__main__":
    parse()
