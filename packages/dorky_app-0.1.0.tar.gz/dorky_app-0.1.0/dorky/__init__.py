from pathlib import Path

dorky_dir = Path(__file__).resolve().parent
assets_dir = str(dorky_dir / "assets")
json_data_dir = str(dorky_dir / "json_data")
