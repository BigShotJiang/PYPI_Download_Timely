=========================
Jitter Modeling Utilities
=========================

.. automodule:: pybert.utility.jitter
   :members:
