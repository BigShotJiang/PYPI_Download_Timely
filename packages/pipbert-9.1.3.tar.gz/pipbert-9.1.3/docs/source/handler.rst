===================
GUI - Event Handler
===================

.. automodule:: pybert.gui.handler
   :members:
