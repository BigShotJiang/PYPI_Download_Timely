==========================
GUI - Main View Definition
==========================

.. automodule:: pybert.gui.view
   :members:
