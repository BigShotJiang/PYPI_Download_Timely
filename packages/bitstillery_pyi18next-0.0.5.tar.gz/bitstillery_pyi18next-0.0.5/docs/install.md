# Install

Install pyi18next using pip

```
python -m pip install -U pyi18next
```