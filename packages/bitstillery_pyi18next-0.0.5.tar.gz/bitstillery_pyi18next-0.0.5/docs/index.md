# pyi18next

pyi18next is a Python version of [i18next](https://github.com/i18next/i18next), and maintains almost the same API interfaces as well as the translation formats.

## Table of Contents

- [Get Started](/get-started/)
- [Installation](/install/)
- Usage
    - [Load Translation Files](/usage/load/)
