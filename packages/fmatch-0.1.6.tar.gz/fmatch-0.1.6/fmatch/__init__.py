"""This file is the init file of the matcher package
which is used as to match and query data from elastic server"""
