from django.db import migrations


class Migration(migrations.Migration):
    dependencies = [
        ("netbox_dns", "0021_record_ip_address"),
    ]

    operations = []
