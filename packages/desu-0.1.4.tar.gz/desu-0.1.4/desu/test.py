import desu

desu.timer.show()
desu.timer.mark()
desu.timer.start()
desu.timer.mark()
desu.timer.show()
help(desu.timer)
help(desu)