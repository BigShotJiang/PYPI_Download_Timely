from enum import Enum


class DocStyleEnum(Enum):
    numpy = "numpy"
    google = "google"
    pep257 = "pep257"
