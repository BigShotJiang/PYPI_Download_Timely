"""usethis: Automate Python project setup and development tasks that are otherwise performed manually."""
