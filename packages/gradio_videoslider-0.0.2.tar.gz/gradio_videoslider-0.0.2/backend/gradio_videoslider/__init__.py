
from .videoslider import VideoSlider

__all__ = ['VideoSlider']
