``fsleyes_props.widgets``
=========================

.. automodule:: fsleyes_props.widgets
    :members:
    :undoc-members:
    :show-inheritance:
