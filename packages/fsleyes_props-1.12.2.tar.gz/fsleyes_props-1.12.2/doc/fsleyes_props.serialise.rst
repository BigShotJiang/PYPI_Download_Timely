``fsleyes_props.serialise``
===========================

.. automodule:: fsleyes_props.serialise
    :members:
    :undoc-members:
    :show-inheritance:
