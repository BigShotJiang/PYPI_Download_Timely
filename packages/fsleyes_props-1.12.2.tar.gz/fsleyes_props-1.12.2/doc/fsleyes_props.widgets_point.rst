``fsleyes_props.widgets_point``
===============================

.. automodule:: fsleyes_props.widgets_point
    :members:
    :undoc-members:
    :show-inheritance:
