``fsleyes_props.properties``
============================

.. automodule:: fsleyes_props.properties
    :members:
    :undoc-members:
    :show-inheritance:
