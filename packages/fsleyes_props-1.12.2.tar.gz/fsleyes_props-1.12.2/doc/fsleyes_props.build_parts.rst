``fsleyes_props.build_parts``
=============================

.. automodule:: fsleyes_props.build_parts
    :members:
    :undoc-members:
    :show-inheritance:
