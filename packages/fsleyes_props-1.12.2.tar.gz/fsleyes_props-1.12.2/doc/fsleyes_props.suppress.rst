``fsleyes_props.suppress``
==========================

.. automodule:: fsleyes_props.suppress
    :members:
    :undoc-members:
    :show-inheritance:
