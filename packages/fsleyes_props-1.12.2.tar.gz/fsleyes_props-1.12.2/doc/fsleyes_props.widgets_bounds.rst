``fsleyes_props.widgets_bounds``
================================

.. automodule:: fsleyes_props.widgets_bounds
    :members:
    :undoc-members:
    :show-inheritance:
