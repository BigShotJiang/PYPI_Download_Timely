``fsleyes_props.syncable``
==========================

.. automodule:: fsleyes_props.syncable
    :members:
    :undoc-members:
    :show-inheritance:
