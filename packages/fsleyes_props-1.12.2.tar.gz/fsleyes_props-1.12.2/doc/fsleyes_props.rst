``fsleyes_props``
=================

.. toctree::
   :hidden:

   fsleyes_props.bindable
   fsleyes_props.build
   fsleyes_props.build_parts
   fsleyes_props.callqueue
   fsleyes_props.cli
   fsleyes_props.properties
   fsleyes_props.properties_types
   fsleyes_props.properties_value
   fsleyes_props.serialise
   fsleyes_props.suppress
   fsleyes_props.syncable
   fsleyes_props.trace
   fsleyes_props.widgets
   fsleyes_props.widgets_boolean
   fsleyes_props.widgets_bounds
   fsleyes_props.widgets_choice
   fsleyes_props.widgets_list
   fsleyes_props.widgets_number
   fsleyes_props.widgets_point

.. automodule:: fsleyes_props
    :members:
    :undoc-members:
    :show-inheritance:
