``fsleyes_props.callqueue``
===========================

.. automodule:: fsleyes_props.callqueue
    :members:
    :undoc-members:
    :show-inheritance:
