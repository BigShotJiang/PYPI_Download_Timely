``fsleyes_props.build``
=======================

.. automodule:: fsleyes_props.build
    :members:
    :undoc-members:
    :show-inheritance:
