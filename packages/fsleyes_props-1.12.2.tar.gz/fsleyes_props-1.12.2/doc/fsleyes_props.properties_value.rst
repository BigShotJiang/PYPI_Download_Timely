``fsleyes_props.properties_value``
==================================

.. automodule:: fsleyes_props.properties_value
    :members:
    :undoc-members:
    :show-inheritance:
