``fsleyes_props.widgets_choice``
================================

.. automodule:: fsleyes_props.widgets_choice
    :members:
    :undoc-members:
    :show-inheritance:
