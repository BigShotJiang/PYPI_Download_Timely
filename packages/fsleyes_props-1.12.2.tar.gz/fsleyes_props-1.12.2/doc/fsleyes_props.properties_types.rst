``fsleyes_props.properties_types``
==================================

.. automodule:: fsleyes_props.properties_types
    :members:
    :undoc-members:
    :show-inheritance:
