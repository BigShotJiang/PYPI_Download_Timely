``fsleyes_props.widgets_boolean``
=================================

.. automodule:: fsleyes_props.widgets_boolean
    :members:
    :undoc-members:
    :show-inheritance:
