``fsleyes_props.bindable``
==========================

.. automodule:: fsleyes_props.bindable
    :members:
    :undoc-members:
    :show-inheritance:
