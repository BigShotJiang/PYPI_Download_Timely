``fsleyes_props.cli``
=====================

.. automodule:: fsleyes_props.cli
    :members:
    :undoc-members:
    :show-inheritance:
