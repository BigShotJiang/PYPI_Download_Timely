``fsleyes_props.widgets_list``
==============================

.. automodule:: fsleyes_props.widgets_list
    :members:
    :undoc-members:
    :show-inheritance:
