``fsleyes-props`` release history
=================================

.. include:: ../CHANGELOG.rst
