``fsleyes_props.widgets_number``
================================

.. automodule:: fsleyes_props.widgets_number
    :members:
    :undoc-members:
    :show-inheritance:
