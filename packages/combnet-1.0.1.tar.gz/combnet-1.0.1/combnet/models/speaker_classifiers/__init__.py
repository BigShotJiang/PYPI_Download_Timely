from .sinc import SincNet
from .conv import ConvClassifier
from .comb import CombClassifier