from .comb import CombClassifier
from .conv import ConvClassifier