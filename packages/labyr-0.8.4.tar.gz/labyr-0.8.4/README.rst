.. image:: https://img.shields.io/badge/pypi-v0.3.0-orange
   :target: https://pypi.org/project/labyr
   :alt: Latest Version
 
labyr
=====

A labyrinth game

Compatibility
=============
This project only supports windows and will potentially support linux.
