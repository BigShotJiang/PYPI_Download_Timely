# __main__.py

from coreshub_mcp_server import main

main()
