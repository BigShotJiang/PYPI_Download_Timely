# mediaComp #
mediaComp is a conversion of the multimedia library JES4PY by Mark Guzdial to Python 3.