"""The moneyball strategy module."""

# ruff: noqa: F401
from .strategy import Strategy
