"""
This file contains the event types for the schedule event model.
"""

_EVENT_TYPES: dict = {
    "liveInput": "eef7ef23-56dc-4f48-8c0e-1f4d52990405",
    "videoAsset": "eef7ef23-56dc-4f48-8c0e-1f4d52990404"
}
