from enum import Enum


class CompressionTypes(Enum):
    WEBP = "webp"
    DEFLATE = "deflate"
