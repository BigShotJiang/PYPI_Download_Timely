from . import (
    blueprints,
    blueprintsExtraData,
    buildings,
    gameObjects,
    ingameData,
    islands,
    pygamePIL,
    research,
    shapeCodes,
    shapeOperations,
    shapeViewer,
    translations,
    utils,
    versions
)