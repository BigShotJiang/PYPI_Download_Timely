#!/bin/bash
export PYGSLODEIV2_BLAS=openblas
python -m pip install --no-deps --ignore-installed .
