env = {'BLAS': 'gslcblas', 'GSL_LIBS': 'gsl,m'}
