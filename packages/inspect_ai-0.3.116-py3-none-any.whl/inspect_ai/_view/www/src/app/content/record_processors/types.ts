export type RecordProcessor = (
  record: Record<string, unknown>,
) => Record<string, unknown>;
