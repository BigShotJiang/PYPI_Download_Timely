# PXE OpenAlex

Provides access to the OpenAlex API

## Installation

uvx:

```
{
  "mcpServers": {
    "pickaxe-mcp-open-alex": {
      "command": "uvx",
      "args": [
        "pickaxe-mcp-open-alex@latest"
      ]
    }
  }
}
```
