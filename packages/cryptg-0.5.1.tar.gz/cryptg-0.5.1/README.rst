|logo|

cryptg
======

This is a small native extension for Python 3 to help libraries that want to
work with the Telegram API, which uses the uncommon AES-IGE mode for it.

Note that while this wrapper library is licensed under CC0, the Rust dependencies
have their own license.

.. |logo| image:: https://raw.githubusercontent.com/cher-nov/cryptg/master/logo.png
    :target: https://github.com/cher-nov/cryptg
    :alt: cryptg
