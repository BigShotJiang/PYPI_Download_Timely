# Contributing

Thank you for considering contributing to fastapi-mongo-base!

## How to Contribute
- Fork the repository
- Create a new branch
- Make your changes
- Submit a pull request

Please follow the code style and add tests for new features. 