from . import Demes, Inference, DemesUtil

from .Demes import SFS, LD, LDdecay
