========================================
Linkage disequilibrium and recombination
========================================

.. todo:: This module has not been completed.

Sections
--------

 - Recombination and low-order LD statistics

 - Ohta and Kimura

 - Single population LD decay curves

 - Multiple populations

 - Selfing
