# quiz_jeu

quiz_jeu est un nettoyeur de texte simple conçu pour être utilisé avec Django. Il permet de nettoyer du texte en supprimant les espaces inutiles, la ponctuation et les caractères spéciaux.

## Fonctionnalités

- Nettoyage de texte simple
- Interface utilisateur intuitive
- Facile à intégrer dans un projet Django

## Installation

Pour installer quiz_jeu, utilisez pip :

```bash
pip install quiz_jeu