# Agents Core Library

Agents with no dependencies on other libraries.