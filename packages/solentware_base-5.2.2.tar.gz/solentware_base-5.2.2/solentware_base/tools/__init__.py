# __init__.py
# Copyright 2019 Roger Marsh
# Licence: See LICENCE (BSD licence)

"""solentwarebase.tools package."""
