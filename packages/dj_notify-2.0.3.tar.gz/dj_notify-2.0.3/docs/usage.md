# Usage

To use dj-notify in a project:

```python
import dj_notify
```
