cd ..
source .env
sudo docker start ${project_name}_postgres
