cd ..
poetry show arpakitlib --latest