from project.util.arpakitlib_project_template_util import get_arpakitlib_project_template_info


def __command():
    print(get_arpakitlib_project_template_info())


if __name__ == '__main__':
    __command()
