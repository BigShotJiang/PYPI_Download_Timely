from project.tg_bot.callback_data_.common import BaseCD


class RemoveMessageClientCD(BaseCD):
    pass
