
"""
mtbmasker: Generate isolate-specific genome masks for Mycobacterium tuberculosis.
"""

__version__ = "0.1.1"

__author__ = "Etienne Ntumba Kabongo, Dan Whiley"
__license__ = "MIT"
