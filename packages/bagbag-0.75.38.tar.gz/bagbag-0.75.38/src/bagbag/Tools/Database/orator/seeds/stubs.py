# -*- coding: utf-8 -*-

DEFAULT_STUB = """from orator.seeds import Seeder


class DummyClass(Seeder):

    def run(self):
        \"\"\"
        Run the database seeds.
        \"\"\"
        pass

"""
