# -*- coding: utf-8 -*-


class ArgumentError(Exception):

    pass
