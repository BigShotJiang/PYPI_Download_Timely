# Copyright 2022 MosaicML Composer authors
# SPDX-License-Identifier: Apache-2.0

"""Runs the Composer CLI."""

import sys

from composer.cli.launcher import main

sys.exit(main())
