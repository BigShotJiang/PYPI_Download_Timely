"""Top-level package for dj-notify."""

__author__ = """Asmita"""
__email__ = 'shahasmita379@gmail.com'
__version__ = '1.0.1'
