::: albert.resources.storage_locations
