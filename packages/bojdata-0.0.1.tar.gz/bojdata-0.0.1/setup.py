"""
Setup script for bojdata package.
This file is needed for editable installs and backwards compatibility.
"""

from setuptools import setup

setup()