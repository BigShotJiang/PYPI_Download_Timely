"""Version information for bojdata."""
__version__ = "0.0.1"