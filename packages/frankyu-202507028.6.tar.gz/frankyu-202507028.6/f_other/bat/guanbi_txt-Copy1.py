import frankyu.kill_program

 

 

bbb = frankyu.kill_program

bbb.kill_program("notepad")

aaa  = r"ping 127.1"
import os
os.system(aaa)