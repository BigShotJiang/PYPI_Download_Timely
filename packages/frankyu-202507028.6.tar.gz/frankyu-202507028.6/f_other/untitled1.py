

aaa = r"http://intel_lianxiang:7777/login?next=%2Flab%2Ftree%2FOneDrive%2F%25E7%25A7%2581%25E4%25BA%25BA%25E6%2596%2587%25E4%25BB%25B6%25EF%25BC%258Cdengchunying1988%2FDocuments%2Fsb_py%2Ffrankyu"


print(aaa)

