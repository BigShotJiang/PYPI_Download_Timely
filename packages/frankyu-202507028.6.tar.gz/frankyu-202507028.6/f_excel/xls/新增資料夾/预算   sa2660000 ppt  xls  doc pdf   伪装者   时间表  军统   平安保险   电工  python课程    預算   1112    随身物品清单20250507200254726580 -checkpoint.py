bbb = r'https://d.docs.live.net/9122e41a29eea899/sb_yufengguang/xls/%E9%A2%84%E7%AE%97_20250507200254726580.xlsx'
aaa = '预算_20250507200254726580'
bbb

import f_excel.over.open_and_process_excel as op

op.open_and_process_excel(bbb)