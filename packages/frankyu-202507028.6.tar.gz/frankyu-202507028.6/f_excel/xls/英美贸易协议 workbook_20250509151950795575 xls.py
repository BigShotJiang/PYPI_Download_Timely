aaa = "英美贸易协议 workbook_20250509151950795575"

bbb = r'https://d.docs.live.net/9122e41a29eea899/sb_yufengguang/xls/%E8%8B%B1%E7%BE%8E%E8%B4%B8%E6%98%93%E5%8D%8F%E8%AE%AE%20workbook_20250509151950795575.xlsx'

import f_excel.over.open_and_process_excel as ex






ex.open_and_process_excel(bbb)