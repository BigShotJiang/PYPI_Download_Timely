aaa = "Linux编程基础_20250508183752649212"
aaa

bbb = r"https://d.docs.live.net/9122e41a29eea899/sb_yufengguang/xls/Linux%E7%BC%96%E7%A8%8B%E5%9F%BA%E7%A1%80_20250508183752649212.xlsx"

import f_excel.over.open_and_process_excel as ov


ov.open_and_process_excel(bbb)