
aaa = "中美为何无法达成协议 xls workbook_20250509151812190427"

bbb = r'https://d.docs.live.net/9122e41a29eea899/sb_yufengguang/xls/%E4%B8%AD%E7%BE%8E%E4%B8%BA%E4%BD%95%E6%97%A0%E6%B3%95%E8%BE%BE%E6%88%90%E5%8D%8F%E8%AE%AE%20xls%20workbook_20250509151812190427.xlsx'



import f_excel.over.open_and_process_excel as ex






ex.open_and_process_excel(bbb)