aaa = 't2051320   于荣祥 借书记录 workbook_20250508183633453310'
aaa

bbb = r'https://d.docs.live.net/9122e41a29eea899/sb_yufengguang/xls/t2051320%20%20%20%E4%BA%8E%E8%8D%A3%E7%A5%A5%20%E5%80%9F%E4%B9%A6%E8%AE%B0%E5%BD%95%20workbook_20250508183633453310.xlsx'
bbb

import f_excel.over.open_and_process_excel as ov


ov.open_and_process_excel(bbb)