import frankyu.xlsx.d单函数.create_new_excel_workbook as cr



cr.create_new_excel_workbook()


import frankyu.xlsx.d单函数.active_excel_objects_get as ac

app,b,c,d=ac.active_excel_objects_get()