aaa = r'''

python 程序打包


# 使用 venv 创建虚拟环境
python -m venv myenv
# 激活虚拟环境
# Windows
myenv\Scripts\activate
# macOS/Linux
source myenv/bin/activate
 
# 安装依赖
pip install -r requirements.txt


pip install pyinstaller
pyinstaller your_script.py


https://www.baidu.com/s?ie=utf-8&f=8&rsv_bp=0&rsv_idx=1&tn=baidu&wd=python%20%E7%A8%8B%E5%BA%8F%E6%89%93%E5%8C%85&rsv_pq=ce9526f2000081a6&rsv_t=bcc9h0B0Y3Bzy7FKFBir0EgRB2Y8BgOLZzf6s70mFcAitgfO02kIoxl9gWw&rqlang=cn&rsv_enter=1&rsv_sug3=4&rsv_sug1=3&rsv_sug7=100&rsv_sug2=0&inputT=1394&rsv_sug4=
'''

print(aaa)