aaa =r'''
/mnt/hdd_500_2/t6
_py/t7073$
'''