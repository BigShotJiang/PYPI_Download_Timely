aaa = r'''
ssh 10
.42.0.1      -p 22 -l kelly

'''
