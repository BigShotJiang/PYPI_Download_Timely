aaa = r'''

sudo usermod -aG kelly frank

exec su -l $USER

'''