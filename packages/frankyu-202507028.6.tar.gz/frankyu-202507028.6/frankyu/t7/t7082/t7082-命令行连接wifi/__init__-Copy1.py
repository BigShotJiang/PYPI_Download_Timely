aaa = r'''
nmcli connection show


sudo nmcli device wifi conn
ect "xiaomi880125" password "55555555" ifname wlx488a
d237935b

sudo ip link set dev wlx488
ad237935b up

'''