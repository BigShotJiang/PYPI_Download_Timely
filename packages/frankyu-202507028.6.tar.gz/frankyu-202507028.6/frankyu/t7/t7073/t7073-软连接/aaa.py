aaa = r'''


sudo ln -sf /usr/local/jupyter/bin/streamlit /usr/local/bin/streamlit

'''
