import frankyu.other.install_jupyterlab_language_pack as i

i.install_package_with_version_check("streamlit")