import frankyu.cmd.command_execute as cm
cm.execute_command("pip install   --upgrade frankyu")
import frankyu.frankyu as fr
fr.dao_ji_shi(20)