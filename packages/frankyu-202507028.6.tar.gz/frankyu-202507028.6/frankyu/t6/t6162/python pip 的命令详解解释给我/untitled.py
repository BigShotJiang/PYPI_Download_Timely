aa = "python pip 的命令详解解释给我"


bbb = r"https://docs.google.com/document/d/1HoVcQpjsLoP_Z7Vs7J5l6ZA23bzq9JxPHSN0Rxmk_no/edit?usp=sharing"