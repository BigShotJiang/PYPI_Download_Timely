aaa = "linux   的命令详解解释给我"

bbb= r"https://docs.google.com/document/d/1JaoV64YFg7E7uahXFZF4vLb4N1PbGH3Ge0xngawkGZI/edit?usp=sharing"