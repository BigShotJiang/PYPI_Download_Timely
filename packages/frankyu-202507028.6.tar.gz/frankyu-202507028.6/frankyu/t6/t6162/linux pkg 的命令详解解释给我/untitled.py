aaaa = "linux pkg 的命令详解解释给我"

bbb = r"https://docs.google.com/document/d/1OVD7Js_NQuLCwD12W9O71OmSbI6wfyRQ16CLxuWj6KA/edit?usp=sharing"