aaa  = "linux apt 的命令详解解释给我"
bbb = r"https://docs.google.com/document/d/1g-_-tVwiGvaw-GhVUBt9zUouT8JC-2FfsrVGcbGKqdY/edit?usp=sharing"