aaa = "linux vi 的命令详解解释给我"

bbb = r"https://docs.google.com/document/d/1mMeNpIn_zxhCqbdp90eDy0yFcvOVyDtM-DZphhZP9ZU/edit?usp=sharing"