aaa = "python conda 的命令详解解释给我"

bbb = r"https://docs.google.com/document/d/1pJFwKKJpqe001t2KkIMVciAdMQkr1xWDb8Bk9Awizmc/edit?usp=sharing"