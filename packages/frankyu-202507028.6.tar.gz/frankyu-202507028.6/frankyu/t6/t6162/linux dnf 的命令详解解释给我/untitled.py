aaa = "linux dnf 的命令详解解释给我"

bbb = r"https://docs.google.com/document/d/1RsXFWwYqCmqvaDllQ93nDYEQEYD3nMFd6p633VnvCYs/edit?usp=sharing"