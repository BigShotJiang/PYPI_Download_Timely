aaa = "linux yum 的命令详解解释给我"


bbb = r"https://docs.google.com/document/d/1rFdPten4aamRbdy0LT-oOTArGFKefpMtIsWARCWKedg/edit?usp=sharing"