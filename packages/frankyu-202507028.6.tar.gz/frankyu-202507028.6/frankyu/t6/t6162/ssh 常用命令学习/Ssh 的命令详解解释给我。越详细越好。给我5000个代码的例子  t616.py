aaa = "Ssh 的命令详解解释给我。越详细越好。给我5000个代码的例子  t616"


bbb = r'''https://d.docs.live.net/9122e41a29eea899/sb_yufengguang/doc/t6_doc/Ssh%20%E7%9A%84%E5%91%BD%E4%BB%A4%E8%AF%A6%E8%A7%A3%E8%A7%A3%E9%87%8A%E7%BB%99%E6%88%91%E3%80%82%E8%B6%8A%E8%AF%A6%E7%BB%86%E8%B6%8A%E5%A5%BD%E3%80%82%E7%BB%99%E6%88%915000%E4%B8%AA%E4%BB%A3%E7%A0%81%E7%9A%84%E4%BE%8B%E5%AD%90%20%20t616.docx
'''