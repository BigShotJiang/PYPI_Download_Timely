aaa = "pywin32 ppt workbook_xls__20250613161729610381"


bbb = r"https://d.docs.live.net/9122e41a29eea899/sb_yufengguang/xls/pywin32%20ppt%20workbook_xls__20250613161729610381.xlsx"