aaa = "Protean  P2530006 客戶端组装安装无法到位  8D Report Form   8D ppt 5Y分析 t611"


bbb = r"https://d.docs.live.net/9122e41a29eea899/sb_yufengguang/ppt/t6/Protean%20%20P2530006%20%E5%AE%A2%E6%88%B6%E7%AB%AF%E7%BB%84%E8%A3%85%E5%AE%89%E8%A3%85%E6%97%A0%E6%B3%95%E5%88%B0%E4%BD%8D%20%208D%20Report%20Form%20%20%208D%20ppt%205Y%E5%88%86%E6%9E%90%20t611.pptx"