aaa = "PPS Plastic Validation Plan-20250523 甘特图 t610"

bbb = r"https://d.docs.live.net/9122e41a29eea899/sb_yufengguang/xls/t6/PPS%20Plastic%20Validation%20Plan-20250523%20%E7%94%98%E7%89%B9%E5%9B%BE%20t610.xlsx"