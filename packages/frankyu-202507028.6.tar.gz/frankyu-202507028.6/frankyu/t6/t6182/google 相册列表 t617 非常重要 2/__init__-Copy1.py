aaa = "google 相册列表 t617 非常重要 "

bbb = r"https://d.docs.live.net/9122e41a29eea899/sb_yufengguang/xls/t6/google%20%E7%9B%B8%E5%86%8C%E5%88%97%E8%A1%A8%20t617%20%E9%9D%9E%E5%B8%B8%E9%87%8D%E8%A6%81%20.xlsx"