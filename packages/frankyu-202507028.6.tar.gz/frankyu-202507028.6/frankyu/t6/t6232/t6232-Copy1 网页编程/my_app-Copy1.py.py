import streamlit as st

st.title("我的第一个 Streamlit 应用")
st.write("你好，Streamlit！这是一个简单的文本展示。")