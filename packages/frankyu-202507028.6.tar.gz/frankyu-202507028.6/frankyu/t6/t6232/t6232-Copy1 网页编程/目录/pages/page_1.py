import streamlit as st

st.title("页面 1")
st.write("这是页面 1 的内容。")
st.slider("页面 1 的滑块", 0, 100)