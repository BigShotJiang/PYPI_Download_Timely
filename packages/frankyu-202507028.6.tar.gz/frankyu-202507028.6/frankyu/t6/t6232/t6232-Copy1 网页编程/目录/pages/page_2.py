import streamlit as st

st.title("页面 2")
st.write("这是页面 2 的内容。")
st.text_input("页面 2 的输入框", "输入一些文本")