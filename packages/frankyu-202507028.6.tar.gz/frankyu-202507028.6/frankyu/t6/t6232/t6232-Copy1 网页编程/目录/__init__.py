import streamlit as st

st.title("主应用页面")
st.sidebar.success("从侧边栏选择一个页面。")

st.write("欢迎来到我的 Streamlit 多页应用！")
st.write("你可以在左侧的侧边栏中找到不同的页面。")