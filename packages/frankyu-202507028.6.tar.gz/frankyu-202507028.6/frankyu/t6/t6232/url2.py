bbb = r'https://d.docs.live.net/380c326fa2fd9c70/%E7%A7%81%E4%BA%BA%E6%96%87%E4%BB%B6%EF%BC%8Cdengchunying1988/%E6%A1%8C%E9%9D%A2%201/%E5%AD%A6%E4%B9%A0/%E5%AE%B6%E5%BA%AD%E8%B4%A6%E7%B0%BF%E6%9B%B4%E6%96%B0%E4%BA%8E2025%E5%B9%B43%E6%9C%8812%E6%97%A5.xlsx'
aaa = '家庭账簿更新于2025年3月12日'

import frankyu.xlsx.initialize_excel as xl
app,b,c = xl.initialize_excel()

 
ccc = ""
for i in app.Workbooks:
    #print(i.Name)
    if aaa in i.Name :
        ccc = aaa
        #print(ccc)
        print(aaa,"已经打开,程序退出")
        break
if ccc == "":
    app.Workbooks.Open(bbb)
    print(aaa,"已经打开")
    
    
    
    
import frankyu.frankyu as fr
fr.daoJiShi_t2(5)
