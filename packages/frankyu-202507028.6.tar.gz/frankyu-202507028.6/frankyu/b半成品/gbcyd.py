import frankyu.frankyu as fr

fr.gbc("YoudaoDict")