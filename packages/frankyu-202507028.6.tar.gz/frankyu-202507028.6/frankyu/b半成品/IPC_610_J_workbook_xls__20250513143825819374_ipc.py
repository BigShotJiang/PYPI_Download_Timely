aaa = "IPC_610_J_workbook_xls__20250513143825819374"
print(aaa)

bbb = r"https://d.docs.live.net/9122e41a29eea899/sb_yufengguang/xls/IPC_610_J_workbook_xls__20250513143825819374.xlsx"

import f_excel.d单函数.open_or_add_process_excel_with_r1c1 as op


op.open_or_add_process_excel_with_r1c1_0(bbb)

from time import *
sleep(10)