


import frankyu.kill_program as gbc
gbc.kill_program("onedrive")