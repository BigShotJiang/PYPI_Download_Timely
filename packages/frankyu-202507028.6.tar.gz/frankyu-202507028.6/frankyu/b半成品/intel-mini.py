import frankyu.other.ip_check_and_adjust_1 as  ip
ip.check_and_adjust("intel-mini")

print("成功了")

import os
os.system("ping 127.1")