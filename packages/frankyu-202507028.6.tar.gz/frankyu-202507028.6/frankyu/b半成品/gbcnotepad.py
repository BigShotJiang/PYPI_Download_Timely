import frankyu.frankyu as fr
fr.gbc("notepad")