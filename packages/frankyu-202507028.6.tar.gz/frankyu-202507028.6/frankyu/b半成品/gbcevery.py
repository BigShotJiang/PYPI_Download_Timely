from frankyu.frankyu import *
gbc("every")
import time
time.sleep(5)