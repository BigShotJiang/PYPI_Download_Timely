from frankyu.frankyu  import *
gbc("pycharm")