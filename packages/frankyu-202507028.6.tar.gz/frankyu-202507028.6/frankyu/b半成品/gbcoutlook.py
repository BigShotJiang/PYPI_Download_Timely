from frankyu.frankyu  import *
gbc("outlook")