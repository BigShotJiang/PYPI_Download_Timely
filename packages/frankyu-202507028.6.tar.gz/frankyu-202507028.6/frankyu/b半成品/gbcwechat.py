from frankyu.frankyu import *
gbc("wechat")