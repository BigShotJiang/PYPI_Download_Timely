from frankyu.frankyu import *
gbc("AcroRd")