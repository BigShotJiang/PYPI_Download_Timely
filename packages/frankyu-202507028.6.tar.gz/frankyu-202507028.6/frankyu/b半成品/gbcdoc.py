from frankyu.frankyu  import *
gbc("word")