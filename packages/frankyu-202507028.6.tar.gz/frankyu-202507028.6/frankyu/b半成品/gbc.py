import frankyu.frankyu

fr = frankyu.frankyu

aaa  = "outlook excel edge chrome onedrive AcroRd32 WINWORD POWERPNT pycharm YoudaoDict".split(" ")

bbb  = "notepad python cmd".split(" ")

ccc = "wechat every".split(" ")


aaa = aaa+bbb

#aaa = aaa+ccc



for i in aaa:
    fr.gbc(i)