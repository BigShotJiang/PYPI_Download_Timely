

#import frankyu

from frankyu import kill_program ,frankyu

print("20250313")


frankyu.daoJiShi_t2(3)

#m = "swriter mspaint every".split(" ")
m = []

m = m + ["SnippingTool"]

m = m + ["team"]

m = m + ["edge", "chrome", "outlook",   "POWERPNT", "YoudaoDict", "Picasa3", "WinRAR", "AcroRd32", "Xmind"]

# m = m  + ["WeChat","WeChatStore"]

# m = m +  ["Everything" ]


m = m + ["iCloud", "notepad"]

m = m + ["cmd"]
m = m + ["pycha"]

m = m + ["WINWORD", ]

m = m + ["Foxmail", "wemeetapp", "WhatsApp", ]
m = m + ["onedrive"]

for i in m:
    


    #frankyu.gbc(i)
    kill_program.kill_program(i)
    

frankyu.daoJiShi_t2(30)

 



