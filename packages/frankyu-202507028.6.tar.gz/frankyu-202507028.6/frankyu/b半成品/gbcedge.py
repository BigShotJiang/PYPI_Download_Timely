import frankyu.frankyu as fr
fr.gbc("edge")