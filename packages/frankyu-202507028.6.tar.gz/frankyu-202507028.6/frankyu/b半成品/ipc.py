aaa ='IPC-A-610 ^0J-STD-001 ^0 IPC-7711_7721 最新版workbook_20250512111752814764'

bbb=r"https://d.docs.live.net/9122e41a29eea899/sb_yufengguang/xls/IPC-A-610%20%5e0J-STD-001%20%5e0%20IPC-7711_7721%20%E6%9C%80%E6%96%B0%E7%89%88workbook_20250512111752814764.xlsx"

aaa.replace(" ","")



#!pip install --upgrade frankyu



bbb

import f_excel.d单函数.open_or_add_process_excel_with_r1c1 as open_or_add_process_excel_with_r1c1





open_or_add_process_excel_with_r1c1.open_or_add_process_excel_with_r1c1(bbb)

import frankyu.frankyu as fr

fr.dao_ji_shi(10)