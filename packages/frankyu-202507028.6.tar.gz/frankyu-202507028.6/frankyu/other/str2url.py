def str2url(name = 'intel-mini'):
    aaa  = "http://intel-mini:7777/"
    
    
    

    
    bbb = ['http://', name, ':7777/']
    
    cm ="".join(bbb)
    print(cm)
    return cm
if __name__ == "__main__":
    
    str2url()