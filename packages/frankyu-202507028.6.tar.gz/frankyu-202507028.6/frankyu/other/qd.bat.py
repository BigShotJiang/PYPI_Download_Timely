import os

os.getcwd()

ddd = r'start  explorer  "%appdata%\Microsoft\Windows\Start Menu\Programs\Startup"'

os.system(ddd)