import frankyu.pptx.create_new_ppt_presentation as cr

cr.create_new_ppt_presentation()