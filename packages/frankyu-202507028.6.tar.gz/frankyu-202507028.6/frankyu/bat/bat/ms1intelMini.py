ddd = "ms 1 intel-mini"

import os

os.system(ddd)