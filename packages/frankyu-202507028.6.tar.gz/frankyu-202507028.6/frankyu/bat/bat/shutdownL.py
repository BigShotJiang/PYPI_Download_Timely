ddd = "shutdown.exe -l"

import os

os.system(ddd)