from django.apps import AppConfig


class BulmaConfig(AppConfig):
    name = 'bulma'
