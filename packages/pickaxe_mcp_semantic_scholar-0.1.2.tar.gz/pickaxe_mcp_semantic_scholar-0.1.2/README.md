# PXE Semantic Scholar

Provides access to the Semantic Scholar API

## Installation

uvx:

```
{
  "mcpServers": {
    "pickaxe-mcp-semantic-scholar": {
      "command": "uvx",
      "args": [
        "pickaxe-mcp-semantic-scholar"
      ],
      "env": {
        "SEMANTIC_SCHOLAR_API_KEY": "..."
      }
    }
  }
}
```
