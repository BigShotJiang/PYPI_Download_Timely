__title__ = "turbobt"
__description__ = "A next generation Bittensor SDK, for Python 3."
__version__ = "0.1.0"
