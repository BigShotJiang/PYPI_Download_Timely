# Prachi_Pattern 
This is a simple Package to print a patterns


## Installaytion 

Install it using pip:

pip install Prachi_Pattern


from Pattern import (pyramid,right_angle,left_angle)


# right_angle

pyramid(5)

# output

*
**
***
****
*****



