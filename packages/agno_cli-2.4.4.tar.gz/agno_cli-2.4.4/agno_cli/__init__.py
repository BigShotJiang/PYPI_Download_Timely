"""
Agno CLI SDK - A terminal-based assistant using Agno AI
"""

__version__ = "2.4.4"
__author__ = "Paul Gedeon"
__description__ = "A Python SDK CLI that wraps around Agno AI"

