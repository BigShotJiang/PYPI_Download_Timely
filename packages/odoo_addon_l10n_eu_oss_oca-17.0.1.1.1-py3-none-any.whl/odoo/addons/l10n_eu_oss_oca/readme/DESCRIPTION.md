This module has been created to help with the tax mapping according to
the EU One-Stop-Shop law, that concerns many companies that carry out
distance sales.

EU taxes have been checked in
\<<https://ec.europa.eu/taxation_customs/tedb/vatSearchForm.html>\>
