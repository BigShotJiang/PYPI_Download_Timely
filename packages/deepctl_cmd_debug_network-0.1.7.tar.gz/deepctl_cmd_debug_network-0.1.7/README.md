# deepctl-cmd-debug-network

Network debug subcommand for the Deepgram CLI (deepctl). This package provides the `network` subcommand under the `debug` command group, allowing users to debug network issues or problems connecting to api.deepgram.com
