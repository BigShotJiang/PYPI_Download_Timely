"""Network debug subcommand for deepctl."""

from .command import NetworkCommand

__all__ = ["NetworkCommand"]
