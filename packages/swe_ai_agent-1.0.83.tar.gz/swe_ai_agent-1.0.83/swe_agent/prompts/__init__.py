"""
Prompt definitions for the SWE Agent system.
Clean, tool-based prompts following LangGraph best practices.
"""