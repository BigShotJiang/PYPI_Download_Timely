'''Django plugin to get version info from the running application, so that we can make versioned URL for static files.'''


__version__ = '0.9'
