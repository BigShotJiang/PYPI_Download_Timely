from pathlib import Path

__all__ = ("ROOT_DIR",)

ROOT_DIR = Path(__file__).parent.parent
