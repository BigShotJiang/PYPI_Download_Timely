Wishlist
========

By adopting open-source best practices, we hope ocetrac will grow into a widely used, community-based project. We anticipate ocetrac will have broad applications in geoscience and are excited to see it used in other domains besides oceanography.