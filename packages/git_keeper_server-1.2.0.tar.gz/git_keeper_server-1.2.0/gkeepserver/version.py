# This file was generated automatically and should not be edited manually.
# Instead, edit the VERSION file in the top level directory of the git-keeper
# project and then run bump_version.py.

__version__ = '1.2.0'
