def test_import_santanello_soil_heat_flux():
    from santanello_soil_heat_flux import santanello_soil_heat_flux
