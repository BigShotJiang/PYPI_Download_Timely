# charchecker/__init__.py
from .checker import check_character
