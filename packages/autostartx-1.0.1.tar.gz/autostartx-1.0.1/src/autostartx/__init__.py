"""Autostartx - 命令行程序服务化工具."""

__version__ = "1.0.1"
__author__ = "Autostartx"
__description__ = "将任何命令行程序转换为可自动重启的后台服务"
