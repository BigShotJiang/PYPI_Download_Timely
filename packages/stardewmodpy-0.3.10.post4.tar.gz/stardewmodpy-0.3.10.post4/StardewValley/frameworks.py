frameworksList={
    "ContentPatcher":{
        "url_download": "https://www.nexusmods.com/stardewvalley/mods/1915",
        "UniqueID": "Pathoschild.ContentPatcher",
        "Dependencies": []
    },
    "SlingShotFramework":{
        "url_download": "https://www.nexusmods.com/stardewvalley/mods/28489",
        "UniqueID": "alichan.SlingShotFramework",
        "Dependencies": []
    },
    "FarmTypeManager":{
        "url_download": "https://www.nexusmods.com/stardewvalley/mods/3231",
        "UniqueID": "Esca.FarmTypeManager",
        "Dependencies": []
    },
    "ItemExtensions":{
        "url_download": "https://www.nexusmods.com/stardewvalley/mods/20357",
        "UniqueID": "mistyspring.ItemExtensions",
        "Dependencies": [
            "ContentPatcher"
        ]
    }
}