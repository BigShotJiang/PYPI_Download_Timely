from ...Data import modelsData


class AddingToStats(modelsData):
    def __init__(self):
        pass

    def getJson(self):
        return "None"

    class Copper(modelsData):
        def __init__(self):
            pass

        def getJson(self):
            return "Cooper"
    
    class Diamonds(modelsData):
        def __init__(self):
            pass

        def getJson(self):
            return "Diamonds"
    
    class GeodesBroken(modelsData):
        def __init__(self):
            pass

        def getJson(self):
            return "GeodesBroken"
    
    class Gold(modelsData):
        def __init__(self):
            pass

        def getJson(self):
            return "Gold"
    
    def Iridium(modelsData):
        def __init__(self):
            pass

        def getJson(self):
            return "Iridium"
    
    def Iron(modelsData):
        def __init__(self):
            pass

        def getJson(self):
            return "Iron"
    
    def MysticStones(modelsData):
        def __init__(self):
            pass

        def getJson(self):
            return "MysticStones"
    
    def OtherGems(modelsData):
        def __init__(self):
            pass

        def getJson(self):
            return "OtherGems"
    
    def PrismaticShards(modelsData):
        def __init__(self):
            pass

        def getJson(self):
            return "PrismaticShards"
    
    def Stone(modelsData):
        def __init__(self):
            pass

        def getJson(self):
            return "Stone"
    
    def Stumps(modelsData):
        def __init__(self):
            pass

        def getJson(self):
            return "Stumps"
    
    def Seeds(modelsData):
        def __init__(self):
            pass

        def getJson(self):
            return "Seeds"
    
    def Weeds(modelsData):
        def __init__(self):
            pass

        def getJson(self):
            return "Weeds"