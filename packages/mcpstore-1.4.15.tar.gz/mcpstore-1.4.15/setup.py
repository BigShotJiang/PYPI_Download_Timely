#!/usr/bin/env python
"""
setup.py for mcpstore - 向后兼容文件
主要配置在 pyproject.toml 中
"""
from setuptools import setup

if __name__ == "__main__":
    setup()
