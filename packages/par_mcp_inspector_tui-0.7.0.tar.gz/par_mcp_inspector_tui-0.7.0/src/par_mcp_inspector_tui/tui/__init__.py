"""TUI components for MCP Inspector."""

from .app import MCPInspectorApp

__all__ = ["MCPInspectorApp"]
