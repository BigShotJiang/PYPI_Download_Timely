name = "kiauhoku"

from .stargrid import StarGrid, StarGridInterpolator
from .stargrid import install_grid, load_interpolator, download
from .stargrid import load_grid, load_full_grid, load_eep_grid

__version__ = "2.1.2"
