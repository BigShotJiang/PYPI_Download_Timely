"""Pruebas del módulo ``asiic_holographic``."""

