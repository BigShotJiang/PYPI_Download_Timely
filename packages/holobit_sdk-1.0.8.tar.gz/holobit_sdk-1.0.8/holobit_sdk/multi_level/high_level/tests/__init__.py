"""Pruebas del módulo de nivel alto."""

