"""Pruebas del módulo de nivel medio."""

