"""Pruebas del módulo ``transpiler``."""

