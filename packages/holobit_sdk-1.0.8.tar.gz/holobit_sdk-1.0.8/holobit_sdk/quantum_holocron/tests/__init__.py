"""Pruebas para el módulo ``quantum_holocron``."""

