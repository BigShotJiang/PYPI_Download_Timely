"""Claude Everything Agent - A general purpose agent with sub-agent and todo capabilities."""

__version__ = "0.0.1"