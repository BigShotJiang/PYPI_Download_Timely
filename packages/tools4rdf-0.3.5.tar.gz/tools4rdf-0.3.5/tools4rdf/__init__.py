from tools4rdf.network.network import OntologyNetwork

