`fps-login` implements the login page for [fps-auth](../auth/#fps-auth)'s token authentication.
