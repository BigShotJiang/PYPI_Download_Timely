`fps-kernels` implements the kernels API, i.e. launching and stopping kernels, serving the kernel protocol over WebSocket, etc.
