# fps-kernels

An FPS plugin for the kernels API.
