# fps-notebook

An FPS plugin for the Notebook API.
