# fps-lab

An FPS plugin for the JupyterLab/Notebook API.
