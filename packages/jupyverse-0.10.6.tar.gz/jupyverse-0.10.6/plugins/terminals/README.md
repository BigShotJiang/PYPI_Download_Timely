# fps-terminals

An FPS plugin for the terminals API.
