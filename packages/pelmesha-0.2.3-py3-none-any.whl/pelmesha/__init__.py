"""
pelmesha

pelmesha is a Python library for loading, preprocessing, processing, storage and extracting peaklists of Mass Spectrometry Imaging (MSI) data.
"""

__author__ = 'Andrey Kuzin'
__credits__ = 'Moscow Institue of Physics and Technology'
