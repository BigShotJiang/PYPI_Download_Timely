from osteoid import Skeleton
PrecomputedSkeleton = Skeleton # backwards compatibility
