import cli_helpers


def test_cli_helpers():
    assert True
