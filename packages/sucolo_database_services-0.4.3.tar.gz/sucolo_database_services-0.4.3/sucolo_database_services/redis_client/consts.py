# sufficies
HEX_SUFFIX = "_hex_centers"
POIS_SUFFIX = "_pois"
