"""GCA Analyzer CLI Entrypoint."""

from gca_analyzer.main import main_cli

if __name__ == "__main__":  # pragma: no cover
    main_cli()
