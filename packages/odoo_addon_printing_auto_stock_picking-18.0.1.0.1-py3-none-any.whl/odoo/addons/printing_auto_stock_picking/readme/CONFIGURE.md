Go to the Operation Type and configure which report or attachment to
print.
