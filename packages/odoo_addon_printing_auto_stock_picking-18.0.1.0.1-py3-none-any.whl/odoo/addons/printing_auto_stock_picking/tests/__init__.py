from . import test_printing_auto_stock
