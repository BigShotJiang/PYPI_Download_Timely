from .system_monitor import SystemMonitor
from .system_logger import SystemLogger

_system_logger = SystemLogger()
_system_monitor = SystemMonitor()
