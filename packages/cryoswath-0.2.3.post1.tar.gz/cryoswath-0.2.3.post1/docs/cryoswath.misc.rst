cryoswath.misc module
=====================

.. automodule:: cryoswath.misc
   :members:
   :undoc-members:
   :show-inheritance:
   