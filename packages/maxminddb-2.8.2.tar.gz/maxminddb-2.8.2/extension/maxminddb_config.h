/* This is just a placeholder. We configure everything in setup.py. */
