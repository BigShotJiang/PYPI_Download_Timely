"""Tests for gfm."""
