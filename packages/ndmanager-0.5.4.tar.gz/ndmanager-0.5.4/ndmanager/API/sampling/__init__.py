"""A collection of classes for nuclear data sampling with sandy"""
