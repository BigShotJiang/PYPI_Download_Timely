"Definition of the `nds` command"
