from ufo2ft.featureWriters.markFeatureWriter import MarkFeatureWriter


class ContextualMarkFeatureWriter(MarkFeatureWriter):
    pass
