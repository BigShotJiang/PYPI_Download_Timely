from patientMatcher.utils.disease import Diseases
from patientMatcher.utils.hpo import HPO, HPOIC

hpo = HPO()
diseases = Diseases()
hpoic = HPOIC()
