## Description
### Added/Changed/Fixed
-

### How to test
- [ ]

### Expected outcome
- 

## Review
- [ ] Tests executed by 
- [ ] "Merge and deploy" approved by

### This [version](https://semver.org/) is a
- [ ] **MAJOR** - when you make incompatible API changes
- [x] **MINOR** - when you add functionality in a backwards compatible manner
- [ ] **PATCH** - when you make backwards compatible bug fixes or documentation/instructions