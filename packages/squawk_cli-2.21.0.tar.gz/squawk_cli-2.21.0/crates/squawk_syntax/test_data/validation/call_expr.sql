-- Trino/Snowflake/Databricks extension that Postgres doesn't support
select try_cast(x as int);
