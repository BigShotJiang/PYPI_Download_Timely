-- pg_docs
close foo;
close all;

