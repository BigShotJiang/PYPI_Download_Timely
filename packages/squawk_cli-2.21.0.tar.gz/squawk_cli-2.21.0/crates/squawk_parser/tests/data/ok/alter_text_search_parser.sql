-- rename
alter text search parser p rename to q;

-- set_schema
alter text search parser p set schema s;

alter text search parser foo.p set schema s;

