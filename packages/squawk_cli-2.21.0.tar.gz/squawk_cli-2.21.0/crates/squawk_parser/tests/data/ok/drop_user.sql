-- simple
drop user foo;

-- full
drop user if exists a, b, c;

