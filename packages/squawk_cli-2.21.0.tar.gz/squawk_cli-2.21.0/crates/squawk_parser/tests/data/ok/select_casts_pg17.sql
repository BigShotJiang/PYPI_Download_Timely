select foo[10].bar(10, 2) '100';
