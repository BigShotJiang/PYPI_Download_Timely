-- missing option
alter foreign data wrapper w;
