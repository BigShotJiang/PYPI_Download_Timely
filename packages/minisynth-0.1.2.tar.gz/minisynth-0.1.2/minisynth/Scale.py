import enum

class Scale(enum.Enum):
    LINEAR = 0
    LOGARITHMIC = 1