"""Init and utils."""

import logging


PACKAGE_NAME = "imio.dummypackage"

logger = logging.getLogger(PACKAGE_NAME)
