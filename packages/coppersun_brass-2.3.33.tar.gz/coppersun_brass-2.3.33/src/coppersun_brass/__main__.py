"""
Copper Sun Brass module entry point.
Allows running Copper Sun Brass as: python -m coppersun_brass
"""
from coppersun_brass.main import main

if __name__ == "__main__":
    main()