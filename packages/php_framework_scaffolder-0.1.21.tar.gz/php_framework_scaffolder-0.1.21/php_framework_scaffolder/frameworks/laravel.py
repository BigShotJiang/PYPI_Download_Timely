from .base import BaseFrameworkSetup
from php_framework_detector.core.models import FrameworkType
from typing import List


class LaravelSetup(BaseFrameworkSetup):
    def __init__(self):
        super().__init__(FrameworkType.LARAVEL)

    def get_setup_commands(self) -> List[List[str]]:
        return [
            [
                "docker",
                "compose",
                "exec",
                "-w",
                "/app",
                "app",
                "php",
                "artisan",
                "key:generate",
                "--force",
                "--no-interaction",
                "--no-ansi"
            ],
            [
                "docker",
                "compose",
                "exec",
                "-w",
                "/app",
                "app",
                "php",
                "artisan",
                "migrate",
                "--force",
                "--no-interaction",
                "--no-ansi"
            ]
        ]

    def get_routes_command(self) -> List[str]:
        return [
            "docker", 
            "compose",
            "exec",
            "-w",
            "/app",
            "app",
            "php",
            "-d",
            "error_reporting=~E_DEPRECATED",
            "artisan",
            "route:list",
            "--json",
            "--no-ansi",
            "--no-interaction"
        ]
