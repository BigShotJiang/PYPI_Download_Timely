# LlamaIndex Experimental

This is the experimental LlamaIndex extension to core. Experimental features
and classes can be found in this package. Features that reside in this project
are more volatile, but indeed can be promoted to core once they've stabilized.
