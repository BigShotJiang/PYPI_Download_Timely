"""
Python-FastUI-Widgets
======================
"""

__version__ = "1.0.3"
__author__ = "NumBNN"

print("fastuiwidgets/__init__.py")
from .components import *
from .common import *
from .window import *
from ._rc import resource