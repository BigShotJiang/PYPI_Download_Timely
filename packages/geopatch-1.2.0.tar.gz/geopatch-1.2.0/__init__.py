"""
GeoPatch - Python package for generating image patches from
satellite imagery to train deep learning models. 
author: hejarshahabi<at>gmail.com
Compatible with Python versions 3+
"""

name = 'GeoPatch'
__version__ = "1.2.0"