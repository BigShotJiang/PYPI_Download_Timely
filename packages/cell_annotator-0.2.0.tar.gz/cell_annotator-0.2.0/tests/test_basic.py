import cell_annotator


def test_package_has_version():
    assert cell_annotator.__version__ is not None
