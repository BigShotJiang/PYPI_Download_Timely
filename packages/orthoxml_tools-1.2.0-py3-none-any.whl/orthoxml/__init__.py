from .legacy.tree import OrthoXMLTree

__version__ = "1.2.0"
