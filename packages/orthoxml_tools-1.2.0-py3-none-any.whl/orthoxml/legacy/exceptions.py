# exceptions.py

class OrthoXMLParsingError(Exception):
    pass
