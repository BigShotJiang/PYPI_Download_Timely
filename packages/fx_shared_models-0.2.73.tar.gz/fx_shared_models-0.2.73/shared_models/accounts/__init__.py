"""
Shared models for accounts management.
This package contains the base models for accounts that can be used across different apps.
""" 