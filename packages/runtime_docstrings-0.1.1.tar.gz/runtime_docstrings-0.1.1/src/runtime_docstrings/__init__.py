from ._parser import docstrings as docstrings, get_docstrings as get_docstrings
