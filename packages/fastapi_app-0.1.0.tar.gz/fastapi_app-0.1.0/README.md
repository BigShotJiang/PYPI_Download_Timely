# FastAPI App

Prosta aplikacja FastAPI z frontendem i backendem
