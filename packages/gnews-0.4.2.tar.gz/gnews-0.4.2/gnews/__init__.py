from .gnews import GNews

name = "gnews"
__all__ = ["GNews"]
