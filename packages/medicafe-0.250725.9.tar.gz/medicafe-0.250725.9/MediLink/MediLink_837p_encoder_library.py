# MediLink_837p_encoder_library.py
from datetime import datetime
import sys, os
from MediLink import MediLink_ConfigLoader

project_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if project_dir not in sys.path:
    sys.path.append(project_dir)

from MediBot import MediBot_Preprocessor_lib
load_insurance_data_from_mains = MediBot_Preprocessor_lib.load_insurance_data_from_mains
from MediBot import MediBot_Crosswalk_Library

# Safe import for API functions - works in multiple contexts
try:
    from .MediLink_API_v3 import fetch_payer_name_from_api
except (ImportError, SystemError):
    try:
        from MediLink_API_v3 import fetch_payer_name_from_api
    except ImportError:
        import MediLink_API_v3
        fetch_payer_name_from_api = MediLink_API_v3.fetch_payer_name_from_api

# Safe import for utility functions - works in multiple contexts
try:
    from .MediLink_837p_utilities import (
        convert_date_format,
        format_datetime,
        get_user_confirmation,
        prompt_user_for_payer_id,
        format_claim_number,
        generate_segment_counts,
        handle_validation_errors,
        get_output_directory,
        winscp_validate_output_directory
    )
except (ImportError, SystemError):
    try:
        from MediLink_837p_utilities import (
            convert_date_format,
            format_datetime,
            get_user_confirmation,
            prompt_user_for_payer_id,
            format_claim_number,
            generate_segment_counts,
            handle_validation_errors,
            get_output_directory,
            winscp_validate_output_directory
        )
    except ImportError:
        import MediLink_837p_utilities
        convert_date_format = MediLink_837p_utilities.convert_date_format
        format_datetime = MediLink_837p_utilities.format_datetime
        get_user_confirmation = MediLink_837p_utilities.get_user_confirmation
        prompt_user_for_payer_id = MediLink_837p_utilities.prompt_user_for_payer_id
        format_claim_number = MediLink_837p_utilities.format_claim_number
        generate_segment_counts = MediLink_837p_utilities.generate_segment_counts
        handle_validation_errors = MediLink_837p_utilities.handle_validation_errors
        get_output_directory = MediLink_837p_utilities.get_output_directory
        winscp_validate_output_directory = MediLink_837p_utilities.winscp_validate_output_directory



# Constructs the ST segment for transaction set.
def create_st_segment(transaction_set_control_number):
    return "ST*837*{:04d}*005010X222A1~".format(transaction_set_control_number)

# Constructs the BHT segment based on parsed data.
def create_bht_segment(parsed_data):
    chart_number = parsed_data.get('CHART', 'UNKNOWN')
    return "BHT*0019*00*{}*{}*{}*CH~".format(
        chart_number, format_datetime(), format_datetime(format_type='time'))
    
# Constructs the HL segment for billing provider.
def create_hl_billing_provider_segment():
    return "HL*1**20*1~"

# Constructs the NM1 segment for billing provider and includes address and Tax ID.
def create_nm1_billing_provider_segment(config, endpoint):
    endpoint_config = config['endpoints'].get(endpoint.upper(), {})
    
    # Billing provider details
    billing_provider_entity_code = endpoint_config.get('billing_provider_entity_code', '85')
    billing_provider_npi_qualifier = endpoint_config.get('billing_provider_npi_qualifier', 'XX')
    #billing_provider_lastname = endpoint_config.get('billing_provider_lastname', config.get('default_billing_provider_name', 'DEFAULT NAME'))
    #billing_provider_firstname = endpoint_config.get('billing_provider_firstname', '')
    billing_provider_lastname = config.get('billing_provider_lastname', config.get('default_billing_provider_name', 'DEFAULT NAME'))
    billing_provider_firstname = config.get('billing_provider_firstname', '')
    billing_provider_npi = endpoint_config.get('billing_provider_npi', config.get('default_billing_provider_npi', 'DEFAULT NPI'))
    
    # Determine billing_entity_type_qualifier based on the presence of billing_provider_firstname
    billing_entity_type_qualifier = '1' if billing_provider_firstname else '2' 
    
    # Construct NM1 segment for the billing provider
    nm1_segment = "NM1*{}*{}*{}*{}****{}*{}~".format(
        billing_provider_entity_code, 
        billing_entity_type_qualifier,
        billing_provider_lastname, 
        billing_provider_firstname,
        billing_provider_npi_qualifier, 
        billing_provider_npi
    )
  
    # Construct address segments
    address_segments = []
    if config.get('billing_provider_address'):
        # N3 segment for address line
        address_segments.append("N3*{}~".format(config.get('billing_provider_address', 'NO ADDRESS')))
        # N4 segment for City, State, ZIP
        address_segments.append("N4*{}*{}*{}~".format(
            config.get('billing_provider_city', 'NO CITY'), 
            config.get('billing_provider_state', 'NO STATE'), 
            config.get('billing_provider_zip', 'NO ZIP')
        ))
    
    # Assuming Tax ID is part of the same loop, otherwise move REF segment to the correct loop
    ref_segment = "REF*EI*{}~".format(config.get('billing_provider_tin', 'NO TAX ID'))
    
    # Construct PRV segment if provider taxonomy is needed, are these just for Medicaid??
    #prv_segment = ""
    #if config.get('billing_provider_taxonomy'):
    #    prv_segment = "PRV*BI*PXC*{}~".format(config.get('billing_provider_taxonomy'))
    
    # Combine all the segments in the correct order, I think the PRV goes after the address and/or after ref
    segments = [nm1_segment]
    #if prv_segment:
    #    segments.append(prv_segment)
    segments.extend(address_segments)
    segments.append(ref_segment)
    
    return segments

# Constructs the NM1 segment and accompanying details for the service facility location.
def create_service_facility_location_npi_segment(config):
    """
    Constructs segments for the service facility location, including the NM1 segment for identification
    and accompanying N3 and N4 segments for address details.
    """
    facility_npi = config.get('service_facility_npi', 'DEFAULT FACILITY NPI')
    facility_name = config.get('service_facility_name', 'DEFAULT FACILITY NAME')
    address_line_1 = config.get('service_facility_address', 'NO ADDRESS')
    city = config.get('service_facility_city', 'NO CITY')
    state = config.get('service_facility_state', 'NO STATE')
    zip_code = config.get('service_facility_zip', 'NO ZIP')

    # NM1 segment for facility identification
    nm1_segment = "NM1*77*2*{}*****XX*{}~".format(facility_name, facility_npi)
    # N3 segment for facility address
    n3_segment = "N3*{}~".format(address_line_1)
    # N4 segment for facility city, state, and ZIP
    n4_segment = "N4*{}*{}*{}~".format(city, state, zip_code)

    return [nm1_segment, n3_segment, n4_segment]

# Constructs the NM1 segment for submitter name and includes PER segment for contact information.
def create_1000A_submitter_name_segment(patient_data, config, endpoint):
    """
    Creates the 1000A submitter name segment, including the PER segment for contact information.

    Args:
        patient_data (dict): Enriched patient data containing payer information.
        config (dict): Configuration settings.
        endpoint (str): Intended Endpoint for resolving submitter information.

    Returns:
        list: A list containing the NM1 segment for the submitter name and the PER segment for contact information.
    """
    endpoint_config = config['endpoints'].get(endpoint.upper(), {})
    submitter_id_qualifier = endpoint_config.get('submitter_id_qualifier', '46')  # '46' for ETIN or 'XX' for NPI
    submitter_name = endpoint_config.get('nm_103_value', 'DEFAULT NAME')  # Default name if not in config
    
    # Extract payer_id from patient_data
    payer_id = patient_data.get('payer_id', '')
    
    # Check if payer_id is Florida Blue (00590 or BCBSF) and assign submitter_id accordingly
    if payer_id in ['00590', 'BCBSF']:
        submitter_id = endpoint_config.get('nm_109_bcbsf', 'DEFAULT BCBSF ID')
    else:
        submitter_id = endpoint_config.get('nm_109_value', 'DEFAULT ID')  # Default ID if not specified in endpoint
    
    # Submitter contact details
    contact_name = config.get('submitter_name', 'NONE')
    contact_telephone_number = config.get('submitter_tel', 'NONE')
    
    # Get submitter first name to determine entity type qualifier
    submitter_first_name = config.get('submitter_first_name', '')
    # Determine entity_type_qualifier: '1' for individual (with first name), '2' for organization
    entity_type_qualifier = '1' if submitter_first_name else '2' # Make sure that this is correct. Original default was 2.
    
    # Construct NM1 segment for the submitter
    nm1_segment = "NM1*41*{}*{}*****{}*{}~".format(entity_type_qualifier, submitter_name, submitter_id_qualifier, submitter_id) # BUG - need to check submitter_name because this is written as fixed ****** which implies a single entry and not a first and last name. This is weird.
    
    # Construct PER segment for the submitter's contact information
    per_segment = "PER*IC*{}*TE*{}~".format(contact_name, contact_telephone_number)
    
    return [nm1_segment, per_segment]

# Constructs the NM1 segment for the receiver (1000B).
def create_1000B_receiver_name_segment(config, endpoint):
    # Retrieve endpoint specific configuration
    endpoint_config = config['endpoints'].get(endpoint.upper(), {})

    # Set the entity identifier code to '40' for receiver and qualifier to '46' for EDI, 
    # unless specified differently in the endpoint configuration.
    receiver_entity_code = '40'
    receiver_id_qualifier = endpoint_config.get('receiver_id_qualifier', '46')
    receiver_name = endpoint_config.get('receiver_name', 'DEFAULT RECEIVER NAME')
    receiver_edi = endpoint_config.get('receiver_edi', 'DEFAULT EDI')
    
    return "NM1*{entity_code}*2*{receiver_name}*****{id_qualifier}*{receiver_edi}~".format(
        entity_code=receiver_entity_code,
        receiver_name=receiver_name,
        id_qualifier=receiver_id_qualifier,
        receiver_edi=receiver_edi
    )

def payer_id_to_payer_name(parsed_data, config, endpoint, crosswalk, client):
    """
    Preprocesses payer information from parsed data and enriches parsed_data with the payer name and ID.

    Args:
        parsed_data (dict): Parsed data containing Z-dat information.
        config (dict): Configuration settings.
        endpoint (str): Intended Endpoint for resolving payer information.

    Returns:
        dict: Enriched parsed data with payer name and payer ID.
    """
    # Step 1: Extract insurance name from parsed data
    insurance_name = parsed_data.get('INAME', '')

    # Step 2: Map insurance name to payer ID
    payer_id = map_insurance_name_to_payer_id(insurance_name, config, client, crosswalk)

    # Step 3: Validate payer_id
    if payer_id is None:
        error_message = "Payer ID for '{}' cannot be None.".format(insurance_name)
        MediLink_ConfigLoader.log(error_message, level="WARNING")
        raise ValueError(error_message)

    # Step 4: Resolve payer name using payer ID
    payer_name = resolve_payer_name(payer_id, config, endpoint, insurance_name, parsed_data, crosswalk, client)

    # Enrich parsed_data with payer name and payer ID
    parsed_data['payer_name'] = payer_name
    parsed_data['payer_id'] = payer_id

    return parsed_data

# Then you can use the enriched parsed_data in your main function
def create_2010BB_payer_information_segment(parsed_data):
    """
    Creates the 2010BB payer information segment.

    Args:
        parsed_data (dict): Parsed data containing enriched payer information.

    Returns:
        str: The 2010BB payer information segment.
    """
    # Extract enriched payer name and payer ID
    payer_name = parsed_data.get('payer_name')
    payer_id = parsed_data.get('payer_id')

    # Validate payer_name and payer_id
    if not payer_name or not payer_id:
        error_message = "Payer name and payer ID must be provided."
        raise ValueError(error_message)

    # Build NM1 segment using provided payer name and payer ID
    return build_nm1_segment(payer_name, payer_id)



def resolve_payer_name(payer_id, config, primary_endpoint, insurance_name, parsed_data, crosswalk, client):
    # Check if the payer_id is in the crosswalk with a name already attached to it.
    if payer_id in crosswalk.get('payer_id', {}):
        payer_info = crosswalk['payer_id'][payer_id]
        MediLink_ConfigLoader.log("Payer ID {} found in crosswalk with name: {}".format(payer_id, payer_info['name']), level="DEBUG")
        return payer_info['name']  # Return the name from the crosswalk directly.
    
    # Step 1: Attempt to fetch payer name from API using primary endpoint
    MediLink_ConfigLoader.log("Attempting to resolve Payer ID {} via API.".format(payer_id), level="INFO")
    try:
        return fetch_payer_name_from_api(client, payer_id, config, primary_endpoint)
    except Exception as api_error:
        # Step 2: Log API resolution failure and initiate user intervention
        MediLink_ConfigLoader.log("API resolution failed for {}: {}. Initiating user intervention.".format(payer_id, str(api_error)), config, level="WARNING")
        
        # Step 3: Print warning message for user intervention
        print("\n\nWARNING: Unable to verify Payer ID '{}' for patient '{}'!".format(payer_id, parsed_data.get('CHART', 'unknown')))
        print("         Claims for '{}' may be incorrectly routed or fail without intervention.".format(insurance_name))
        print("\nACTION REQUIRED: Please verify the internet connection and the Payer ID by searching for it at the expected endpoint's website or using Google.")
        print("\nNote: If the Payer ID '{}' is incorrect for '{}', \nit may need to be manually corrected.".format(payer_id, insurance_name))
        print("If the Payer ID appears correct, you may skip the correction and force-continue with this one.")
        print("\nPlease check the Payer ID in the Crosswalk and the initial \ndata source (e.g., Carol's CSV) as needed.")
        print("If unsure, llamar a Dani for guidance on manual corrections.")
    
        # Step 4: Integrate user input logic
        user_decision = input("\nType 'FORCE' to force-continue with the Medisoft name, or press Enter to pause processing and make corrections: ").strip().lower()
        
        if user_decision == 'force':
            # Step 5: Fallback to truncated insurance name
            truncated_name = insurance_name[:10]  # Temporary fallback
            MediLink_ConfigLoader.log("Using truncated insurance name '{}' as a fallback for {}".format(truncated_name, payer_id), config, level="WARNING")
            return truncated_name
        elif not user_decision:
            # Step 6: Prompt user for corrected payer ID
            corrected_payer_id = prompt_user_for_payer_id(insurance_name)
            if corrected_payer_id:
                try:
                    resolved_name = fetch_payer_name_from_api(client, corrected_payer_id, config, primary_endpoint)
                    print("API resolved to insurance name: {}".format(resolved_name))
                    MediLink_ConfigLoader.log("API Resolved to standard insurance name: {} for corrected payer ID: {}".format(resolved_name, corrected_payer_id), config, level="INFO")
    
                    # Step 7: Ask for user confirmation using the helper
                    confirmation_prompt = "Proceed with updating the Payer ID for '{}'? (yes/no): ".format(resolved_name)
                    if get_user_confirmation(confirmation_prompt):
                        # Step 8: Load crosswalk
                        try:
                            config, crosswalk = MediLink_ConfigLoader.load_configuration()
                        except Exception as e:
                            print("Failed to load configuration and crosswalk: {}".format(e))
                            MediLink_ConfigLoader.log("Failed to load configuration and crosswalk: {}".format(e), config, level="ERROR")
                            exit(1)
                        
                        # Step 9: Update the crosswalk with the corrected Payer ID
                        if MediBot_Crosswalk_Library.update_crosswalk_with_corrected_payer_id(client, payer_id, corrected_payer_id, config, crosswalk):
                            return resolved_name
                        else:
                            print("Failed to update crosswalk with the corrected Payer ID.")
                            MediLink_ConfigLoader.log("Failed to update crosswalk with the corrected Payer ID.", config, level="ERROR")
                            exit(1)  # Consider handling failure differently.
                    else:
                        # Step 10: Handle rejection
                        print("User did not confirm the standard insurance name. Manual intervention is required.")
                        MediLink_ConfigLoader.log("User did not confirm the standard insurance name. Manual intervention is required.", config, level="CRITICAL")
                        
                        # TODO: CRITICAL ISSUE - Current rejection handling is incorrect
                        # The current implementation exits the program when a user rejects the standard insurance name,
                        # which is an overly aggressive approach. Instead, we should:
                        # 1. Prompt the user to manually enter the correct insurance name
                        # 2. Use that manually entered name to proceed with the claim processing
                        # 3. Update the crosswalk with the corrected payer name (requires a new function to be implemented)
                        # 4. Log the correction for future reference
                        #
                        # The insurance name confirmation is primarily a sanity check to verify the API recognizes the payer ID,
                        # not a critical validation for claim processing. The payer name is not used in the crosswalk or in the
                        # actual claims once they are built. The current implementation unnecessarily halts the entire process
                        # when this check fails, rather than providing a recovery path.
                        #
                        # When revisiting this code, the entire flow of interdependent functions should be reconsidered to
                        # ensure proper error handling and recovery mechanisms are in place throughout the process.
                        
                        # Placeholder for future implementation:
                        # corrected_name = input("Please enter the correct insurance name: ")
                        # MediLink_ConfigLoader.log(f"User provided corrected insurance name: {corrected_name}", config, level="INFO")
                        # print(f"Using manually entered insurance name: {corrected_name}")
                        # TODO: Implement update_crosswalk_with_corrected_payer_name(corrected_name, payer_id, config, crosswalk)
                        # return corrected_name
    
                        exit(1)  
                except Exception as e:
                    # Step 11: Handle exceptions during resolution
                    print("Failed to resolve corrected payer ID to standard insurance name: {}".format(e))
                    MediLink_ConfigLoader.log("Failed to resolve corrected payer ID to standard insurance name: {}".format(e), config, level="ERROR")
                    exit(1)  # Consider handling differently.
            else:
                # Step 12: Handle absence of corrected payer ID
                print("Exiting script. Please make the necessary corrections and retry.")
                MediLink_ConfigLoader.log("Exiting script due to absence of corrected Payer ID.", config, level="CRITICAL")
                exit(1)  # Consider handling differently.
        else:
            # Optional: Handle unexpected user input
            print("Invalid input. Manual intervention is required.")
            MediLink_ConfigLoader.log("Invalid user input during payer name resolution.", config, level="CRITICAL")
            exit(1)  # Consider handling differently.

def handle_missing_payer_id(insurance_name, config, crosswalk, client):
    # Reset config pull to make sure its not using the MediLink config key subset
    config, crosswalk = MediLink_ConfigLoader.load_configuration()
    
    # Step 1: Inform about the missing Payer ID
    print("Missing Payer ID for insurance name: {}".format(insurance_name))
    MediLink_ConfigLoader.log("Missing Payer ID for insurance name: {}".format(insurance_name), config, level="WARNING")
    
    # Step 2: Prompt the user for manual payer ID input
    payer_id = prompt_user_for_payer_id(insurance_name)
    
    if not payer_id:
        # Step 3: Handle absence of payer ID input
        message = "Unable to resolve missing Payer ID. Manual intervention is required."
        MediLink_ConfigLoader.log(message, config, level="CRITICAL")
        print(message)
        return None
    
    # Step 4: Resolve the payer ID to a standard insurance name via API
    try:
        # primary_endpoint=None should kick to the default in the API function.
        standard_insurance_name = resolve_payer_name(payer_id, config, primary_endpoint=None, insurance_name=insurance_name, parsed_data={}, crosswalk=crosswalk, client=client)
        message = "Resolved to standard insurance name: {} for payer ID: {}".format(standard_insurance_name, payer_id)
        print(message)
        MediLink_ConfigLoader.log(message, config, level="INFO")
    except Exception as e:
        # Step 5: Handle exceptions during resolution
        message = "Failed to resolve payer ID to standard insurance name: {}".format(e)
        print(message)
        MediLink_ConfigLoader.log(message, config, level="ERROR")
        return None
    
    # Step 6: Ask for user confirmation
    confirmation_prompt = "Is the standard insurance name '{}' correct? (yes/no): ".format(standard_insurance_name)
    if get_user_confirmation(confirmation_prompt):
        # Step 7: Update the crosswalk with the new payer ID and insurance name mapping
        try:
            MediLink_ConfigLoader.log("Updating crosswalk with payer ID: {} for insurance name: {}".format(payer_id, insurance_name), config, level="DEBUG")
            MediBot_Crosswalk_Library.update_crosswalk_with_new_payer_id(client, insurance_name, payer_id, config, crosswalk)
            return payer_id  # Return the payer_id after successful update
        except Exception as e:
            # Enhanced error message to include exception type and context
            error_message = "Failed to update crosswalk with new Payer ID: {}. Exception type: {}. Context: {}".format(
                e, type(e).__name__, str(e)
            )
            print(error_message)
            MediLink_ConfigLoader.log(error_message, config, level="ERROR")
            return None
    else:
        # Step 8: Handle rejection
        print("User did not confirm the standard insurance name. Manual intervention is required.")
        MediLink_ConfigLoader.log("User did not confirm the standard insurance name. Manual intervention is required.", config, level="CRITICAL")
        return None



def build_nm1_segment(payer_name, payer_id):
    # Step 1: Build NM1 segment using payer name and ID
    return "NM1*PR*2*{}*****PI*{}~".format(payer_name, payer_id)

def map_insurance_name_to_payer_id(insurance_name, config, client, crosswalk):
    """
    Maps insurance name to payer ID using the crosswalk configuration.

    Args:
        insurance_name (str): Name of the insurance.
        config (dict): Configuration settings.

    Returns:
        str: The payer ID corresponding to the insurance name.
    """
    try:        
        # Load crosswalk configuration only if 'payer_id' is not initialized
        if 'payer_id' not in crosswalk:
            _, crosswalk = MediLink_ConfigLoader.load_configuration(None, config.get('crosswalkPath', 'crosswalk.json'))
            
            # Ensure crosswalk is initialized and 'payer_id' key is available
            if 'payer_id' not in crosswalk:
                raise ValueError("Crosswalk 'payer_id' not found. Please run MediBot_Preprocessor.py with the --update-crosswalk argument.")

        # Load insurance data from MAINS to get insurance ID
        insurance_to_id = load_insurance_data_from_mains(config)
        
        # Get medisoft ID corresponding to the insurance name
        medisoft_id = insurance_to_id.get(insurance_name)
        if medisoft_id is None:
            error_message = "No Medisoft ID found for insurance name: {}. Consider checking MAINS directly.".format(insurance_name)
            MediLink_ConfigLoader.log(error_message, config, level="ERROR")
            # Asking for payer ID here is not the right approach.
            raise ValueError(error_message)
        
        # Convert medisoft_id to string to match the JSON data type
        medisoft_id_str = str(medisoft_id)
        
        # Get payer ID corresponding to the medisoft ID
        payer_id = None
        for payer, payer_info in crosswalk['payer_id'].items():
            if medisoft_id_str in payer_info['medisoft_id']:
                payer_id = payer
                break

        # Handle the case where no payer ID is found
        if payer_id is None:
            error_message = "No payer ID found for Medisoft ID: {}.".format(medisoft_id)
            MediLink_ConfigLoader.log(error_message, config, level="ERROR")
            print(error_message)
            payer_id = handle_missing_payer_id(insurance_name, config, crosswalk, client)

        if payer_id is None:
            raise ValueError("Payer ID cannot be None after all checks.")

        return payer_id

    except ValueError as e:
        if "JSON" in str(e) and "decode" in str(e):
            error_message = "Error decoding the crosswalk JSON file in map_insurance_name_to_payer_id"
            MediLink_ConfigLoader.log(error_message, config, level="CRITICAL")
            raise ValueError(error_message)
        else:
            error_message = "Unexpected error in map_insurance_name_to_payer_id: {}".format(e)
            MediLink_ConfigLoader.log(error_message, config, level="ERROR")
            raise e

def create_nm1_payto_address_segments(config):
    """
    Constructs the NM1 segment for the Pay-To Address, N3 for street address, and N4 for city, state, and ZIP.
    This is used if the Pay-To Address is different from the Billing Provider Address.
    """
    payto_provider_name = config.get('payto_provider_name', 'DEFAULT PAY-TO NAME')
    payto_address = config.get('payto_address', 'DEFAULT PAY-TO ADDRESS')
    payto_city = config.get('payto_city', 'DEFAULT PAY-TO CITY')
    payto_state = config.get('payto_state', 'DEFAULT PAY-TO STATE')
    payto_zip = config.get('payto_zip', 'DEFAULT PAY-TO ZIP')

    nm1_segment = "NM1*87*2*{}~".format(payto_provider_name)  # '87' indicates Pay-To Provider
    n3_segment = "N3*{}~".format(payto_address)
    n4_segment = "N4*{}*{}*{}~".format(payto_city, payto_state, payto_zip)

    return [nm1_segment, n3_segment, n4_segment]

def create_payer_address_segments(config):
    """
    Constructs the N3 and N4 segments for the payer's address.
    
    """
    payer_address_line_1 = config.get('payer_address_line_1', '')
    payer_city = config.get('payer_city', '')
    payer_state = config.get('payer_state', '')
    payer_zip = config.get('payer_zip', '')

    n3_segment = "N3*{}~".format(payer_address_line_1)
    n4_segment = "N4*{}*{}*{}~".format(payer_city, payer_state, payer_zip)

    return [n3_segment, n4_segment]

# Constructs the PRV segment for billing provider.
def create_billing_prv_segment(config, endpoint):
    if endpoint.lower() == 'optumedi':
        return "PRV*BI*PXC*{}~".format(config['billing_provider_taxonomy'])
    return ""

# Constructs the HL segment for subscriber [hierarchical level (HL*2)]
def create_hl_subscriber_segment():
    return ["HL*2*1*22*0~"]

# (2000B Loop) Constructs the SBR segment for subscriber based on parsed data and configuration.
def create_sbr_segment(config, parsed_data, endpoint):
    # Determine the payer responsibility sequence number code based on the payer type
    # If the payer is Medicare, use 'P' (Primary)
    # If the payer is not Medicare and is primary insurance, use 'P' (Primary)
    # If the payer is secondary insurance after Medicare, use 'S' (Secondary)
    # Assume everything is Primary for now.
    responsibility_code = 'P'

    # Insurance Type Code
    insurance_type_code = insurance_type_selection(parsed_data)

    # TODO (COB ENHANCEMENT): Enhanced SBR segment for Medicare and COB support
    # For Medicare Part B: SBR09 = "MB"
    # For Medicare Advantage: SBR09 = "MA" 
    # For secondary claims: SBR01 = "S"
    # See MediLink_837p_cob_library.create_enhanced_sbr_segment() for implementation

    # Construct the SBR segment using the determined codes
    sbr_segment = "SBR*{responsibility_code}*18*******{insurance_type_code}~".format(
        responsibility_code=responsibility_code,
        insurance_type_code=insurance_type_code
    )
    return sbr_segment

def insurance_type_selection(parsed_data):
    """
    Quick Fix: This funtion selects the insurance type for a patient based on predefined codes.
    
    TODO (HIGH SBR09) Finish making this function. 
    This should  eventually integrate into a menu upstream. This menu flow probably needs to be alongside the suggested endpoint flow.
    For now let's make a menu here and then figure out the automated/API method to getting this per patient as there are no
    useful historical patterns other than to say that the default should be PPO (12), then CI, then FI as most common options, 
    followed by the rest. 
    
    Present a user-selectable menu of insurance types based on predefined codes.
    User needs to input the desired 2 character code for that patient or default to PPO.
    
    Currently implements a simple text-based selection menu to choose
    an insurance type for a patient. The default selection is '12' for PPO, but the user
    can input other codes as per the options listed. This initial implementation uses
    simple input/output functions for selection and can be replaced in the future by a 
    more dynamic interface or API-driven selection method.

    Future Enhancements:
    - Automate selection via an API that fetches patient data directly and auto-assigns the insurance type.
    - Error handling to manage incorrect inputs and retry mechanisms.
    
    Parameters:
    - parsed_data (dict): Contains patient's last name under key 'LAST'.
    
    Returns:
    - str: The insurance type code selected by the user.
    
    """
    MediLink_ConfigLoader.log("insurance_type_selection(parsed_data): {}".format(parsed_data), level="DEBUG")
    
    # Check if insurance type is already assigned and is valid
    insurance_type_code = parsed_data.get('insurance_type')
    if insurance_type_code and len(insurance_type_code) == 2 and insurance_type_code.isalnum():
        MediLink_ConfigLoader.log("Insurance type already assigned: {}".format(insurance_type_code), level="DEBUG")
        return insurance_type_code
    elif insurance_type_code:
        MediLink_ConfigLoader.log("Invalid insurance type: {}".format(insurance_type_code), level="WARNING")
    
    print("\nInsurance Type Validation Error: Select the insurance type for patient {}: ".format(parsed_data['LAST']))

    # Retrieve insurance options with codes and descriptions
    config, _ = MediLink_ConfigLoader.load_configuration()
    insurance_options = config['MediLink_Config'].get('insurance_options')
    
    # TODO (COB ENHANCEMENT): Enhanced insurance options for Medicare support
    # See MediLink_837p_cob_library.get_enhanced_insurance_options() for Medicare codes:
    # - MB: Medicare Part B
    # - MA: Medicare Advantage  
    # - MC: Medicare Part C

    def prompt_display_insurance_options():
        # Prompt to display full list
        display_full_list = input("Do you want to see the full list of insurance options? (yes/no): ").strip().lower()

        # Display full list if user confirms
        if display_full_list in ['yes', 'y']:
            MediLink_UI.display_insurance_options(insurance_options)

    # Horrible menu
    prompt_display_insurance_options()
    
    # Default selection
    insurance_type_code = '12'

    # User input for insurance type
    user_input = input("Enter the 2-character code for the insurance type (or press Enter to default to '12' for PPO): ").strip().upper()

    # Validate input and set the insurance type code
    if user_input in insurance_options:
        insurance_type_code = user_input
    else:
        print("Skipped or Input not recognized. Defaulting to Preferred Provider Organization (PPO)\n")

    return insurance_type_code

# Constructs the NM1 segment for subscriber based on parsed data and configuration.
def create_nm1_subscriber_segment(config, parsed_data, endpoint):
    if endpoint.lower() == 'optumedi':
        entity_identifier_code = config['endpoints']['OPTUMEDI'].get('subscriber_entity_code', 'IL')
    else:
        entity_identifier_code = 'IL'  # Default value if endpoint is not 'optumedi'

    return "NM1*{entity_identifier_code}*1*{last_name}*{first_name}*{middle_name}***MI*{policy_number}~".format(
        entity_identifier_code=entity_identifier_code,
        last_name=parsed_data['LAST'].replace('_', ' '), # Replace underscores with spaces in the name.
        first_name=parsed_data['FIRST'].replace('_', ' '),
        middle_name=parsed_data['MIDDLE'],
        policy_number=parsed_data['IPOLICY']
    )

# Constructs the N3 and N4 segments for subscriber address based on parsed data.
def create_subscriber_address_segments(parsed_data):
    return [
        "N3*{}~".format(parsed_data['ISTREET']),
        "N4*{}*{}*{}~".format(
            parsed_data['ICITY'],  
            parsed_data['ISTATE'],  
            parsed_data['IZIP'][:5]
        )
    ]

# Constructs the DMG segment for subscriber based on parsed data.
def create_dmg_segment(parsed_data):
    return "DMG*D8*{}*{}~".format(
        convert_date_format(parsed_data['BDAY']),  
        parsed_data['SEX'] # ensure it returns a string instead of a list if it only returns one segment
    )

def create_nm1_rendering_provider_segment(config, is_rendering_provider_different=False):
    """
    # BUG This is getting placed incorrectly. Has this been fixed??
    
    Constructs the NM1 segment for the rendering provider in the 2310B loop using configuration data.
    
    Parameters:
    - config: Configuration dictionary including rendering provider details.
    - is_rendering_provider_different: Boolean indicating if rendering provider differs from billing provider.
    
    Returns:
    - List containing the NM1 segment for the rendering provider if required, otherwise an empty list.
    """
    if is_rendering_provider_different:
        segments = []
        rp_npi = config.get('rendering_provider_npi', '')
        rp_last_name = config.get('rendering_provider_last_name', '')
        rp_first_name = config.get('rendering_provider_first_name', '')

        # NM1 Segment for Rendering Provider
        segments.append("NM1*82*1*{0}*{1}**XX*{2}~".format(
            rp_last_name, 
            rp_first_name, 
            rp_npi
        ))
        
        # PRV Segment for Rendering Provider Taxonomy
        if config.get('rendering_provider_taxonomy'):
            segments.append("PRV*PE*PXC*{}~".format(config['billing_provider_taxonomy']))
        
        return segments
    else:
        return []



# Constructs the CLM and related segments based on parsed data and configuration.
def create_clm_and_related_segments(parsed_data, config, crosswalk): 
    """
    Insert the claim information (2300 loop), 
    ensuring that details such as claim ID, total charge amount,and service date are included.
    
    The HI segment for Health Care Diagnosis Codes should accurately reflect the diagnosis related to the service line.
    
    Service Line Information (2400 Loop):
    Verify that the service line number (LX), professional service (SV1), and service date (DTP) segments contain
    accurate information and are formatted according to the claim's details.
    
    TODO (COB ENHANCEMENT): This function needs enhancement for COB scenarios:
    1. Enhanced CLM segment with proper claim frequency (CLM05-3)
    2. Support for service-level COB adjudication (2430 loop)
    3. Integration with 835-derived adjudication data
    4. PWK segment support for attachments
    
    See MediLink_837p_cob_library.create_enhanced_clm_segment() for enhanced implementation.
    """
    
    # FINAL LINE OF DEFENSE: Validate all claim data before creating segments
    validated_data = validate_claim_data_for_837p(parsed_data, config, crosswalk)
    
    segments = []
    
    # Format the claim number
    chart_number = validated_data.get('CHART', '')
    date_of_service = validated_data.get('DATE', '')
    formatted_claim_number = format_claim_number(chart_number, date_of_service)
        
    # CLM - Claim Information
    # TODO (COB ENHANCEMENT): Enhanced claim frequency handling
    # For COB claims, CLM05-3 should be "1" (original) unless replacement logic applies
    claim_frequency = "1"  # Default to original
    # if validated_data.get('claim_type') == 'secondary':
    #     claim_frequency = "1"  # Original for secondary claims
    
    segments.append("CLM*{}*{}***{}:B:{}*Y*A*Y*Y~".format(
        formatted_claim_number,
        validated_data['AMOUNT'],
        validated_data['TOS'],
        claim_frequency))
    
    # HI - Health Care Diagnosis Code
    # Hardcoding "ABK" for ICD-10 codes as they are the only ones used now.
    medisoft_code = ''.join(filter(str.isalnum, validated_data['DIAG']))
    diagnosis_code = next((key for key, value in crosswalk.get('diagnosis_to_medisoft', {}).items() if value == medisoft_code), None)
    
    # This should never be None now due to validation, but keeping as safety check
    if diagnosis_code is None:
        raise ValueError("Diagnosis code mapping failed for patient {} with medisoft code {}".format(chart_number, medisoft_code))

    cleaned_diagnosis_code = ''.join(char for char in diagnosis_code if char.isalnum())
    segments.append("HI*ABK:{}~".format(cleaned_diagnosis_code))
    
    # (2310C Loop) Service Facility Location NPI and Address Information
    segments.extend(create_service_facility_location_npi_segment(config))
    
    # For future reference, SBR - (Loop 2320: OI, NM1 (2330A), N3, N4, NM1 (2330B)) - Other Subscriber Information goes here.
    # TODO (COB ENHANCEMENT): COB loops for secondary claims and Medicare adjudication
    # See MediLink_837p_cob_library for implementation of:
    # - create_2320_other_subscriber_segments() for secondary payer info
    # - create_2330B_prior_payer_segments() for Medicare prior payer
    # - create_2430_service_line_cob_segments() for service-level adjudication
    # - create_2330C_other_subscriber_name_segments() when patient != subscriber
    # TODO (COB ENHANCEMENT): Optional attachment references (PWK) for non-electronic EOB handling
    # See MediLink_837p_cob_library.create_pwk_attachment_segment() for implementation
    # Example: PWK*EB*FX*123456~ for attachment control number
    # if parsed_data.get('requires_attachment'):
    #     pwk_segment = MediLink_837p_cob_library.create_pwk_attachment_segment(parsed_data, config)
    #     if pwk_segment:
    #         segments.append(pwk_segment)
    
    # LX - Service Line Counter
    segments.append("LX*1~")
    
    # SV1 - Professional Service
    segments.append("SV1*HC:{}:{}*{}*MJ*{}***1~".format(
        validated_data['CODEA'],
        validated_data['POS'],
        validated_data['AMOUNT'],
        validated_data['MINTUES']))
    
    # DTP - Date
    segments.append("DTP*472*D8*{}~".format(convert_date_format(validated_data['DATE'])))
    
    # Is there REF - Line Item Control Number missing here? Private insurance doesn't need it, but Medicare does?
    # segments.append("REF*6R*1~") # REF01, Reference Identification Qualifier; REF02, Line Item Control Number.
    # 6R - Provider Control Number (Number assigned by information provider company for tracking and billing purposes)
    # 1 - Reference information as defined for a particular Transaction Set or as specified by the Reference Identification Qualifier
    

    # TODO (COB ENHANCEMENT): Service-level COB adjudication (2430 loop)
    # See MediLink_837p_cob_library.create_2430_service_line_cob_segments() for implementation
    # This would include SVD, CAS, and DTP*573 segments for service-level adjudication
    # if parsed_data.get('service_adjudications'):
    #     cob_segments = MediLink_837p_cob_library.create_2430_service_line_cob_segments(parsed_data, config, crosswalk)
    #     segments.extend(cob_segments)
    
    return segments

def get_endpoint_config(config, endpoint):
    """
    Retrieves the configuration for a specified endpoint.

    Args:
        config (dict): Configuration settings loaded from a JSON file.
        endpoint (str): The endpoint for which the configuration is requested.

    Returns:
        dict: The configuration for the specified endpoint, or raises an error if not found.
    """
    endpoint_config = config['endpoints'].get(endpoint.upper(), None)
    
    if endpoint_config is None:
        error_message = "Endpoint configuration for '{}' not found.".format(endpoint)
        MediLink_ConfigLoader.log(error_message, config, level="ERROR")
        raise ValueError(error_message)  # Raise an error for invalid endpoint

    return endpoint_config

def create_interchange_elements(config, endpoint, transaction_set_control_number):
    """
    Create interchange headers and trailers for an 837P document.

    Parameters:
    - config: Configuration settings loaded from a JSON file.
    - endpoint: The endpoint for which the data is being processed.
    - transaction_set_control_number: The starting transaction set control number.

    Returns:
    - Tuple containing (ISA header, GS header, GE trailer, IEA trailer).
    """
    endpoint_config = get_endpoint_config(config, endpoint)
    
    # Get the current system time and format it as 'HHMMSS' in 24-hour clock.
    current_time = datetime.now().strftime('%H%M%S')
    isa13 = '000' + current_time  # Format ISA13 with '000HHMMSS'.

    # Check if isa13 could not be generated from the current time
    if len(isa13) != 9:
        # If isa13 cannot be generated from the current time, use the configured value.
        isa13 = endpoint_config.get('isa_13_value', '000000001')
    
    # Create interchange header and trailer using provided library functions.
    isa_header, gs_header = create_interchange_header(config, endpoint, isa13)
    ge_trailer, iea_trailer = create_interchange_trailer(config, transaction_set_control_number, isa13)
    
    return isa_header, gs_header, ge_trailer, iea_trailer

# Generates the ISA and GS segments for the interchange header based on configuration and endpoint.
def create_interchange_header(config, endpoint, isa13):
    """
    Generate ISA and GS segments for the interchange header, ensuring endpoint-specific requirements are met.
    Includes support for Availity, Optum, and PNT_DATA endpoints, with streamlined configuration and default handling.

    Parameters:
    - config: Configuration dictionary with settings and identifiers.
    - endpoint: String indicating the target endpoint ('Availity', 'Optum', 'PNT_DATA').
    - isa13: The ISA13 field value representing the current system time.

    Returns:
    - Tuple containing the ISA and GS segment strings.
    """
    endpoint_config = config['endpoints'].get(endpoint.upper(), {})
    
    # Set defaults for ISA segment values
    isa02 = isa04 = "          "  # Default value for ISA02 and ISA04
    isa05 = isa07 = 'ZZ'  # Default qualifier
    isa15 = 'P'  # 'T' for Test, 'P' for Production
    
    # Conditional values from config
    isa_sender_id = endpoint_config.get('isa_06_value', config.get('submitterId', '')).rstrip()
    isa07_value = endpoint_config.get('isa_07_value', isa07)
    isa_receiver_id = endpoint_config.get('isa_08_value', config.get('receiverId', '')).rstrip()
    gs_sender_code = endpoint_config.get('gs_02_value', config.get('submitterEdi', ''))
    gs_receiver_code = endpoint_config.get('gs_03_value', config.get('receiverEdi', ''))
    isa15_value = endpoint_config.get('isa_15_value', isa15)

    # ISA Segment
    isa_segment = "ISA*00*{}*00*{}*{}*{}*{}*{}*{}*{}*^*00501*{}*0*{}*:~".format(
        isa02, isa04, isa05, isa_sender_id.ljust(15), isa07_value, isa_receiver_id.ljust(15),
        format_datetime(format_type='isa'), format_datetime(format_type='time'), isa13, isa15_value
    )

    # GS Segment
    # GS04 YYYYMMDD
    # GS06 Group Control Number, Field Length 1/9, must match GE02
    # BUG probably move up a function.
    gs06 = '1' # Placeholder for now?
    
    gs_segment = "GS*HC*{}*{}*{}*{}*{}*X*005010X222A1~".format(
        gs_sender_code, gs_receiver_code, format_datetime(), format_datetime(format_type='time'), gs06
    )

    MediLink_ConfigLoader.log("Created interchange header for endpoint: {}".format(endpoint), config, level="INFO")
    
    return isa_segment, gs_segment

# Generates the GE and IEA segments for the interchange trailer based on the number of transactions and functional groups.
def create_interchange_trailer(config, num_transactions, isa13, num_functional_groups=1):
    """
    Generate GE and IEA segments for the interchange trailer.
    
    Parameters:
    - config: Configuration dictionary with settings and identifiers.
    - num_transactions: The number of transactions within the functional group.
    - isa13: The ISA13 field value representing the current system time.
    - num_functional_groups: The number of functional groups within the interchange. Default is 1.
    
    Returns:
    - Tuple containing the GE and IEA segment strings.
    """
    
    # GE Segment: Functional Group Trailer
    # Indicates the end of a functional group and provides the count of the number of transactions within it.
    
    # GE02 Group Control Number, Field Length 1/9, must match GS06 (Header)
    # TODO This gs/ge matching should probably move up a function like isa13. 
    ge02 = '1' #Placeholder for now?
    ge_segment = "GE*{}*{}~".format(num_transactions, ge02)
    
    # IEA Segment: Interchange Control Trailer (Note: IEA02 needs to equal ISA13)
    iea_segment = "IEA*{}*{}~".format(num_functional_groups, isa13)
    
    MediLink_ConfigLoader.log("Created interchange trailer", config, level="INFO")
    
    return ge_segment, iea_segment

def validate_claim_data_for_837p(parsed_data, config, crosswalk):
    """
    Final line of defense validation for 837P claim data.
    
    This function validates that all required fields have valid values before creating
    the 837P claim. If invalid values are found, it provides detailed user guidance
    and allows manual input to correct the data.
    
    Parameters:
    - parsed_data: Dictionary containing claim data
    - config: Configuration settings
    - crosswalk: Crosswalk data for mappings
    
    Returns:
    - Dictionary with validated claim data, or raises ValueError if validation fails
    """
    validated_data = parsed_data.copy()
    chart_number = parsed_data.get('CHART', 'UNKNOWN')
    
    # Validate diagnosis code
    medisoft_code = ''.join(filter(str.isalnum, parsed_data.get('DIAG', '')))
    diagnosis_code = next((key for key, value in crosswalk.get('diagnosis_to_medisoft', {}).items() if value == medisoft_code), None)
    
    if not diagnosis_code:
        # Log the error condition with detailed context
        error_message = "Diagnosis code is empty for chart number: {}. Please verify. Medisoft code is {}".format(chart_number, medisoft_code)
        MediLink_ConfigLoader.log(error_message, config, level="CRITICAL")
        
        print("\n{}".format("="*80))
        print("CRITICAL: Missing diagnosis code mapping for patient {}".format(chart_number))
        print("{}".format("="*80))
        print("Medisoft code: '{}'".format(medisoft_code))
        print("Patient: {}, {}".format(parsed_data.get('LAST', 'Unknown'), parsed_data.get('FIRST', 'Unknown')))
        print("Service Date: {}".format(parsed_data.get('DATE', 'Unknown')))
        print("\nThis diagnosis code needs to be added to the crosswalk.json file.")
        print("\nCurrent diagnosis_to_medisoft mapping format:")
        
        # Show example entries from the crosswalk
        diagnosis_examples = list(crosswalk.get('diagnosis_to_medisoft', {}).items())[:3]
        for full_code, medisoft_short in diagnosis_examples:
            print("  '{}': '{}'".format(full_code, medisoft_short))
        
        print("\nPlease enter the complete ICD-10 diagnosis code (e.g., H25.10):")
        diagnosis_code = input("> ").strip()
        
        if not diagnosis_code:
            raise ValueError("Cannot proceed without diagnosis code for patient {}".format(chart_number))
        
        # Update the crosswalk dictionary with the new pairing of diagnosis_code and medisoft_code
        crosswalk['diagnosis_to_medisoft'][diagnosis_code] = medisoft_code
        MediLink_ConfigLoader.log("Updated crosswalk with new diagnosis code: {}, for Medisoft code {}".format(diagnosis_code, medisoft_code), config, level="INFO")
        print("\n[SUCCESS] Added '{}' -> '{}' to crosswalk".format(diagnosis_code, medisoft_code))
        print("  IMPORTANT: You must manually save this to crosswalk.json to persist the change!")
        # TODO This needs to actually save the .json though which right now I'd like to route through the dedicated function for updating the crosswalk. 
        # TODO This should have been a validation exercise upstream and not a last minute check like this.
    
    # Validate procedure code
    procedure_code = parsed_data.get('CODEA', '').strip()
    if not procedure_code or procedure_code.lower() in ['unknown', 'none', '']:
        # Log the error condition with detailed context
        error_message = "Procedure code is empty for chart number: {}. Please verify. Diagnosis code is {}".format(chart_number, diagnosis_code)
        MediLink_ConfigLoader.log(error_message, config, level="CRITICAL")
        
        print("\n{}".format("="*80))
        print("CRITICAL: Missing procedure code for patient {}".format(chart_number))
        print("{}".format("="*80))
        print("Diagnosis: {}".format(diagnosis_code))
        print("Patient: {}, {}".format(parsed_data.get('LAST', 'Unknown'), parsed_data.get('FIRST', 'Unknown')))
        print("Service Date: {}".format(parsed_data.get('DATE', 'Unknown')))
        print("\nThis procedure code needs to be added to the crosswalk.json file.")
        print("\nCurrent procedure_to_diagnosis mapping format:")
        
        # Show example entries from the crosswalk
        procedure_examples = list(crosswalk.get('procedure_to_diagnosis', {}).items())[:3]
        for proc_code, diagnosis_list in procedure_examples:
            print("  '{}': {}".format(proc_code, diagnosis_list))
        
        print("\nPlease enter the CPT procedure code (e.g., 66984):")
        procedure_code = input("> ").strip()
        
        if not procedure_code:
            raise ValueError("Cannot proceed without procedure code for patient {}".format(chart_number))
        
        # Update the crosswalk dictionary with the new pairing of procedure_code and diagnosis_code
        if procedure_code not in crosswalk.get('procedure_to_diagnosis', {}):
            crosswalk.setdefault('procedure_to_diagnosis', {})[procedure_code] = []
        crosswalk['procedure_to_diagnosis'][procedure_code].append(diagnosis_code)
        MediLink_ConfigLoader.log("Updated crosswalk with new procedure code: {}, for diagnosis code {}".format(procedure_code, diagnosis_code), config, level="INFO")
        print("\n[SUCCESS] Added '{}' -> ['{}'] to crosswalk".format(procedure_code, diagnosis_code))
        print("  IMPORTANT: You must manually save this to crosswalk.json to persist the change!")
        # TODO This needs to actually save the .json though which right now I'd like to route through the dedicated function for updating the crosswalk. 
        # TODO This should have been a validation exercise upstream and not a last minute check like this.
    
    # Update the validated data
    validated_data['DIAG'] = medisoft_code
    validated_data['CODEA'] = procedure_code
    
    # Validate other critical fields
    critical_fields = {
        'AMOUNT': 'claim amount',
        'TOS': 'type of service',
        'POS': 'place of service',
        'MINTUES': 'service minutes'
    }
    
    for field, description in critical_fields.items():
        value = validated_data.get(field, '').strip()
        if not value or value.lower() in ['unknown', 'none', '']:
            print("\n{}".format("="*80))
            print("CRITICAL: Missing {} for patient {}".format(description, chart_number))
            print("{}".format("="*80))
            print("Field: {}".format(field))
            print("Patient: {}, {}".format(parsed_data.get('LAST', 'Unknown'), parsed_data.get('FIRST', 'Unknown')))
            print("Service Date: {}".format(parsed_data.get('DATE', 'Unknown')))
            print("\nPlease enter the {}:".format(description))
            new_value = input("> ").strip()
            
            if not new_value:
                raise ValueError("Cannot proceed without {} for patient {}".format(description, chart_number))
            
            validated_data[field] = new_value
            print("\n[SUCCESS] Updated {} to '{}'".format(field, new_value))
    
    print("\n[SUCCESS] All claim data validated for patient {}".format(chart_number))
    return validated_data



