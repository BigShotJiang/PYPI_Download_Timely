VERSION = '0.0.78'
PACKAGE_NAME = 'azureml-designer-internal'
DESCRIPTION = 'Internal functionalities provided for Azure Machine Learning designer built-in modules. ' \
              'Not intended for public use.'
