# Slimformers

**Slimformers** is a modular Python library for exploring transformer model compression. It supports structural pruning, neuron selection, and efficient fine-tuning techniques such as LoRA (Low-Rank Adaptation).

---