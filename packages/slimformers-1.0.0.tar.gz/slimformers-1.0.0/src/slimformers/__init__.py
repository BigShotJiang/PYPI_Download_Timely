def start():
    return "Slimformers is ready."
