"""The wavetrain main module."""

from .create import create

__VERSION__ = "0.2.20"
__all__ = ("create",)
