"""The wavetrain reducer module."""
