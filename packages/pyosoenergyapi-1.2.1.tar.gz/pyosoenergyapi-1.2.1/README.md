# Introduction
This is a library which intefaces with the OSO Energy platform. 
This library is built mainly to integrate with the Home Assistant platform,
but it can also be used independently


