"""
Returns version of the package
"""
__version__ = "2.0.7"
