"""
Entry point for running Kontext MCP server as a module.
"""

from kontext_mcp.server import main

if __name__ == "__main__":
    main()
