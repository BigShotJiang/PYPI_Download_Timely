"""
Kontext MCP Server - Portable, provider-agnostic memory on top of Azure Data Explorer (Kusto).
"""

__version__ = "0.1.0"
