This module is an all-in-one property management system (PMS) focused on medium-sized properties
for managing every aspect of your property's daily operations.

You can manage properties with multi-property and multi-company support, including your rooms inventory,
reservations, check-in, daily reports, board services, rate and availability plans among other property functionalities.
