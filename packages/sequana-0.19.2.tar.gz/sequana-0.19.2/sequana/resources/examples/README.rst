test example used in the documentation/examples
