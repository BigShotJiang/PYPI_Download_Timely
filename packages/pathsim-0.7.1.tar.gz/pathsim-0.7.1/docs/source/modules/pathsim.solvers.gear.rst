pathsim.solvers.gear module
===========================

.. automodule:: pathsim.solvers.gear
   :members:
   :show-inheritance:
   :undoc-members:
