pathsim.utils.gilbert module
============================

.. automodule:: pathsim.utils.gilbert
   :members:
   :show-inheritance:
   :undoc-members:
