pathsim.blocks.spectrum module
==============================

.. automodule:: pathsim.blocks.spectrum
   :members:
   :show-inheritance:
   :undoc-members:
