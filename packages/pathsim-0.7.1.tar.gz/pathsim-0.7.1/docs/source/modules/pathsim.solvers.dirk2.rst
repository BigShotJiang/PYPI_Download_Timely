pathsim.solvers.dirk2 module
============================

.. automodule:: pathsim.solvers.dirk2
   :members:
   :show-inheritance:
   :undoc-members:
