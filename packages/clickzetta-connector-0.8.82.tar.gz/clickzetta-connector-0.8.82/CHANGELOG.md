Changelog
=========
## [0.8.80] - 2025-04-28
- [`84391454`]() - [to #CZPDEV-20080] fix result dict has no attribute 'code' error

## [0.8.79.16] - 2025-02-11
- [`84391454`](https://github.com/clickzetta/clickzetta-connector-python/commit/84391454dc427e4cf8f28d5ef51b745db65e504d) - [to #CZPDEV-20080] fix timeout after 90 seconds killed by sdk

## [0.8.79.15] - 2024-12-26
- [`5dca2587`](https://github.com/clickzetta/clickzetta-connector-python/commit/5ce7bfe8bbee1130c54f8ede34a631135d591a95) - [to #CZPDEV-18957] fix job timeout kill

## [0.8.79.14] - 2024-12-26
- [`5dca2587`](https://github.com/clickzetta/clickzetta-connector-python/commit/5dca2587d50dfbb6b464279750a588119381530d) - [to #CZPDEV-18957] ignore the miss proto type 

## [0.8.79.11] - 2024-11-12
- [`edd5fc6b`](https://github.com/clickzetta/clickzetta-connector-python/commit/edd5fc6bce4185c765a282c0c51a20a20e89b8b7) - [to #CZPDEV-18432] Fix the use command not work
- 
## [0.8.79.10] - 2024-11-12
- [`1d830dbe`](https://github.com/clickzetta/clickzetta-connector-python/commit/1d830dbe40506b0fec3e9e3186e735762aa74829) - [to #CZPDEV-18432] Bump version to pyarrow14.0.1 for CVE-2023-47248