
<a href="https://pypi.org/project/Nimbus-Splash/">
<img src="https://img.shields.io/badge/dynamic/json?label=PyPI%20&query=%24.info.version&url=https%3A%2F%2Fpypi.org%2Fpypi%2Fnimbus_splash%2Fjson" />
</a>

<a href="https://pypi.org/project/Nimbus-Splash/">
<img src="https://img.shields.io/badge/dynamic/json?label=Python%20&query=%24.info.requires_python&url=https%3A%2F%2Fpypi.org%2Fpypi%2Fnimbus_splash%2Fjson" />
</a>

<a href="https://splash.kragskow.group/">
<img src="https://img.shields.io/website?label=Documentation&down_color=red&down_message=Offline&up_color=green&up_message=Online&url=https%3A%2F%2Fsplash.kragskow.group">
</a>

# nimbus_splash

Splash - the sound an orca would make if it had a Bath.

`nimbus_splash` is a package to make life easier when using the University of Bath's cloud computing suite for Orca calculations.


# Installation

See the [Documentation](https://splash.kragskow.group/) for Installation and Usage instructions
