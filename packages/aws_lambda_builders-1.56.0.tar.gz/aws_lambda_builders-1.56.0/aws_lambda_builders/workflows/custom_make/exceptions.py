"""
Series of Exceptions raised by Custom Makefile builder.
"""


class MakeFileNotFoundError(Exception):
    pass
