"""
Enum for determining type of architectures for Lambda Function.
"""

X86_64 = "x86_64"
ARM64 = "arm64"
