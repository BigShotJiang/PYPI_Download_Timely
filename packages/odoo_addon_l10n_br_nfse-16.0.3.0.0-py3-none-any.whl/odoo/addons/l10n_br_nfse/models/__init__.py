from . import res_company
from . import document
from . import document_line
from . import product_template
from . import res_partner
