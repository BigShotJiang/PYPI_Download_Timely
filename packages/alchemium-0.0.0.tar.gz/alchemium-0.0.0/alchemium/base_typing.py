from typing import TypeVar, Type, Any

T = TypeVar("T")
ModelType = Type[Any]
