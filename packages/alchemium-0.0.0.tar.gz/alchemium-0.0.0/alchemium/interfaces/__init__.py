from .base import (
    ICreateRepository,
    IReadRepository,
    IUpdateRepository,
    IDeleteRepository,
)
