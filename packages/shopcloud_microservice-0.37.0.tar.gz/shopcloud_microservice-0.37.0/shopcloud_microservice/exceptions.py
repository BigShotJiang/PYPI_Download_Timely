class ConfigInvalidVersion(Exception):
    pass


class CommandError(Exception):
    pass


class ProjectFileNotFound(Exception):
    pass
