#!/usr/bin/env python
"""Setup script for backward compatibility. Use pyproject.toml for configuration."""
from setuptools import setup

setup()
