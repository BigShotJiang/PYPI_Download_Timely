#include "common.h"

graph_edge::graph_edge(node_t u_, node_t v_, edge_attr_dict_factory attr_) : u(u_), v(v_), attr(attr_) {}