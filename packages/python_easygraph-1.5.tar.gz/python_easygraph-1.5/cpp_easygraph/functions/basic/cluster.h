#pragma once

#include "../../common/common.h"

py::object clustering(py::object G, py::object nodes, py::object weight);