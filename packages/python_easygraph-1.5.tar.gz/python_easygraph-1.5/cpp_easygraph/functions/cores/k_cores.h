#pragma once

#include "../../common/common.h"

py::object core_decomposition(py::object G);