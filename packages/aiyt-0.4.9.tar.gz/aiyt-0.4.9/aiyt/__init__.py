metadata = {
    "name": "aiyt",
    "version": "0.4.9",
    "description": "Transcribe, Chat and Summarize Youtube Video with AI",
}
