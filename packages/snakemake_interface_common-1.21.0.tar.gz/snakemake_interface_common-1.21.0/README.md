# snakemake-interface-common

Common functions and classes for Snakemake and its plugins.