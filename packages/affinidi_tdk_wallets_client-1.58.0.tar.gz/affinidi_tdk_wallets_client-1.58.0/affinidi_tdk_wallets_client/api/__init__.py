# flake8: noqa

# import apis into api package
from affinidi_tdk_wallets_client.api.revocation_api import RevocationApi
from affinidi_tdk_wallets_client.api.wallet_api import WalletApi

