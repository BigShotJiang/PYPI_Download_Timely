def brk(text: str) -> str:
    return f"[{text}]"


def brc(text: str) -> str:
    return f"{{{text}}}"


def brp(text: str) -> str:
    return f"({text})"
