from setuptools import setup, find_packages

setup(
    name="requires-python",
    version="10.0.5",
    author="seeker0x",
    author_email="seeker0x@wearehackerone.com",
    description="This package is a proof of concept used by seeker0x to conduct a research. It has been uploaded for test purposes only. Its only function is to confirm the installation of the package on victim's machines. The code is not malicious in any way and will be deleted after the research survey has been concluded. I do not accept any liability for any direct, indirect, or consequential loss or damage arising from use of, or reliance on, this package.",
    packages=find_packages(),
    install_requires=['requests','os','base64','socket'],
)
