from . import main

main.main()
