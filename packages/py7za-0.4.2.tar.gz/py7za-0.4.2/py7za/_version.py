__version__ = '0.4.2'
__version_date__ = '2025-07-22'
