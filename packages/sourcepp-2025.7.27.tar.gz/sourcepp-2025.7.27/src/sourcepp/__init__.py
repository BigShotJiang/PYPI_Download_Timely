from ._sourcepp_impl import __doc__, bsppp, gamepp, sourcepp, steampp, toolpp, vcryptpp, vtfpp

__author__ = "craftablescience"
__version__ = "2025.7.27"
__all__ = ['__author__', '__doc__', '__version__', 'bsppp', 'gamepp', 'sourcepp', 'steampp', 'toolpp', 'vcryptpp', 'vtfpp']
