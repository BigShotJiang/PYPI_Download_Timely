from griptape.events import BaseEvent


class BaseAudioTranscriptionEvent(BaseEvent): ...
