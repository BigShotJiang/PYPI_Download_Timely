from .dummy_exception import DummyError

__all__ = ["DummyError"]
