from griptape.drivers.embedding.ollama_embedding_driver import OllamaEmbeddingDriver

__all__ = ["OllamaEmbeddingDriver"]
