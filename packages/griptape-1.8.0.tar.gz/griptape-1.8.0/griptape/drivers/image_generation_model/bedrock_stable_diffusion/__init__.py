from griptape.drivers.image_generation_model.bedrock_stable_diffusion_image_generation_model_driver import (
    BedrockStableDiffusionImageGenerationModelDriver,
)

__all__ = [
    "BedrockStableDiffusionImageGenerationModelDriver",
]
