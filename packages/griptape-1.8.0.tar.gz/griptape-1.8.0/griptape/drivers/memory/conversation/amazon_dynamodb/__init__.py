from griptape.drivers.memory.conversation.amazon_dynamodb_conversation_memory_driver import (
    AmazonDynamoDbConversationMemoryDriver,
)

__all__ = ["AmazonDynamoDbConversationMemoryDriver"]
