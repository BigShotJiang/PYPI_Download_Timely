from griptape.drivers.text_to_speech.dummy_text_to_speech_driver import DummyTextToSpeechDriver

__all__ = ["DummyTextToSpeechDriver"]
