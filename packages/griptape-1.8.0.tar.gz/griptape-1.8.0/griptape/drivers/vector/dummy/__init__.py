from griptape.drivers.vector.dummy_vector_store_driver import DummyVectorStoreDriver

__all__ = ["DummyVectorStoreDriver"]
