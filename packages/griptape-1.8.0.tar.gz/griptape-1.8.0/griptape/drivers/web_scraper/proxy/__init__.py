from griptape.drivers.web_scraper.proxy_web_scraper_driver import ProxyWebScraperDriver

__all__ = ["ProxyWebScraperDriver"]
