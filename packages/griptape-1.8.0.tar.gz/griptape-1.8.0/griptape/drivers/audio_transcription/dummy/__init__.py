from griptape.drivers.audio_transcription.dummy_audio_transcription_driver import DummyAudioTranscriptionDriver

__all__ = ["DummyAudioTranscriptionDriver"]
