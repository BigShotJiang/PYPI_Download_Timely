"""Setup script for meta-ads-mcp package."""

from setuptools import setup

if __name__ == "__main__":
    setup() 