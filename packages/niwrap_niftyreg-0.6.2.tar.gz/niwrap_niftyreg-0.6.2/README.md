# NiWrap wrappers for [NiftyReg](http://cmictig.cs.ucl.ac.uk/wiki/index.php/NiftyReg)

NiftyReg is an open-source software for efficient medical image registration. It has been mainly developed by members of the Centre for Medical Image Computing at University College London, UK.

NiftyReg is made by NiftyReg Developers.

This package contains wrappers only and has no affiliation with the original authors.
