from .tapo import *

__doc__ = tapo.__doc__
if hasattr(tapo, "__all__"):
    __all__ = tapo.__all__
