mod power_strip_plug_result;

pub use power_strip_plug_result::*;
