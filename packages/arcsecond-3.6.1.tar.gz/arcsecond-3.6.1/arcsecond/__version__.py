# Make sure to update pyproject.toml too
__version__ = "3.6.1"
