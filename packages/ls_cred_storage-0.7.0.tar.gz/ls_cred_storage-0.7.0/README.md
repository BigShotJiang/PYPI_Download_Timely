Lightsolver internal package.
cred storage package for storing user credential.