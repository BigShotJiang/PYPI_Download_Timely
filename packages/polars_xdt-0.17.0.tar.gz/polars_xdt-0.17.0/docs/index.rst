polars-xdt
===============

**polars-xdt** is a Python library which is a plugin for
Polars, a blazingly fast dataframe library.

.. image:: https://github.com/MarcoGorelli/polars-xdt/assets/33491632/928c68c4-4e71-45a7-bc89-14922c7ce61b
  :width: 400
  :alt: Polar bear in an office with a nice warm cup of coffee

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   API
