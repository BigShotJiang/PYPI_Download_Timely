API
===

.. autosummary::
   :toctree: api/

    polars_xdt.date_range
    polars_xdt.ceil
    polars_xdt.day_name
    polars_xdt.format_localized
    polars_xdt.from_local_datetime
    polars_xdt.is_workday
    polars_xdt.month_name
    polars_xdt.month_delta
    polars_xdt.to_local_datetime
    polars_xdt.to_julian_date
