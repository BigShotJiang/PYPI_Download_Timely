﻿polars\_xdt.date\_range
=======================

.. currentmodule:: polars_xdt

.. autofunction:: date_range