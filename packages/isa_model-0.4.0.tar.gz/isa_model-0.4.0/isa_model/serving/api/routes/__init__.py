"""
API Routes Module

Contains all API route definitions for different services
"""