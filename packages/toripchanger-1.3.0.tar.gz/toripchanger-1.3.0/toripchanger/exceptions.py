class TorIpError(Exception):
    pass
