"""
Constants for Unified Price API system.

Contains token addresses, DEX configurations, and other constants used across
different blockchain implementations for price calculation.
"""

from dataclasses import dataclass
from typing import Any

from .types import Currency, Protocol, SwapPrograms

# ===== Ethereum Mainnet Token Addresses =====

# Native and wrapped ETH
ETH_ADDRESS = "0x0000000000000000000000000000000000000000"  # Native ETH (zero address)
WETH_ADDRESS = "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"  # Wrapped ETH

# Stablecoins on Ethereum
USDC_ETH_ADDRESS = "0xA0b86991c6218b36c1d19d4a2e9eb0ce3606eb48"  # USDC on Ethereum (correct address)
USDT_ETH_ADDRESS = "0xdAC17F958D2ee523a2206206994597C13D831ec7"  # USDT on Ethereum

# ===== Polygon Token Addresses =====

# Stablecoins on Polygon
USDT_POLYGON_ADDRESS = "0xc2132d05d31c914a87c6611c10748aeb04b58e8f"  # USDT (PoS) on Polygon

# POL (previously MATIC) addresses
POL_ETH_ADDRESS = "0x7D1AfA7B718fb893dB30A3aBc0Cfc608AaCfeBB0"  # MATIC token on Ethereum (low liquidity)
WMATIC_POLYGON_ADDRESS = "0x0d500b1d8e8ef31e21c99d1db9a6444d3adf1270"  # WMATIC on Polygon (API lacks Polygon data)

# ===== Solana Token Addresses =====

# Native SOL and stablecoins (existing from svm.py)
SOL_MINT = "So11111111111111111111111111111111111111112"  # Native SOL
USDC_SOL_MINT = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"  # USDC on Solana

# ===== BSC Token Addresses =====

# Native BNB and stablecoins
WBNB_BSC_ADDRESS = "0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c"  # WBNB on BSC
USDT_BSC_ADDRESS = "0x55d398326f99059fF775485246999027B3197955"  # BSC-USD (USDT) on BSC
USDC_BSC_ADDRESS = "0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d"  # USDC on BSC

# ===== Avalanche Token Addresses =====

# Native AVAX and stablecoins
WAVAX_AVALANCHE_ADDRESS = "0xb31f66aa3c1e785363f0875a1b74e27b85fd66c7"  # WAVAX on Avalanche
USDC_AVALANCHE_ADDRESS = "0xB97EF9Ef8734C71904D8002F8b6Bc66Dd9c48a6E"  # USDC on Avalanche


@dataclass
class TokenConfig:
    """Configuration for a token on a specific blockchain."""

    address: str
    symbol: str
    decimals: int
    blockchain: str  # "ethereum", "polygon", "bsc", or "solana"


@dataclass
class DEXConfig:
    """Configuration for DEX-specific price calculation."""

    protocol: Protocol | SwapPrograms | str
    preferred_pairs: list[tuple[str, str]]  # List of (token1, token2) pairs to try
    min_liquidity_threshold: float = 1000.0  # Minimum USD value for valid swaps


# ===== Token Configurations =====

TOKEN_CONFIGS = {
    "ETH": TokenConfig(
        address=WETH_ADDRESS,  # Use WETH for swap calculations
        symbol="ETH",
        decimals=18,
        blockchain="ethereum",
    ),
    "SOL": TokenConfig(address=SOL_MINT, symbol="SOL", decimals=9, blockchain="solana"),
    "POL": TokenConfig(address=WMATIC_POLYGON_ADDRESS, symbol="WMATIC", decimals=18, blockchain="polygon"),
    "BNB": TokenConfig(address=WBNB_BSC_ADDRESS, symbol="WBNB", decimals=18, blockchain="bsc"),
    "AVAX": TokenConfig(address=WAVAX_AVALANCHE_ADDRESS, symbol="WAVAX", decimals=18, blockchain="avalanche"),
    "USDC_ETH": TokenConfig(address=USDC_ETH_ADDRESS, symbol="USDC", decimals=6, blockchain="ethereum"),
    "USDC_SOL": TokenConfig(address=USDC_SOL_MINT, symbol="USDC", decimals=6, blockchain="solana"),
    "USDT_POLYGON": TokenConfig(address=USDT_POLYGON_ADDRESS, symbol="USDT", decimals=6, blockchain="polygon"),
    "USDT_BSC": TokenConfig(address=USDT_BSC_ADDRESS, symbol="USDT", decimals=18, blockchain="bsc"),
    "USDC_BSC": TokenConfig(address=USDC_BSC_ADDRESS, symbol="USDC", decimals=18, blockchain="bsc"),
    "USDC_AVALANCHE": TokenConfig(address=USDC_AVALANCHE_ADDRESS, symbol="USDC", decimals=6, blockchain="avalanche"),
}

# ===== DEX Configurations =====

DEX_CONFIGS = {
    "ethereum": DEXConfig(
        protocol=Protocol.UNISWAP_V3,  # Most liquid for ETH/USDC
        preferred_pairs=[
            (WETH_ADDRESS, USDC_ETH_ADDRESS),  # WETH/USDC is most liquid
            (ETH_ADDRESS, USDC_ETH_ADDRESS),  # Native ETH/USDC as fallback
        ],
        min_liquidity_threshold=5000.0,  # Higher threshold for Ethereum due to gas costs
    ),
    "polygon": DEXConfig(
        protocol=Protocol.UNISWAP_V3,  # Uniswap V3 on Polygon for WMATIC/USDT
        preferred_pairs=[
            (WMATIC_POLYGON_ADDRESS, USDT_POLYGON_ADDRESS),  # WMATIC/USDT primary pair
        ],
        min_liquidity_threshold=100.0,  # Lower threshold for Polygon (lower volume)
    ),
    "solana": DEXConfig(
        protocol=SwapPrograms.JUPITER_V6,  # Best aggregated liquidity
        preferred_pairs=[
            (SOL_MINT, USDC_SOL_MINT),  # SOL/USDC primary pair
        ],
        min_liquidity_threshold=1000.0,  # Lower threshold for Solana
    ),
    "bsc": DEXConfig(
        protocol=Protocol.UNISWAP_V3,  # PancakeSwap V3 uses same protocol as Uniswap V3
        preferred_pairs=[
            (WBNB_BSC_ADDRESS, USDT_BSC_ADDRESS),  # WBNB/USDT primary pair
        ],
        min_liquidity_threshold=1000.0,  # Standard threshold for BSC
    ),
    "avalanche": DEXConfig(
        protocol=Protocol.UNISWAP_V3,  # Uniswap V3 on Avalanche for WAVAX/USDC
        preferred_pairs=[
            (WAVAX_AVALANCHE_ADDRESS, USDC_AVALANCHE_ADDRESS),  # WAVAX/USDC primary pair
        ],
        min_liquidity_threshold=1000.0,  # Standard threshold for Avalanche
    ),
}

# ===== Price Calculation Settings =====


@dataclass
class PriceSettings:
    """Settings for price calculation algorithms."""

    base_trades: int = 100  # Base number of trades to sample
    base_minutes: int = 15  # Base time window in minutes
    max_trades: int = 500  # Maximum trades to sample
    max_minutes: int = 120  # Maximum time window in minutes
    min_sample_size: int = 3  # Minimum trades needed for price calculation
    outlier_threshold: tuple[float, float] = (0.0001, 100000.0)  # (min_price, max_price) sanity check
    confidence_threshold: float = 0.1  # Minimum confidence score (0-1)
    cache_ttl_volatile: int = 60  # Cache TTL for volatile markets (seconds)
    cache_ttl_stable: int = 300  # Cache TTL for stable markets (seconds)
    volatility_threshold: float = 0.05  # Volatility threshold for cache TTL selection


# Default price settings
DEFAULT_PRICE_SETTINGS = PriceSettings()

# ===== Supported Currencies =====

SUPPORTED_CURRENCIES = {
    Currency.ETH: {
        "blockchain": "ethereum",
        "token_config": TOKEN_CONFIGS["ETH"],
        "dex_config": DEX_CONFIGS["ethereum"],
        "base_pair": TOKEN_CONFIGS["USDC_ETH"],
    },
    Currency.SOL: {
        "blockchain": "solana",
        "token_config": TOKEN_CONFIGS["SOL"],
        "dex_config": DEX_CONFIGS["solana"],
        "base_pair": TOKEN_CONFIGS["USDC_SOL"],
    },
    Currency.POL: {
        "blockchain": "polygon",
        "token_config": TOKEN_CONFIGS["POL"],
        "dex_config": DEX_CONFIGS["polygon"],
        "base_pair": TOKEN_CONFIGS["USDT_POLYGON"],
    },
    Currency.BNB: {
        "blockchain": "bsc",
        "token_config": TOKEN_CONFIGS["BNB"],
        "dex_config": DEX_CONFIGS["bsc"],
        "base_pair": TOKEN_CONFIGS["USDT_BSC"],
    },
    Currency.AVAX: {
        "blockchain": "avalanche",
        "token_config": TOKEN_CONFIGS["AVAX"],
        "dex_config": DEX_CONFIGS["avalanche"],
        "base_pair": TOKEN_CONFIGS["USDC_AVALANCHE"],
    },
}

# ===== Helper Functions =====


def get_currency_config(currency: Currency | str) -> dict[str, Any] | None:
    """Get configuration for a supported currency."""
    if isinstance(currency, str):
        # Try to convert string to Currency enum
        try:
            currency = Currency(currency.upper())
        except ValueError:
            return None
    return SUPPORTED_CURRENCIES.get(currency)


def is_currency_supported(currency: Currency | str) -> bool:
    """Check if a currency is supported."""
    if isinstance(currency, str):
        try:
            currency = Currency(currency.upper())
        except ValueError:
            return False
    return currency in SUPPORTED_CURRENCIES
