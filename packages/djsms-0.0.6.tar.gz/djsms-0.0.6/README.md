# DJSMS
A reusable Django app for sending sms
