'''
Provides functionalities for common EDA tasks
'''

from .core import Edazer
from .idf import interactive_df
#from .profiling import show_data_profile

