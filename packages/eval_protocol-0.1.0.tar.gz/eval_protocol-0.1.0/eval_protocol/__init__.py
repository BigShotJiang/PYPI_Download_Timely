class EvalProtocol:
    def __init__(self):
        pass
