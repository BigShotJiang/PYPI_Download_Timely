.. _swh-model:

.. include:: README.rst

.. toctree::
   :caption: Overview:
   :titlesonly:

   data-model
   persistent-identifiers
   cli

.. only:: standalone_package_doc

   Indices and tables
   ------------------

   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`
