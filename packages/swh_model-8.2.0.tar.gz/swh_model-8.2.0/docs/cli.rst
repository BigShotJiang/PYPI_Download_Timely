Command-line interface
======================

.. click:: swh.model.cli:identify
  :prog: swh identify
  :nested: full
