# Thoth SQL Database Manager

A Python module for managing SQL databases (SQLite and PostgreSQL) with support for LSH-based search.

## Installation

```bash
pip install thoth_sqldb