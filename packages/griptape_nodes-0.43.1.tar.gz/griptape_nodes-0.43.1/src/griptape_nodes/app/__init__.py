"""App package."""

from griptape_nodes.app.app import start_app

__all__ = ["start_app"]
