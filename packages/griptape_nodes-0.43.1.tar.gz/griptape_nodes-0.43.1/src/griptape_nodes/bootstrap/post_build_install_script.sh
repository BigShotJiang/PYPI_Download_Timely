#!/bin/bash

python register_libraries_script.py