from linkmerce.collect.base import Collector, PaginationMixin
