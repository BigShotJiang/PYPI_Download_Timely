"""
pybae: Core utilities for backend applications.

This package provides configuration management and backend helpers for Python projects.
"""