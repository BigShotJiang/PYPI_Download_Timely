# Copyright (c) 2023-2025 Datalayer, Inc.
# Distributed under the terms of the Modified BSD License.

"""The main for Datalayer."""

from datalayer_core.serverapplication import main

if __name__ == "__main__":
    main()
