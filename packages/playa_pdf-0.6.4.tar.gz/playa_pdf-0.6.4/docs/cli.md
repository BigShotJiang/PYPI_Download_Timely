# PLAYA-PDF Command Line Interface

::: playa.cli
    options:
        show_root_heading: false
        members: false
