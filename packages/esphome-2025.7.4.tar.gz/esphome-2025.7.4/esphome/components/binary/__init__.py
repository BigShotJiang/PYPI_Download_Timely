import esphome.codegen as cg

binary_ns = cg.esphome_ns.namespace("binary")
