def main():
    print(
        "KDTreeFiltering: Spatial and Bilateral filtering using "
        "Gaussian KDTree data structures."
    )
    print(
        "This is a library and is not intended to be run as a "
        "standalone script."
    )


if __name__ == "__main__":
    main()
