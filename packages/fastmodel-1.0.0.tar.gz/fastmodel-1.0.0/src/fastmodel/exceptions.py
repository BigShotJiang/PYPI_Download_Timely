class FastModelCLIException(Exception):
    pass


class FastModelException(Exception):
    pass


class HandledException(FastModelException):
    pass
