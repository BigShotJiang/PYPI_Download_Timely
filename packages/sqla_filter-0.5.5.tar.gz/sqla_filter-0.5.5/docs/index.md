# SQLAlchemy Filter

Package for convenient filtering and ordering functionality in SQLAlchemy

Quite often, optional filtering functionality is required. To facilitate the implementation of filtering functionality, this package was written

Features:

* filtering:
    * relationships
    * "or" filtering
* ordering
