from typing import Any, TypeVar

SelectClause = TypeVar("SelectClause", bound=tuple[Any, ...])
