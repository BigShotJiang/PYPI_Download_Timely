# SQLAlchemy Filter

## Package for convenient filtering and ordering functionality in SQLAlchemy

Quite often, optional filtering functionality is required. To facilitate the implementation of filtering functionality, this package was written

See [documentation](https://barbarrista.github.io/sqla-filter/)

All examples are available at the [following link](https://github.com/barbarrista/sqla-filter/tree/main/examples)
