# astdoc

## Installation

Install the astdoc using pip:

```bash
pip install astdoc
```
