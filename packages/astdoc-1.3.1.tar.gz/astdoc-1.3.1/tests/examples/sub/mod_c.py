"""Module C."""


class ClassC:
    """Class C."""

    def method_c(self):
        """Method C."""


def func_c():
    """Function C."""
