"""Module B."""


class ClassB:
    """Class B."""

    def method_b(self):
        """Method B."""


def func_b():
    """Function B."""
