def func():
    """This is a function in the sub module."""
