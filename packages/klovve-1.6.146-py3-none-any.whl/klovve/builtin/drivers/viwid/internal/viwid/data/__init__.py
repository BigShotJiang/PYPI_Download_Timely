# SPDX-FileCopyrightText: © 2025 Josef Hahn
# SPDX-License-Identifier: AGPL-3.0-only
"""
Various data structures, like points and sizes for geometry, or lists. See all subpackages.
"""
