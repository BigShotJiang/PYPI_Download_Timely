Module: csv
==============

.. autofunction:: befordata.csv.read_csv_as_befordata

.. autofunction:: befordata.csv.read_csv



