
Module: tools
================

.. autofunction:: befordata.tools.detect_sessions

.. autofunction:: befordata.tools.butter_filter



