"""Custom exceptions for ``rest_encrypt`` (currently unused)."""

# Placeholder for future error definitions.
