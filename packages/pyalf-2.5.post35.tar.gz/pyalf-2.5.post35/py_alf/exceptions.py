"""Exceptions for pyALF"""

class TooFewBinsError(Exception):
    """Triggered when observable has too few bins for analysis."""
