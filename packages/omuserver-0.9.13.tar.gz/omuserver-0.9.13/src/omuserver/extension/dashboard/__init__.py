from .dashboard_extension import DashboardExtension

__all__ = [
    "DashboardExtension",
]
