from .asset_extension import AssetExtension

__all__ = [
    "AssetExtension",
]
