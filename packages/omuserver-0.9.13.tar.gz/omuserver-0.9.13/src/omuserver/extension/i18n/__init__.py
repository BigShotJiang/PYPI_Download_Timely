from .i18n_extension import I18nExtension

__all__ = [
    "I18nExtension",
]
