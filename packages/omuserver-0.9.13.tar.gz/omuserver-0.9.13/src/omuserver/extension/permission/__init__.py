from .permission_extension import PermissionExtension

__all__ = [
    "PermissionExtension",
]
