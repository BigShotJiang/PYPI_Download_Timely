# from sentify.main import sentify

__version__ = "1.0.2"
