def uniq(data: list) -> list:
    return list(set(data))
