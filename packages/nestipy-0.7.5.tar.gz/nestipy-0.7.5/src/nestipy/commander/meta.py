class CommanderMeta:
    Meta: str = "__commander__meta__"
    Name: str = "__commander__name__"
    Description: str = "__commander__description__"
