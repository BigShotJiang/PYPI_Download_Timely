# SCIV

> SCIV: Unveiling the pivotal cell types involved in variant function regulation at a single-cell resolution

## Introduction

## Install
