- ForgeFlow \<https://www.ForgeFlow.com\>  
  \*\* Jordi Ballester Alomar \<jordi.ballester@ForgeFlow.com\>

- [Aion Tech](https://aiontech.company/):
  - Simone Rubino \<simone.rubino@aion-tech.it\>
