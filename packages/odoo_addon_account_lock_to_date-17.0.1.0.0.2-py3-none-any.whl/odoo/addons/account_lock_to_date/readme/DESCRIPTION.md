This module allows to set a Period and Fiscal year Locking end dates.
This will prevent users from posting journal entries on a date after the
defined period or fiscal year end date.
