# bill-flow-plugin

A package to create plugins for bill-flow system
