"""Add full precision for tsql to support nanoseconds."""


def migrate(state_sync, **kwargs):  # type: ignore
    pass
