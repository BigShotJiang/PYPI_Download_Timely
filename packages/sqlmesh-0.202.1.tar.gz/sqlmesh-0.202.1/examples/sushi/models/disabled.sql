MODEL (
  name sushi.disabled,
  enabled False,
);

SELECT 1 AS a;
