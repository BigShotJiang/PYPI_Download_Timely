# HamiltonIO
A library of IO of Hamiltonian files of DFT codes

## Installation
```bash
pip install hamiltonIO
```

## Usage

See the examples.

