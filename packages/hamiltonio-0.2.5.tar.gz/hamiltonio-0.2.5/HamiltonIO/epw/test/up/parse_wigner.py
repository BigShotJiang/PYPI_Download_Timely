
#dataclass

from dataclasses import dataclass
from typing import List, Optional, Union
import numpy as np

@dataclass
class Wigner:
    Rmesh: List[int]


