## REQUIRED Columns for Bollinger Bands
REQUIRED_COLUMNS = {'calculation_date', 'p_to_e', 'adj_p_to_e', 'pricesales', 'pebitda'}