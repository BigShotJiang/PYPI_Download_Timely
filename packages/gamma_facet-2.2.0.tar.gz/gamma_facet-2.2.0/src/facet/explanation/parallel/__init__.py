"""
Running multiple explainers in parallel using a :class:`ParallelExplainer` instance.
"""

from ._parallel import *
