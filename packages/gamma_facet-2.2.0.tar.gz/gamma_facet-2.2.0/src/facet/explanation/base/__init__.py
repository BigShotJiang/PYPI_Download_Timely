"""
Abstract base classes for the `facet.explanation` package.
"""

from ._base import *
