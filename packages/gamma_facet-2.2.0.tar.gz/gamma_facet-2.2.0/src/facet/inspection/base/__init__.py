"""
Abstract base classes for model inspection.
"""

from ._model_inspector import *
