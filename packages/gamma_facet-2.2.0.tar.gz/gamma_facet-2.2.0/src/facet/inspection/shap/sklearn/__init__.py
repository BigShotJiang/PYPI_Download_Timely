"""
SHAP calculators for *scikit-learn* regressors and classifiers.
"""

from ._sklearn import *
