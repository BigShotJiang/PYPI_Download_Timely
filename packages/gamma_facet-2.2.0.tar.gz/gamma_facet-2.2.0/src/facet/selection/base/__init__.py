"""
Base classes and supporting classes for module :mod:`facet.selection`.
"""

from ._parameters import *
