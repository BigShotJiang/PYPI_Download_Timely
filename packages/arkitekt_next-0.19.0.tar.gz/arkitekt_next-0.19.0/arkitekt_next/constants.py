REPO_URL = "https://arkitekt.live/repo.json"
DEFAULT_ARKITEKT_URL = "http://127.0.0.1"
