"""HDRezka urls types"""
from .quality import *
from .subtitle import *
from .video import *
