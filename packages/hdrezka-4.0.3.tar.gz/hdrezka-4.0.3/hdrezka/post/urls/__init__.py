"""Module of HDRezka urls view by kind"""
from .kind import *
from .urls import *
