"""Module of HDRezka urls view"""
from .post import *
from .urls import *
