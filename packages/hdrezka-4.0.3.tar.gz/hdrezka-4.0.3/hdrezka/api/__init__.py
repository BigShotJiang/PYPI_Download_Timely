"""HDRezka API call functions"""
from .ajax import *
from .search import *
