"""HDRezka stream module"""
from .player import *
