# Recommend

Types:

```python
from admesh.types import RecommendGetRecommendationsResponse
```

Methods:

- <code title="post /agent/recommend">client.recommend.<a href="./src/admesh/resources/recommend.py">get_recommendations</a>(\*\*<a href="src/admesh/types/recommend_get_recommendations_params.py">params</a>) -> <a href="./src/admesh/types/recommend_get_recommendations_response.py">RecommendGetRecommendationsResponse</a></code>
