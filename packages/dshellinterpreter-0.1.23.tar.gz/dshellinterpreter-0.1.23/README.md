# Dshell_Interpreter

Python interpreter for Discord.
