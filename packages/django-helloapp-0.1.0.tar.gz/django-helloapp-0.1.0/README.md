# django-helloapp

Une app Django simple avec une vue "hello world".