from .angled_stratified import stratified

__all__ = ["stratified"]