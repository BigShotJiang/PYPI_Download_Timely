# Super Math

A super simple math utility package.

## Installation
```bash
pip install super-math
```

## Usage
```python
from super_math import add
result = add(5, 3)
print(result) # Output: 8
```
