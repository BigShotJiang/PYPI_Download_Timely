# Copyright (C) 2022-2025 Indoc Systems
#
# Contact Indoc Systems for any questions regarding the use of this source code.

from .geid_client import GEIDClient

__all__ = [
    'GEIDClient',
]
