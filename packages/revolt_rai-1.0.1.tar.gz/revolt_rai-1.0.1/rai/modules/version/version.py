class Version:
    def __init__(self):
        self.git_version = "v1.0.1"
        self.pypi = "1.0.1"