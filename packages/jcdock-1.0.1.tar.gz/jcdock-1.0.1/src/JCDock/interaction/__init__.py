"""
User interaction components for the JCDock docking framework.

This package contains drag-and-drop logic, overlays, and interaction handling.
"""