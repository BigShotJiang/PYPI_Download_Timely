"""
Data model and persistence components for the JCDock docking framework.

This package contains layout models, serialization, and rendering logic.
"""