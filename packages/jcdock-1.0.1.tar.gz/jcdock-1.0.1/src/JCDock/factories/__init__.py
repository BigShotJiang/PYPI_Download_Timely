"""
Factory and management components for the JCDock docking framework.

This package contains widget creation, window management, and model update logic.
"""