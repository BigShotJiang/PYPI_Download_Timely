# @omlish-lite
"""
These are the 'core' lite modules. These generally have a 'full' equivalent, in which case non-lite code should prefer
that.
"""
