"""Main entry point for the reclaimed package."""

from .cli import main

if __name__ == "__main__":
    main()
