from enum import Enum


class SummarizationType(Enum):
    THREAD_TITLE = "thread_title"
    DEFAULT = "default"
