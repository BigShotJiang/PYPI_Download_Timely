from .ChkReader import ChkReader

# always keep the value is same as setup.py
__version__ = "0.1.20"
