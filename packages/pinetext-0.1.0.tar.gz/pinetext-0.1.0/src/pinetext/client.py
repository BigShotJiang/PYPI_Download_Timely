from pinetext.settings import Settings


settings = Settings()


class PineText:
    def __init__(self):
        pass

    def run(self):
        print("OK")
