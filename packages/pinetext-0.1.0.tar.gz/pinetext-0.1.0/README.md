## PineText

[![test](https://github.com/ezhuk/pinetext/actions/workflows/test.yml/badge.svg)](https://github.com/ezhuk/pinetext/actions/workflows/test.yml)
[![codecov](https://codecov.io/github/ezhuk/pinetext/graph/badge.svg?token=0YJASFE5OM)](https://codecov.io/github/ezhuk/pinetext)
