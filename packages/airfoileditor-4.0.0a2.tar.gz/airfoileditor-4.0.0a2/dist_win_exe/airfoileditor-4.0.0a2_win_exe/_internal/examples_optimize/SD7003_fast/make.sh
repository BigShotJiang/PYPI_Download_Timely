
localXoptfoil2="../../linux/bin/Xoptfoil2"

$localXoptfoil2 -i SD7003_fast.xo2 -o SD7003_fast

