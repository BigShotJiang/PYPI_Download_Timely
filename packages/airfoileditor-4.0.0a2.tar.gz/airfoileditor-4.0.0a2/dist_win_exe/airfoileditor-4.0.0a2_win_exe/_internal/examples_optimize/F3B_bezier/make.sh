localXoptfoil2="../../linux/bin/Xoptfoil2"

$localXoptfoil2 -i F3B_bezier.xo2