from sqlalchemy.orm import DeclarativeBase


class DBObjectClassBase(DeclarativeBase):
    pass
