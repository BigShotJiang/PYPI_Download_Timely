sqlite\_database.operators module
=================================

.. automodule:: sqlite_database.operators
   :members:
   :undoc-members:
   :show-inheritance:
