sqlite\_database.model.errors module
====================================

.. automodule:: sqlite_database.model.errors
   :members:
   :undoc-members:
   :show-inheritance:
