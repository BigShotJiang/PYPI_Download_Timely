This module lets users select a release channel and set a specific
cutoff time for it.

When the current time (now) becomes later than the cutoff time and the
channel is still open, the kanban view for that channel will display the
cutoff time in red as a warning.
