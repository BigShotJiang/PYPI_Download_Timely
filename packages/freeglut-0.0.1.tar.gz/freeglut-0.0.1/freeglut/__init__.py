# Safe dummy package: freeglut
