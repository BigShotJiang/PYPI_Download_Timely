from setuptools import setup, find_packages

setup(
    name="single-lang",
    version="1.4.0",
    packages=find_packages(),
    package_dir={'': '.'},
    entry_points={
        'console_scripts': [
            'single = single_lang.nucleus.main:run_from_command_line',
        ],
    },
)