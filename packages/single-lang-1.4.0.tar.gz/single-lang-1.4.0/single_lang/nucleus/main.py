import sys
import os
from typing import List, Dict, Tuple

class SingleSyntaxError(Exception):
    def __init__(self, message: str, line_num: int, line: str):
        self.message = message
        self.line_num = line_num
        self.line = line
        super().__init__(self._format_message())
    
    def _format_message(self) -> str:
        return (f"SyntaxError: {self.message}\n"
                f"  Line {self.line_num}: {self.line.strip()}\n"
                f"{'^':>{len(str(self.line_num)) + len(str(self.line)) + 3}}")

class SingleInterpreter:
    def __init__(self):
        self.functions = {
            'console': self._handle_console
        }
        self.types = {
            'text': str
        }
        self.has_errors = False
    
    def _handle_console(self, args: List[str], line_num: int, line: str):
        if self.has_errors:
            return
        
        if len(args) != 2:
            self.has_errors = True
            raise SingleSyntaxError("console() expects exactly 2 arguments", line_num, line)
        
        type_part = args[0].strip()
        if not type_part.endswith('.'):
            self.has_errors = True
            raise SingleSyntaxError("Expected type specifier with '.' (e.g., 'text.')", line_num, line)
        
        type_name = type_part[:-1]
        if type_name not in self.types:
            self.has_errors = True
            raise SingleSyntaxError(f"Unknown type: {type_name}", line_num, line)
        
        message = args[1].strip('"\'')
        print(message)
    
    def _parse_args(self, arg_str: str, line_num: int, line: str) -> List[str]:
        if self.has_errors:
            return []
        
        args = []
        current_arg = []
        in_quotes = False
        quote_char = None
        
        for char in arg_str:
            if char in ('"', "'") and not in_quotes:
                in_quotes = True
                quote_char = char
                current_arg.append(char)
            elif char == quote_char and in_quotes:
                in_quotes = False
                current_arg.append(char)
            elif char == ',' and not in_quotes:
                args.append(''.join(current_arg).strip())
                current_arg = []
            else:
                current_arg.append(char)
        
        if in_quotes:
            self.has_errors = True
            raise SingleSyntaxError("Unclosed quotation marks", line_num, line)
        
        if current_arg:
            args.append(''.join(current_arg).strip())
        
        return args
    
    def execute_line(self, line: str, line_num: int):
        if self.has_errors:
            return
        
        line = line.strip()
        if not line or line.startswith('//'):
            return
        
        if not line.endswith(';'):
            self.has_errors = True
            raise SingleSyntaxError("Missing semicolon at end of statement", line_num, line)
        
        line = line[:-1]
        
        if '(' not in line or not line.endswith(')'):
            self.has_errors = True
            raise SingleSyntaxError("Function call must be in format func_name(arg1, arg2)", line_num, line)
        
        func_name = line[:line.index('(')].strip()
        arg_str = line[line.index('(')+1:-1]
        
        if func_name not in self.functions:
            self.has_errors = True
            raise SingleSyntaxError(f"Unknown function: {func_name}", line_num, line)
        
        args = self._parse_args(arg_str, line_num, line)
        self.functions[func_name](args, line_num, line)
    
    def execute_file(self, file_path: str):
        try:
            with open(file_path, 'r') as f:
                lines = f.readlines()
                for line_num, line in enumerate(lines, 1):
                    try:
                        self.execute_line(line, line_num)
                    except SingleSyntaxError as e:
                        print(e)
                        return
        except FileNotFoundError:
            print(f"Error: File not found - {file_path}")
        except Exception as e:
            print(f"Unexpected error: {str(e)}")

def run_from_command_line():
    if len(sys.argv) != 3 or sys.argv[1] != 'main':
        print("Usage: single main filename.single")
        return
    
    file_path = sys.argv[2]
    if not file_path.endswith('.single'):
        print("Error: Only .single files are supported")
        return
    
    interpreter = SingleInterpreter()
    interpreter.execute_file(file_path)