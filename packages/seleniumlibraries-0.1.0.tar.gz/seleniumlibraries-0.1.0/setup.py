"""The setup script."""

from setuptools import setup

setup()
