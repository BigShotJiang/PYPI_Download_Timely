cryptid
===

Cryptographic, location aware ID conversions