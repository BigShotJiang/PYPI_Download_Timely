# synapso-core
Core utils
