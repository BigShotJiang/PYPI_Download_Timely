--8<-- "README.md:abstract"

## Usage

To get started, please check out the [quickstart guide](./quickstart.md).

--8<-- "README.md:citation"

--8<-- "README.md:acknowledgements"
