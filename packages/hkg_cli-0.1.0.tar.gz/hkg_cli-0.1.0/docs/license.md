Unless stated otherwise, all code provided by this project
(excluding external dependencies) is distributed under the following license:

```
--8<-- "LICENSE"
```

This project is [REUSE](https://reuse.software/) compliant.
The following detailed license and copyright information in
[DEP5](https://www.debian.org/doc/packaging-manuals/copyright-format/1.0/)
format can also be found in the `REUSE.toml` file in the project source directory:

```
--8<-- "REUSE.toml"
```
