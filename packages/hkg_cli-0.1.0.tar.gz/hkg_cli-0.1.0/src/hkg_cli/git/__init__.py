"""Git utility functions."""
