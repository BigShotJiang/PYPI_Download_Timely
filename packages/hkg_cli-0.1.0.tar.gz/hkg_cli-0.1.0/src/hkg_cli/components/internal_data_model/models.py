from hkg_cli.components.models import BaseEnvVars


class InternalDataModelEnvVars(BaseEnvVars):
    """Environment variables for the Internal Data Model component."""

    pass
