from hkg_cli.components.models import BaseEnvVars


class DataStorageApiManifestsEnvVars(BaseEnvVars):
    """Environment variables for the Data Storage API Manifests component."""

    pass
