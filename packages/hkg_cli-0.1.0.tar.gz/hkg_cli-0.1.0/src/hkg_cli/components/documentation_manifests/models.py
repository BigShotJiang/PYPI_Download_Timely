from hkg_cli.components.models import BaseEnvVars


class DocumentationManifestsEnvVars(BaseEnvVars):
    """Environment variables for the Documentation Manifests component."""

    pass
