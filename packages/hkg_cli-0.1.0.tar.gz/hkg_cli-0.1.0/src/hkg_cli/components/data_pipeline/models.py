from hkg_cli.components.models import BaseEnvVars


class DataPipelineEnvVars(BaseEnvVars):
    """Environment variables for the Data Pipeline component."""

    pass
