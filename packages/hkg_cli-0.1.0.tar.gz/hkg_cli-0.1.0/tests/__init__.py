"""Tests for hkg-cli."""
