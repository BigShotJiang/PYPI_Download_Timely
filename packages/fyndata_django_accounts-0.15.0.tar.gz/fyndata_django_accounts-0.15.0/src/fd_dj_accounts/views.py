# from django.views.generic import (
#     CreateView,
#     DeleteView,
#     DetailView,
#     UpdateView,
#     ListView
# )

# from .models import (
#     User,
# )


# class UserCreateView(CreateView):
#
#     model = User


# class UserDeleteView(DeleteView):
#
#     model = User


# class UserDetailView(DetailView):
#
#     model = User


# class UserUpdateView(UpdateView):
#
#     model = User


# class UserListView(ListView):
#
#     model = User
