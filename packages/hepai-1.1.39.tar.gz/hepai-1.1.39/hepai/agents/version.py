
__version__ = "0.5.6"
__appname__ = 'DrSai'
__author__ = 'hepai'
__email__ = 'hepai@ihep.ac.cn'
__description__ = 'A development framework for single and multi-agent collaborative systems developed by the Dr.Sai team at the IHEP, CAS.'