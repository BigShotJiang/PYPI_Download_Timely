
import os, sys
import hai
# from hai import Testor

# module_path = '/home/zzd/VSProjects/FINet'

# cwd = os.getcwd()

# os.chdir(module_path)
# if module_path not in sys.path:
#     sys.path.insert(0, module_path)
# testor = Testor()
# testor.test_module(module_name='FINet')



