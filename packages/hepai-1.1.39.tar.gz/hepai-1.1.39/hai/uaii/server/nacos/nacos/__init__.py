from .client import NacosClient, NacosException, DEFAULTS, DEFAULT_GROUP_NAME
__version__ = client.VERSION

__all__ = ["NacosClient", "NacosException", "DEFAULTS", DEFAULT_GROUP_NAME]
