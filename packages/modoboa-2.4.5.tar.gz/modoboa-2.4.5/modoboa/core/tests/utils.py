import os


def get_doveadm_test_path():
    return f"{os.path.dirname(__file__)}/doveadm"
