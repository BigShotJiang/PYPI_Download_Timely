from pathlib import Path

TEST_DATA_PATH = Path(__file__).parent.parent / "tests/data"
