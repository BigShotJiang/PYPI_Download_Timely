"""
MLFCrafter Test Suite
====================

Test package for MLFCrafter ML pipeline automation.

Test Files:
- test_mlfcrafter.py: Main pipeline tests (end-to-end)
"""
