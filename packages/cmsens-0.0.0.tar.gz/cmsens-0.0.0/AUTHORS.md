# Core Developers
----------
- AmirHosein Rostami  - Open Science Laboratory ([Github](https://github.com/AHReccese)) **
- Sepand Haghighi - Open Science Laboratory ([Github](https://github.com/sepandhaghighi))

** **Maintainer**

# Other Contributors
----------
- [@boreshnavard](https://github.com/boreshnavard) ++
- [@sadrasabouri](https://github.com/sadrasabouri)


++ Graphic designer