# import packages/modules
# internal


# api url
API_URL = "https://script.google.com/macros/s/"
