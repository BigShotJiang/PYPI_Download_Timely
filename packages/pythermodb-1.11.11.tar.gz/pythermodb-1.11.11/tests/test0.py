# import packages/modules
import pyThermoDB as ptdb
from rich import print

# versions
print(ptdb.__version__)

print(ptdb.__description__)
