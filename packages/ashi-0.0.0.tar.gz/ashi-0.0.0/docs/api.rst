.. py:module:: ashi

Example
*******

.. python-apigen-group:: welcome