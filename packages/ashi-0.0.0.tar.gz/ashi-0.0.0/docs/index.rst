ashi
===========

v0.0.1 of :obj:`ashi` has no functionality, please refer to later versions


.. toctree::
   :caption: Getting Started
   :hidden:

   getting-started.rst


.. toctree::
   :caption: Basic Usage
   :hidden:

   basic-usage/basic-usage.rst


.. toctree::
   :caption: Development
   :hidden:

   development/installation.rst
   development/unit-tests.rst
   development/formatting.rst
   development/documentation.rst

.. toctree::
   :caption: API
   :hidden:
   :maxdepth: 2

   api.rst


.. toctree::
   :caption: Release Notes
   :hidden:

   release-notes/versioning.rst
   release-notes/v0.0.md
