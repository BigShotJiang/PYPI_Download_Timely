def welcome():
    return "Welcome! Functionality will be added soon!"
