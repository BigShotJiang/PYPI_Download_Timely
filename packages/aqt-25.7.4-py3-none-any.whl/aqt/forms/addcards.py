from _aqt.forms.addcards_qt6 import *
