from _aqt.forms.profiles_qt6 import *
