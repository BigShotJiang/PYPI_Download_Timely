from _aqt.forms.addmodel_qt6 import *
