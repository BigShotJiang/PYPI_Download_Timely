from _aqt.forms.about_qt6 import *
