const w="5";var e,d,n;typeof window<"u"&&((n=(d=(e=window.__svelte)!=null?e:window.__svelte={}).v)!=null?n:d.v=new Set).add(w);
