import{l as o,a as r}from"../chunks/CT0460aE.mjs";export{o as load_css,r as start};
