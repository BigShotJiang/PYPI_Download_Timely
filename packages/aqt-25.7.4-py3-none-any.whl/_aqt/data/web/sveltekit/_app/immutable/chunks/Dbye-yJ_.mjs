const o=Symbol("touchDevice"),e=Symbol("modals"),s=Symbol("floating"),t=Symbol("select");export{s as f,e as m,t as s,o as t};
