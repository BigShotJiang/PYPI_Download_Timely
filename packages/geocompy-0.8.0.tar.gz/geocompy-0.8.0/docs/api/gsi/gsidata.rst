:icon: material/code-brackets

Data
====

.. automodule:: geocompy.gsi.gsidata

    Definitions
    -----------
