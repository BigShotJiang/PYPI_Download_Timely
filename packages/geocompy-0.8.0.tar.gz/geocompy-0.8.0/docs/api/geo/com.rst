:icon: material/arrow-right-bottom

Communication
=============

.. automodule:: geocompy.geo.com
    :inherited-members:

    Definitions
    -----------
