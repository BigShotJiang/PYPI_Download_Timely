:icon: material/arrow-right-bottom

Supervisor
==========

.. automodule:: geocompy.geo.sup
    :inherited-members:

    Definitions
    -----------
