:icon: material/arrow-right-bottom

Theodolite Measurement and Calculation
======================================

.. automodule:: geocompy.geo.tmc
    :inherited-members:

    Definitions
    -----------
