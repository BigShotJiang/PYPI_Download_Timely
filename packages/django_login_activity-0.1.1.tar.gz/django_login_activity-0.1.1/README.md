# django-login-activity

Suivi simple et efficace des connexions utilisateurs dans Django.

## Installation

```bash
pip install django-login-activity
