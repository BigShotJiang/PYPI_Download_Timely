# login_activity/views.py
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import LoginActivity

@login_required
def activity_list(request):
    activities = LoginActivity.objects.all().order_by('-timestamp')[:100]
    return render(request, 'login_activity/list.html', {'activities': activities})
