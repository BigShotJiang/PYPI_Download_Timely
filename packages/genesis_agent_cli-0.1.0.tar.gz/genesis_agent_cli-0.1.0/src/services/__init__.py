"""Services for Genesis Agent CLI."""
