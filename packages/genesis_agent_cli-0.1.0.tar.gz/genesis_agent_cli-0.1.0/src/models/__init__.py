"""Data models for Genesis Agent CLI."""
