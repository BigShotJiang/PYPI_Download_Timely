"""Genesis component mappings."""

# This module is now empty as we use dynamic component discovery
# from the Genesis Studio API instead of static mappings

__all__ = []