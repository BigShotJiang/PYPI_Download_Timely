"""Genesis Agent CLI - Manage AI agents using specifications."""

__version__ = "0.1.0"
