"""Genesis Component Registry module."""

from .dynamic_component_mapper import DynamicComponentMapper

__all__ = ["DynamicComponentMapper"]