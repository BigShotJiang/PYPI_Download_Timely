"""This module contains the jinja templates used for the code generation."""
