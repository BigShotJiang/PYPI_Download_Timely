.. role:: hidden
    :class: hidden-section
.. currentmodule:: {{ module }}


{{ name | underline}}

.. autoclass:: {{ name }}
    :members:


.. minigallery::
    :add-heading: Gallery examples

    BrierScore
    ../auto_tutorials/tutorial_bayesian.py

    
