# Experiments

Torch-Uncertainty proposes various benchmarks to evaluate uncertainty quantification methods.

## Classification

*Work in progress*

## Segmentation

*Work in progress*

## Regression

*Work in progress*

## Pixel Regression

*Work in progress*
