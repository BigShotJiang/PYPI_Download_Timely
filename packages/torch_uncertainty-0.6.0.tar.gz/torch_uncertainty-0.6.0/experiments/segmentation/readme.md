# Segmentation Benchmarks

Note: Optimize the number of `data.workers` to your computer to gain speed and avoid pauses.
