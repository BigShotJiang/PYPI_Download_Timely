.. _Segmentation_examples:

Segmentation
---------------------------

Tutorials for modeling uncertainty in Segmentation tasks.
