# ruff: noqa: F401
from .kitti import KITTIDataModule
from .muad import MUADDataModule
from .nyu import NYUv2DataModule
