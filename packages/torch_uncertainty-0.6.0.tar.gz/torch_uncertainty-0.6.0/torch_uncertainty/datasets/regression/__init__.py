# ruff: noqa: F401
from .uci_regression import UCIRegression
