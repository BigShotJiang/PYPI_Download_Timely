# ruff: noqa: F401
from .camvid import CamVid
from .cityscapes import Cityscapes
