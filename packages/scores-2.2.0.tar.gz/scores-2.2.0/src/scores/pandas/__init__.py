"""
Explicit Pandas API
"""

from scores.pandas import continuous

__all__ = ["continuous"]
