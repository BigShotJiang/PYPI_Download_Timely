# Settings plugin

This plugin allows to configure ajenti options and certificates.
