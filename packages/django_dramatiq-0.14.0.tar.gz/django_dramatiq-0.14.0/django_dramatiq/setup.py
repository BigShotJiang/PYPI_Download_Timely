import django

django.setup()
