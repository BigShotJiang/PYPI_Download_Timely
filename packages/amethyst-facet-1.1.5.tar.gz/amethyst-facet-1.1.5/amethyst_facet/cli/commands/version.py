import click

@click.command
def version():
    """Print version and exit
    """
    print("Facet v. 1.1.5 (July 24, 2025)")