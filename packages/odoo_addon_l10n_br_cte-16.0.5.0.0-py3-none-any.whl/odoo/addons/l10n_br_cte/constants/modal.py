CTE_MODALS = [
    ("01", "Rodoviário"),
    ("02", "Aéreo"),
    ("03", "Aquaviário"),
    ("04", "Ferroviário"),
    ("05", "Dutoviário"),
    ("06", "Multimodal"),
]

CTE_MODAL_DEFAULT = "01"

CTE_MODAL_VERSION_DEFAULT = "4.00"

TUF = [
    ("AC", "AC"),
    ("AL", "AL"),
    ("AM", "AM"),
    ("AP", "AP"),
    ("BA", "BA"),
    ("CE", "CE"),
    ("DF", "DF"),
    ("ES", "ES"),
    ("GO", "GO"),
    ("MA", "MA"),
    ("MG", "MG"),
    ("MS", "MS"),
    ("MT", "MT"),
    ("PA", "PA"),
    ("PB", "PB"),
    ("PE", "PE"),
    ("PI", "PI"),
    ("PR", "PR"),
    ("RJ", "RJ"),
    ("RN", "RN"),
    ("RO", "RO"),
    ("RR", "RR"),
    ("RS", "RS"),
    ("SC", "SC"),
    ("SE", "SE"),
    ("SP", "SP"),
    ("TO", "TO"),
    ("EX", "EX"),
]
