from pipelex.types import StrEnum


class OcrPlatform(StrEnum):
    MISTRAL = "mistral"
