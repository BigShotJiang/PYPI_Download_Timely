"""
公共配置文件, 项目直接访问
"""

PGSQL_URL:str

SCHEMA='public'


from config_private import *