#!/usr/bin/env sh
./worker.py --project ./worker.json --outputdir ~/.out-worker
