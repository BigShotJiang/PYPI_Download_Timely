def run():
    from . import exporter
    exporter.main()
