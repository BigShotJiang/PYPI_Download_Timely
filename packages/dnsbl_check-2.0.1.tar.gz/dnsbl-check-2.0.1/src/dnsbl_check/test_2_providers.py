import pytest


def test_1():
    from checker import CheckIP, CheckDomain
    pass
