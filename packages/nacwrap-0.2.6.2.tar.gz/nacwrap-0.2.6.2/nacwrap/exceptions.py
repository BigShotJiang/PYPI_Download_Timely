class WorkflowApiError(Exception):
    pass
