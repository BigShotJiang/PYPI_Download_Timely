agentle.agents.a2a.message\_parts.adapters
==========================================

.. automodule:: agentle.agents.a2a.message_parts.adapters

   
   .. rubric:: Classes

   .. autosummary::
   
      AgentPartToGenerationPartAdapter
      GenerationPartToAgentPartAdapter
   
.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   agent_part_to_generation_part_adapter
   generation_part_to_agent_part_adapter
