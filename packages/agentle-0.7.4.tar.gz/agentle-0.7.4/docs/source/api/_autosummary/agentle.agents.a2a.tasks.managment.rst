agentle.agents.a2a.tasks.managment
==================================

.. automodule:: agentle.agents.a2a.tasks.managment

   
.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   in_memory
   task_manager
