agentle.agents.a2a.models.artifact
==================================

.. automodule:: agentle.agents.a2a.models.artifact

   
   .. rubric:: Functions

   .. autosummary::
   
      Field
   
   .. rubric:: Classes

   .. autosummary::
   
      Any
      Artifact
      BaseModel
      ConfigDict
      Sequence
      TextPart
   