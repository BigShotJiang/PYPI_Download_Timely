# SPDX-License-Identifier: MIT
class Unset:
    pass
