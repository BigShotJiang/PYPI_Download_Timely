# pipeline_info = {
#     'pipeline_sheet_id': pipeline_sheet_id,
#     'create_at': time.time(),
#     'pipeline_sheet_name': pipeline_sheet_name,
#     'xai_task_sheet_id': "",
#     'xai_task_status': "undefined",
#     'xai_task_ticket': "",
#     'xai_evaluation_task_sheet_id': "",
#     'evaluation_task_status': "undefined",
#     'evaluation_task_ticket': "",
# }

pipeline_sheet_id = 'pipeline_sheet_id'
create_at = 'create_at'
pipeline_sheet_name = 'pipeline_sheet_name'
pipeline_execution_name = 'pipeline_execution_name'
pipeline_ticket = 'pipeline_ticket'
pipeline_type = 'pipeline_type'

task_execution_tickets = 'task_execution_tickets'
