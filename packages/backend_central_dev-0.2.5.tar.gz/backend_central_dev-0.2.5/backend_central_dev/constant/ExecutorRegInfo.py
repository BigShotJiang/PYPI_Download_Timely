
executor_id = 'executor_id'
executor_name = 'executor_name'
executor_owner = 'executor_owner'
executor_register_time = 'executor_register_time'
executor_info = 'executor_info'
executor_type = 'executor_type'
executor_endpoint_url = 'executor_endpoint_url'
publisher_endpoint_url = 'publisher_endpoint_url'

sys_info = 'sys_info'
