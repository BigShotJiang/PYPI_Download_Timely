
time_tail = '__time_tail__'
executor_id = 'executor_id'
executor_endpoint_url = 'executor_endpoint_url'

task_sheet_id = 'task_sheet_id'
task_sheet = 'task_sheet'
task_sheet_name = 'task_sheet_name'
task_type = 'task_type'
task_ticket = 'task_ticket'
task_owner = 'task_owner'
task_function_key = 'task_function_key'

publisher = 'publisher'

task_execution_name = 'task_execution_name'
task_status = 'task_status'
task_execution_std_output_str = 'task_execution_std_output_str'
task_execution_std_error_str = 'task_execution_std_error_str'
task_parameters = 'task_parameters'

db_service_url = 'db_service_url'
model_service_url = 'model_service_url'
xai_service_url = 'xai_service_url'
evaluation_service_url = 'evaluation_service_url'
model_evaluation_service_url = 'model_evaluation_service_url'

previous_task_ticket = 'previous_task_ticket'
next_task_ticket = 'next_task_ticket'

request_time = 'request_time'
start_time = 'start_time'
end_time = 'end_time'
running_info = 'running_info'
code_version_hash = 'code_version_hash'

empty = ''
