executor_registration_col = 'executor_registration_col'

task_sheet_col = 'task_sheet_col'
task_execution_col = 'task_execution_col'

pipeline_sheet_col = 'pipeline_sheet_col'
pipeline_execution_col = 'pipeline_execution_col'

configuration_col = 'configuration_col'
