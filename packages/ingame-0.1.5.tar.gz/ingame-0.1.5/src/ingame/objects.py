import tkinter as tk

def Button(
    tk_obj: tk.Tk,
    **kwargs
) -> tk.Button:
    return tk.Button(tk_obj, **kwargs)