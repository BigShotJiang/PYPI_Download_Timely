from django.apps import AppConfig


class WbwriterConfig(AppConfig):
    name = "wbwriter"
