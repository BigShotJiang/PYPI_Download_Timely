from pathlib import Path

version = (Path(__file__).parent / "version").read_text().strip()
