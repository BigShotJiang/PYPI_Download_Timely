# Long term wishes

- fuzzy search tables + columns + enums 
- LLM-friendly installation docs
- allow executing write queryies: config flag to enable it only on certain DBs + use solicitation to enable writes for the duration of a session
- allow live reloading of config
- add temporary DB just for the current session
- config via .env file or env vars
- HTTP/SSE
- Create a CI pipeline using GitHub Actions that runs pytest

