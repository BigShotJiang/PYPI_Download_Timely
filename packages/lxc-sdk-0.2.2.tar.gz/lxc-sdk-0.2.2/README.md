# my_package

Tools for convenient developing <3

## Installation

```bash
pip install lxc-sdk
```

## What's new in 0.2.X

- Added more useful functions
- And more ... games???


released on 2025-07-25