#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# pygenutils/operative_systems/__init__.py

# Define what should be available when using 'from pygenutils.operative_systems import *'
__all__ = [
    'os_operations'
]