"""Write structure files for .as and .xyz format"""
