2025-05-30 Version: 1.1.0
- Support API acceptFulfillmentDecision.
- Update API CreateDemandPlan: add request parameters body.targetCid.
- Update API CreateDemandPlanV2: add request parameters body.targetCid.
- Update API PushResourcePlan: add request parameters body.methodList.$.promiseDate.
- Update API PushResourcePlan: add request parameters body.methodList.$.dataList.$.supplyVmAmount.


2023-11-29 Version: 1.0.0
- Generated python 2021-12-17 for yunjian.

