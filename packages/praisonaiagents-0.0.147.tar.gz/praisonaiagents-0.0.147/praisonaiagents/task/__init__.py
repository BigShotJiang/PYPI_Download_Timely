"""Task module for AI agent tasks"""
from .task import Task

__all__ = ['Task'] 