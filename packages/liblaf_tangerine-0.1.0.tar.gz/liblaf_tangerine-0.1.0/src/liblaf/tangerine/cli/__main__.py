from ._app import app


def main() -> None:
    app.meta()
