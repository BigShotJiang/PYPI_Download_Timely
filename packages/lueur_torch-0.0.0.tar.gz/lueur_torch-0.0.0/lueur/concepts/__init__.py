"""
Module for extracting concepts.
"""

from .craft import craft
