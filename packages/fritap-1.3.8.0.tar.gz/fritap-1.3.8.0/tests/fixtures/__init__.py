"""
Test fixtures and test data for friTap testing.

Contains mock objects, sample data, and test utilities
used across different test modules.
"""