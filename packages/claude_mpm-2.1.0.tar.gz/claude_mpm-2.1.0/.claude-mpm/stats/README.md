# Statistics Directory

Contains aggregated metrics:
- Agent performance statistics
- Token usage tracking
- Execution time analysis
- Success rates
- Task completion metrics
