# SPDX-License-Identifier: MIT
import logging

logger = logging.getLogger("odxtools")

xsi = "{http://www.w3.org/2001/XMLSchema-instance}"
