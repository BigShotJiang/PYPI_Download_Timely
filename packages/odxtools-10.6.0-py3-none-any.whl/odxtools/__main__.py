# SPDX-License-Identifier: MIT
if __name__ == "__main__":
    from . import _main

    # Command line tool
    _main()
