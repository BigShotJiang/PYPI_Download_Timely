# SPDX-License-Identifier: MIT
from enum import Enum


class Direction(Enum):
    UPLOAD = "UPLOAD"
    DOWNLOAD = "DOWNLOAD"
