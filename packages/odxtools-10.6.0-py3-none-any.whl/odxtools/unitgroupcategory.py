# SPDX-License-Identifier: MIT
from enum import Enum


class UnitGroupCategory(Enum):
    COUNTRY = "COUNTRY"
    EQUIV_UNITS = "EQUIV-UNITS"
