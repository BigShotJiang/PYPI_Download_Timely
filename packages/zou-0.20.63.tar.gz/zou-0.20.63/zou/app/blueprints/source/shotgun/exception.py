class ShotgunEntryImportFailed(Exception):
    pass
