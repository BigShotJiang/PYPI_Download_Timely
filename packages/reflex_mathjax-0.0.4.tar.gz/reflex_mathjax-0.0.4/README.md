# mathjax

A Reflex custom component mathjax.

## Installation

```bash
pip install reflex-mathjax
```