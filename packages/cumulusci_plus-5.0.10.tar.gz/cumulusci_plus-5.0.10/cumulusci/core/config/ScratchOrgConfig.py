from cumulusci.utils.deprecation import warn_moved

from .scratch_org_config import *  # noqa

warn_moved(".scratch_org_config", ".ScratchOrgConfig")
