"""
GACCode Monitor - 监控GACCode平台积分余额的工具
"""

__version__ = "0.1.0"
