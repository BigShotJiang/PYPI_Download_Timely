"""
GACCode Monitor 工具函数
"""
