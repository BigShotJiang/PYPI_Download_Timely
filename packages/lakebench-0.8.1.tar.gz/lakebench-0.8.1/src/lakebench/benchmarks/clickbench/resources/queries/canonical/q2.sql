SELECT
    COUNT(*)
FROM
    hits
WHERE
    AdvEngineID <> 0;