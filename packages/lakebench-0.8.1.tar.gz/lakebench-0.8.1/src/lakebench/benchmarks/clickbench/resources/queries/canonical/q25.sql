SELECT
    SearchPhrase
FROM
    hits
WHERE
    SearchPhrase <> ''
ORDER BY
    EventTime
LIMIT
    10;