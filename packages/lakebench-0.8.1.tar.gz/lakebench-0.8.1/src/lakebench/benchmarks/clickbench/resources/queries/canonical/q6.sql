SELECT
    COUNT(DISTINCT SearchPhrase)
FROM
    hits;