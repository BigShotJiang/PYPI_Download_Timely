"""AWS Bedrock AgentCore A2A Proxy."""

__version__ = "0.1.2"
