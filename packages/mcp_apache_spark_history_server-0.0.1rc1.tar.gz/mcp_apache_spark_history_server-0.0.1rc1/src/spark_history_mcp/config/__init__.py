"""Configuration handling for Spark History Server MCP."""
