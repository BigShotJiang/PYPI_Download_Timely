'''
import shortcuts
'''

from .pydanticalize import pydanticalize
