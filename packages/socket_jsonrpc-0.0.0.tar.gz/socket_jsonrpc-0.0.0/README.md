# socket-jsonrpc
Library for JSONRPC 2.0 over TCP/IP and UNIX sockets
