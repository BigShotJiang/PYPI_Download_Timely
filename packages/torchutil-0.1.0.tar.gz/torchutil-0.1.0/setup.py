from setuptools import find_packages, setup


with open('README.md') as file:
    long_description = file.read()


setup(packages=find_packages())
