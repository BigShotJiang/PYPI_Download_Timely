.. _nutrient_profile-api:

Nutrient Profile
================

This module contains the ``NutrientProfile`` data class, which holds detailed nutritional and dietary information.

.. automodule:: meal_generator.nutrient_profile
   :members:
   :undoc-members:
   :show-inheritance: