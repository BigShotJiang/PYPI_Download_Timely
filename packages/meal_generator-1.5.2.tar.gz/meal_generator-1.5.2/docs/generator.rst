.. _generator-api:

Generator
=========

This module contains the core logic for generating meal data from natural language strings using the Generative AI model.

.. automodule:: meal_generator.generator
   :members:
   :undoc-members:
   :show-inheritance: