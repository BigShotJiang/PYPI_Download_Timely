"""
Constants used throughout the VA (Vibe Automation) framework.
"""

REVIEW_TIMEOUT = 600  # Default timeout in seconds for review operations
