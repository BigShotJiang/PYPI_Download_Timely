# Kimina client

Client SDK to interact with Kimina Lean server.

Usage:
```python
from kimina import Kimina

client = Kimina()
client.check("#check Nat")
```