

# Graph ID

## Installation 
### pypi
```
pip install graph-id-core
```

### GitHub
```
git clone https://github.com/kmu/graph-id-core.git
git submodule init
git submodule update
pip install -e .
```
