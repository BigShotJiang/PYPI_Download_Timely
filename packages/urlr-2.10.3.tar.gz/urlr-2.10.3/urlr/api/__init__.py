# flake8: noqa

# import apis into api package
from urlr.api.access_tokens_api import AccessTokensApi
from urlr.api.domains_api import DomainsApi
from urlr.api.folders_api import FoldersApi
from urlr.api.links_api import LinksApi
from urlr.api.qr_codes_api import QRCodesApi
from urlr.api.statistics_api import StatisticsApi
from urlr.api.workspaces_api import WorkspacesApi

