from .fcn import (
    VggFCN8s,
    VggFCN16s,
    VggFCN32s,
    VggFCNs,
    VggFCN,
    ResFCN,
    DenseFCN,
    MobileFCN,
    MobileFCN1
)

from .unet import UNet
