"""Integration tests for estat_api_dlt_helper."""
