# Channelog
All further changes wil be documented here.

## [0.1.0] -2025-07-28
- init release of `json_parser`
- `json_parser` can parse json files using lexical analysis
- support for primitve, compound datatypes, comments.
- cli interface for validating json files.
