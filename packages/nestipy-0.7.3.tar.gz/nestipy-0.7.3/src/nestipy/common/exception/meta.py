class ExceptionKey:
    MetaFilter: str = "__exception_filter__"
    MetaType: str = "__exception_filter_type__"
