from typing import TypedDict


class AuthHeaders(TypedDict):
    Authorization: str
