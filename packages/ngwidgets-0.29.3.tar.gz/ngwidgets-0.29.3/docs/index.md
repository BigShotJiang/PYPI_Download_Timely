# ngwidgets API Documentation

::: ngwidgets
    options:
      show_submodules: true
