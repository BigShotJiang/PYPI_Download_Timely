﻿bayesianbandits.api
===================

.. automodule:: bayesianbandits.api

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      Agent
      ContextualAgent
      EpsilonGreedy
      LipschitzContextualAgent
      PolicyDefaultUpdate
      PolicyProtocol
      ThompsonSampling
      UpperConfidenceBound
   
   

   
   
   



