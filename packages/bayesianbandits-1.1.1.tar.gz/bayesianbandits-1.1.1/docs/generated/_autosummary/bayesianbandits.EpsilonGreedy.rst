bayesianbandits.EpsilonGreedy
=============================

.. currentmodule:: bayesianbandits

.. autoclass:: EpsilonGreedy

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~EpsilonGreedy.__init__
      ~EpsilonGreedy.select
      ~EpsilonGreedy.update
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~EpsilonGreedy.samples_needed
   
   