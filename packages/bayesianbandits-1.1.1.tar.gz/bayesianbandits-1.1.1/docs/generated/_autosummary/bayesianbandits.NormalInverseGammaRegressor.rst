bayesianbandits.NormalInverseGammaRegressor
===========================================

.. currentmodule:: bayesianbandits

.. autoclass:: NormalInverseGammaRegressor

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~NormalInverseGammaRegressor.__init__
      ~NormalInverseGammaRegressor.decay
      ~NormalInverseGammaRegressor.fit
      ~NormalInverseGammaRegressor.get_metadata_routing
      ~NormalInverseGammaRegressor.get_params
      ~NormalInverseGammaRegressor.partial_fit
      ~NormalInverseGammaRegressor.predict
      ~NormalInverseGammaRegressor.sample
      ~NormalInverseGammaRegressor.score
      ~NormalInverseGammaRegressor.set_fit_request
      ~NormalInverseGammaRegressor.set_params
      ~NormalInverseGammaRegressor.set_partial_fit_request
      ~NormalInverseGammaRegressor.set_score_request
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~NormalInverseGammaRegressor.cov_
      ~NormalInverseGammaRegressor.shape_
   
   