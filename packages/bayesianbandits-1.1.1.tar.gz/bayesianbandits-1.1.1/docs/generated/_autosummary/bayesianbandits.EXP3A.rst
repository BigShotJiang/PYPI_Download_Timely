bayesianbandits.EXP3A
=====================

.. currentmodule:: bayesianbandits

.. autoclass:: EXP3A

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~EXP3A.__init__
      ~EXP3A.select
      ~EXP3A.update
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~EXP3A.samples_needed
   
   