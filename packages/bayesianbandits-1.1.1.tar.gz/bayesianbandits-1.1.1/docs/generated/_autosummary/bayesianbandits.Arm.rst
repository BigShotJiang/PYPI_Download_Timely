bayesianbandits.Arm
===================

.. currentmodule:: bayesianbandits

.. autoclass:: Arm

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Arm.__init__
      ~Arm.decay
      ~Arm.pull
      ~Arm.sample
      ~Arm.update
   
   

   
   
   