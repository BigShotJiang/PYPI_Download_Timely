bayesianbandits.ArmColumnFeaturizer
===================================

.. currentmodule:: bayesianbandits

.. autoclass:: ArmColumnFeaturizer

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ArmColumnFeaturizer.__init__
      ~ArmColumnFeaturizer.transform
   
   

   
   
   