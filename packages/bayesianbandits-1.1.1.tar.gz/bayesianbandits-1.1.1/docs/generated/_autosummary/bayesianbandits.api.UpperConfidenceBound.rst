bayesianbandits.api.UpperConfidenceBound
========================================

.. currentmodule:: bayesianbandits.api

.. autoclass:: UpperConfidenceBound

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~UpperConfidenceBound.__init__
      ~UpperConfidenceBound.select
      ~UpperConfidenceBound.update
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~UpperConfidenceBound.samples_needed
   
   