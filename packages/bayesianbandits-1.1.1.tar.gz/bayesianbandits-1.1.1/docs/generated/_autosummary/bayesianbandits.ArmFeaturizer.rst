bayesianbandits.ArmFeaturizer
=============================

.. currentmodule:: bayesianbandits

.. autoclass:: ArmFeaturizer

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ArmFeaturizer.__init__
      ~ArmFeaturizer.transform
   
   

   
   
   