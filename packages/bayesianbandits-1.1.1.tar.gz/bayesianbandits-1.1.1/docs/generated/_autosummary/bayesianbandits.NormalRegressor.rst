bayesianbandits.NormalRegressor
===============================

.. currentmodule:: bayesianbandits

.. autoclass:: NormalRegressor

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~NormalRegressor.__init__
      ~NormalRegressor.decay
      ~NormalRegressor.fit
      ~NormalRegressor.get_metadata_routing
      ~NormalRegressor.get_params
      ~NormalRegressor.partial_fit
      ~NormalRegressor.predict
      ~NormalRegressor.sample
      ~NormalRegressor.score
      ~NormalRegressor.set_fit_request
      ~NormalRegressor.set_params
      ~NormalRegressor.set_partial_fit_request
      ~NormalRegressor.set_score_request
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~NormalRegressor.cov_
   
   