bayesianbandits.FunctionArmFeaturizer
=====================================

.. currentmodule:: bayesianbandits

.. autoclass:: FunctionArmFeaturizer

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~FunctionArmFeaturizer.__init__
      ~FunctionArmFeaturizer.transform
   
   

   
   
   