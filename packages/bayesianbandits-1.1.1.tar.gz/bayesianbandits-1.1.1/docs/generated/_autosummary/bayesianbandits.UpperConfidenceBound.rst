bayesianbandits.UpperConfidenceBound
====================================

.. currentmodule:: bayesianbandits

.. autoclass:: UpperConfidenceBound

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~UpperConfidenceBound.__init__
      ~UpperConfidenceBound.select
      ~UpperConfidenceBound.update
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~UpperConfidenceBound.samples_needed
   
   