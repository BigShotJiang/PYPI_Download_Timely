from enum import Enum


class LibertaiChain(str, Enum):
    base = "base"
    solana = "solana"
