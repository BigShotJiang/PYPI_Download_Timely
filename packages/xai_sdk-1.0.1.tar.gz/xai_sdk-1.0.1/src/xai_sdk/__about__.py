# DO NOT EDIT THIS MANUALLY.

# To change the version, do so using `uv run hatch version <new-version>`
# or `uv run hatch version <patch|minor|major>` to bump the patch/minor/major version respectively.
# See https://hatch.pypa.io/latest/version/#updating for more details.
__version__ = "1.0.1"
