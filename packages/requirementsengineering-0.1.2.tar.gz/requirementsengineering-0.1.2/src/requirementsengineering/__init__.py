# __init__.py
from .main import main

__version__ = "0.1.2"

if __name__ == "__main__":
    main()
