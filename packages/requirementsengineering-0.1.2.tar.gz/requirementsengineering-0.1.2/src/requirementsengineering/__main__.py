# requirementsengineering/__main__.py

from .main import main as requirements_main

def main():
    requirements_main()

if __name__ == "__main__":
    main()
