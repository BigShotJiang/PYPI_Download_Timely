# TODO: This custom green screens need work, refactor and 
# make them work better and simplify te code.
# Consider this part as experimental.
# Was working in the first stage but it is not clear how 
# to handle it in code (x.x)

# I kept working on them and I simplified the process.
# We can add some image or video into an image or
# video greenscreen. We can customize any greenscreen
# but we will have them stored online