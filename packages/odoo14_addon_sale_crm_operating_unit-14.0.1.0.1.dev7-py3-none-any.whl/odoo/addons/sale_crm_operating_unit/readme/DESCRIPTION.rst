This module introduces the following features:

* Passes the Operating Unit (OU) from Opportunity to Quotation.
