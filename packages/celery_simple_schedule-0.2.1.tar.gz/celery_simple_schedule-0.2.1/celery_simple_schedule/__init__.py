from .core import simplify_schedules

__all__ = ['simplify_schedules']
