"""Data loading and processing utilities."""
