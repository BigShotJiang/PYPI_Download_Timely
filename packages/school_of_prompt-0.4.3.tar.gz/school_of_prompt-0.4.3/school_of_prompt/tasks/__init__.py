"""Task detection and handling."""
