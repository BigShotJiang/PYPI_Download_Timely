import{r as t}from"./index.CJ1pwDgq.js";const o=r=>{const e=t.useRef();return t.useEffect(()=>{e.current=r},[r]),e.current};export{o as u};
