#!/bin/bash

apt-get install -y curl
curl -LsSf https://astral.sh/uv/install.sh | sh