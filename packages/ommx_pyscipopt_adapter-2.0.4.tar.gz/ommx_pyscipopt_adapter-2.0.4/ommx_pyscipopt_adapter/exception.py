class OMMXPySCIPOptAdapterError(Exception):
    pass
