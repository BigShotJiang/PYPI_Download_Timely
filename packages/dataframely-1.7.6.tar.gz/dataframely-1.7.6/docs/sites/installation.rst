Installation
============

To install ``dataframely``, use your favorite package manager, e.g., using ``pixi`` or ``pip``:

.. code:: bash

    pixi add dataframely
    pip install dataframely
