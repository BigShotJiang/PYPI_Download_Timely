FAQ
===

Whenever you find out something that you were surprised by or needed some non-trivial
thinking, please add it here.
