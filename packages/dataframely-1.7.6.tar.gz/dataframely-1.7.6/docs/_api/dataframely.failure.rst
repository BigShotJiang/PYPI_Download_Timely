dataframely.failure module
==========================

.. automodule:: dataframely.failure
   :members:
   :show-inheritance:
   :undoc-members:
