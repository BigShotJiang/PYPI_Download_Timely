dataframely.columns.string module
=================================

.. automodule:: dataframely.columns.string
   :members:
   :show-inheritance:
   :undoc-members:
