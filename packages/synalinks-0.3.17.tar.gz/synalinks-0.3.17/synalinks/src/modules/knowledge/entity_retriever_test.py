# License Apache 2.0: (c) 2025 Yoan Sallami (Synalinks Team)

from synalinks.src import testing


class EntityRetrieverTest(testing.TestCase):
    pass
