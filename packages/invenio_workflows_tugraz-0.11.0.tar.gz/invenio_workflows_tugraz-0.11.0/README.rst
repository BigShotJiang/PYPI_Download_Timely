# invenio-workflows-tugraz
Implements TU Graz specific workflows
