def main():
    print("Hello from open-xtract!")


if __name__ == "__main__":
    main()
