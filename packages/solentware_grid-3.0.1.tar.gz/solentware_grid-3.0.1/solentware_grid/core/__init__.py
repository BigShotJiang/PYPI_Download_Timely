# dataclient.py
# Copyright 2021 Roger Marsh
# Licence: See LICENCE (BSD licence)
"""Provide access to records for display in scrollable grids.

Refresh of multiple grids showing the same records when those records
are updated is supported.
"""
