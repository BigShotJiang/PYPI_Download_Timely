# git-keeper-client

This package provides the faculty client for git-keeper, a git-based system for
distributing, testing, and collecting programming assignments.

For more detailed documentation, see our GitHub repository:
[https://github.com/git-keeper/git-keeper](https://github.com/git-keeper/git-keeper)
