def run(annotation, ref_annotation):
    """

    TO BE IMPLEMENTED

    :param annotation:
    :param ref_annotation:
    :return:
    """
    return 0
