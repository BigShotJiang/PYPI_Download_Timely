from ml_tools.irdataset import main

if __name__ == "__main__":
    main()
