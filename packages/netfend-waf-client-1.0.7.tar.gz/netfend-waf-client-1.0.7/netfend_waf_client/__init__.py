# netfend_waf_client/__init__.py

from .waf_client import WAFClient
