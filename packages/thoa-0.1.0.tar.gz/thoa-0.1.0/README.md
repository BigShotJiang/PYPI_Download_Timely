# thoa
Thoa CLI for submitting jobs to Thoa platform
