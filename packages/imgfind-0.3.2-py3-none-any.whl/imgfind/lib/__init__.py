# TODO: detect and enable available media backends
# TODO: make backend-agnostic wrappers for meta reading, resizing, converting

# TODO: should we support not having any backend incl. pillow for ifind-only?
