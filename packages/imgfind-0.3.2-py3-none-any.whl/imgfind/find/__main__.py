import sys
from imgfind.find import main

sys.exit(main())
