# Srtify

A terminal application written in Python for translating srt subtitles to any language using Gemini AI