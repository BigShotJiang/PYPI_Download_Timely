class GrazieApiGatewayUrls:
    STAGING = "https://api.app.stgn.grazie.aws.intellij.net"
    PRODUCTION = "https://api.app.prod.grazie.aws.intellij.net"
