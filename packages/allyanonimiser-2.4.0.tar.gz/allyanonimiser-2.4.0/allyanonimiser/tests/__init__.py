"""
Test package for Allyanonimiser.
"""