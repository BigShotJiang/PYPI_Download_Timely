"""
Dataset publisher stub for testing.
"""

class DatasetPublisher:
    """Stub class for testing."""
    def __init__(self):
        pass