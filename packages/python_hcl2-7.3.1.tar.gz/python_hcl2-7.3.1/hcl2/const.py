"""Module for various constants used across the library"""

START_LINE_KEY = "__start_line__"
END_LINE_KEY = "__end_line__"
