from password_generator.generator import generate_password

def main():
    password = generate_password()
    print(password)
