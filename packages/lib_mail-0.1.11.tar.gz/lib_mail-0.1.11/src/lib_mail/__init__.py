from .mailbox import Mailbox

__all__ = [
    'Mailbox',
]