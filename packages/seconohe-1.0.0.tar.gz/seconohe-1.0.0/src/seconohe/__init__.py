import os


__version__ = "1.0.0"
JS_PATH = os.path.join(os.path.dirname(__file__), "js")
