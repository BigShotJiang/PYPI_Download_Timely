# ilc-models

![version](https://img.shields.io/badge/version-0.1.8-blue)
![Python Version from PEP 621 TOML](https://img.shields.io/python/required-version-toml?tomlFilePath=https%3A%2F%2Fraw.githubusercontent.com%2Ffourtreestech%2Filc-models%2Fmain%2Fpyproject.toml)
![coverage](https://img.shields.io/badge/coverage-100%25-green)

**ilc-models** contains all data models for the *ILC* project.

## Installation

    (.venv) $ pip install ilc-models


