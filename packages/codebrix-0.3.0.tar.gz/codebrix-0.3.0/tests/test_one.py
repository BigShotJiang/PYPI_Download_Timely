from codebrix import utils

utils.ai.speak("Hallo, dies ist ein KI-Assistent. ich freue mich, sie willkommen zu heißen!")