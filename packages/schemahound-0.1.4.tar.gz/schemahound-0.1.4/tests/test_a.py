def test_init() -> None:
    assert 1 == 1  # noqa: PLR0133
