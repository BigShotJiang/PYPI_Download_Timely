def hello_world() -> None:
    print("Initial release test")
