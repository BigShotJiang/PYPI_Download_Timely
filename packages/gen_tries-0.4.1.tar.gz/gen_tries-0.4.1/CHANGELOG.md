# python-gen-trie

* 0.1.0 - Initial release to github
* 0.1.1 through 0.1.3 WIP releases
* 0.1.4 - First public release to PyPI
* 0.1.5 - Fix to install instructions
* 0.2.0 - Refactored internal node implementation
* 0.2.1 - Updated examples code
* 0.2.2 - More examples code
* 0.3.0 - Added support for 'key in trie'
* 0.3.1 - Typo correction for example 7
* 0.3.2 - Updated installation instructions
* 0.3.3 - Fix to readthedocs usage page
* 0.4.0 - Deprecated gentrie.Hashable for gentrie.TrieKeyToken and updated documentation. Tuned tests and added more documentation.
* 0.4.1 - Removed use of '@deprecated' decorator as it is only available from Python 3.13 and later. Added example of using dataclass for a class usable as a content-aware trie key token. Added docstrings for test classes. Tweaked clear() method for performance. Simplified prefixes() method slightly. Addressed various minor lint issues.
