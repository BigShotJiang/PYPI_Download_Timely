"""Run scripts for mini-SWE-agent."""
