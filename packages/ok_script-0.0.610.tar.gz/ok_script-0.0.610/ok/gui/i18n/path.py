import os

i18n_path = os.path.dirname(__file__)
