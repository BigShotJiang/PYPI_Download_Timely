import os

PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))
SCIPTS_DIR = os.path.join(os.path.dirname(PACKAGE_DIR), 'Scipts')

