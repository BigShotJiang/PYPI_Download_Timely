2025-07-24 Version: 2.2.0
- Support API CreateService.
- Support API DeleteService.
- Support API GetService.
- Support API ListServices.
- Support API UpdateService.


2025-07-23 Version: 2.1.0
- Support API GetServiceObservability.
- Update API ListAlertActions: add response parameters Body.alertActions.$.ebParam.
- Update API ListAlertActions: add response parameters Body.alertActions.$.fc3Param.


2025-05-13 Version: 2.0.0
- Support API CreateEntityStore.
- Support API CreatePrometheusInstance.
- Support API CreateUmodel.
- Support API DeleteEntityStore.
- Support API DeleteUmodel.
- Support API DeleteUmodelData.
- Support API DeleteWorkspace.
- Support API GetEntityStore.
- Support API GetEntityStoreData.
- Support API GetUmodel.
- Support API GetUmodelData.
- Support API GetWorkspace.
- Support API ListWorkspaces.
- Support API PutWorkspace.
- Support API UpdateUmodel.
- Support API UpsertUmodelData.
- Update API ListAlertActions: add request parameters RegionId.
- Update API ListAlertActions: delete request parameters regionId.


2024-11-04 Version: 1.0.0
- Generated python 2024-03-30 for Cms.

