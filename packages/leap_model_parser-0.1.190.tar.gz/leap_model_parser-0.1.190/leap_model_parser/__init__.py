from onnx2kerastl import customonnxlayer  # type: ignore

# expose customonnxlayer to the outside
customonnxlayer = customonnxlayer
