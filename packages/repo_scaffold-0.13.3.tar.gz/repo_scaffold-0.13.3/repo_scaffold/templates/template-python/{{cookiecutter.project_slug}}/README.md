# {{cookiecutter.repo_name}}

### Overview

{{cookiecutter.description}}

### Installation

```bash
pip install {{cookiecutter.project_slug}}
```