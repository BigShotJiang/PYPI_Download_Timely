<div align="center">
    <h1>unzer-python-sdk</h1>
    <a href="https://pypi.org/project/unzer/">
        <img alt="Badge showing current PyPI version" title="PyPI" src="https://img.shields.io/pypi/v/unzer">
    </a>
    <a href="LICENSE">
        <img src="https://img.shields.io/github/license/mausbrand/unzer-python-sdk" alt="Badge displaying the license" title="License badge">
    </a>
    <br>
    An unofficial python SDK for the payment service <a href="https://www.unzer.com">Unzer</a>.
</div>
