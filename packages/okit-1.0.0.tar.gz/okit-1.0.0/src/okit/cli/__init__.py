"""
okit CLI Module

Includes functionality related to the command-line interface.
"""

from .main import main

__all__ = [
    "main",
]