"""Entry point for the debug_dojo package."""

if __name__ == "__main__":
    from ._cli import main

    main()
