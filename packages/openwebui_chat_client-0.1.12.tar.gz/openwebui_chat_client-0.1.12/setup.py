from setuptools import setup

# This file is required for compatibility purposes.
# The main configuration is in pyproject.toml.
setup()