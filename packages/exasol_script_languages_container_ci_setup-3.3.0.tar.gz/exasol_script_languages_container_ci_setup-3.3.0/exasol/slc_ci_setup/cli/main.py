#! /usr/bin/env python3

import exasol.slc_ci_setup.cli.commands  # pylint: disable=unused-import
from exasol.slc_ci_setup.cli.cli import cli


def main():
    cli()


if __name__ == "__main__":
    main()
