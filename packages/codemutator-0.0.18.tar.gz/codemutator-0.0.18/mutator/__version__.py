"""Version information for the Mutator Framework."""

__version__ = "0.0.18"
__author__ = "Code Mutator SDK Team"
__email__ = "info@codemutator.com"
__description__ = "A comprehensive Python SDK for building coding agents using GenAI" 