"""Top-level package for Acumatica API wrapper."""
from .client import AcumaticaClient

__all__ = ["AcumaticaClient"]
