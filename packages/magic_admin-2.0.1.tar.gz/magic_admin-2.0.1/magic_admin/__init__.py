from magic_admin.magic import Magic  # noqa: F401


# Magic API secret key.
api_secret_key = None

# A grace period time in second applied to the nbf field for token validation.
did_token_nbf_grace_period_s = 300
