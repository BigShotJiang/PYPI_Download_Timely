from enum import Enum
 
class SensorOrder(Enum):
    FIRST = 1
    LAST = 2
