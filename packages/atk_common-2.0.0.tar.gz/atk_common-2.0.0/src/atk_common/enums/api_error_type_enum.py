from enum import Enum
 
class ApiErrorType(Enum):
    CONNECTION = 1
    INTERNAL = 2
