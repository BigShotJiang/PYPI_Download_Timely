A library to fetch data form ETF websites active on Tehran Stock Exchange.
