# Snipd export format

![](https://raw.githack.com/bGZo/assets/dev/2025/202501200020991.gif)

> [!NOTE]
> This is a very early version, if something help, I would maintain it.

Snipd export to a singal file sucks, which cannot query on obsidian, And I have more then 3,000 snipds on platform, If I format manully, it's would be a hell.

I export them and delete the account, even though the origin data is still on server. I have no idea how deal with that, or is there something alternative?

Any, snipd sucks!

## Quick Start

```shell
pip3 install --trusted-host pypi.tuna.tsinghua.edu.cn -i https://pypi.tuna.tsinghua.edu.cn/simple -r requirements.txt -t .
python3 main.py
```
