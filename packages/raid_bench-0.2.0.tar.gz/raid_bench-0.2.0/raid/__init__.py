from ._version import __version__
from .detect import run_detection
from .evaluate import run_evaluation
