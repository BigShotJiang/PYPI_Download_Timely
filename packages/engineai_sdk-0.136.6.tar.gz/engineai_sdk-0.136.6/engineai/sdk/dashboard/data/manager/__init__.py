"""Data management components for handling widget dependencies."""
