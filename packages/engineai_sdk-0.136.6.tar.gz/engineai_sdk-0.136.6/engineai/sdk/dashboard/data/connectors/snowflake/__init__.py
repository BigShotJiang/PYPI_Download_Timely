"""Snowflake connector for dashboard data retrieval."""
