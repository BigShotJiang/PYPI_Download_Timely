"""Specs for Snowflake Connector Dependency."""

from .snowflake_connector import SnowflakeConnectorDependency

__all__ = ["SnowflakeConnectorDependency"]
