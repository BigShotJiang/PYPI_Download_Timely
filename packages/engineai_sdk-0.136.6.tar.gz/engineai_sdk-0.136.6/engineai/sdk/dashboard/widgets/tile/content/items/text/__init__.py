"""Tile Text Item Package."""
