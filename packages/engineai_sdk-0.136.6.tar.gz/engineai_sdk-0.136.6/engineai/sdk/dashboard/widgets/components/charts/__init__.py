"""Specs shared by different chart widgets."""
