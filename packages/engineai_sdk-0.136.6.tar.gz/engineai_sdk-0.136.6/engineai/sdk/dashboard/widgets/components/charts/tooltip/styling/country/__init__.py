"""Country-specific styling components for chart tooltip items."""
