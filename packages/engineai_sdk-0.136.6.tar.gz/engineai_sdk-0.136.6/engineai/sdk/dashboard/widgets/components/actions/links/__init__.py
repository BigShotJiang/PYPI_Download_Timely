"""Specs for Actions objects."""

from .url_link import UrlLink

__all__ = ["UrlLink"]
