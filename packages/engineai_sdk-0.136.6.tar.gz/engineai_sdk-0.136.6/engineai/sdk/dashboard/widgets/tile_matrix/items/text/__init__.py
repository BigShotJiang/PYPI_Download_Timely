"""Specs for Tile Matrix text item."""
