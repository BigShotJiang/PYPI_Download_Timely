"""Specs for Tile Matrix items input."""
