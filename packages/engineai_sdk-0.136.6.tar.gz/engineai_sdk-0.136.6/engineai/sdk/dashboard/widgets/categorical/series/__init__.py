"""Specs for series in a Categorical chart."""
