"""Dashboard version package."""
