"""
EzQt Widgets CLI Package

Command-line interface for running examples and utilities.
"""

__version__ = "1.0.0"
__author__ = "EzQt Widgets Team" 