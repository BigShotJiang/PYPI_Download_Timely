# Pattern

This is a simple package to print the patterns

# Installation

Install it using pip

pip install Shalinee_pattern_package

from pattern import (pyramid,right_angle,left_angle)

# pyramid
pyramid(5)
# output

    *
   * *
  * * *
 * * * *
* * * * *