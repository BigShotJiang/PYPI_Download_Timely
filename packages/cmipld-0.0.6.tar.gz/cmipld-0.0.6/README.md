# CMIP-LD
CMIP Linked Data Utilities Library

<image style='width:400px;' src="https://wcrp-cmip.github.io/CMIP-LD/static/logo.jpg"/>




## Developing 
## installing using editable mode
`pip install -e .`
