# CMIP-LD Documentation

Welcome to the CMIP-LD documentation.

## Overview

This documentation includes:
- Project information
- Source data documentation (auto-generated from src-data folder)
- API references
- Usage guides

## Navigation

Use the navigation menu to browse the documentation.
