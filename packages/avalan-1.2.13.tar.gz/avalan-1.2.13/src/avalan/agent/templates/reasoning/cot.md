Let's solve the following problem step by step.

Problem: {{ prompt }}

Provide your reasoning inside <think> and </think> tags, or start the line with "Reasoning:".
Finish by giving the final answer prefixed with "Answer:".
