from typing import Literal

Encoding = Literal["utf-8"]


class PartitionerException(BaseException):
    pass
