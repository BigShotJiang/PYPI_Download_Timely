"""UI modules for the Computer-Use Agent."""
