"""UI-TARS tools package."""
