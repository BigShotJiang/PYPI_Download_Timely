"""UI-TARS Agent provider package."""
