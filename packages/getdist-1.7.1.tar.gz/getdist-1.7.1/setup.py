from setuptools import setup

setup(name="getdist")
