from ._version import VERSION

__version__ = VERSION

def test():
    print(f"ExosphereHost PySDK v{VERSION}")