"""Tests for aceiot_models.api package."""
