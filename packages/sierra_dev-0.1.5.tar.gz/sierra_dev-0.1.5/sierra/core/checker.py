###TODO Implement type-checker and different checks for invoker scripts using ast and PEP for python standards [optional]
