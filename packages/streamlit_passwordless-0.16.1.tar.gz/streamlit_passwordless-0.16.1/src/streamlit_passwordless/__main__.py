r"""Execute the Streamlit Passwordless CLI as `python -m streamlit_passwordless`."""

# Local
from streamlit_passwordless.cli.main import main

if __name__ == '__main__':
    main()
