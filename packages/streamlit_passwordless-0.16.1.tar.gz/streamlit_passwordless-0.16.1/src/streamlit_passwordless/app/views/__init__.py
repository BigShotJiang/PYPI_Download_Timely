r"""The views of the pages of the app."""
