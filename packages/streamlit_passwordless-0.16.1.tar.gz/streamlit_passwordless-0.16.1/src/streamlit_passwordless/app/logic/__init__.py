r"""The application logic of the Streamlit Passwordless web apps."""
