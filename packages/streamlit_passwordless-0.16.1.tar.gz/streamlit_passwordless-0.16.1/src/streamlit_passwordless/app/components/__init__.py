r"""The components of the web apps."""
