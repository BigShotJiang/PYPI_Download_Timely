r"""The Streamlit Passwordless CLI (stp) for managing the user database."""
