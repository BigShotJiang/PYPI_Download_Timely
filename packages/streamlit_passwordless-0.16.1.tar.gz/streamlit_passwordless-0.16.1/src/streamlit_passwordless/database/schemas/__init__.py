r"""The schemas of the data models that serve as the input to the database crud operations."""
