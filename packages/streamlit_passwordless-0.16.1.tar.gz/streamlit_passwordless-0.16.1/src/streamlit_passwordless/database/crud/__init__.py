r"""Functions for performing CREATE, UPDATE and DELETE operations on the database."""
