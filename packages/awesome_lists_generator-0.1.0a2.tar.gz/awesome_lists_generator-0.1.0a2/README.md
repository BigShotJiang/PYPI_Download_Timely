<h1 align="center">
    Awesome-List Generator
</h1>

The awesome-list-generator is a CLI tool the will generate a markdown page from yaml based configration file that allows you specifcy categories, labels and items to create your list. It alos comes with a GitHub Action workflow for a fully automated updates process. 

> Create your own awesome-lists in just 5 minutes with this guide (not ready yet).

## Highlights
- Generates a markdown page from a `yaml`  list 
- Flexiable configuration and generation 
- Verifies item link accessablity and can use the web-pages metadata to help populate 
- GitHub Action workflow for fully automated updates 

## Awesome Lists 
[![Awesome](https://awesome.re/badge.svg)](https://awesome.re)
Awesome-lists offer curated lists of content on specific topics that are generally avliable as open source GitHub repos.  For more inforamtion in setting up your own Awesome-list read the [Awesome Manifesto](https://github.com/sindresorhus/awesome/blob/main/awesome.md) and you can always find the main [Awesome](https://awesome.re) repo on GitHub. 

## Documentaion 

## Support 
