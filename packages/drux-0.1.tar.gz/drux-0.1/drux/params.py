# -*- coding: utf-8 -*-
"""Drux parameters and constants."""

DRUX_VERSION = "0.1"
