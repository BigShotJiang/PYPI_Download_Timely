# A stub implementation of argcomplete which does nothing.
import argparse
from typing import Any


def autocomplete(parser: argparse.ArgumentParser, **kw: Any) -> None:
    pass
