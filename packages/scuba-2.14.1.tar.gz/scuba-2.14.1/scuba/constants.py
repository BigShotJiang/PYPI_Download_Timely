# Name of config file to search for and load
SCUBA_YML = ".scuba.yml"

# Default shell to run in the container
DEFAULT_SHELL = "/bin/sh"
