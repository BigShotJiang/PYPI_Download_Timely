"""
Cleanup package for removing old data from the SEC processing pipeline.
"""
