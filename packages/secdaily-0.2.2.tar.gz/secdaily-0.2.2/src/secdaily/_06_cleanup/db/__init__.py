"""
Database access module for the cleanup package.
"""
