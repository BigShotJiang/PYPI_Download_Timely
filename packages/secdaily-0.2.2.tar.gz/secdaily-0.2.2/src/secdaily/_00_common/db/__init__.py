"""
Database access modules for common functionality.
"""
