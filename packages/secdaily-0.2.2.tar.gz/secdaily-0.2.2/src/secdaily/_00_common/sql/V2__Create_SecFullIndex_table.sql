CREATE TABLE IF NOT EXISTS sec_fullindex_file
(
    year,
    quarter,
    state,
    processdate,
    PRIMARY KEY (year, quarter)
)