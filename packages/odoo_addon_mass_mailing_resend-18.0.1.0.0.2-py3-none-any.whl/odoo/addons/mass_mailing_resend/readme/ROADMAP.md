- Add an indicator / filter for knowing resent mailings.
- Include information on the number of new recipients to be sent on the
  resending (through get_remaining_recipients method).
