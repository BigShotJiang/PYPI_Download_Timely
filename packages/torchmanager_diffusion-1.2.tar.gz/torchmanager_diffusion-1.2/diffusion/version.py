from torchmanager_core import Version

API = Version("v1.2")
CURRENT = Version("v1.2")
DESCRIPTION = f"Torchmanager Implementation for Diffusion Model ({CURRENT})"
