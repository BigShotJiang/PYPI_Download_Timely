'use strict';

class UrlParametersExtension {
    getUrl(url) {
        return url;
    }
}