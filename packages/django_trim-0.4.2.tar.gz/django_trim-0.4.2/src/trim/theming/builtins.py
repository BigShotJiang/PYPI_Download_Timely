"""
Apply to the template engine options for auto loading the template theming tool
"""

from .templatetags.theming import *
