from .config import install, name_default_redirect
