{
  // Unexpected token MULT
  j = 5/*3;
}