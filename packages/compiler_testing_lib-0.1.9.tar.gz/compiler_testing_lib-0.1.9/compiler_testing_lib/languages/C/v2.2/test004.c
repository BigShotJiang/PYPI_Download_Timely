{
  // Unexpected token EOL
  w = ;
}