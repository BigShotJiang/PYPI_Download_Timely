{
  // Unexpected ELSE
  f = 1;
  if (f == 1) {
    f = 2;
  } else {
    f = 3;
  } else {
    f = 4;
  }
}