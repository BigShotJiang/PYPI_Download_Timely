{
  // Unexpected token CLOSE_BRA
  c = //4;
}