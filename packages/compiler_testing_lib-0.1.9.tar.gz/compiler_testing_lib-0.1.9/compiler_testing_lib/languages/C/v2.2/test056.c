{
  // Missing OPEN_PAR
  while 1 == 1
    f = 5;
}