{
  // Unexpected token IDEN
  X = 1;
  d = 3 X;
}