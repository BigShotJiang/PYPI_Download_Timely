{
  // Unexpected EOF (Missing CLOSE_BRA)
  e = 1;
  if (e == 1) {
}