{
  // Unexpected EOF (Missing CLOSE_BRA)
  f = 1;
  while (f == 1) {
    f = 2;
}