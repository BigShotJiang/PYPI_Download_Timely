{
  // Unexpected token MULT
  h = *;
}