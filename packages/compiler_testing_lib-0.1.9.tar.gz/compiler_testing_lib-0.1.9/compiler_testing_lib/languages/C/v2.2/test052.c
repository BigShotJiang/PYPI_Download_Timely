{
  // Missing Right Expression
  o = 1;
  if (!) {
    o = 2;
  }
}