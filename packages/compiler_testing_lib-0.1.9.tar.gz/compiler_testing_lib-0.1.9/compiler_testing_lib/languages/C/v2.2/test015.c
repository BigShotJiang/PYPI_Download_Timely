{
  // Unexpected token MULT
  j = 1+*7;
}