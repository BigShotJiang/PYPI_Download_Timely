{
  // Unexpected token DIV
  u = /;
}