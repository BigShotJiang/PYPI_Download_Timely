{
  // Unexpected OPEN_BRA
  u = 1;
  if (u == 1) {
    u = 2;
  }
  {
    u = 3;
  }
}