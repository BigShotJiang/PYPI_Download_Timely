{
  // Unexpected token MULT
  r = 5**2;
}