{
  // Missing OPEN_BRA
  j = 1;
  if (j == 1)
    j = 2;
  }
}