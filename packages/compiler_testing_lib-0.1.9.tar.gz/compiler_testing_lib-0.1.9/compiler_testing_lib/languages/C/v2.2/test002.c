{
  // Unexpected token EOL
  y = 4+;
}