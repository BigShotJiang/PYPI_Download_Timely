{
  // Unexpected EOF (Missing CLOSE_BRA)
  v = 1;
  if (v == 1) {
    v = 2;
  } else {
    v = 3;
}