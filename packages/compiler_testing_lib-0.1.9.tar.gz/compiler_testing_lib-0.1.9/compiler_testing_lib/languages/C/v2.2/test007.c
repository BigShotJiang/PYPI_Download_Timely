{
  // Unexpected token INT (expected EOL)
  u = 4 2;
}