{
  // Unexpected token CLOSE_PAR
  h = (5));
}