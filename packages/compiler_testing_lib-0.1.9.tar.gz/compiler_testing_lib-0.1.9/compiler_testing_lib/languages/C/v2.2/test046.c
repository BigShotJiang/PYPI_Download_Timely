{
  // Missing OPEN_BRA
  w = 1;
  while (w == 1)
    w = 2;
  }
}