{
  // Unexpected token MULT
  t = *7;
}