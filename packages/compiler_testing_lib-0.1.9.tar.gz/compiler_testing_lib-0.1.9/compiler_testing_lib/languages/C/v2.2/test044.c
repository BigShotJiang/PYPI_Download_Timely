{
  // Missing OPEN_BRA
  k = 1;
  if (k == 1) {
    k = 2;
  } else
    k = 3;
  }
}