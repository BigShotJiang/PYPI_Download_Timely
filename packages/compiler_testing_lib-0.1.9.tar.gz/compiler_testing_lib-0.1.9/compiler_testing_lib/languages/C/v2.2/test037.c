{
  // Unexpected token IDEN
  1x = 2;
  printf(1x);
}