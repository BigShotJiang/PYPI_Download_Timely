{
  // Unexpected token DIV
  s = 1+/7;
}