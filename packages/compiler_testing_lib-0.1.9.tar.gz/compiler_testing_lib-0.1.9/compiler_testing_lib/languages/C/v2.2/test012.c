{
  // Unexpected token EOL
  d = 4/;
}