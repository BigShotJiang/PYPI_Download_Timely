{
  // Unexpected token CLOSE_PAR
  a = 3);
}