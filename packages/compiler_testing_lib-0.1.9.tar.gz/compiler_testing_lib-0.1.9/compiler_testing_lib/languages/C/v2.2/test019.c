{
  // Unexpected token DIV
  u = 9*/4;
}