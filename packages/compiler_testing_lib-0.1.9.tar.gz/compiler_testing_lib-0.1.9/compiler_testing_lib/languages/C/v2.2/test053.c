{
  // Missing OPEN_PAR
  p = scanf;
}