{
  // Unexpected token DIV
  f = /9;
}