{
  // Unexpected token EOL
  h = 5*;
}