{
  // Missing CLOSE_PAR
  s = ((3);
}