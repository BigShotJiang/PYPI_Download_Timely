{
  // Unexpected token OPEN_BRA (expected EOF)
  x = 8;
}
{
}