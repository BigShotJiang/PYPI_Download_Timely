{
  // Unexpected token CLOSE_BRA (expected EOF)
  g = 7;
}
}