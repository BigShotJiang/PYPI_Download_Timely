{
  // Unexpected token DIV
  c = /6;
}