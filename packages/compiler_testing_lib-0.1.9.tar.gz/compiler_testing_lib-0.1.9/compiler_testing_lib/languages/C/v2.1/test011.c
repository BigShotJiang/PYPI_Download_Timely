{
  // Unexpected token EOL
  t = 5*;
}