{
  // Unexpected token MULT
  a = 1+*4;
}