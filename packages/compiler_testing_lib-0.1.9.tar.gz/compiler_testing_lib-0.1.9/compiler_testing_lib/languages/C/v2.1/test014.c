{
  // Unexpected token DIV
  p = /;
}