{
  // Unexpected token EOF (expected CLOSE_BRA)
  i = 3;