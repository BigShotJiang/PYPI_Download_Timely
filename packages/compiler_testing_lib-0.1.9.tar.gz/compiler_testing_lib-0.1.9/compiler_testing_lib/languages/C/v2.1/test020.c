{
  // Unexpected token MULT
  i = 1/*2;
}