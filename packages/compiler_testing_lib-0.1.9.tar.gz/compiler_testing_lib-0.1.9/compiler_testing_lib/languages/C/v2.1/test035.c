// Unexpected token IDEN (expected OPEN_BRA)
k = 3;