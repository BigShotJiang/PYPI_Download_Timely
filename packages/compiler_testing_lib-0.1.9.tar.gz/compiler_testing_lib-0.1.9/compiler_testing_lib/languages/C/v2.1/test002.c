{
  // Unexpected token EOL
  g = 3+;
}