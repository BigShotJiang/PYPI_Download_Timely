{
  // Unexpected token OPEN_BRA (expected EOF)
  z = 8;
}
{
}