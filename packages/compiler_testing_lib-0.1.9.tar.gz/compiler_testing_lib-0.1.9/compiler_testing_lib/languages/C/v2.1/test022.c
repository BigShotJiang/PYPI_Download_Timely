{
  // Unexpected token CLOSE_PAR
  r = 6);
}