{
  // Unexpected token EOL
  x = 7-;
}