{
  // Unexpected token MULT
  p = *4;
}