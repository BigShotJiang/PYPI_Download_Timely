{
  // Unexpected token MULT
  r = 4**3;
}