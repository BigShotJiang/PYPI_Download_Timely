{
  // Unexpected token DIV
  v = 6*/8;
}