{
  // Unexpected token CLOSE_PAR
  y = (5));
}