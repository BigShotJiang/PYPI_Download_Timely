{
  // Unexpected token IDEN
  X = 1;
  q = 6 X;
}