{
  // Unexpected token EOL
  e = 6/;
}