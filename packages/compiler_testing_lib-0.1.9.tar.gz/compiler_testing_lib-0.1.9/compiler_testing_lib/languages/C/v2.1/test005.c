{
  // Unexpected token EOL
  a = +;
}