{
  // Unexpected token CLOSE_BRA
  e = //7;
}