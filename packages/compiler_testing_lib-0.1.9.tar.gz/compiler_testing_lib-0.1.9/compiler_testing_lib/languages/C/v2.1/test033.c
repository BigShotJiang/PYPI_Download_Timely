{
  {
    // Unexpected token OPEN_BRA
    c = 3;
  }
}