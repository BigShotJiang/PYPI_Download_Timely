{
  // Unexpected token INT (expected EOL)
  t = 7 8;
}