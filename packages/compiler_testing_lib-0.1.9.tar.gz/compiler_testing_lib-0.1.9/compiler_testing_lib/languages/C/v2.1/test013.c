{
  // Unexpected token MULT
  x = *;
}