{
  // Unexpected EOF (Missing CLOSE_BRA)
  int t = 1;
  if (t == 1) {
    t = 2;
  } else {
    t = 3;
}