{
  // Incompatible Types
  int k = true/1;
}