{
  // Missing OPEN_BRA
  int g = 1;
  if (g == 1) {
    g = 2;
  } else
    g = 3;
  }
}