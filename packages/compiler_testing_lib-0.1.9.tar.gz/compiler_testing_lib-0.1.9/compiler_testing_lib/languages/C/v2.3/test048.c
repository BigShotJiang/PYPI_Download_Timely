{
  // Unexpected ELSE
  int s = 1;
  if (s == 1) {
    s = 2;
  } else {
    s = 3;
  } else {
    s = 4;
  }
}