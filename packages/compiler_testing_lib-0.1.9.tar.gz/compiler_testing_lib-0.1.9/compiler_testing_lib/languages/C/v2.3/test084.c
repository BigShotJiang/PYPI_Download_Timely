{
  // Incompatible Types
  int r = true-1;
}