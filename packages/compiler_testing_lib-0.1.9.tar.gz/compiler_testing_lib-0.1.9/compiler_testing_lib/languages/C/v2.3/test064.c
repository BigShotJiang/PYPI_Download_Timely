{
  // Incompatible types
  str j = false;
}