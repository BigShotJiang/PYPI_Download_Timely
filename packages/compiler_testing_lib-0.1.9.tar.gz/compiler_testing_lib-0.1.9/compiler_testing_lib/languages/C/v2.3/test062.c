{
  // Incompatible types
  bool m = 1;
}