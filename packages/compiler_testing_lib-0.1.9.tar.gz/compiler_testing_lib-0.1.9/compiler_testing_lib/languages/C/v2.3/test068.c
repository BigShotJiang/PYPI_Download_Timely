{
  // Variable not found
  bool d = True;
}