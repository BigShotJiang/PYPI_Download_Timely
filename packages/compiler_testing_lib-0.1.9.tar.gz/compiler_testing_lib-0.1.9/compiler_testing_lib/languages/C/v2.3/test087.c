{
  // Incompatible Types
  int r = 8/true;
}