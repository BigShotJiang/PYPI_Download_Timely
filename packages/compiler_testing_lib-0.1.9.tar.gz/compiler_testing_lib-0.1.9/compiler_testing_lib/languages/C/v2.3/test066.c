{
  // Variable Already Declared
  int w;
  str w;
}