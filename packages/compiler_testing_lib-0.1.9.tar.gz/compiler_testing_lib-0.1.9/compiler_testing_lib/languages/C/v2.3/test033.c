{
  {
    // Unexpected token OPEN_BRA
    int k = 7;
  }
}