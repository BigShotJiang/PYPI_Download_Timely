{
  // Incompatible Types
  bool b = true<2;
}