{
  // Missing OPEN_PAR
  while 1 == 1 {
    int i = 9;
  }
}