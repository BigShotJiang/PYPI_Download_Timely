{
  // Missing OPEN_PAR
  int y = scanf;
}