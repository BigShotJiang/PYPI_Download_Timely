{
  // Unexpected EOF (Missing CLOSE_BRA)
  int g = 1;
  while (g == 1) {
    g = 2;
}