{
  // Missing OPEN_BRA
  int x = 1;
  while (x == 1)
    x = 2;
  }
}