{
  // Missing CLOSE_PAR
  int k = scanf(;
}