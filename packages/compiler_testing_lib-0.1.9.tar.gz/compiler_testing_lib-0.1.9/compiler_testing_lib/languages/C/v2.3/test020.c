{
  // Unexpected token MULT
  int x = 6/*8;
}