{
  // Unexpected token IDEN
  int 1x = 6;
  printf(1x);
}