{
  // Unexpected EOF (Missing CLOSE_BRA)
  int d = 1;
  if (d == 1) {
}