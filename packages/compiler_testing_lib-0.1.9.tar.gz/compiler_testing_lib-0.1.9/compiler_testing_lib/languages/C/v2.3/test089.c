{
  // Incompatible Types
  int r = true||false;
}