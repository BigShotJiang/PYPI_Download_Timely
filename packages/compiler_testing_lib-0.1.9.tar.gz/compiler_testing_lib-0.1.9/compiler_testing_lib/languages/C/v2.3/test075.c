{
  // Incompatible Types
  bool b = 7<"a";
}