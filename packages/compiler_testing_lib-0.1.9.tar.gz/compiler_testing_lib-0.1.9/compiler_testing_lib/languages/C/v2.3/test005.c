{
  // Unexpected token EOL
  int e = +;
}