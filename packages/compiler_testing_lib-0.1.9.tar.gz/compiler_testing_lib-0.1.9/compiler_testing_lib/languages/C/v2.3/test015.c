{
  // Unexpected token MULT
  int v = 2+*5;
}