{
  // Incompatible types
  str y = scanf();
}