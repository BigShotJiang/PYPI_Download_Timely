{
  // Missing CLOSE_PAR
  int e = ((7);
}