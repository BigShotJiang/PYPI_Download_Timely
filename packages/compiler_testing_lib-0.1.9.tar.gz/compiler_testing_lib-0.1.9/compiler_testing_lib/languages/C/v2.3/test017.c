{
  // Unexpected token MULT
  int w = 7**4;
}