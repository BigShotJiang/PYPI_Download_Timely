{
  // Incompatible Types
  int q = true+1;
}