{
  // Incompatible Types
  bool n = 1==true;
}