{
  // Incompatible Types
  bool y = 5=="a";
}