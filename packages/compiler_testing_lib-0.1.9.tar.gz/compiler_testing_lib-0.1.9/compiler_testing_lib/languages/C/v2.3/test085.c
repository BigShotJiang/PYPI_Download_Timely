{
  // Incompatible Types
  int o = 1*true;
}