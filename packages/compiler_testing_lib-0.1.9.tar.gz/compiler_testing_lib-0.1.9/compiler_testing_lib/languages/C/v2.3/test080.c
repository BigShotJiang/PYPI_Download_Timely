{
  // Incompatible Types
  bool n = !9;
}