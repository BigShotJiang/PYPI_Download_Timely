{
  // Unexpected token DIV
  int e = /2;
}