{
  // Unexpected token MULT
  int d = *;
}