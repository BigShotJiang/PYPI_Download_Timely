{
  // Unexpected token DIV
  int s = 4*/4;
}