{
  // Unexpected OPEN_BRA
  int c = 1;
  if (c == 1) {
    c = 2;
  }
  {
    c = 3;
  }
}