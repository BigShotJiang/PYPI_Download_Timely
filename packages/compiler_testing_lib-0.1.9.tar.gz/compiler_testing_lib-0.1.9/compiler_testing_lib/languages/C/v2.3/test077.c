{
  // Incompatible Types
  bool c = "a"<true;
}