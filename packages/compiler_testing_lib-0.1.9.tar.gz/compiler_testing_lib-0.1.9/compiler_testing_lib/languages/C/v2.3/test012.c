{
  // Unexpected token EOL
  int b = 4/;
}