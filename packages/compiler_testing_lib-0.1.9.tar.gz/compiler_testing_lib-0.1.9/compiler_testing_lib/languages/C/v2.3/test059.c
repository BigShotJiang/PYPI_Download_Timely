{
  // Incompatible types
  int b = "a";
}