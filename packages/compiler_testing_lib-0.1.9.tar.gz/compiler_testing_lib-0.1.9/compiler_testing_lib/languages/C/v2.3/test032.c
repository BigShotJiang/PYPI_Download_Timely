{
  // Unexpected token OPEN_BRA (expected EOF)
  int u = 5;
}
{
}