{
  // Unexpected token DIV
  int f = /;
}