{
  // Unexpected token MULT
  int z = *4;
}