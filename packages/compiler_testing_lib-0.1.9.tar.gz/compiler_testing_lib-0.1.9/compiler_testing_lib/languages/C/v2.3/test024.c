{
  // Unexpected token CLOSE_PAR
  int z = (8));
}