{
  // Incompatible Types
  bool b = "a"<true;
}