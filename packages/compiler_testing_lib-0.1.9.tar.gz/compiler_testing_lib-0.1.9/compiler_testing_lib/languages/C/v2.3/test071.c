{
  // Incompatible Types
  bool e = "a"==true;
}