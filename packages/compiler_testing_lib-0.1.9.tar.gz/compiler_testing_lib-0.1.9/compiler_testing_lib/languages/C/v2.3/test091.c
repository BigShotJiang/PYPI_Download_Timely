{
  // Incompatible Types
  bool d = "a"."b";
}