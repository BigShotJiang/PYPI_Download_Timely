{
  // Unexpected token CLOSE_BRA
  int k = //4;
}