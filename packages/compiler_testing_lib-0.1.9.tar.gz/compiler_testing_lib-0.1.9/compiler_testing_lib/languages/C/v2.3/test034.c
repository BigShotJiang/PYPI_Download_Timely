{
  // Unexpected token CLOSE_BRA (expected EOF)
  int w = 5;
}
}