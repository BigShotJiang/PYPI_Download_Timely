{
  // Incompatible types
  int j = true;
}