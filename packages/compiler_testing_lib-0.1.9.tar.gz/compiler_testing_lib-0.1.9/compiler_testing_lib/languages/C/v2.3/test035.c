// Unexpected token IDEN (expected OPEN_BRA)
int a = 7;