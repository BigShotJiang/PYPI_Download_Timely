{
  // Unexpected token EOL
  int q = 8-;
}