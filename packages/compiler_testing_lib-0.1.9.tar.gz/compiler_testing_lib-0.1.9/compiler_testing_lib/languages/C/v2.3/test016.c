{
  // Unexpected token DIV
  int w = 3+/1;
}