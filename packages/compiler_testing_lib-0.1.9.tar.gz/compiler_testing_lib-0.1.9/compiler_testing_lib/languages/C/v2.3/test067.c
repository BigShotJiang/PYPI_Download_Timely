{
  // Unexpected EOF
  str z = "a;
}