{
  // Incompatible Types
  str g = 4+7;
}