{
  // Unexpected token INT (expected EOL)
  int k = 8 6;
}