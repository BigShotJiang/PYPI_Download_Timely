{
  // Incompatible types
  bool n = 7;
}