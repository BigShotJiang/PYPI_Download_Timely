{
  // Missing CLOSE_PAR
  int a = (7;
}