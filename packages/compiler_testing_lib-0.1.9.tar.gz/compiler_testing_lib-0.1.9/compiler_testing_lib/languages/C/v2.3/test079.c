{
  // Incompatible Types
  bool c = "a"||4;
}