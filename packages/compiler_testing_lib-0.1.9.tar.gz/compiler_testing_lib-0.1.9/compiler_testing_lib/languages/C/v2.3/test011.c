{
  // Unexpected token EOL
  int m = 6*;
}