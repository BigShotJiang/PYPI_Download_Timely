{
  // Missing OPEN_PAR
  if 1 == 1 {
    int k = 7;
  }
}