{
  // Incompatible types
  str m = 1;
}