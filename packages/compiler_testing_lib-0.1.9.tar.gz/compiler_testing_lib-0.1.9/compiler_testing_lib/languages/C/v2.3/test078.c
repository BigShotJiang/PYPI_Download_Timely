{
  // Incompatible Types
  bool t = "a"&&7;
}