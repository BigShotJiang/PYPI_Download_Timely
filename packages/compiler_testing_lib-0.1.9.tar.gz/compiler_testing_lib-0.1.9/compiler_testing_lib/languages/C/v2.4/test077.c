void main() {
  // Incompatible Types
  bool c = "a"<true;
}