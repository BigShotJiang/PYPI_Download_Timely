void main() {
  // Incompatible Types
  bool q = 3>"a";
}