void main() {
  // Incompatible Types
  int b = true||false;
}