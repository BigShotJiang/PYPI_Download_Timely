void main() {
  // Variable Already Declared
  int d;
  str d;
}