void main() {
  // Incompatible Types
  str t = 4+3;
}