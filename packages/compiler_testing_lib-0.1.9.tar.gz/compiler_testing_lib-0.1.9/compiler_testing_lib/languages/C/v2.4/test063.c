void main() {
  // Incompatible types
  str g = 9;
}