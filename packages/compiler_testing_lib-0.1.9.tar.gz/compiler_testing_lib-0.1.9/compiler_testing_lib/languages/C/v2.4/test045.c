void main() {
  // Unexpected EOF (Missing CLOSE_BRA)
  int c = 1;
  while (c == 1) {
    c = 2;
}