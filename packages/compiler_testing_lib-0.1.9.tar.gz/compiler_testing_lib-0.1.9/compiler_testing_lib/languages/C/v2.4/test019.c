void main() {
  // Unexpected token DIV
  int u = 2*/4;
}