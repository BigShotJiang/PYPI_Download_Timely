void main() {
  // Incompatible Types
  bool n = "a"==true;
}