void main() {
  // Unexpected token INT (expected EOL)
  int z = 1 4;
}