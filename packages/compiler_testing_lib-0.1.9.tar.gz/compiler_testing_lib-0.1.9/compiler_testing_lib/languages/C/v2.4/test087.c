void main() {
  // Incompatible Types
  int w = 1/true;
}