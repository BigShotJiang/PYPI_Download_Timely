void main() {
  // Incompatible types
  int w = "a";
}