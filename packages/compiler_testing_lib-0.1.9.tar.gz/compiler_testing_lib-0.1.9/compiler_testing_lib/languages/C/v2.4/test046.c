void main() {
  // Missing OPEN_BRA
  int q = 1;
  while (q == 1)
    q = 2;
  }
}