void main() {
  // Unexpected EOF (Missing CLOSE_BRA)
  int f = 1;
  if (f == 1) {
    f = 2;
  } else {
    f = 3;
}