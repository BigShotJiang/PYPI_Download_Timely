void main() {
  // Unexpected token CLOSE_BRA
  int d = //5;
}