void main() {
  // Incompatible Types
  bool y = true<5;
}