void main() {
  // Incompatible Types
  bool h = !3;
}