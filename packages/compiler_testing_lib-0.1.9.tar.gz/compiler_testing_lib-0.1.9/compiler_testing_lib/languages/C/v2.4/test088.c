void main() {
  // Incompatible Types
  int c = true/1;
}