void main() {
  // Identifier not found
  int x1 = 2;
  printf(X1);
}