void main() {
  // Incompatible types
  bool k = "a";
}