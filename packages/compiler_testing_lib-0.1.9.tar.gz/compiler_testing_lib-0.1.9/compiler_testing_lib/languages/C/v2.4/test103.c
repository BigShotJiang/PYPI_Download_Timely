int p = 2;
void main() {
  // Function not found
  printf(p(3));
}