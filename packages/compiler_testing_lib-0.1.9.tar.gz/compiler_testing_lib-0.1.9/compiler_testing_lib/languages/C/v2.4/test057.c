void main() {
  // Unexpected Identifier
  imt x1 = 3;
}