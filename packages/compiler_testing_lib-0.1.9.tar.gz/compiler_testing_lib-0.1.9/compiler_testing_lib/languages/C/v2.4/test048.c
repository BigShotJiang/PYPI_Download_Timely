void main() {
  // Unexpected ELSE
  int a = 1;
  if (a == 1) {
    a = 2;
  } else {
    a = 3;
  } else {
    a = 4;
  }
}