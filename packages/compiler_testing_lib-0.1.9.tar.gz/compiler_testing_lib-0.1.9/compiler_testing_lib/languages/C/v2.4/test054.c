void main() {
  // Missing CLOSE_PAR
  int q = scanf(;
}