void main() {
  // Unexpected EOF (Missing CLOSE_BRA)
  int i = 1;
  if (i == 1) {
}