void main() {
  // Unexpected token EOL
  int s = 7/;
}