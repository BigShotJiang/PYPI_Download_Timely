void main() {
  // Incompatible Types
  int a = 1+true;
}