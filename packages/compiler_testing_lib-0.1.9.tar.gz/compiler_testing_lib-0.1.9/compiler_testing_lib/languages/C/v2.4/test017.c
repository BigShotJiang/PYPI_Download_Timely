void main() {
  // Unexpected token MULT
  int x = 9**8;
}