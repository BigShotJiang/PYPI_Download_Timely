void main() {
  // Unexpected token MULT
  int p = *7;
}