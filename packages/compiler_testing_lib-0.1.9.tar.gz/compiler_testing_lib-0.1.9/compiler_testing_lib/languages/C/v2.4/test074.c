void main() {
  // Incompatible Types
  bool s = "a"<true;
}