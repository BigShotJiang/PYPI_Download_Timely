void main() {
  // Unexpected EOF
  str i = "a;
}