void main() {
  // Incompatible Types
  bool d = "a"||2;
}