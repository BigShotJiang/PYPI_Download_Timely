void main() {
  // Invalid token @
  int j = @;
}