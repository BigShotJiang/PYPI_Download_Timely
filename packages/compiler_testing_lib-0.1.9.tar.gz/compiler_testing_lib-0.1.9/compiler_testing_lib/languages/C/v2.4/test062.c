void main() {
  // Incompatible types
  bool e = 5;
}