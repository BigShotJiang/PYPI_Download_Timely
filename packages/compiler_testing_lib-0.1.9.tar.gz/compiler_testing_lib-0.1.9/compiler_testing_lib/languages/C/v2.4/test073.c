void main() {
  // Incompatible Types
  bool d = 1>true;
}