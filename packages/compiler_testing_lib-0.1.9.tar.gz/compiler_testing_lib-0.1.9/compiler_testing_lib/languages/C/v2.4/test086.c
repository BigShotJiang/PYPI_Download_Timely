void main() {
  // Incompatible Types
  int k = true*1;
}