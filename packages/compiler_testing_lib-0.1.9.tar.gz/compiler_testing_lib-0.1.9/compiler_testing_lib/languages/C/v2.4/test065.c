void main() {
  // Incompatible types
  str t = scanf();
}