void main() {
  // Unexpected token MULT
  int u = *;
}