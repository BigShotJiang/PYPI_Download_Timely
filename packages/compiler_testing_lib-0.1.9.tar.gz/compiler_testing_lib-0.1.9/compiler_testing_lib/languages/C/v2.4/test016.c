void main() {
  // Unexpected token DIV
  int w = 2+/1;
}