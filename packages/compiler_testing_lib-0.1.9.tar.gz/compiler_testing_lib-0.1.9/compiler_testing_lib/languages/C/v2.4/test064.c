void main() {
  // Incompatible types
  str w = false;
}