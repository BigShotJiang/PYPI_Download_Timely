void main() {
  // Incompatible Types
  bool c = "a"&&8;
}