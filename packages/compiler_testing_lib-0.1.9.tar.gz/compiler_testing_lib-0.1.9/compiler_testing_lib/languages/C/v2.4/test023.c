void main() {
  // Missing CLOSE_PAR
  int d = ((8);
}