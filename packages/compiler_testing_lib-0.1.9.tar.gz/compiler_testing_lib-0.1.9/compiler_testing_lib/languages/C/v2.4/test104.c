void main() {
  // Var out of scope
  {
    int d = 6;
  }
  d = 6;
}