void main() {
  // Unexpected token EOF (expected CLOSE_BRA)
  int b = 2;