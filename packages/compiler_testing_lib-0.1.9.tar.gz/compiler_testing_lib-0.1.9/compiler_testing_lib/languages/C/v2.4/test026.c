void main() {
  // Unexpected token IDEN
  int L = 1;
  int m = 4 L;
}