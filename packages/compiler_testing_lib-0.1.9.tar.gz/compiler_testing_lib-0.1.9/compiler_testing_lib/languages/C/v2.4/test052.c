void main() {
  // Missing Right Expression
  int t = 1;
  if (!) {
    t = 2;
  }
}