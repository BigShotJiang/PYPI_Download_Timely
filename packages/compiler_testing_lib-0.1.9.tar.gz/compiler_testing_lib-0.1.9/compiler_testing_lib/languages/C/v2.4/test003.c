void main() {
  // Unexpected token EOL
  int w = 5-;
}