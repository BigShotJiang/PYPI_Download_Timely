void main() {
  // Unexpected token MULT
  int j = 3+*9;
}