void main() {
  // Incompatible Types
  bool a = "a"."b";
}