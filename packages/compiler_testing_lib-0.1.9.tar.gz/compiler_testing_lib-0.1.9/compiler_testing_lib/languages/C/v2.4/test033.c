void main() {
  void main() {
    // Unexpected token FUNC or OPEN_PAR
    int o = 9;
  }
}