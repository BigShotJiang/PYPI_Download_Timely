void main() {
  // Incompatible Types
  bool d = 5<"a";
}