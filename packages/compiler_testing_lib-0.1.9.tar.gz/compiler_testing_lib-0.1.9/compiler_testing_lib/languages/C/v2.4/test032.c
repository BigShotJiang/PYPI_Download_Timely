void main() {
  // Unexpected token OPEN_BRA (expected EOF)
  int x = 3;
}
{
}