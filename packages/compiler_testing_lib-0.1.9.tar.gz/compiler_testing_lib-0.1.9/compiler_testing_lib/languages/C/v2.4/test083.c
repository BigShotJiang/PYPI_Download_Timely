void main() {
  // Incompatible Types
  int k = 1-true;
}