void main() {
  // Unexpected token CLOSE_PAR
  int j = 4);
}