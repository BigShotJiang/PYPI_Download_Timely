void main() {
  // Unexpected token EOL
  int r = +;
}