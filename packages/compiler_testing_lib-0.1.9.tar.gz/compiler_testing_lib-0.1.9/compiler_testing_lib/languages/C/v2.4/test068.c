void main() {
  // Variable not found
  bool j = True;
}