void main() {
  // Incompatible types
  bool i = 4;
}