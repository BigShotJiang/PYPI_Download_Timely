void main() {
  // Unexpected token EOL
  int s = ;
}