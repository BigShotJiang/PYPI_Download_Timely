void main() {
  // Incompatible Types
  bool q = 6=="a";
}