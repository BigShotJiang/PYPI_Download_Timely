void main() {
  // Unexpected token CLOSE_BRA (expected EOF)
  int f = 3;
}
}