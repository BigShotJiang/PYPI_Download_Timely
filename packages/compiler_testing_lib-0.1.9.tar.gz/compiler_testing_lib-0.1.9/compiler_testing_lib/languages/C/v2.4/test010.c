void main() {
  // Unexpected token DIV
  int u = /1;
}