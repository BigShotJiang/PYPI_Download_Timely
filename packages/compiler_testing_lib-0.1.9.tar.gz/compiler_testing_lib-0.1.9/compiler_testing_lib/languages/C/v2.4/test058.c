void main() {
  // Incompatible types
  int a = true;
}