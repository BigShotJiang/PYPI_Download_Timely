void main() {
  // Incompatible Types
  int m = 1*true;
}