void main() {
  // Missing OPEN_BRA
  int p = 1;
  if (p == 1) {
    p = 2;
  } else
    p = 3;
  }
}