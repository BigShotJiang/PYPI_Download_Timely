from pathlib import Path

DATA_PATH = Path(__file__).resolve().parent
