__version__ = '0.3.2'


def get_version() -> str:
    return __version__


__all__ = [
    '__all__',
]