"""
Tools for accessing execution metadata.
"""