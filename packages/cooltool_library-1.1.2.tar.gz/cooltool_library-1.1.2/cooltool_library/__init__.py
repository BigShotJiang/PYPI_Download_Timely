"""
CoolTool Library

A library with many functionality to became easly the code writing end reading

The principal Class is CTl (Cool Tool library) and it contains the main functions
"""

from .cooltool_library import *