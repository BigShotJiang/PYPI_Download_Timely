## 0.2.0a4 (2025-07-24)

### Feat

- major refactor to langchain api
- added chats api

## 0.2.0a3 (2025-07-04)

### Feat

- added interaction log models

## 0.2.0a2 (2025-06-30)

## 0.2.0a1 (2025-06-26)

### Feat

- add workflow api

### Refactor

- changing prompt api functionality

## 0.2.0a0 (2025-06-26)

### Feat

- add workflow api

### Refactor

- changing prompt api functionality

## 0.1.0 (2025-06-26)

### Feat

- add workflow api
- added initial working version of app

### Refactor

- changing prompt api functionality
