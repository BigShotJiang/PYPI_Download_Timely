"""
Google integration for django-chain.
"""


def get_google_chat_model(
    api_key: str, model_name: str = "gpt-3.5-turbo", temperature: float = 0.7, **kwargs
):
    return NotImplemented


def get_google_embedding_model(api_key: str, model_name: str = "text-embedding-ada-002", **kwargs):
    return NotImplemented
