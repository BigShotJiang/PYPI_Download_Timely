"""
HuggingFace integration for django-chain.
"""


def get_huggingface_chat_model(*args, **kwargs):
    return NotImplemented


def get_huggingface_embedding_model(*args, **kwargs):
    return NotImplemented
