"""
Django Chain - A Django library for seamless LangChain integration
"""

__version__ = "0.2.0a4"
