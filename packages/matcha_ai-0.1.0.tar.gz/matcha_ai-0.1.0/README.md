# Matcha AI

A placeholder package for matcha-ai.

## Installation

```bash
pip install matcha-ai
```

## Usage

```python
import matcha_ai

print(matcha_ai.hello())
```

## Development

This package is currently in development. More features coming soon!

## License

MIT License
