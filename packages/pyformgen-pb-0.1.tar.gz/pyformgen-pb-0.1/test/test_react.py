import sys
import os

# Add the root directory to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from package import generate_react_form

schema = {
  "name": {
    "type": "text",
    "label": "Full Name",
    "placeholder": "Enter your name"
  },
  "email": {
    "type": "email",
    "label": "Email",
    "required": True
  },
  "age": {
    "type": "number",
    "label": "Age",
    "min": 0,
    "max": 120
  }
}



# Output path
output_path = "example/GeneratedForm.jsx"
generate_react_form(schema, output_path)
