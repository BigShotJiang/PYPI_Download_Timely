from setuptools import setup,find_packages

setup(
    name="pyformgen-pb",
    version="0.1",
    packages=find_packages(),
    author="Pradnyesh Bhalekar",
    description="a package which creates react or html form using by json",
    python_requires=">=3.6",
)