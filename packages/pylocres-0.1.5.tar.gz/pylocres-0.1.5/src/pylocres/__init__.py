from .locres import LocresFile, Namespace, Entry, entry_hash
from .locmeta import LocmetaFile, LocmetaVersion