# Package Reference

The `flyde` package contains the following modules:

- [flyde.flow](package/flyde.flow.md) - root level Flow
- [flyde.io](package/flyde.io.md) - low-level I/O for Nodes
- [flyde.node](package/flyde.node.md) - Node API
