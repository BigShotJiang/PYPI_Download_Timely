# UI Colors and constants
PENGUIN_COLOR = "blue"
TOOL_COLOR = "yellow"
USER_COLOR = "cyan"
RESULT_COLOR = "green"  