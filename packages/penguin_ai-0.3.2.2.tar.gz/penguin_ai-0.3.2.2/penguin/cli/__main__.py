"""
Main entry point for the Penguin CLI when invoked as a module.
"""
from penguin.penguin.chat.cli import app

if __name__ == "__main__":
    app() 