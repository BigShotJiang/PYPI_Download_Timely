# new and better logging system

# will probably just use most of the code from the old logging system,
# but with some modifications to fit the new system architecture
