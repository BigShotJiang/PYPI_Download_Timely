zero_shot_template = """你是电信运营商领域的专家。请针对以下问题，提供简洁、准确、直接的回答。  


问题：{question}


答案："""