def clean_command_output(text):
    return text.strip() 