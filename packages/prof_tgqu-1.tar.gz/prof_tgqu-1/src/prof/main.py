# This will execute prof.py without importing any module

exec(open("prof.py").read())
