"""
Configuration package for font analyzer.
"""

__version__ = "1.0.0"
__author__ = "Aykut Cantürk"
