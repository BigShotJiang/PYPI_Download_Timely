- Enter your value in omnibar search field
- Press and hold Shift key
- Select field with mouse or keyboard to perform search on

[![Try me on Runbot](https://odoo-community.org/website/image/ir.attachment/5784_f2813bd/datas)](https://runbot.odoo-community.org/runbot/162/11.0)
