valkey_host = "127.0.0.1"
valkey_port = 10002

HF_TOKEN = ""

GITHUB_TOKEN = ""