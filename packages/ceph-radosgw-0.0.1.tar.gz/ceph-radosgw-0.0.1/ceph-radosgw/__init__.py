# Safe dummy package: ceph-radosgw
