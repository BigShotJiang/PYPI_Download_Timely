This directory stores Kubernetes YAML manifests used by `intclt` when deploying
services. Place your deployment files here.
