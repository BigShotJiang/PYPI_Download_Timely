"""Tests for Civic Auth Python SDK."""
