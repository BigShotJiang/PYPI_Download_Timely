"""
Rigging - Hook Orchestration for AI Agents

All hands to the rigging!
"""

__version__ = "0.1.0"
__author__ = "Brian Morin"

# Defer imports to avoid circular dependencies
__all__ = ["Hook", "HookType", "ToolMatcher"]