# multiprogress

[![PyPI Version][pypi-v-image]][pypi-v-link]
[![Python Version][python-v-image]][python-v-link]
[![Build Status][GHAction-image]][GHAction-link]
[![Coverage Status][codecov-image]][codecov-link]

<!-- Badges -->
[pypi-v-image]: https://img.shields.io/pypi/v/multiprogress.svg
[pypi-v-link]: https://pypi.org/project/multiprogress/
[python-v-image]: https://img.shields.io/pypi/pyversions/multiprogress.svg
[python-v-link]: https://pypi.org/project/multiprogress
[GHAction-image]: https://github.com/daizutabi/multiprogress/actions/workflows/ci.yaml/badge.svg?branch=main&event=push
[GHAction-link]: https://github.com/daizutabi/multiprogress/actions?query=event%3Apush+branch%3Amain
[codecov-image]: https://codecov.io/github/daizutabi/multiprogress/coverage.svg?branch=main
[codecov-link]: https://codecov.io/github/daizutabi/multiprogress?branch=main
