## Release 0.1.6

### Changes
- Automated release from commit e5173350889bf264d67cfa17387ec5d6d160d7f2

### Installation
```bash
pip install lombardi==0.1.6
```

### Usage
```bash
lombardi analyze --sql "SELECT * FROM table" --dialect snowflake
```

For full documentation, visit [PyPI](https://pypi.org/project/lombardi/).
