"""SQL analysis modules."""
