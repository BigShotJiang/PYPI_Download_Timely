"""Warehouse-specific optimization rules."""
