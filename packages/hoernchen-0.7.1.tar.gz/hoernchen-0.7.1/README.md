lightweight sqlite3 wrapper based on dataclasses
