# XGrammar Documentation

The documentation was built upon [Sphinx](https://www.sphinx-doc.org/en/master/).

See XGrammar docs for help to build the documentation.
