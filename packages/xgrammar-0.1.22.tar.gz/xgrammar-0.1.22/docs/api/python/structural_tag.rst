Structural Tag
==========================

.. currentmodule:: xgrammar

.. autoclass:: StructuralTagItem
   :show-inheritance:
   :exclude-members: model_config
