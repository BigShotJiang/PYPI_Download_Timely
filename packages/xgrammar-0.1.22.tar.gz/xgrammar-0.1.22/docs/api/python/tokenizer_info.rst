﻿xgr.TokenizerInfo
======================

.. currentmodule:: xgrammar

.. autoclass:: VocabType
   :show-inheritance:
   :autosummary:

.. autoclass:: TokenizerInfo
   :no-show-inheritance:
   :special-members: __init__
   :autosummary:
