Configuration
==========================

.. currentmodule:: xgrammar

Recursion Depth Management
--------------------------

.. autofunction:: get_max_recursion_depth
.. autofunction:: set_max_recursion_depth
.. autofunction:: max_recursion_depth
