

.. _cli:

.. automodule:: quant_met.cli
