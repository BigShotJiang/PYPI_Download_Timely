﻿quant\_met.parameters.Control
=============================

.. currentmodule:: quant_met.parameters

.. autodata:: Control
