﻿

.. raw:: html

   <div class="prename">quant_met.bdg.</div>
   <div class="empty"></div>

calculate_current_density
=======================================

.. currentmodule:: quant_met.bdg

.. autofunction:: calculate_current_density
