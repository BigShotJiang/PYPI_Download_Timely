
import('https://cdn.oaistatic.com/assets/cuau6nn9sjz8q54j.js').then((module) => { 
    window._chatp_old = module.cJ;//bT;
    window._ark = module.cJ;//?bS;
    window._chatp = module.cI;//bR;
    window._device = module.cd;//bx;
    window._wss = module.J;//K;
}).catch(error => console.error("Error loading dh0yl0m9q337gmci.js:", error));

import('https://cdn.oaistatic.com/assets/ebwx7yj0baonheef.js').then((module) => { 
    window._turnstile = module.ix;//ce;
    window._proof = module.jt;//Jg;
}).catch(error => console.error("Error loading ktiwgucld5a8s55m.js:", error));
