from .ChatGPTWeb import chatgpt

__all__ = ['chatgpt']
