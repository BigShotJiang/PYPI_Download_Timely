from .data_fetcher import scorecard_data

__all__ = ["scorecard_data"]