def main():
    print("Hello! I'm a chatbot!")

if __name__ == "__main__":
    main()
