"""Entry point for AgentKnowledgeMCP package when run as module."""
from .main_server import cli_main

if __name__ == "__main__":
    cli_main()
