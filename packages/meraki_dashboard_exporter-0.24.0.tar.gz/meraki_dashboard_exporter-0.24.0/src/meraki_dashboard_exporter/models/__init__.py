"""Data models for the Meraki Dashboard Exporter."""
