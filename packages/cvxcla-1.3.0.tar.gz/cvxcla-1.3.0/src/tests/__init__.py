"""Tests for the Critical Line Algorithm (CLA) package.

This package contains tests for the cvxcla package, which implements
the Critical Line Algorithm for portfolio optimization.
"""
