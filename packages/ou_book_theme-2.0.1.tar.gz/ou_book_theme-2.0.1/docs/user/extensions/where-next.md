# Where Next

The `{where-next}` block is used at the end of a part to indicate that the student is ready to move on to the next
part and to give an indication of what the student can expect to see there:

::::{code-block} markdown
:::{where-next}
You are now ready to move on to the next part.
:::
::::

:::{where-next}
You are now ready to move on to the next part.
:::
