"""
Core functionality package
"""
