"""
Test suite for SYSTEM-SELL
"""
