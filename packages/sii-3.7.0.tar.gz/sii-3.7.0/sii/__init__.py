# -*- coding: utf-8 -*-

__LIBRARY_VERSION__ = '3.7.0'
__SII_VERSION__ = '1.1'
