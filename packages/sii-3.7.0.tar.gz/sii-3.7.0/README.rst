SII
===

.. image:: https://travis-ci.org/gisce/sii.svg?branch=master
    :target: https://travis-ci.org/gisce/sii

.. image:: https://coveralls.io/repos/github/gisce/sii/badge.svg?branch=master
    :target: https://coveralls.io/github/gisce/sii?branch=master

.. image:: https://img.shields.io/pypi/v/sii.svg
    :target: https://pypi.python.org/pypi/sii

AEAT Suministro Inmediato de Información
