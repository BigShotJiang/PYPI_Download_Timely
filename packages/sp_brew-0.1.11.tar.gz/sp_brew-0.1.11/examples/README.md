# Examples directory

This directory contains a list of example uses of the package

it will require the package to be installed to be run.
