#!/usr/bin/env python3
"""
Setup script for llmtoolkit package.
This file provides backward compatibility for older pip versions.
"""

from setuptools import setup

# Use pyproject.toml for configuration
setup()