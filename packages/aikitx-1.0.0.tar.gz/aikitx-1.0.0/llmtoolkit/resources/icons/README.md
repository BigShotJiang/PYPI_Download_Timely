# Icons Directory

This directory contains application icons and UI graphics.

Icons should be provided in multiple sizes:
- 16x16 for small UI elements
- 32x32 for toolbar buttons
- 48x48 for dialog icons
- 64x64 for main application icon