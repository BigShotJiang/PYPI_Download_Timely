# Themes Directory

This directory contains UI theme definitions for the application.

Each theme should be defined as a JSON file with:
- Color palette definitions
- Font specifications
- UI element styling
- Dark/light mode variants