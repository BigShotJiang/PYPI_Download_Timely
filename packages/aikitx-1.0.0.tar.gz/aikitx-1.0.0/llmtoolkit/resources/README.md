# Resources Directory

This directory contains application resources including:

- `icons/` - Application icons and UI graphics
- `themes/` - UI theme definitions
- `default_config.json` - Default application configuration
- `sample_prompts.json` - Sample system prompts for users