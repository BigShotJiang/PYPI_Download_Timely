"""
Core application components for the GGUF Loader App.

This package contains the core business logic and application control components.
"""