"""
Test file to check if we can write to the app/core directory.
"""

from enum import Enum

class TestEnum(Enum):
    VALUE1 = "value1"
    VALUE2 = "value2"

print("Test file created successfully!")