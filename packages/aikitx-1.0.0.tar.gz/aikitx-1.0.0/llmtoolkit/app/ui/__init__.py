"""
UI components for the GGUF Loader App.

This package contains the user interface components built with PySide6.
"""