"""
Services Package

This package contains the application services that provide business logic
and coordinate between the UI and core components.
"""