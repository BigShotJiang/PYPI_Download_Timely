"""
Data models for the GGUF Loader App.

This package contains the data model classes used throughout the application.
"""