"""
Backend implementations for Diary storage.
"""

from .local import LocalBackend

__all__ = ["LocalBackend"]
