# turbobt
A next generation Bittensor SDK, for Python 3.