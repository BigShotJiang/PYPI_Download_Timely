from compas_ifc.entities.element import Element


class GeographicElement(Element):
    """
    Class representing an IFC Geographic Element.
    """

    pass
