"""Tests for the agent_runtime module."""

import logging

# Configure logging for all tests
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger("agent-runtime-test")
