#!/bin/bash

streamlit run mlox/app.py
