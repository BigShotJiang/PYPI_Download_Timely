from .connection import TCPConnection as TCPConnection
from .limits import MAXLINE as MAXLINE