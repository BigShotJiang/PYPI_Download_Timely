from enum import Enum


class InstanceRoleType(Enum):
    WORKER = "WORKER"
    PROVISIONER = "PROVISIONER"
