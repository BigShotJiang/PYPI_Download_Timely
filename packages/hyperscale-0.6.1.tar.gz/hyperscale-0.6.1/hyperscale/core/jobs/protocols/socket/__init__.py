from .socket import bind_tcp_socket as bind_tcp_socket
from .socket import bind_udp_socket as bind_udp_socket
