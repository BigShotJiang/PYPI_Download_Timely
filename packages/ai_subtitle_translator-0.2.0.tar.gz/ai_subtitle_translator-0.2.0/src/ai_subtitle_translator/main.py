"""
Main entry point for the AI subtitle translator package.
"""


def main():
    """Print a hello message from the package."""
    print("Hello from ai-subtitle-translator!")


if __name__ == "__main__":
    main()
