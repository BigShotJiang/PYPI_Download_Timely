# Changelog

## 0.1.0 (2025-07-28)


### Features

* add CLI interface and remove backward compatibility [AI] ([72f7a71](https://github.com/stkr22/private-assistant-comms-satellite-py/commit/72f7a7113e55cf89ca92a3bc35db0e528e70bd51))


### Bug Fixes

* make pyaudio optional dependency for CI/CD compatibility [AI] ([04cc12c](https://github.com/stkr22/private-assistant-comms-satellite-py/commit/04cc12ce86aac005b2b78b9599b5124446c54946))
