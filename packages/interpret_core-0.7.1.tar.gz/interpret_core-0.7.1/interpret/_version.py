# Copyright (c) 2023 The InterpretML Contributors
# Distributed under the MIT software license

# NOTE: Version is replaced by a regex script.
__version__ = "0.7.1"
