export const EDIT = "edit";
export const VIEW = "view";
export const CONFIGURE = "configure";
