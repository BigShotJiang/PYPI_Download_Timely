from django.apps import AppConfig


class ArchesComponentLabConfig(AppConfig):
    name = "arches_component_lab"
    is_arches_application = True
