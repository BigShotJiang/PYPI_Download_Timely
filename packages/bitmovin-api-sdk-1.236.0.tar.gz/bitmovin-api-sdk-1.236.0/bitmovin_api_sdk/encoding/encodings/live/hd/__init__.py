from bitmovin_api_sdk.encoding.encodings.live.hd.hd_api import HdApi
