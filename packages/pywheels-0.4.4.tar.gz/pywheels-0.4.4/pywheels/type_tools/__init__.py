from .basic import is_same_type


__all__ = [
    "is_same_type",
]