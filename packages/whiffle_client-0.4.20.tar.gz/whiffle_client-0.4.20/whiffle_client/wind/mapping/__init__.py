from whiffle_client.common.mapping.base import BaseMapping
from whiffle_client.wind.mapping.turbine_model_specs import TurbineModelSpecsEndpoints
from whiffle_client.wind.mapping.wind_simulation_tasks import (
    WindSimulationTaskEndpoints,
)
