from whiffle_client.forecast.client import WhiffleForecastClient

__all__ = ["WhiffleForecastClient"]
