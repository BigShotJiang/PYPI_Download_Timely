"""
This package contains the tilers py3dtiles can use. A tiler is the entity that controls how tiles are created from an input file.
"""
