"""
This package contains all the readers that py3dtiles can use.
"""
