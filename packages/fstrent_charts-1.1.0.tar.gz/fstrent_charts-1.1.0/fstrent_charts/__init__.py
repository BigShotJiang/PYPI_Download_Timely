"""FSTrent Charts - Color Chart options for terminal output."""
from .fstrent_charts import *

__version__ = "1.1.0"
