import sourcedefender
try:
   from . import activate
except Exception as e:
   pass
