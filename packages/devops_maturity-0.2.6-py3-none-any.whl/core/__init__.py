from importlib.metadata import version

__version__ = version("devops-maturity")  # Get the package version
