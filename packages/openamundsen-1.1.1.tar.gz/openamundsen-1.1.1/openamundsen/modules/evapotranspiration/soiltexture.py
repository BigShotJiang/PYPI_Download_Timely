class SoilTextureClass:
    SAND = 1
    LOAMY_SAND = 2
    SANDY_LOAM = 3
    LOAM = 4
    SILT_LOAM = 5
    SILT = 6
    SILT_CLAY_LOAM = 7
    SILTY_CLAY = 8
    CLAY = 9
