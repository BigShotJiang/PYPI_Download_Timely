"""Provide staticfiles for backwards compatibility."""

from django.templatetags.static import *  # noqa
