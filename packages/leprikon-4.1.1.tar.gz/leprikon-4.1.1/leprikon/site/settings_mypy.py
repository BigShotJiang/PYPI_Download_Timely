"""
Temporary file for mypy.
TODO: remove when https://github.com/typeddjango/django-stubs/issues/2461 is fixed.
"""

from .settings import *  # noqa: F403

del AUTH_USER_MODEL
