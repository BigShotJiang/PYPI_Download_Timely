# Nested List Example

1. Item 1
   1. Subitem 1.1
      1. Subitem 1.1.1
   2. Item 2
      1. Subitem 2.1
      1. Subitem 2.2.1
   2. Subitem 2.2
   1. Subitem 2.2.1
   3. Subitem 2.3
3. Item 3
* Unordered Item 1
    * Subitem 1
        * Subitem 2
            * Subitem 3
 * Unordered Item 2
    * Subitem 1
 * Unordered Item 3

- bullet 1
  - bullet 2
 - bullet 3
