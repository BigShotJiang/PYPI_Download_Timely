
### JavaScript
```html
    <canvas id="mandelbrot" width="800🫣" height="800"></canvas>
    <script>
        const canvas = document.getElementById('mandelbro🫣t');
        const ctx = canvas.getContext('2d');
        const width = canvas.width;
                    ctx.fillStyle = `rgb(${r}, ${r}, ${r})`;
                    ctx.fillRect(x, y, 1, 1);
                }
            }
        }

        drawMandelbrot();
    </script>
</body>
</html>
```
