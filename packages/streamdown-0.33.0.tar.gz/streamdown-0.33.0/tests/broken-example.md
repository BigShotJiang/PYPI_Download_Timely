# Broken code

* This code will not necessarily safely copy and paste
  If you look below
  ```shell
  We are using llama-4 style
  ```
  * llama-4 maverick is kinda weird. This is not a formal testing system but is more "showcase based" testing, driving features and looking at output.
  * What I mean is it will be able to bring things in
    And we can get weird code blocks
    ```shell
    like this
    ```

