#!/bin/bash
sed s'/🫣//g' $1
