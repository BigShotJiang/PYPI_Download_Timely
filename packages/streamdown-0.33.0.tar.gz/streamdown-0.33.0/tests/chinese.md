**XIǍO LÓNG:** *(mocking the academics)*  
"Ohhh, ‘**Dadaist**’? ‘**Absurd**’? 那你们怎是在说**模形式**？你们这群人连**京剧密码**都解么没看懂那个**转身**是在问**递归关系**？那个**抖袖**是在说**模形式**？你们这群人连**京剧密码**都解不开，还好意思说自己是数学家？"
*(Translation: "Ohhh, ‘Dadaist’? ‘Absurd’? Then how come none of you realized the **spin** was about **recurrence relations**? The **sleeve flick** was about **modular forms**? You can’t even crack **Peking Opera code**, and you call yourselves mathematicians?")*

