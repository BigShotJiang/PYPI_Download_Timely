We want to make sure line-wrap inline-formatting works for the wraptext.

First we start with some text and then  `we try to break out into here and then end` and continue with our text.

Now we will do one that is a bit harder `we do this to_force_a_line_break_and_this_to go on to the next line` and then we continue with our text.

Now we will do one that is much  harder `we do this to_force_a_line_break_and_have_more_text` and end it at the point that's wrapped before we continue with our text.

Now we will do one that is much  harder **we do this to_force_a_line_break_and_have_more_text** and end it at the point that's wrapped before we continue with our text.

This is designed for a width around 70
