"""Initializing tulflow Python package."""
name = "tulflow"
