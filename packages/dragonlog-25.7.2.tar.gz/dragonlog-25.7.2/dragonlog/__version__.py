__version__ = 'v25.07.2'
__version_str__ = 'v25.07.2'
__branch__ = 'master'
__unclean__ = False
