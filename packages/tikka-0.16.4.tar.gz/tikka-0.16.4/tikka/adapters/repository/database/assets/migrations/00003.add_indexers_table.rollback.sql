drop table if exists indexers;
