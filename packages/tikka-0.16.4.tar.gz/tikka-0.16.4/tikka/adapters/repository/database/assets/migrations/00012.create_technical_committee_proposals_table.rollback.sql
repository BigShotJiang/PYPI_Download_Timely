drop table if exists technical_committee_proposals;
