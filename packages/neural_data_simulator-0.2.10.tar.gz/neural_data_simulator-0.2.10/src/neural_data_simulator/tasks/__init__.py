"""This package is meant to host a collection of BCI tasks.

Currently, the only task available in the package is the center-out reach task
(see :mod:`tasks.center_out_reach`). Its entry point is the
:meth:`tasks.run_center_out_reach.run` method.
"""
