"""Script errors."""


class InvalidPluginError(Exception):
    """Plugin cannot be used."""

    pass
