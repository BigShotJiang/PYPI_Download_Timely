"""Inputs API and implementation."""
