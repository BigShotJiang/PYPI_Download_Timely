"""A collection of built-in plugins for NDS."""
