"""Common functions used throughout the NDS package."""
