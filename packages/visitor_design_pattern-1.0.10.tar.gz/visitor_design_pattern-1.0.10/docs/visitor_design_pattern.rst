visitor\_design\_pattern package
================================

Submodules
----------

visitor\_design\_pattern.visitor\_design\_pattern module
--------------------------------------------------------

.. automodule:: visitor_design_pattern.visitor_design_pattern
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: visitor_design_pattern
   :members:
   :undoc-members:
   :show-inheritance:
