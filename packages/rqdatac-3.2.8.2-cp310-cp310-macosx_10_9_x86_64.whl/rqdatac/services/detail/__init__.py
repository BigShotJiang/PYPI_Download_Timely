# -*- coding: utf-8 -*-
#
# Copyright 2017 Ricequant, Inc
