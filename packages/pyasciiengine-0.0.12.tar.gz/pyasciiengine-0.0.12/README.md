# pyConsoleEngine
Ascii engine for drawing in console. Based on curses library

by [@Arizel79](https://t.me/Arizel79)

## Install
```
pip install pyAsciiEngine
```
## Example:
```python

```


