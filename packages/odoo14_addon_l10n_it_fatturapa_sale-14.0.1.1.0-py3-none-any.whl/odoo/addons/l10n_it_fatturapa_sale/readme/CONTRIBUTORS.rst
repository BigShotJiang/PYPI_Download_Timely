* Agile Business Group
* `Ooops <https://www.ooops404.com>`_:

   * Giovanni Serra <giovanni@gslab.it>
