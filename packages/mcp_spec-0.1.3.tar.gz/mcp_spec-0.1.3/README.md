# SPEC-mcp

模仿`kiro`的`SPEC`模式, 按照 需求 -> 设计 -> TODO -> 