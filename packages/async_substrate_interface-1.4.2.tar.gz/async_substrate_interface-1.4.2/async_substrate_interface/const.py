# Re-define SS58 format here to remove unnecessary dependencies.
SS58_FORMAT = 42
