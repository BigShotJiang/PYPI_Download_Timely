# Core Utilities Folder

This folder should contain utilities that are specifically used to interact with the Nominal API, in particular, working with conjure.
