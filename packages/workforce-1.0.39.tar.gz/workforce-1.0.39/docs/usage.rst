=====
Usage
=====

To use workforce in a project::

    import workforce
