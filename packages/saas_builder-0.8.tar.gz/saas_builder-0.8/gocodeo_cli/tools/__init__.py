"""
Tools for the agent-based system.
""" 