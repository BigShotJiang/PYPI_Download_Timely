from setuptools import setup, find_packages

setup(name="ReactiveMode", version="0.1", packages=find_packages(), author="FallingXbot", description="Small Python Library About Events.")