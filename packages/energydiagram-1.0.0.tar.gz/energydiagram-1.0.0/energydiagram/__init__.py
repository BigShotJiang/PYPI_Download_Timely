#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Nov 25 12:56:47 2019

@author: giacomo
"""
from .energydiagram import ED