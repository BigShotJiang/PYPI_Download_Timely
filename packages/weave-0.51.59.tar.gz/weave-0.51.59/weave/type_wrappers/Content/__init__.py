from .content import Content

__docspec__ = [Content]
