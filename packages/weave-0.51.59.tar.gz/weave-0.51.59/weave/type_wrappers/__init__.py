from weave.type_wrappers.Content import Content

__docspec__ = [
    Content,
]
