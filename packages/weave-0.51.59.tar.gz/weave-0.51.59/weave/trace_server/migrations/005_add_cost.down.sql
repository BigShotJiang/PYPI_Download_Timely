DROP TABLE llm_token_prices;
