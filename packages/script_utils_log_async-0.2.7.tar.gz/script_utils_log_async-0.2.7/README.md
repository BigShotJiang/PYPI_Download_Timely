# Script utilities

* setup logging
* setup main with
  * logging the start, end, total time
  * setting up asyncio with the ability to catch interrupts
