from odoo.addons.component.core import Component


class ContractUtils(Component):
    _name = "contract.utils"
    _usage = "contract.utils"
    _apply_on = "contract.contract"
    _collection = "utils.backend"
