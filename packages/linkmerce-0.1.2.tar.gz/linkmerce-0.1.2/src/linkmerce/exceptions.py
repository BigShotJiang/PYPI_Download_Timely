from __future__ import annotations


class UnauthorizedError(RuntimeError):
    ...
