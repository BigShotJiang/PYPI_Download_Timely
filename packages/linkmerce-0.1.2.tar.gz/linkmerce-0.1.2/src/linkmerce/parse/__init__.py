from linkmerce.parse.base import Map, Array
