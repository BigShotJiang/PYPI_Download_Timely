__version__ = "76" # shoud equal `git rev-list --count master`
                   # can roll back to 0 if errors
from .json2rdf import json2rdf, j2r
