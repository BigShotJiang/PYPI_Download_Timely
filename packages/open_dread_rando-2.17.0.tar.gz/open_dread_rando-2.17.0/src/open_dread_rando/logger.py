import logging

LOG = logging.getLogger("dread_patcher")
