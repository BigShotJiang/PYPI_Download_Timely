RandomizerPowerup.tProgressiveModels['TEMPLATE("actordef_name")'] = TEMPLATE("progressive_models")
