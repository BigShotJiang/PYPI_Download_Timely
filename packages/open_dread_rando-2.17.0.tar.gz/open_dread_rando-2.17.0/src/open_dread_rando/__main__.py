from open_dread_rando import cli

cli.main()
