# Icons
unplug by tezar tantular from [Noun Project](https://thenounproject.com/browse/icons/term/unplug/) (CC BY 3.0)