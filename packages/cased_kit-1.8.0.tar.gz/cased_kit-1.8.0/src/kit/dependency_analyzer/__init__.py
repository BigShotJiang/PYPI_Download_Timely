from __future__ import annotations

from .dependency_analyzer import DependencyAnalyzer

__all__ = ["DependencyAnalyzer"]
