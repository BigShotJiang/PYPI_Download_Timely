API Reference
=============

.. autoclass:: zbitvector.Symbolic
.. autoclass:: zbitvector.Constraint
.. autoclass:: zbitvector.BitVector
.. autoclass:: zbitvector.Uint
    :exclude-members: +width
.. autoclass:: zbitvector.Int
    :exclude-members: +width
.. autoclass:: zbitvector.Array
    :exclude-members: +__eq__, __ne__
.. autoclass:: zbitvector.Solver
