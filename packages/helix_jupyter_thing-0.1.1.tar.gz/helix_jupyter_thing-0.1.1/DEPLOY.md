# Uploading to PyPI

1. `pip install .[deploy]`
2. `python -m build`
3. `python -m twine upload dist/*`
