# SPDX-FileCopyrightText: 2025-present asungy <62207329+asungy@users.noreply.github.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.1.1"
