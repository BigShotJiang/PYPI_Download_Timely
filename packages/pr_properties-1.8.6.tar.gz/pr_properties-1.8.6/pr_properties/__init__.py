from .pr_properties import pr_properties

__all__ = ['pr_properties']
