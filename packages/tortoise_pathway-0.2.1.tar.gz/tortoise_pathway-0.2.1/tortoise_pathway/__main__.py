"""
Main entry point for the Tortoise Pathway CLI.
"""

from tortoise_pathway.cli import main

if __name__ == "__main__":
    main()
