"""
TortoisePath - A schema migration tool for Tortoise ORM
"""

__version__ = "0.1.0"
