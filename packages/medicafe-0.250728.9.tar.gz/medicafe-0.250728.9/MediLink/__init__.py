from .MediLink import enrich_with_insurance_type
