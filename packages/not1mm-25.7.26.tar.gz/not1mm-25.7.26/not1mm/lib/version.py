"""It's the version"""

__version__ = "25.7.26"
