__package__ = "usdm3.rules.library.schema"
