"""a set of tools for modeling the expansion of a malignant clone in blood cells"""
__version__="0.0.1"