"""
Base filters for database tables.
"""


class BaseFilter:
    pass
