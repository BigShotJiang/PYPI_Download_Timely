# AIAS Common

This package contains the common utils for AIAS and others. Notably, the file Access Manager. It unifies access and storage of files on local file systems as well as on object stores. It is part of the AIAS project, maintained by Gisaïa.
