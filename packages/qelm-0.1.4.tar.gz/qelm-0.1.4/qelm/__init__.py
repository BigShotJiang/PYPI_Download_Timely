from importlib.metadata import version
__version__ = version("qelm", default="0.0.0.dev0")
