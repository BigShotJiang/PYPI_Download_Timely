class ConfigurationError(Exception): pass
