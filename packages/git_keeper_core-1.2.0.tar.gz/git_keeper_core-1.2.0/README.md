# git-keeper-core

This package is a dependency for git-keeper-client and git-keeper-server. It
provides functionality that is shared between the two packages.

For more detailed documentation, see our GitHub repository:
[https://github.com/git-keeper/git-keeper](https://github.com/git-keeper/git-keeper)
