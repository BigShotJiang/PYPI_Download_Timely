from django.apps import AppConfig

class DjangoSecuxConfig(AppConfig):
    name = 'django_secux'
    verbose_name = 'Django Secux'
