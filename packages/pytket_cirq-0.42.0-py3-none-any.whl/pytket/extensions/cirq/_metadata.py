__extension_version__ = "0.42.0"
__extension_name__ = "pytket-cirq"
