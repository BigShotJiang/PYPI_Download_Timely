sqlite\_database.functions module
=================================

.. automodule:: sqlite_database.functions
   :members:
   :show-inheritance:
   :undoc-members:
