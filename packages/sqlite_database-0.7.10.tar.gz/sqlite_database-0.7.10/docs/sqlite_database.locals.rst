sqlite\_database.locals module
==============================

.. automodule:: sqlite_database.locals
   :members:
   :show-inheritance:
   :undoc-members:
