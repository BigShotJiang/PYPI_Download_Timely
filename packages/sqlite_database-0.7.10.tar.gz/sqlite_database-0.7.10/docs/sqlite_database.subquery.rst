sqlite\_database.subquery module
================================

.. automodule:: sqlite_database.subquery
   :members:
   :show-inheritance:
   :undoc-members:
