# License AGPL-3 - See http://www.gnu.org/licenses/agpl-3.0.html

from . import uom
from . import res_country_state
from . import res_partner
from . import res_company
from . import product_product
from . import product_supplierinfo
from . import ncm
from . import cest
from . import tax_ipi_guideline
from . import document_type
from . import document_related
from . import document
from . import document_line
from . import document_supplement
from . import res_city
from . import res_config_settings
from . import cfop
from . import invalidate_number
from . import dfe
from . import mde

spec_schema = "nfe"
spec_version = "40"
