# -*- coding: utf-8 -*-
"""
Package version.
"""

__version__ = '2025.07.25'
