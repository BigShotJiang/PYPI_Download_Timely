@resolvers:
    POST:
        call: ecommerce.cartService.remove_from_cart
===