column_order:-
    sizes
    colors
    styles
small,red,crew-neck:
    stock: 44
    cost: 0.0
small,red,v-neck:
    stock: 0
    cost: 0.0
small,red,polo:
    stock: 0
    cost: 5.0
small,red,jersey:
    stock: 0
    cost: 5.0
small,red,tank-tops:
    stock: 0
    cost: 2.0
small,white,crew-neck:
    stock: 10
    cost: 0.0
small,white,v-neck:
    stock: 0
    cost: 0.0
small,white,polo:
    stock: 0
    cost: 5.0
small,white,jersey:
    stock: 0
    cost: 5.0
small,white,tank-tops:
    stock: 0
    cost: 2.0
small,blue,crew-neck:
    stock: 0
    cost: 0.0
small,blue,v-neck:
    stock: 0
    cost: 0.0
small,blue,polo:
    stock: 0
    cost: 5.0
small,blue,jersey:
    stock: 0
    cost: 5.0
small,blue,tank-tops:
    stock: 0
    cost: 2.0
medium,red,crew-neck:
    stock: 0
    cost: 0.0
medium,red,v-neck:
    stock: 0
    cost: 0.0
medium,red,polo:
    stock: 0
    cost: 5.0
medium,red,jersey:
    stock: 0
    cost: 5.0
medium,red,tank-tops:
    stock: 0
    cost: 2.0
medium,white,crew-neck:
    stock: 0
    cost: 0.0
medium,white,v-neck:
    stock: 0
    cost: 0.0
medium,white,polo:
    stock: 3
    cost: 5.0
medium,white,jersey:
    stock: 0
    cost: 5.0
medium,white,tank-tops:
    stock: 0
    cost: 2.0
medium,blue,crew-neck:
    stock: 0
    cost: 0.0
medium,blue,v-neck:
    stock: 0
    cost: 0.0
medium,blue,polo:
    stock: 0
    cost: 5.0
medium,blue,jersey:
    stock: 0
    cost: 5.0
medium,blue,tank-tops:
    stock: 0
    cost: 2.0
large,red,crew-neck:
    stock: 0
    cost: 0.0
large,red,v-neck:
    stock: 0
    cost: 0.0
large,red,polo:
    stock: 0
    cost: 5.0
large,red,jersey:
    stock: 0
    cost: 5.0
large,red,tank-tops:
    stock: 0
    cost: 2.0
large,white,crew-neck:
    stock: 0
    cost: 0.0
large,white,v-neck:
    stock: 0
    cost: 0.0
large,white,polo:
    stock: 0
    cost: 5.0
large,white,jersey:
    stock: 0
    cost: 5.0
large,white,tank-tops:
    stock: 0
    cost: 2.0
large,blue,crew-neck:
    stock: 0
    cost: 0.0
large,blue,v-neck:
    stock: 0
    cost: 0.0
large,blue,polo:
    stock: 0
    cost: 5.0
large,blue,jersey:
    stock: 0
    cost: 5.0
large,blue,tank-tops:
    stock: 0
    cost: 2.0
XL,red,crew-neck:
    stock: 0
    cost: 2.0
XL,red,v-neck:
    stock: 0
    cost: 2.0
XL,red,polo:
    stock: 0
    cost: 7.0
XL,red,jersey:
    stock: 0
    cost: 7.0
XL,red,tank-tops:
    stock: 0
    cost: 4.0
XL,white,crew-neck:
    stock: 0
    cost: 2.0
XL,white,v-neck:
    stock: 0
    cost: 2.0
XL,white,polo:
    stock: 0
    cost: 7.0
XL,white,jersey:
    stock: 0
    cost: 7.0
XL,white,tank-tops:
    stock: 0
    cost: 4.0
XL,blue,crew-neck:
    stock: 0
    cost: 2.0
XL,blue,v-neck:
    stock: 0
    cost: 2.0
XL,blue,polo:
    stock: 0
    cost: 7.0
XL,blue,jersey:
    stock: 0
    cost: 7.0
XL,blue,tank-tops:
    stock: 0
    cost: 4.0
2XL,red,crew-neck:
    stock: 0
    cost: 2.0
2XL,red,v-neck:
    stock: 0
    cost: 2.0
2XL,red,polo:
    stock: 0
    cost: 7.0
2XL,red,jersey:
    stock: 0
    cost: 7.0
2XL,red,tank-tops:
    stock: 0
    cost: 4.0
2XL,white,crew-neck:
    stock: 0
    cost: 2.0
2XL,white,v-neck:
    stock: 0
    cost: 2.0
2XL,white,polo:
    stock: 0
    cost: 7.0
2XL,white,jersey:
    stock: 0
    cost: 7.0
2XL,white,tank-tops:
    stock: 0
    cost: 4.0
2XL,blue,crew-neck:
    stock: 0
    cost: 2.0
2XL,blue,v-neck:
    stock: 0
    cost: 2.0
2XL,blue,polo:
    stock: 0
    cost: 7.0
2XL,blue,jersey:
    stock: 0
    cost: 7.0
2XL,blue,tank-tops:
    stock: 0
    cost: 4.0
3XL,red,crew-neck:
    stock: 0
    cost: 4.0
3XL,red,v-neck:
    stock: 0
    cost: 4.0
3XL,red,polo:
    stock: 0
    cost: 9.0
3XL,red,jersey:
    stock: 0
    cost: 9.0
3XL,red,tank-tops:
    stock: 0
    cost: 6.0
3XL,white,crew-neck:
    stock: 0
    cost: 4.0
3XL,white,v-neck:
    stock: 0
    cost: 4.0
3XL,white,polo:
    stock: 0
    cost: 9.0
3XL,white,jersey:
    stock: 0
    cost: 9.0
3XL,white,tank-tops:
    stock: 0
    cost: 6.0
3XL,blue,crew-neck:
    stock: 0
    cost: 4.0
3XL,blue,v-neck:
    stock: 0
    cost: 4.0
3XL,blue,polo:
    stock: 0
    cost: 9.0
3XL,blue,jersey:
    stock: 0
    cost: 9.0
3XL,blue,tank-tops:
    stock: 0
    cost: 6.0
4XL,red,crew-neck:
    stock: 0
    cost: 4.0
4XL,red,v-neck:
    stock: 0
    cost: 4.0
4XL,red,polo:
    stock: 0
    cost: 9.0
4XL,red,jersey:
    stock: 0
    cost: 9.0
4XL,red,tank-tops:
    stock: 0
    cost: 6.0
4XL,white,crew-neck:
    stock: 0
    cost: 4.0
4XL,white,v-neck:
    stock: 0
    cost: 4.0
4XL,white,polo:
    stock: 0
    cost: 9.0
4XL,white,jersey:
    stock: 0
    cost: 9.0
4XL,white,tank-tops:
    stock: 0
    cost: 6.0
4XL,blue,crew-neck:
    stock: 0
    cost: 4.0
4XL,blue,v-neck:
    stock: 0
    cost: 4.0
4XL,blue,polo:
    stock: 0
    cost: 9.0
4XL,blue,jersey:
    stock: 0
    cost: 9.0
4XL,blue,tank-tops:
    stock: 0
    cost: 6.0
5XL,red,crew-neck:
    stock: 0
    cost: 5.0
5XL,red,v-neck:
    stock: 0
    cost: 5.0
5XL,red,polo:
    stock: 0
    cost: 10.0
5XL,red,jersey:
    stock: 0
    cost: 10.0
5XL,red,tank-tops:
    stock: 0
    cost: 7.0
5XL,white,crew-neck:
    stock: 0
    cost: 5.0
5XL,white,v-neck:
    stock: 0
    cost: 5.0
5XL,white,polo:
    stock: 0
    cost: 10.0
5XL,white,jersey:
    stock: 0
    cost: 10.0
5XL,white,tank-tops:
    stock: 0
    cost: 7.0
5XL,blue,crew-neck:
    stock: 0
    cost: 5.0
5XL,blue,v-neck:
    stock: 0
    cost: 5.0
5XL,blue,polo:
    stock: 0
    cost: 10.0
5XL,blue,jersey:
    stock: 0
    cost: 10.0
5XL,blue,tank-tops:
    stock: 0
    cost: 7.0