@resolvers:
    GET:
        call: ecommerce.productService.get_product
===