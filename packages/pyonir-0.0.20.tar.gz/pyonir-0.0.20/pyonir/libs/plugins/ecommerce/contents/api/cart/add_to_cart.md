@resolvers:
    GET.call: ecommerce.cartService.add_to_cart
===
Add a specified quantity of a product to the user's shopping cart.
        