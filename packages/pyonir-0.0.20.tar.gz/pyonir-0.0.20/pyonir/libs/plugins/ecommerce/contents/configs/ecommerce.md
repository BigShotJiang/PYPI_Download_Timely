name: Ecommerce Plugin Configurations
install_demo: true
return_url: /my-shop/thank-you
cancel_url: /my-shop/cancel-cart
===
Ecommerce plugin configuration file can be managed from the source application.

### Parameters

install_demo: plugin will install templates and demo files locally into the applications plugin directory