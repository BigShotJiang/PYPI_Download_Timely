sizes:-
    name: small
    cost: 0
    -
    name: medium
    cost: 0
    -
    name: large
    cost: 0
    -
    name: XL
    cost: 2
    -
    name: 2XL
    cost: 2
    -
    name: 3XL
    cost: 4
    -
    name: 4XL
    cost: 4
    -
    name: 5XL
    cost: 5
        
