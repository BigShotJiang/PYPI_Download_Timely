@resolvers:
    GET.call: ecommerce.cartService.remove_from_cart
===
Remove a product from the user's shopping cart.
        