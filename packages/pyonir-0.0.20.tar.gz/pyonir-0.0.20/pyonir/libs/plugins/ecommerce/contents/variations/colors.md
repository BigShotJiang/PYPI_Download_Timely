colors:-
    name: red
    -
    name: white
    -
    name: blue
