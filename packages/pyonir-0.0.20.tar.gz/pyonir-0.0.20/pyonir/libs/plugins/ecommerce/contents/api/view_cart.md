@resolvers:
    GET.call: ecommerce.cartService.view_cart
===
View users cart from session