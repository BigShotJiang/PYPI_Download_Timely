@resolvers:
    GET.call: ecommerce.orderService.cancel_order
===
Cancel an existing order and restock the items.
        