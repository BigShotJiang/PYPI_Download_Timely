@resolvers:
    GET.call: ecommerce.orderService.create_order
===
Creates an official order confirmed from gateway and user.