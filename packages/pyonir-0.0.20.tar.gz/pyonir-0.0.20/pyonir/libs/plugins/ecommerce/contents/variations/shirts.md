shirts:-
    name: crew neck
    cost: 0
    -
    name: v-neck
    cost: 0
    -
    name: polo
    cost: 5
    -
    name: jersey
    cost: 5
    -
    name: tank tops
    cost: 2

    