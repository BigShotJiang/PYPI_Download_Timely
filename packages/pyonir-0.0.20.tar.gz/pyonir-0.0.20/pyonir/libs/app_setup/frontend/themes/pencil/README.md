name: Pencil theme
author: Pablo Pyonir
static: public
===
# Pencil

a minimal site theme demo