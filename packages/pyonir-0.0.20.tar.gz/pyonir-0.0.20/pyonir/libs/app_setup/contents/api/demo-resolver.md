@resolvers:
    GET.call: controllers.demo_controller.dynamic_lambda
===