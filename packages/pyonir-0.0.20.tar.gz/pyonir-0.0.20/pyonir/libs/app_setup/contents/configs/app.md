name: Pyonir Demo app
theme_name: pencil
description: my site description 
author: Pablo Pycasso
timezone: US/Eastern
keywords:- cms, blog, web developers, web designers
enabled_plugins:- Ecommerce, Forms, Navigation
===
Default site configurations