# OSBot-Fast-API-Serverless
Repo for OSBot-Fast-API-Serverless
