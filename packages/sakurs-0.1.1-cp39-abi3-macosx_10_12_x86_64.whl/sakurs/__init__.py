from .sakurs import *

__doc__ = sakurs.__doc__
if hasattr(sakurs, "__all__"):
    __all__ = sakurs.__all__