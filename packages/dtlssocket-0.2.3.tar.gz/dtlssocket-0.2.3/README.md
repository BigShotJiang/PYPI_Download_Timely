This is a cython wrapper for tinydtls.

It currently implements a socket like Interface with sendmsg and readmsg.
All other calls are passt to the underlying socket.

For more info of tinydtls see https://projects.eclipse.org/projects/iot.tinydtls

This Code was created at the [Multimedia Communication Laboratory](http://mc-lab.de) of the [Bonn-Rhein-Sieg University of Applied Sciences](http://h-brs.de)

The Repo was originally hostet in our [GitLab](https://git.fslab.de/archived_jkonra2m_1/tinydtls-cython) \
The main Repo is now on [GitHub](https://github.com/mclab-hbrs/DTLSSocket)
