#!/usr/bin/env bash

python ../../eta/modules/embed_vgg16.py embed_vgg16_module-config.json
