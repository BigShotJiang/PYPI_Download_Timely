"""
Dataset module for nahiarhdNLP.
"""

from .loaders import DatasetLoader

__all__ = ["DatasetLoader"]
