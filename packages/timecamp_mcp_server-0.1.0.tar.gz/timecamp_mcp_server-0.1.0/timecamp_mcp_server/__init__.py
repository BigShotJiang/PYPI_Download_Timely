"""TimeCamp MCP Server - A Model Context Protocol server for TimeCamp time tracking integration."""

__version__ = "0.1.0"
