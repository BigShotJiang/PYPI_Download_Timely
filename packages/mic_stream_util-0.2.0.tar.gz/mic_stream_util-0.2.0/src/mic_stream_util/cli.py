#!/usr/bin/env python3
"""CLI tool for microphone-util library."""

from mic_stream_util.cli.main import main

if __name__ == "__main__":
    main()
