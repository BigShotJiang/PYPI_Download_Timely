from ..app import app, app_state

__all__ = []


# noinspection PyShadowingBuiltins
@app.command()
def compile(

):
    """
    Compile Pine Script to Python through pynesys.com
    """
    # TODO: Implement the compile command when API is ready
