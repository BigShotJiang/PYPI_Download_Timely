from ..types.display import Display

all: Display = Display()  # noqa F821
data_window: Display = Display()
none: Display = Display()
pane: Display = Display()
price_scale: Display = Display()
status_line: Display = Display()
