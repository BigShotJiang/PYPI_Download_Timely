from ..types.datetime import DayOfWeek

#
# Constatns
#

sunday = DayOfWeek()
monday = DayOfWeek()
tuesday = DayOfWeek()
wednesday = DayOfWeek()
thursday = DayOfWeek()
friday = DayOfWeek()
saturday = DayOfWeek()
