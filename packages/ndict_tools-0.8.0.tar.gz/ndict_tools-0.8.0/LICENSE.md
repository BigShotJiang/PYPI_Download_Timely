CeCILL-C Free Software License

# Lecteur francophone

Ce module python permet de gérer des dictionnaires imbriqués en conservant une structure héritée des dictionnaires
python. Ce module est développé sour la licence [CeCILL-C](http://www.cecill.info/licences/Licence_CeCILL-C_V1-fr.html).

Cette licence n'est pas contaminante pour les autres modules si vous vous en servez. Cependant, si vous y 
apportez des modifications, vous devrez le soumettre au préalable ce qui permettra de l'améliorer.

# English reader and ROW

This python module lets you manage nested dictionaries using type inherited from standard python dictionaries.
This module has been developed under the [CeCILL-C](http://www.cecill.info/licences/Licence_CeCILL-C_V1-en.html)
license.

This license does not contaminate other modules if you use this one. However, if you 
However, if you make any modifications to it, you'll need to submit them beforehand, which will enable us to improve it.