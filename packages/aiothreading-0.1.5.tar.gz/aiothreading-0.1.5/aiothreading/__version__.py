# Copyright 2022 Amy Reese
# Licensed under the MIT license
# 2024-2025 Modified by Vizonex & x42005e1f

__version__ = "0.1.5"
