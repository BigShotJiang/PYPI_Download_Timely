from django.apps import AppConfig


class VoipConfig(AppConfig):
    name = 'voip'
    default_auto_field = 'django.db.models.AutoField'
