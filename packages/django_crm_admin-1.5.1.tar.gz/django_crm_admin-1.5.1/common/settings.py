
# TODO: The "REMAINDER_CHECK_INTERVAL" setting is deprecated and will be removed in the future.
REMAINDER_CHECK_INTERVAL = 60 * 5
