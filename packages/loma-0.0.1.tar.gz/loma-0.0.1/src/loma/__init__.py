def start():
    return "LOMA is ready."
