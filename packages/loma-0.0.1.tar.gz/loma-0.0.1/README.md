# LOMA

**LOMA** (**L**ightweight **O**ptimization and **M**odel **A**daptation) is a modular Python framework for experimenting with model compression, structural pruning, and efficient fine-tuning techniques like LoRA.

---

