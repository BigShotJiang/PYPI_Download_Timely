
cache: [cache/cache.js,cache/save.js]
cache.save: cache/save.js
log: log/%Y%m%d_log_test.txt