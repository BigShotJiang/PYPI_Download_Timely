#coding=utf-8
from . import sc
sc.run()