[
    {
        nullable: 1,
        key: args,
        default: []
    },
    {
        nullable: 1,
        key: maps,
        default: {}
    }
]