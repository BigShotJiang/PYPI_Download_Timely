
main:{
    data.total: total
    data.diff: datas1
    datas1: [datas, list, trs.datas]
}

trs.datas: {
    var0: code
    var1: name
    var2: group
    var3: num
    var4: val
    _: [type, val, 'A']
    _1: [typeV, var, x]
}