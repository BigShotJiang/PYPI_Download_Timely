{
    data: {
        total: 1024
        diff: [
            {
                var0: 001
                var1: 测试
                var2: 100
                var3: 1000
                var4: 1e2
            }
            {
                var0: 002
                var1: 测试
                var2: 102
                var3: 1002
                var4: 2e3
            }
            {
                var0: 003
                var1: 测试
                var2: 300
                var3: 3000
                var4: 3e4
            }
            {
                var0: 004
                var1: 测试
                var2: 104
                var3: 1004
                var4: 4e5
            }
        ]
    }
}