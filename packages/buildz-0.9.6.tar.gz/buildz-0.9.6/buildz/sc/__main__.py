from . import subrun
from .. import pyz
pyz.lc(locals(), subrun.test)