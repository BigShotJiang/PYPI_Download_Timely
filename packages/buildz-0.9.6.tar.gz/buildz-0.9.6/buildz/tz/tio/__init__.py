#coding=utf-8

from .getch import getch