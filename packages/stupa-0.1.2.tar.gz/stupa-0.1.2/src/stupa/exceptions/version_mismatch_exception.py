
class VersionMismatchException(Exception):
    "Raised when there is a mismatch of version for the record being updated"
    pass
