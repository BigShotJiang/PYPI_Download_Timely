"""
Experimental extra functions for Pikaur.
MB later it will be turned into a plugin system.
"""
from . import dep_tree

__all__ = [
    "dep_tree",
]
