import warnings


def enable_exceptions():
    warnings.warn("Exceptions are not an experimental feature anymore and enabled by default.")


def disable_exceptions():
    warnings.warn("Exceptions are not an experimental feature anymore and enabled by default.")
