def signal(x, y):
    pass