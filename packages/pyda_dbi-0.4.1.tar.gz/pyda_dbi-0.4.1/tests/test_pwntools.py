from pwn import *
from pyda import *

p = process(io=True)
p.run()
print("pass")