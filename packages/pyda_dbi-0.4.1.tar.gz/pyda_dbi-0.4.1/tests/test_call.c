
int lol(char *arg1, int arg2) {
    printf("lol %s %d\n", arg1, arg2);
}

int main() {
    printf("here1\n");
    printf("here2\n");
}