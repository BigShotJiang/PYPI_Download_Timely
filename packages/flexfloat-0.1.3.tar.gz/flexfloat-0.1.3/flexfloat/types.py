"""Type definitions for the flexfloat package."""

from typing import TypeAlias

Number: TypeAlias = int | float
