apiurl='https://a1.fanbook.mobi/api/bot/'
apilist={
    'getme':'/getMe',
    'sendmessage':'/sendMessage',
    'getPrivateChat':'/getPrivateChat'
}
