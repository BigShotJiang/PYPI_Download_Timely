# Authors
- William Mangione
- Zackary Falls
- James Schuler
- Matt Hudson
- Melissa Van Norden
- Liana Bruggemann
- Ram Samudrala

For general questions about the conceptual and scientific tenets of the CANDO platform, please contact Ram Samudrala (<ram@compbio.org>) and Zackary Falls (<zmfalls@buffalo.edu>). For questions about cando.py source code or its operation/installion, please contact William Mangione (<wmangion@buffalo.edu>) and Zackary Falls (<zmfalls@buffalo.edu>), and Cc Ram Samudrala (<ram@compbio.org>). 
