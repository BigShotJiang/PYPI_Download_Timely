from setuptools import setup

from grafana_client.version import version

setup(
    version=version,
)
