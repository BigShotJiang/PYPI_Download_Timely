"""
Extract data from text using a specified strategy and target dataclass type.
"""

from ._extractors import extract

__all__ = ['extract',]


