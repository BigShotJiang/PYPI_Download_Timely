from .yolov5_base import *
from .yolov8_base import *
from .megadetectorv5 import *
from .megadetectorv6 import *
from .megadetectorv6_distributed import *
from .Deepfaune import *
