## 0.4.3 (2025-07-24)

### Fix

- final patchfix for ci cd, separe dev/master

### Refactor

- improve modularity with typing, abstract and generic var

## 0.4.2 (2025-07-23)

### Fix

- final patchfix for ci cd, separe dev/master

## 0.4.1 (2025-07-23)

### Fix

- azd
- try patchfix ci/cd
- try patchfix ci/cd

## 0.4.0 (2025-07-23)

### Feat

- add factory of exception responses, add tests, add dev dependencies / func
- init project with uv and commitizen

### Refactor

- delete fastapi dependency with protocol http exception
