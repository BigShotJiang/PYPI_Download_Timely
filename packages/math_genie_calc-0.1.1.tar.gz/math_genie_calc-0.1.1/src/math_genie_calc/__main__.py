from math_genie_calc import main
main()