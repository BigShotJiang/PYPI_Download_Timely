# paper-qa-pymupdf

[![GitHub](https://img.shields.io/badge/github-%23121011.svg?logo=github&logoColor=white)](https://github.com/Future-House/paper-qa/tree/main/packages/paper-qa-pymupdf)
[![PyPI version](https://badge.fury.io/py/paper-qa-pymupdf.svg)](https://badge.fury.io/py/paper-qa-pymupdf)
[![tests](https://github.com/Future-House/paper-qa/actions/workflows/tests.yml/badge.svg)](https://github.com/Future-House/paper-qa)
![License](https://img.shields.io/badge/license-AGPLv3-blue.svg)
![PyPI Python Versions](https://img.shields.io/pypi/pyversions/paper-qa-pymupdf)

PDF reading code backed by
[PyMuPDF](https://github.com/pymupdf/PyMuPDF).
