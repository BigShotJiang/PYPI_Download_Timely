from __future__ import absolute_import


def init_core_modules(*args, **kwargs) -> None:
    """
    Init core handlers, middlewares and services for fastapi application
    :return: None
    """
    pass
