#!/usr/bin/env python-sirius
"""Test beaglebone module."""
from unittest import TestCase


class TestBeagleBone(TestCase):
    """Test PRUInterface API."""

    pass
