"""Oscilloscope subpackage."""

from .scopes import Scopes, ScopeSignals
from .keysight import Keysight
