"""Optics subpackage."""
