"""Sirius CAThread class."""
import epics


class CAThread(epics.ca.CAThread):
    """."""
    pass
