.. include:: ../../refs.rst

.. _ref_defines:

slm.defines
------------

.. toctree::
   :maxdepth: 1

   alertlevel
   antennacalibration
   antennafeatures
   antennareferencepoint
   aspiration
   cardinaldirection
   collocationstatus
   equipmentstate
   flagseverity
   fracturespacing
   frequencystandardtype
   geodesymlversion
   instrumentation
   isocountry
   logentrytype
   sitefileuploadstatus
   sitelogformat
   sitelogstatus
   slmfiletype
   tectonicplates
