.. include:: ../../refs.rst

.. autoclass:: slm.defines.CollocationStatus
   :members:
   :undoc-members:
   :show-inheritance:
