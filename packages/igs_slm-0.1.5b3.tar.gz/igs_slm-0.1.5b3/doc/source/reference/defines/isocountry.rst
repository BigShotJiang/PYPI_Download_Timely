.. include:: ../../refs.rst

.. autoclass:: slm.defines.ISOCountry
   :members:
   :undoc-members:
   :show-inheritance:
