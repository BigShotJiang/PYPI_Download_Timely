.. include:: ../../refs.rst

.. autoclass:: slm.defines.AlertLevel
   :members:
   :undoc-members:
   :show-inheritance:
