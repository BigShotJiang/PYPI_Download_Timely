.. include:: ../../refs.rst

.. autoclass:: slm.defines.FrequencyStandardType
   :members:
   :undoc-members:
   :show-inheritance:
