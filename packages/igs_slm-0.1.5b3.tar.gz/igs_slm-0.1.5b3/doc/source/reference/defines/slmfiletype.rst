.. include:: ../../refs.rst

.. autoclass:: slm.defines.SLMFileType
   :members:
   :undoc-members:
   :show-inheritance:
