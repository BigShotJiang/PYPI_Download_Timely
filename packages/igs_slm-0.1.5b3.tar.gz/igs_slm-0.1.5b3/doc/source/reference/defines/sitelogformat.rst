.. include:: ../../refs.rst

.. autoclass:: slm.defines.SiteLogFormat
   :members:
   :undoc-members:
   :show-inheritance:
