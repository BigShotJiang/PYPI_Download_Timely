.. include:: ../../refs.rst

.. autoclass:: slm.defines.FractureSpacing
   :members:
   :undoc-members:
   :show-inheritance:
