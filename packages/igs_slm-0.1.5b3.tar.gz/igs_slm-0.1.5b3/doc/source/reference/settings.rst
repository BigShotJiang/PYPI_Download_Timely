.. include:: ../refs.rst

.. _ref_settings:

slm.settings
------------

.. automodule:: slm.settings
    :members:
