from django.contrib import admin

from slm.map.models import MapSettings

admin.site.register(MapSettings)
