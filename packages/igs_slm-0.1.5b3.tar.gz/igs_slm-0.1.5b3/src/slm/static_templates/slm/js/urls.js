if (typeof slm === 'undefined' || slm == null) { var slm = {}; }

{% urls_to_js %}

slm.urls = new URLResolver();
