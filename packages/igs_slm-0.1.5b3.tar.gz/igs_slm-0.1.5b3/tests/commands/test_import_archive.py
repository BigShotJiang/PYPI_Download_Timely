from django.test import TestCase
from django.core.management import call_command

# class TestImportArchive(TestCase):

#     def test_import_archive(self):

#         import_cmd = call_command('import_archive')
