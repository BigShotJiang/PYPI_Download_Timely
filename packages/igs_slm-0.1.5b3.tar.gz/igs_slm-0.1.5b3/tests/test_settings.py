def test_custom_loaders():
    pass
