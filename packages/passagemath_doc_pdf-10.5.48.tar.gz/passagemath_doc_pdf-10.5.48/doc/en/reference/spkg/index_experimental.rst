Mathematics
~~~~~~~~~~~

* :ref:`spkg_awali`
* :ref:`spkg_barvinok`
* :ref:`spkg_cocoalib`
* :ref:`spkg_deformation`
* :ref:`spkg_gap3`
* :ref:`spkg_lie`
* :ref:`spkg_modular_decomposition`
* :ref:`spkg_polylib`
* :ref:`spkg_r_jupyter`
* :ref:`spkg_surf`

Other dependencies
~~~~~~~~~~~~~~~~~~

