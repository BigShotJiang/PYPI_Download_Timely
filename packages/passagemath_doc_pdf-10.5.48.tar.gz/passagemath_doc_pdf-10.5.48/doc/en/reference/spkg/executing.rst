.. _spkg_executing:

executing: Get the currently executing AST node of a frame, and other information
===========================================================================================

Description
-----------

Get the currently executing AST node of a frame, and other information

License
-------

MIT

Upstream Contact
----------------

https://pypi.org/project/executing/


Type
----

standard


Dependencies
------------

- $(PYTHON)
- :ref:`spkg_pip`

Version Information
-------------------

package-version.txt::

    2.0.1

version_requirements.txt::

    executing


Equivalent System Packages
--------------------------

.. tab:: conda-forge

   .. CODE-BLOCK:: bash

       $ conda install executing 


.. tab:: Fedora/Redhat/CentOS

   .. CODE-BLOCK:: bash

       $ sudo yum install python3-executing 


.. tab:: Gentoo Linux

   .. CODE-BLOCK:: bash

       $ sudo emerge dev-python/executing 



If the system package is installed and if the (experimental) option
``--enable-system-site-packages`` is passed to ``./configure``, then ``./configure``
will check if the system package can be used.

