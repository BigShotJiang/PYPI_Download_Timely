.. _spkg_flit_core:

flit_core: Distribution-building parts of Flit. See flit package for more information
===============================================================================================

Description
-----------

Distribution-building parts of Flit. See flit package for more information

License
-------

Upstream Contact
----------------

https://pypi.org/project/flit-core/


Type
----

standard


Dependencies
------------

- $(PYTHON)
- :ref:`spkg_pip`

Version Information
-------------------

package-version.txt::

    3.9.0

version_requirements.txt::

    flit-core >= 3.7.1


Equivalent System Packages
--------------------------

.. tab:: conda-forge

   .. CODE-BLOCK:: bash

       $ conda install flit-core 


.. tab:: Fedora/Redhat/CentOS

   .. CODE-BLOCK:: bash

       $ sudo yum install python3-flit-core 


.. tab:: Gentoo Linux

   .. CODE-BLOCK:: bash

       $ sudo emerge dev-python/flit_core 


.. tab:: Void Linux

   .. CODE-BLOCK:: bash

       $ sudo xbps-install python3-flit_core 



If the system package is installed and if the (experimental) option
``--enable-system-site-packages`` is passed to ``./configure``, then ``./configure``
will check if the system package can be used.

