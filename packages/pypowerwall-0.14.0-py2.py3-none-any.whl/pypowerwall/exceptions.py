class PyPowerwallInvalidConfigurationParameter(Exception):
    pass


class InvalidBatteryReserveLevelException(Exception):
    pass
