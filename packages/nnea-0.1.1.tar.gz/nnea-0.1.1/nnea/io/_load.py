
def load():

    print("loading nnea object")