

class nadata(object):

    def __init__(self):

        self.assays = {}
        self.meta = 0
        self.var = 0
        self.model = 0
        self.indicator = 0 # sparse matrix