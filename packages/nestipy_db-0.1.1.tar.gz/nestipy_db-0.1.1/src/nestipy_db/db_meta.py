class DbMetadata:
    ModelMeta = "__edgy__model__"
    Models = "__edgy__models__"
