from datetime import datetime
from uuid import UUID, uuid4

import edgy

from nestipy_db import BaseModel, Model


@Model()
class Auth(BaseModel):
    id: UUID = edgy.UUIDField(primary_key=True, default=uuid4, editable=False)
    created_at: datetime = edgy.DateTimeField(auto_now_add=True)
    updated_at: datetime = edgy.DateTimeField(auto_now=True)
