This directory (/home/work) will be deleted when the compute session is terminated.
To keep persistent files after termination:
- Create and mount data folder(s) when starting new sessions.
- Always use them to put any persistent files.

이 디렉토리(/home/work)는 연산 세션이 종료될 때 함께 삭제됩니다.
계속 보존할 파일들을 잃어버리지 않으려면:
- 데이터 폴더를 생성하여 세션 실행 시 마운트합니다.
- 보존할 파일들을 항상 마운트된 폴더들 안에 저장하십시오.
