class CLIInputError(Exception):
    pass
