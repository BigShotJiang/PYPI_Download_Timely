from .string import String


class Password(String):
    _format = "password"
