# clearskies

clearskies is a very opinionated Python framework intended for developing microservices in the cloud via declarative programming principles.  It is mainly intended for backend services and so is designed for RESTful API endpoints, queue listeners, scheduled tasks, and the like.

## Installation, Documentation, and Usage

To install:

```bash
pip3 install clear-skies
```

Documentation is under construction here:

[https://clearskies.info](https://clearskies.info)
