exiftool-wrapper
================

This is is a lightweight Python wrapper for ``exiftool``.

It runs ``exiftool`` in batch mode, minimizing overhead when processing a large number of files.
