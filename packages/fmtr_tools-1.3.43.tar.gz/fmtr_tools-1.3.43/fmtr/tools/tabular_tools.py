import pandas as pd

Table = DataFrame = pd.DataFrame
Series = pd.Series

CONCAT_HORIZONTALLY = 1
CONCAT_VERTICALLY = 0
