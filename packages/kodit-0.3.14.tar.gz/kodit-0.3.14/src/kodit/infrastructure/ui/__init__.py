"""UI infrastructure module."""
