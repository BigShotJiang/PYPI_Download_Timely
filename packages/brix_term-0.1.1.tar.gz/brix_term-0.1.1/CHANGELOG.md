[2025/07/26]
- initial implementation
- terminal with special commands
- rich formatting and console printing
- code generation
- chat
- smart error fixing terminal
- configuration
- arize integration
- optimization for light color mode
