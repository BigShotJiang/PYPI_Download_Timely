from github_heatmap.cli import main

if __name__ == "__main__":
    main()
