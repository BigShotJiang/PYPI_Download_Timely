"""A command-line FITS header editor."""

__version__ = "0.1.4"
