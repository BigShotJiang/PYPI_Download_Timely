
def callbackvoid(*args, **kwargs):
    pass