This folder has the models adapted from `SamsungLabs/ritm_interactive_segmentation`

The file `./test_exposed_model_stuff.py` tests compliance with the contract that other components expect

Adding new models here must pass those test cases
