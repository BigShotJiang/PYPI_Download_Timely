from browser import Captchafox


__all__ = ["Captchafox", "__version__"]

__version__: str = "0.6.0"
