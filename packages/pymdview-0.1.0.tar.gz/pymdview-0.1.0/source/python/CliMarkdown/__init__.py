"""
CLI Markdown Viewer - A command line tool to display Markdown files
"""

__version__ = "0.1.0"