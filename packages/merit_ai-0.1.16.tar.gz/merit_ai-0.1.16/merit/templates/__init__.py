"""
MERIT Templates Module

This module provides templates for various components of the MERIT framework.
"""

from .templates import *
