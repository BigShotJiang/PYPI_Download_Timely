"""
MERIT Knowledge Module

This module provides functionality for working with knowledge bases.
"""

from .knowledgebase import KnowledgeBase
