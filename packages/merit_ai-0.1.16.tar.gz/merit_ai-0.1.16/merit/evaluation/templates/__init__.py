"""
MERIT Evaluation Templates Module

This module provides templates for evaluation reports.
"""
