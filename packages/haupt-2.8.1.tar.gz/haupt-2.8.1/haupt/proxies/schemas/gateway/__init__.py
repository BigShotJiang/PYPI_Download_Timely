from haupt.proxies.schemas.gateway.base import get_base_config
from haupt.proxies.schemas.gateway.redirect import get_redirect_config
