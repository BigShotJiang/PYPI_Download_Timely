from haupt.proxies.schemas.streams.base import get_base_config
