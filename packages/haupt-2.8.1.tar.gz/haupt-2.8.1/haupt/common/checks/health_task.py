def health_task(x: int, y: int) -> int:
    return x + y
