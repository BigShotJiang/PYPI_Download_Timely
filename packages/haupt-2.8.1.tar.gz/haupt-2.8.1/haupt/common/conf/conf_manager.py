from haupt.common.memory_manager import MemoryCacheManager

conf_cache_manager = MemoryCacheManager()
