from haupt.db.abstracts.project_versions import BaseProjectVersion


class ProjectVersion(BaseProjectVersion):
    pass
