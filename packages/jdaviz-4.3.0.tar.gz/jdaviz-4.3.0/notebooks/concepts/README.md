This directory stores notebooks that may not yet function,
but represent *desired* Jdaviz workflows.
