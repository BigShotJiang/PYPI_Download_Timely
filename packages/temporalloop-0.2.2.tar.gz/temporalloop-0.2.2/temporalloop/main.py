#!/usr/bin/env python3
from temporalloop.cmd.looper import main

if __name__ == "__main__":
    main()  # pylint: disable=no-value-for-parameter # pragma: no cover
