from .core import LightWhisperSTT
