from . import _cli

_cli.run()
