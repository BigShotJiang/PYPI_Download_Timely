"""
자동 생성 파일입니다. 직접 수정하지 마세요.
생성일자: 2025-07-28
생성 위치: init_generator/interfaces/__init__.py
"""
from .abstract_init_generator import AbstractInitGeneratorBase

__all__ = [
    "AbstractInitGeneratorBase"
]
