from pydantic import BaseModel


class EmbeddedPydantic(BaseModel):
    int_attr: int
    float_attr: float
    bool_attr: bool
    str_attr: str