# from napari_fluoresfm import write_single_image, write_multiple

# add your tests here...


def test_something():
    pass
