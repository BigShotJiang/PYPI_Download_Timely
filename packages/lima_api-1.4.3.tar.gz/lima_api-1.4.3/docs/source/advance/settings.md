# Settings

You could see all settings on 
[lima_api/config.py](https://github.com/paradigmadigital/lima-api/blob/main/src/lima_api/config.py)

```{eval-rst}
.. autoclass:: lima_api.config.LimaSettings
   :members:
   :undoc-members:
   :show-inheritance:
```
