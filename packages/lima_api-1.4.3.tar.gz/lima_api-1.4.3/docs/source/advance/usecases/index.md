(lima-usecases)=

# 🛠 Usecases

Here you are same examples for common usecases

```{toctree}
json_patch
opentracing
upload_files
```
