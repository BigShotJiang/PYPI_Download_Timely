(lima-advance)=

# 🕵 Advance

Here you are more information about Lima-API

```{toctree}
recomendations
settings
parameters
retry_processor
dynamic_payload
```
