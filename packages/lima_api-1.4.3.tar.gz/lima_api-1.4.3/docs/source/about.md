# About

Lima-API is sync and async library that allows implements Rest APIs libs with python typing.

You could read more about it on [our post (Spanish)](https://www.paradigmadigital.com/dev/poder-del-tipado-python-funciones-sin-codigo/).

You could install from [pypi](https://pypi.org/project/lima-api/) with:
```shell
pip install lima-api
```

You can find the source code for Lima-API at GitHub:
[paradigma digital][paradigma-organization] /
[lima-api](https://github.com/paradigmadigital/lima-api)


[paradigma-organization]: https://github.com/paradigmadigital
