## v1.0.0 (2025-07-26)

### Feat

- Complete test suite overhaul and comprehensive README

## v0.1.0 (2025-07-20)

### Fix

- update pydanic
