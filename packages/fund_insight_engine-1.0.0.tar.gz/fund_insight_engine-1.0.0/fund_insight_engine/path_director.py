import os

DIR_DATA = 'data'

FILE_FOLDER = {
    'bulk': os.path.join(DIR_DATA, 'data-bulk')
}
