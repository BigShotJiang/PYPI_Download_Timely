ncrvi
=====

Determine the number of components returning version information

Example usage
-------------

.. code-block:: bash

    $ ncrvi -h
    Here be dragons

Installation
------------

The `project <https://pypi.org/project/ncrvi/>`_ is on PyPI, so simply run

.. code-block:: bash

    $ python -m pip install ncrvi
