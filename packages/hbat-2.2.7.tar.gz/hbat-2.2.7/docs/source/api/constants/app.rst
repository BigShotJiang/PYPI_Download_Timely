Application Metadata
====================

Contains application name, version, and metadata information.

Module Overview
---------------

.. automodule:: hbat.constants.app
   :members:
   :undoc-members:
   :show-inheritance:

Constants
---------

Application Information
~~~~~~~~~~~~~~~~~~~~~~~

.. autodata:: hbat.constants.app.APP_NAME
.. autodata:: hbat.constants.app.APP_VERSION