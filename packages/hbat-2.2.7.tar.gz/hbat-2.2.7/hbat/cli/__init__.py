"""Command-line interface for HBAT."""
