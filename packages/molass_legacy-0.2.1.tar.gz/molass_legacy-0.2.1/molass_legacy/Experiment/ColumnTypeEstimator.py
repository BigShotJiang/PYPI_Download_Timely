"""
    SecTheory.ColumnTypeEstimator.py

    Copyright (c) 2023, SAXS Team, KEK-PF
"""
from .ColumnTypes import COLUMN_TYPE_DICT

class ColumnTypeEstimator:
    def __init__(self):
        pass

    def guess_from_sd(self, sd):
        pass

def guess_for_all_data():
    pass
