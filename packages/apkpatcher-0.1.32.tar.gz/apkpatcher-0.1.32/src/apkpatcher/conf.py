"""conf file
"""

VERSION = "0.1.32"
