import pytest


@pytest.mark.django_db
class TestSpecificSViewsets:
    pass
