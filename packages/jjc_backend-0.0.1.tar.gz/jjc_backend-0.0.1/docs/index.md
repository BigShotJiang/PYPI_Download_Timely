# jjc-backend

[![Release](https://img.shields.io/github/v/release/makanu/jjc-backend)](https://img.shields.io/github/v/release/makanu/jjc-backend)
[![Build status](https://img.shields.io/github/actions/workflow/status/makanu/jjc-backend/main.yml?branch=main)](https://github.com/makanu/jjc-backend/actions/workflows/main.yml?query=branch%3Amain)
[![Commit activity](https://img.shields.io/github/commit-activity/m/makanu/jjc-backend)](https://img.shields.io/github/commit-activity/m/makanu/jjc-backend)
[![License](https://img.shields.io/github/license/makanu/jjc-backend)](https://img.shields.io/github/license/makanu/jjc-backend)

This is the django-backend of JourneyJinks Canvas.
