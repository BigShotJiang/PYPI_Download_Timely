from time import sleep


def main():
    sleep(2)


if __name__ == "__main__":
    main()
