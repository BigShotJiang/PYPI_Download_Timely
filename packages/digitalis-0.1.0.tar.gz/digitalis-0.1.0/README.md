# Digitalis 🪻

## Debug

```sh
uv run textual run --dev digitalis.app:main
```
