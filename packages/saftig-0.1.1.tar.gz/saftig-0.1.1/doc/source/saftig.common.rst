``saftig.common`` Module
========================

.. automodule:: saftig.common
      :members:

