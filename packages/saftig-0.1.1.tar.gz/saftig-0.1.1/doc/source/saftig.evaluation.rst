``saftig.evaluation`` Module
============================

.. automodule:: saftig.evaluation
      :members:

