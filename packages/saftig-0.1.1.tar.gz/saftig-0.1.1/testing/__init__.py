# just a placeholder to make this a module

"""
TODO:
+ check output dimension correctness
+ check that cancellation efficiencies match the expectation
- check that no exceptions are thrown for different input lengths
- check that FIR filter coefficient peak is at correct index (correct targeting)
- check effectveness of all parameters
"""
