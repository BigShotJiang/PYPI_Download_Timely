NODE_ENV = "development"
SOURCE = "AWS"
