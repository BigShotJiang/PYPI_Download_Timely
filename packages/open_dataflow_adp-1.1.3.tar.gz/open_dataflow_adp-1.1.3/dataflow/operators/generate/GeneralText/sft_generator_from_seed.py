from dataflow.prompts.general_text import SFTGeneratorSeedPrompt
import re
import json
import pandas as pd
from dataflow.utils.registry import OPERATOR_REGISTRY
from dataflow import get_logger

from dataflow.utils.storage import DataFlowStorage
from dataflow.core import OperatorABC
from dataflow.core import LLMServingABC
from dataflow.serving import LocalModelLLMServing_vllm

def extract_json_object(model_output):
    """提取第一个包含 instruction 和 output 字段的 JSON 对象"""
    json_pattern = r'\{[^}]*\}'
    matches = re.findall(json_pattern, model_output)
    for match in matches:
        try:
            obj = json.loads(match)
            if 'instruction' in obj and 'output' in obj:
                return obj
        except json.JSONDecodeError:
            continue
    return None

@OPERATOR_REGISTRY.register()
class SFTGeneratorSeed(OperatorABC):
    def __init__(self, llm_serving: LLMServingABC, custom_prompt: str):
        self.logger = get_logger()
        self.prompts = SFTGeneratorSeedPrompt(custom_prompt=custom_prompt)    
        self.llm_serving = llm_serving
        self.max_tokens = 4096  
    
    @staticmethod
    def get_desc(lang: str = "zh"):
        return "基于给定文档内容，生成监督微调格式的问答数据。并支持用户自定义生成内容要求。" if lang == "zh" else "Generate supervised fine-tuning format Q&A data based on the given document content and support user-defined content generation requirements."

    def run(self, storage: DataFlowStorage, input_key: str = "raw_content"):
        self.input_key = input_key
        self.logger.info("Running SFTGenerator...")

        # Load the raw dataframe from the input file
        dataframe = storage.read('dataframe')
        self.logger.info(f"Loading, number of rows: {len(dataframe)}")

        # Create a list to hold all generated questions and answers
        llm_inputs = []

        # Prepare LLM inputs by formatting the prompt with raw content from the dataframe
        for index, row in dataframe.iterrows():
            raw_content = row.get(self.input_key, '')
            llm_input = self.prompts.sft_generate_prompt(content=raw_content)
            llm_inputs.append(llm_input)
        
        # Generate the text using the model
        try:
            self.logger.info("Generating text using the model...")
            outputs = self.llm_serving.generate_from_input(llm_inputs)
            self.logger.info("Text generation completed.")
        except Exception as e:
            self.logger.error(f"Error during text generation: {e}")
            return

        valid_records = []
        for idx, output in enumerate(outputs):
            result = extract_json_object(output)
            if result:
                result["raw_content"] = dataframe[self.input_key].iloc[idx]  # 添加原文内容
                valid_records.append(result)

        # Add the generated content back to the dataframe
        output_df = pd.DataFrame(valid_records)

        # Save the updated dataframe to the output file
        output_file = storage.write(output_df)
        return ['instruction', 'output']
