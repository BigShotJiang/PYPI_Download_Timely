VERSION = "0.6.0"

# fmt: off
MAPPING = {
    "pytest_dependency": "https://pytest-dependency.readthedocs.io/en/stable/",
    "pytest_dependency.depends": "https://pytest-dependency.readthedocs.io/en/stable/reference.html#pytest_dependency.depends",
}
