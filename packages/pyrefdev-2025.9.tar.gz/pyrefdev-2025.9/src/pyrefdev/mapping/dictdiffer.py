VERSION = "0.9.0"

# fmt: off
MAPPING = {
    "dictdiffer": "https://dictdiffer.readthedocs.io/en/latest/",
    "dictdiffer.diff": "https://dictdiffer.readthedocs.io/en/latest/#dictdiffer.diff",
    "dictdiffer.dot_lookup": "https://dictdiffer.readthedocs.io/en/latest/#dictdiffer.dot_lookup",
    "dictdiffer.patch": "https://dictdiffer.readthedocs.io/en/latest/#dictdiffer.patch",
    "dictdiffer.revert": "https://dictdiffer.readthedocs.io/en/latest/#dictdiffer.revert",
    "dictdiffer.swap": "https://dictdiffer.readthedocs.io/en/latest/#dictdiffer.swap",
}
