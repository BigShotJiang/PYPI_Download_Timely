VERSION = "1.3.1"

# fmt: off
MAPPING = {
    "hexbytes": "https://hexbytes.readthedocs.io/en/stable/",
    "hexbytes.main": "https://hexbytes.readthedocs.io/en/stable/hexbytes.html",
    "hexbytes.main.hexbytes": "https://hexbytes.readthedocs.io/en/stable/hexbytes.html#hexbytes.main.HexBytes",
    "hexbytes.main.hexbytes.to_0x_hex": "https://hexbytes.readthedocs.io/en/stable/hexbytes.html#hexbytes.main.HexBytes.to_0x_hex",
}
