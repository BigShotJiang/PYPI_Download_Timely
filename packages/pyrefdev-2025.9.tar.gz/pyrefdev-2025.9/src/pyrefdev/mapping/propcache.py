VERSION = "0.3.2"

# fmt: off
MAPPING = {
    "propcache": "https://propcache.aio-libs.org/en/latest/",
    "propcache.api": "https://propcache.aio-libs.org/en/latest/api/",
    "propcache.api.cached_property": "https://propcache.aio-libs.org/en/latest/api/#propcache.api.cached_property",
    "propcache.api.under_cached_property": "https://propcache.aio-libs.org/en/latest/api/#propcache.api.under_cached_property",
}
