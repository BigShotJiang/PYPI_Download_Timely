VERSION = "2.1.0"

# fmt: off
MAPPING = {
    "pyhamcrest": "https://pyhamcrest.readthedocs.io/en/latest/",
}
