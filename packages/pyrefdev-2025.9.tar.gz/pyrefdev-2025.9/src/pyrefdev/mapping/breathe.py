VERSION = "4.36.0"

# fmt: off
MAPPING = {
    "breathe": "https://breathe.readthedocs.io/en/latest/",
}
