VERSION = "1.3.2"

# fmt: off
MAPPING = {
    "aiosignal": "https://aiosignal.aio-libs.org/en/stable/",
    "aiosignal.signal": "https://aiosignal.aio-libs.org/en/stable/index.html#aiosignal.Signal",
    "aiosignal.signal.freeze": "https://aiosignal.aio-libs.org/en/stable/index.html#aiosignal.Signal.freeze",
    "aiosignal.signal.frozen": "https://aiosignal.aio-libs.org/en/stable/index.html#aiosignal.Signal.frozen",
    "aiosignal.signal.send": "https://aiosignal.aio-libs.org/en/stable/index.html#aiosignal.Signal.send",
}
