VERSION = "3.0.4"

# fmt: off
MAPPING = {
    "semver": "https://python-semver.readthedocs.io/en/latest/",
}
