VERSION = "0.4.7"

# fmt: off
MAPPING = {
    "methodtools": "https://methodtools.readthedocs.io/en/latest/",
    "methodtools.lru_cache": "https://methodtools.readthedocs.io/en/latest/index.html#methodtools.lru_cache",
}
