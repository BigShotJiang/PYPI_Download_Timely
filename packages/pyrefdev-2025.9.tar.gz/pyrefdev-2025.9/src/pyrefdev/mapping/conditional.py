VERSION = "2.0"

# fmt: off
MAPPING = {
    "conditional": "https://conditional.readthedocs.io/en/latest/",
    "conditional.conditional": "https://conditional.readthedocs.io/en/latest/index.html#conditional.conditional",
}
