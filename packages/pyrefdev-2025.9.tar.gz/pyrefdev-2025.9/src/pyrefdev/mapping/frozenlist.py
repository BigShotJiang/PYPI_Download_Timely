VERSION = "1.7.0"

# fmt: off
MAPPING = {
    "frozenlist": "https://frozenlist.aio-libs.org/en/latest/",
    "frozenlist.frozenlist": "https://frozenlist.aio-libs.org/en/latest/#frozenlist.FrozenList",
    "frozenlist.frozenlist.freeze": "https://frozenlist.aio-libs.org/en/latest/#frozenlist.FrozenList.freeze",
    "frozenlist.frozenlist.frozen": "https://frozenlist.aio-libs.org/en/latest/#frozenlist.FrozenList.frozen",
}
