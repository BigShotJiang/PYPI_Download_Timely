VERSION = "1.0.3"

# fmt: off
MAPPING = {
    "inflate64": "https://inflate64.readthedocs.io/en/latest/",
}
