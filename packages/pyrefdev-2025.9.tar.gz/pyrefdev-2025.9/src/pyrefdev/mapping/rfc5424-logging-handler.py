VERSION = "1.4.3"

# fmt: off
MAPPING = {
    "rfc5424_logging_handler": "https://rfc5424-logging-handler.readthedocs.io/en/latest/",
}
