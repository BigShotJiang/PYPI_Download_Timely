VERSION = "0.15.0"

# fmt: off
MAPPING = {
    "drf_standardized_errors": "https://drf-standardized-errors.readthedocs.io/en/latest/",
    "drf_standardized_errors.openapi_validation_errors": "https://drf-standardized-errors.readthedocs.io/en/latest/openapi.html",
    "drf_standardized_errors.openapi_validation_errors.extend_validation_errors": "https://drf-standardized-errors.readthedocs.io/en/latest/openapi.html#drf_standardized_errors.openapi_validation_errors.extend_validation_errors",
}
