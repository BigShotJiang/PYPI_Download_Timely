VERSION = "1.9.0"

# fmt: off
MAPPING = {
    "numpydoc": "https://numpydoc.readthedocs.io/en/latest/",
}
