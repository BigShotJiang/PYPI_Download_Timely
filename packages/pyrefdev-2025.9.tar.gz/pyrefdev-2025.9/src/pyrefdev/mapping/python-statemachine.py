VERSION = "2.5.0"

# fmt: off
MAPPING = {
    "python_statemachine": "https://python-statemachine.readthedocs.io/en/latest/",
}
