VERSION = "1.1.0"

# fmt: off
MAPPING = {
    "pymatreader": "https://pymatreader.readthedocs.io/en/latest/",
    "pymatreader.read_mat": "https://pymatreader.readthedocs.io/en/latest/index.html#pymatreader.read_mat",
}
