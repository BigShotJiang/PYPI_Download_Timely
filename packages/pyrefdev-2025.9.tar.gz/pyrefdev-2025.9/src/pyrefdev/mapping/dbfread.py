VERSION = "2.0.7"

# fmt: off
MAPPING = {
    "dbfread": "https://dbfread.readthedocs.io/en/latest/",
}
