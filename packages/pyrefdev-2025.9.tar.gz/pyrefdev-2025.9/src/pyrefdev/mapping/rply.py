VERSION = "0.7.8"

# fmt: off
MAPPING = {
    "rply": "https://rply.readthedocs.io/en/latest/",
    "rply.token": "https://rply.readthedocs.io/en/latest/api/token.html",
}
