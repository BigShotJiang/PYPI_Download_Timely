VERSION = "4.1.2"

# fmt: off
MAPPING = {
    "singledispatch": "https://singledispatch.readthedocs.io/en/latest/",
    "singledispatch.singledispatch": "https://singledispatch.readthedocs.io/en/latest/index.html#singledispatch.singledispatch",
    "singledispatch.singledispatchmethod": "https://singledispatch.readthedocs.io/en/latest/index.html#singledispatch.singledispatchmethod",
    "singledispatch.singledispatchmethod.register": "https://singledispatch.readthedocs.io/en/latest/index.html#singledispatch.singledispatchmethod.register",
}
