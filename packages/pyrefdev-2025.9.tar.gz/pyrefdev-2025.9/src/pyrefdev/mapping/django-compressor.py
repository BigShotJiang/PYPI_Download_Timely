VERSION = "4.5.1"

# fmt: off
MAPPING = {
    "compressor": "https://django-compressor.readthedocs.io/en/stable/",
    "compressor.signals": "https://django-compressor.readthedocs.io/en/stable/usage.html",
    "compressor.signals.post_compress": "https://django-compressor.readthedocs.io/en/stable/usage.html#compressor.signals.post_compress",
}
