VERSION = "6.1.0"

# fmt: off
MAPPING = {
    "cornice": "https://cornice.readthedocs.io/en/latest/",
    "cornice.service": "https://cornice.readthedocs.io/en/latest/api.html",
}
