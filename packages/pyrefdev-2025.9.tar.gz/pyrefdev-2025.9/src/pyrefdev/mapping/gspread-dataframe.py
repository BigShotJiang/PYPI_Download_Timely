VERSION = "4.0.0"

# fmt: off
MAPPING = {
    "gspread_dataframe": "https://gspread-dataframe.readthedocs.io/en/latest/",
    "gspread_dataframe.get_as_dataframe": "https://gspread-dataframe.readthedocs.io/en/latest/index.html#gspread_dataframe.get_as_dataframe",
    "gspread_dataframe.set_with_dataframe": "https://gspread-dataframe.readthedocs.io/en/latest/index.html#gspread_dataframe.set_with_dataframe",
}
