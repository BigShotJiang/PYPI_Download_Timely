VERSION = "1.6"

# fmt: off
MAPPING = {
    "lazy": "https://lazy.readthedocs.io/en/latest/",
    "lazy.invalidate": "https://lazy.readthedocs.io/en/latest/index.html#lazy.invalidate",
    "lazy.lazy": "https://lazy.readthedocs.io/en/latest/index.html#lazy.lazy",
}
