VERSION = "1.0.0"

# fmt: off
MAPPING = {
    "alabaster": "https://alabaster.readthedocs.io/en/latest/",
}
