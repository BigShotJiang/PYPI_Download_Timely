"""pyref.dev is a fast, convenient way to access Python reference docs."""

from ._version import version as _version


__version__ = _version
