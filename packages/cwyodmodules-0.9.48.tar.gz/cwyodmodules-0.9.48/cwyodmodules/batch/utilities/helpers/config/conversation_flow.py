from enum import Enum


class ConversationFlow(Enum):
    CUSTOM = "custom"
    BYOD = "byod"
