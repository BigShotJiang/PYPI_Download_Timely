Examples
========

.. toctree::
    :maxdepth: 2

    examples/cmip6
    
