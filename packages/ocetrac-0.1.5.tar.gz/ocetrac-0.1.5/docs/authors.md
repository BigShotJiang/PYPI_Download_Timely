Citing Ocetrac
==================



Project Contributors
--------------------

The following people have made contributions to the project (in alphabetical order by last name) and are considered "Ocetrac Developers". These contributors will be added as authors upon the next major release of ocetrac (i.e. new DOI release).

- [Ryan Abernathey](https://rabernat.github.io/) - Columbia University, USA. (ORCID: [0000-0001-5999-4917](https://orcid.org/0000-0001-5999-4917))
- [Julius Busecke](http://jbusecke.github.io/) -  Columbia University, USA. (ORCID: [0000-0001-8571-865X](https://orcid.org/0000-0001-8571-865X))
- [David John Gagne](https://staff.ucar.edu/users/dgagne) - National Center for Atmospheric Research, USA. (ORCID: [0000-0002-0469-2740](https://orcid.org/0000-0002-0469-2740))
- [Hillary Scannell](https://www.hillaryscannell.com/) - Columbia University, USA. (ORCID: [0000-0002-6604-1695](https://orcid.org/0000-0002-6604-1695))
- [LuAnne Thompson](https://www.ocean.washington.edu/home/LuAnne+Thompson) - University of Washington, USA. (ORCID: [0000-0001-8295-0533](https://orcid.org/0000-0001-8295-0533))
- [Daniel Whitt](https://danielwhitt.github.io/) - National Aeronautics and Space Administration, Ames Research Center, USA. 

