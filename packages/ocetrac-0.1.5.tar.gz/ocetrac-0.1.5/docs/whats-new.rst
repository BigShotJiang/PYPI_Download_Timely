.. currentmodule:: ocetrac

What's New
===========

.. Template (do not remove)
    ------------------------

    Breaking changes
    ~~~~~~~~~~~~~~~~
    Description. (:pull:`ii`, :issue:`ii`). By `Name <https://github.com/github_username>`_.

    New Features
    ~~~~~~~~~~~~

    Documentation
    ~~~~~~~~~~~~~

    Internal Changes
    ~~~~~~~~~~~~~~~~

    Bug fixes
    ~~~~~~~~~