API Reference
=============

The API reference is automatically generated from the function docstrings in the octrac package. Refer to the examples in the sidebar for reference on how to use the functions.

    
Tracking
------------
.. currentmodule:: ocetrac
.. autosummary::
   :toctree: ./_generated/
   
   Tracker.track
