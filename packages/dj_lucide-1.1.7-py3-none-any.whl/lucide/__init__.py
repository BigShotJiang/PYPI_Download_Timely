from __future__ import annotations

import functools
import os
from contextlib import closing
from copy import deepcopy
from xml.etree import ElementTree
from zipfile import ZipFile

from lucide._compat import open_binary
from lucide._compat import str_removeprefix


class IconDoesNotExist(Exception):
    pass


def _get_custom_zip_path():
    try:
        from django.conf import settings
        return getattr(settings, "LUCIDE_ICONS_ZIP_PATH", None)
    except ImportError:
        return None


@functools.lru_cache(maxsize=128)
def _load_icon(name: str) -> ElementTree.Element:
    zip_path = _get_custom_zip_path()
    if zip_path and os.path.exists(zip_path):
        zip_data = open(zip_path, "rb")
    else:
        # Fallback: use the default embedded zip file
        zip_data = open_binary("lucide", "lucide.zip")

    with closing(zip_data), ZipFile(zip_data, "r") as zip_file:
        try:
            svg_bytes = zip_file.read(f"{name}.svg")
        except KeyError:
            raise IconDoesNotExist(f"The icon {name!r} does not exist.")

        svg = ElementTree.fromstring(svg_bytes.decode())
        for node in svg.iter():
            node.tag = ElementTree.QName(
                str_removeprefix(node.tag, "{http://www.w3.org/2000/svg}")
            )
        return svg


_PATH_ATTR_NAMES = frozenset(
    {
        "stroke-linecap",
        "stroke-linejoin",
        "vector-effect",
    }
)


def _render_icon(name: str, size: int | None, **kwargs: object) -> str:
    svg = deepcopy(_load_icon(name))
    if size is not None:
        svg.attrib["width"] = svg.attrib["height"] = str(size)

    svg_attrs = {}
    path_attrs = {}
    for raw_name, value in kwargs.items():
        name = raw_name.replace("_", "-")
        if name in _PATH_ATTR_NAMES:
            path_attrs[name] = str(value)
        else:
            svg_attrs[name] = str(value)

    svg.attrib.update(svg_attrs)
    if path_attrs:
        for path in svg.findall("path"):
            path.attrib.update(path_attrs)

    string = ElementTree.tostring(svg, encoding="unicode")
    # Inline SVG's don't need xmlns
    return string.replace(' xmlns="http://www.w3.org/2000/svg"', "", 1)
