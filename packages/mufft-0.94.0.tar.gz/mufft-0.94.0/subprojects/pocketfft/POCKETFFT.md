PocketFFT
=========

This is a 3rd party source code taken from the "cpp" branch of the PocketFFT
repository (hash 8e4ae199512bba3c9da35e64fe6e961f71568934):

https://gitlab.mpcdf.mpg.de/mtr/pocketfft

It is distributed under a 3-clause BSD license, see LICENSE.md.