"""Tests for {{ project_name }}."""

__version__ = "0.1.0"
