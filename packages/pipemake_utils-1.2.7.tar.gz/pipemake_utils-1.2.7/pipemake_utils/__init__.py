# Basic Information
__name__ = "pipemake_utils"
__version__ = "1.2.7"
__summary__ = "Pipemake Utilities"
__url__ = "https://github.com/kocherlab/pipemake_utils"
__code__ = "https://github.com/kocherlab/pipemake_utils"
__issue__ = "https://github.com/kocherlab/pipemake_utils/issues"
__docs__ = ""
__license__ = "MIT"
__copyright__ = "2023"

# Author Information
__authors__ = "Andrew Webb and Sarah Kocher"
__email__ = "19213578+aewebb80@users.noreply.github.com"
