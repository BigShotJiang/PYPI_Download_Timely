- [ForgeFlow](https://forgeflow.com):

  > - Bernat Puig \<<bernat.puig@forgeflow.com>\>

- [APSL-Nagarro](https://apsl.tech):

  > - Antoni Marroig \<<amarroig@apsl.net>\>
  > - Miquel Alzanillas \<<malzanillas@apsl.net>>\>
- `Heliconia Solutions Pvt. Ltd. <https://www.heliconia.io>`_
