configuration_id = "configuration_id"
configuration_name = "configuration_name"
configuration_content = "configuration_content"
configuration_type = "configuration_type"

dataset_configuration_id = "dataset_configuration_id"
model_configuration_id = "model_configuration_id"
trainer_configuration_id = "trainer_configuration_id"
