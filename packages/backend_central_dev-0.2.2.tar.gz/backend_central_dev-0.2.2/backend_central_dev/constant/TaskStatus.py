
undefined = 'undefined'
initialized = 'initialized'
running = 'running'
stopping = 'stopping'
stopped = 'stopped'
finished = 'finished'
error = 'error'

not_exist_in_executor_process_holder = 'not_exist_in_executor_process_holder'
