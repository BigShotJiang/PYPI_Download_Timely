
def print_to_log(*msg, **kwargs):
    print(*msg, **kwargs, flush=True)
