sphinx-build -M html docs-src/source docs-src/build
cp -r docs-src/build/html/* docs/