"""Base class modules."""

from ._classifier import BaseClassifier

__all__ = ['BaseClassifier']
