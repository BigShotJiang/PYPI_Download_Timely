from setuptools import setup

# This file is required for editable installs (pip install -e .)
# and for backward compatibility with some tools.
setup()
