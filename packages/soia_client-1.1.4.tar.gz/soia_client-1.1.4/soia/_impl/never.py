from typing import NoReturn

Never = NoReturn
