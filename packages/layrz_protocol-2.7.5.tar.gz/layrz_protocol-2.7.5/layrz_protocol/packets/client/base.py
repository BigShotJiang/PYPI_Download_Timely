from layrz_protocol.packets.base import Packet


class ClientPacket(Packet):
  """Client packet definition"""
