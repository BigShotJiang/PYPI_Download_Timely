from polyapi.cli import execute_from_cli


if __name__ == "__main__":
    execute_from_cli()
