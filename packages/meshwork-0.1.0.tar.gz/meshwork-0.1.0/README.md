Ripple Python Library
===

This library is responsible for the propagation of parameters and
results through a higher level system. It provides small primitives
and re-usable components that can be used as the basis for distributed
job execution and streaming.

