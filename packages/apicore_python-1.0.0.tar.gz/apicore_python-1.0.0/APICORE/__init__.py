"""
APICORE - A Python library for parsing API configuration files following the APICORE specification.
"""

from .core import APICORE

__all__ = ['APICORE']
__version__ = '1.0.0'
