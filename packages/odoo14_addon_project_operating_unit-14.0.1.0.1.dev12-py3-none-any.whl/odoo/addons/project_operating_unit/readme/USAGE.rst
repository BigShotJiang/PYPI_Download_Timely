* Go to Project
* You only see the projects and tasks of your operating units
* Create a new project. It is assigned to your default operating unit.
* Create a task within a project. It inherits the operating unit of the project.
