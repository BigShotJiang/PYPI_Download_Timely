This module adds operating unit information to projects and tasks.
