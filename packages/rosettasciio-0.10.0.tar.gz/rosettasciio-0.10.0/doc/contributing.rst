.. This is a stub, see the top level CONTRIBUTING.rst file.

.. include:: ../CONTRIBUTING.rst
