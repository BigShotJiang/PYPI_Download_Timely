.. _de5-format:

Direct Electron EMD (DE5)
-------------------------

This is a compliant version of the :ref:`EMD format <emd-format>` developed by
Direct Electron to serve as an image format of their cameras. All ``.de5`` files
are read as if they are :ref:`NCEM EMD files <emd_ncem-format>`.

.. note::
   To read this format, the optional dependency ``h5py`` is required.
