.. This is a stub, see the top level CHANGES.rst file.


.. include:: ../CHANGES.rst
