---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: 'type: feature request'
assignees: ''

---

#### Describe the functionality you would like to see.
A clear and concise description of what you would like to do.

#### Describe the context
Do you want to extend existing functionalities, what IO plugin does it concern, etc.

#### Additional information
Add any other context or screenshots about the feature request here.
