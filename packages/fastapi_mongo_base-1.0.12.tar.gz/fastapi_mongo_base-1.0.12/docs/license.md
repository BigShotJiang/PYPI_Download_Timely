# License

This project is licensed under the MIT License. See the LICENSE.txt file for details. 