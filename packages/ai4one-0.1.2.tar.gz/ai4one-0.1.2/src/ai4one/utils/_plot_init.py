import matplotlib.pyplot as plt

plt.rcParams['font.family'] = ['SimHei', 'Microsoft YaHei', 'sans-serif']
