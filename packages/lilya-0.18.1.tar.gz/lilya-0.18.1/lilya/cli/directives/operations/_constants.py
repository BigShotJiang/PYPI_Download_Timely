import os

PATH = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
SECRET_KEY_INSECURE_PREFIX = "lilya-insecure-"
LILYA_SETTINGS_MODULE = "LILYA_SETTINGS_MODULE"
