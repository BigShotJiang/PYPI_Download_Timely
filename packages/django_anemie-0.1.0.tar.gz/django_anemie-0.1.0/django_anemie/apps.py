from django.apps import AppConfig

class DjangoAnemieConfig(AppConfig):
    name = "django_anemie"
    verbose_name = "Sensibilisation Anémie"
