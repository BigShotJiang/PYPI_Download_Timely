# Django Anémie

Une application Django pour sensibiliser à l’anémie sévère chez les jeunes.