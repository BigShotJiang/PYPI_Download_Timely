"""Built-in schema definitions for milvus-ingest."""
