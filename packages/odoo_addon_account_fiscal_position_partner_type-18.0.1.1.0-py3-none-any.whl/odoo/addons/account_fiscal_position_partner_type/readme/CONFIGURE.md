User can configure the default value according to the system company
going to:

- Settings/Users & Companies/Companies.
- Changing the value of the "Default Partner Fiscal Position Type"
  field.
