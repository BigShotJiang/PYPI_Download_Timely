This module adds the concept of type applied to fiscal positions and
partners. The idea is to categorize them for not applying fiscal
positions that doesn't belong to the same type.
