- [Sygel](https://www.sygel.es):

  > - Harald Panten
  > - Valentin Vinagre

- [Tecnativa](https://www.tecnativa.com):

  > - Pedro M. Baeza

- Open Source Integrators (<https://opensourceintegrators.com>)
  - Nikul Chaudhary \<<nchaudhary@opensourceintegrators.com>\>
