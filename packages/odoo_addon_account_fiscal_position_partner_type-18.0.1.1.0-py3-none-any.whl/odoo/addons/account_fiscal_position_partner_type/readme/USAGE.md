Create a new partner and define the "Fiscal Position Type" field.

Create a new Fiscal Position, with the following configuration:

- 'Detect Automatically' -\> checked.
- 'Fiscal Position Type'

Create a new Sale/Invoice and select the partner. Remember that the
system recalculates the fiscal position according to the shipping
address.
