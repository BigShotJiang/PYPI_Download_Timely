=====
Usage
=====

To use SAMPIClyser in a project::

	import sampiclyser
