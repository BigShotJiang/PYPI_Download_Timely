"""
TODO:
 - ServiceConfig, specifically?
"""
from omlish import lang
from omlish import typedvalues as tv


##


class Config(tv.TypedValue, lang.Abstract):
    pass
