from .docs import swagger_generate

__all__ = [
    'swagger_generate',
]
