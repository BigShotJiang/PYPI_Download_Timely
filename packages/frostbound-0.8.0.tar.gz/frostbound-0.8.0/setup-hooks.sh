pre-commit install --hook-type commit-msg
