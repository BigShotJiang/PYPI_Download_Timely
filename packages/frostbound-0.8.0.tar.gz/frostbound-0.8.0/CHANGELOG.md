# CHANGELOG

<!-- version list -->

## v0.3.0 (2025-06-20)

### Features

- Rename.
  ([`3c9d22d`](https://github.com/gao-hongnan/frost/commit/3c9d22df5ee3acda2bae7e47153f7081f1f7e60a))


## v1.0.0 (2025-06-20)

- Initial Release

## v0.1.0 (2025-06-20)

- Initial Release

## v0.1.0 (2025-06-20)

- Initial Release

## v0.1.0 (2025-06-20)

- Initial Release

## v0.1.0 (2025-06-20)

- Initial Release
