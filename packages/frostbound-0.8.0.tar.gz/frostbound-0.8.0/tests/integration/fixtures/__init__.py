"""Test fixtures package for integration testing."""
