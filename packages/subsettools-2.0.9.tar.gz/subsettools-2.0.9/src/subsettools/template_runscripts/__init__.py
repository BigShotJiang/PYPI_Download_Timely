"""This subpackage contains the provided template runscripts. 

The runscripts can be accessed with the get_template_runscript() function.
"""
