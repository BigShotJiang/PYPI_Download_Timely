"""This file gets run when we call `python3 -m flynt`."""

import sys

from flynt import main

sys.exit(main())
