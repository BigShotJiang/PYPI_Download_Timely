from fastapi_users.authentication import JWTStrategy


class APIJWTStrategy(JWTStrategy):
    pass
