PERMISSION_TYPES = ["read", "write", "delete", "share"]
