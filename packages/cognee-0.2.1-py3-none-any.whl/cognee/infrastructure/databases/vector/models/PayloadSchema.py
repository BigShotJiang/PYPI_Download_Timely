from typing import TypeVar

PayloadSchema = TypeVar("PayloadSchema")
