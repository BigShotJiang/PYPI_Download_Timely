from cognee.exceptions.exceptions import CriticalError


class ContentPolicyFilterError(CriticalError):
    pass
