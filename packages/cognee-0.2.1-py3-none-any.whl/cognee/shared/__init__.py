# Loading LLM Config from data_models.py requires to have dotenv imported first
# and to have it loaded

import dotenv

dotenv.load_dotenv(override=True)
