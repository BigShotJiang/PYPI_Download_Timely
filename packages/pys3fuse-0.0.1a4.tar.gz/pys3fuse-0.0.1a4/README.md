# pys3fuse
A FUSE Written in Python to Support S3 Protocol on POSIX

## Installation
1. You must have these libraries
`libfuse2t64   libfuse3-3    libfuse3-dev  libfuse-dev`
