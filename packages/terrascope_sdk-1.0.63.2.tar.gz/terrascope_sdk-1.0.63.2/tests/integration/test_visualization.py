import pytest


class TestVisualization:

    @pytest.mark.asyncio
    async def test_get(self):
        implemented = False
        assert implemented
