class UnsupportedMarketError(Exception):
    pass
