class UnsupportedFuseError(Exception):
    pass
