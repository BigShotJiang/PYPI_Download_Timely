class UnsupportedChainId(Exception):
    pass
