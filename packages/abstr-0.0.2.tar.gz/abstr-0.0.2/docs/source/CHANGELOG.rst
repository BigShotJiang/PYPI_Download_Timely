Changelog
=========

[0.0.1] - July, 25 2025
------------------------

- **Initial release:** ``Abstr`` The Abstract Universe Project.

