from authbroker_client.version import __version__


def test_version():
    # Tests the version of the package
    assert __version__ == "5.0.0"
