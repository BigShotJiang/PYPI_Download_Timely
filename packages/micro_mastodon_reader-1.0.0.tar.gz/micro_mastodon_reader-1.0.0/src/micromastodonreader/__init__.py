__version__ = "1.0.0"
from .micro_mastodon_reader import MicroMastodonReader

__all__ = [
    "MicroMastodonReader",
]
