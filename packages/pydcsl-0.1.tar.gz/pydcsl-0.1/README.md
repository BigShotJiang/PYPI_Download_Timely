# PyDCSL
A compact Python tool to check if a Widevine device certificate (DCSL) is revoked or valid.
