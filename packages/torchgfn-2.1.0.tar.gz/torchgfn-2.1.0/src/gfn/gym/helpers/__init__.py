"""This module contains helper functions for the gym environments."""
