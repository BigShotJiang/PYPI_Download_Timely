This is a glue module between sale_order_import_ubl and
sale_order_customer_free_ref. It extracts the CurstomerReference, from
the XML received.
