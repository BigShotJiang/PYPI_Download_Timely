# MustafaInstagram

A library to generate Instagram usernames.

