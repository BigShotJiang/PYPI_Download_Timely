"""Cleaning tests package."""
