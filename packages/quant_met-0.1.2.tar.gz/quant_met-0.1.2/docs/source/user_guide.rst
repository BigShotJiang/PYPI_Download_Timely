

User Guide
==========

.. toctree::
   :caption: CLI

   user_guide/first-scf
   user_guide/search_T_C

.. toctree::
   :caption: Other examples

   examples/test_sisl
