﻿quant\_met.parameters.KPoints
=============================

.. currentmodule:: quant_met.parameters

.. autoclass:: KPoints
