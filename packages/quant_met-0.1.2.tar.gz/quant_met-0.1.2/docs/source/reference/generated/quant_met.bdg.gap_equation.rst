﻿

.. raw:: html

   <div class="prename">quant_met.bdg.</div>
   <div class="empty"></div>

gap_equation
==========================

.. currentmodule:: quant_met.bdg

.. autofunction:: gap_equation
