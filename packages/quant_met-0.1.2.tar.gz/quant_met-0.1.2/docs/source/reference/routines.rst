

.. _routines:

.. automodule:: quant_met.routines
