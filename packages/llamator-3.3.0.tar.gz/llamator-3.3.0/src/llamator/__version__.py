"""Version information."""

# fmt: off
__version__ = '3.3.0'  # noqa
# fmt: on
