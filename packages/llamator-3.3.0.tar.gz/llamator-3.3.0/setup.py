#!/usr/bin/env python3
"""Packaging code - boilerplate required by pip <= 21.1 for development install (-e)."""
from setuptools import setup

setup()
