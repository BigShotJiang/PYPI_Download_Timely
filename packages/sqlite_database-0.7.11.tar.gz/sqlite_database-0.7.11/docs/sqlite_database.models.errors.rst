sqlite\_database.models.errors module
=====================================

.. automodule:: sqlite_database.models.errors
   :members:
   :show-inheritance:
   :undoc-members:
