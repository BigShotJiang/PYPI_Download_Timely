sqlite\_database.errors module
==============================

.. automodule:: sqlite_database.errors
   :members:
   :show-inheritance:
   :undoc-members:
