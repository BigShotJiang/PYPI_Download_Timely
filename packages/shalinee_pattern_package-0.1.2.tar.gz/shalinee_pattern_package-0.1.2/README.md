# Pattern

This is a simple package to print the patterns

# shalinee_pattern_package

A custom Python package for pattern generation, created by Shalinee.

# Installation

Install it using pip

pip install shalinee_pattern_package

from shalinee_pattern_package import (pyramid,right_angle,left_angle)

# pyramid
pyramid(5)

# output

    *
   * *
  * * *
 * * * *
* * * * *

# right_angle
right_angle(5)

*
**
***
****
*****

# left_angle
left_angle(5)
    *
   **
  ***
 ****
*****