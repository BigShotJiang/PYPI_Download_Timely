class CorruptHashError(Exception):
    pass
