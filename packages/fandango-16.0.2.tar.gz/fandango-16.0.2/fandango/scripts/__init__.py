""" 
Just exporting scripts submodule to sphinx 

Type "fandango --help" to see command line usage

"""

__all__ = []
