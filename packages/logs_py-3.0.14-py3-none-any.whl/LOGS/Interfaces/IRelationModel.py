from dataclasses import dataclass


@dataclass
class IRelationModel:
    pass
