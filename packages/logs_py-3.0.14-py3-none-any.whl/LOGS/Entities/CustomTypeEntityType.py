from enum import Enum


class CustomTypeEntityType(Enum):
    Sample = "Sample"
    Dataset = "Dataset"
    Inventory = "Inventory"
    Project = "Project"
    Person = "Person"
    Method = "Method"
    Facility = "Facility"
