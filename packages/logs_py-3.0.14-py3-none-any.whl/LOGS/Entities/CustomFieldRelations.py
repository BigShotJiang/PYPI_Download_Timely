from typing import TYPE_CHECKING

from LOGS.Entity.EntityRelations import EntityRelations

if TYPE_CHECKING:
    pass


class CustomFieldRelations(EntityRelations):
    """Relations of a CustomType with other entities"""
