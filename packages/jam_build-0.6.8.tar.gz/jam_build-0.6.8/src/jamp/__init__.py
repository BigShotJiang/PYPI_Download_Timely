# make this callable as script
from jamp.build import main_cli
