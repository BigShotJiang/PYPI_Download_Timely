#include "test.h"

void func2() {
    PRINT_2();
}
