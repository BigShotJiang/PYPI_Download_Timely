with open(r'requirements.txt' , 'r') as fp:
        data = fp.read().splitlines()

print(data)