from django.apps import AppConfig

class PycalculatriceConfig(AppConfig):
    name = 'pycalculatrice'
