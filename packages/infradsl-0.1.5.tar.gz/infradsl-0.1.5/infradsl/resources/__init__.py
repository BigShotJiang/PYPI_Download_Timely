"""
InfraDSL Resources
"""

from .compute import VirtualMachine, InstanceSize, ImageType

__all__ = ["VirtualMachine", "InstanceSize", "ImageType"]
