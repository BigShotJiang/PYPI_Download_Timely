"""
AWS Storage resources for InfraDSL
"""

from .s3 import AWSS3

__all__ = [
    "AWSS3",
]