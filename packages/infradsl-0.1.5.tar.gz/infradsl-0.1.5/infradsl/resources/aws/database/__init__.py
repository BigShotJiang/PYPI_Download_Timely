"""
AWS Database resources for InfraDSL
"""

from .rds import AWSRDS

__all__ = [
    "AWSRDS",
]