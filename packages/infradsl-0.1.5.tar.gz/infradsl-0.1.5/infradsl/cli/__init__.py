"""
InfraDSL CLI - Command Line Interface
"""

from .main import main

__all__ = ["main"]
