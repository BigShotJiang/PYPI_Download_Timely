"""
CLI utilities
"""