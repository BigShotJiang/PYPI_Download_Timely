"""
CLI entry point for InfraDSL when called as a module
"""

from .main import main

if __name__ == "__main__":
    exit(main())