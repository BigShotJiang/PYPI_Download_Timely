from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from dhicn_document_service.api.document_api import DocumentApi
from dhicn_document_service.api.health_api import HealthApi
