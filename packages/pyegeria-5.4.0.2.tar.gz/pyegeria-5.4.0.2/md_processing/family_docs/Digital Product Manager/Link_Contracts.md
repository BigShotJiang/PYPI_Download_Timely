# **Link Contracts**
>	Attach or detach an agreement to an element describing the location of the contract documents.

## **Contract Id**
>	**Input Required**: False

>	**Description**: Contract identifier.


## **Contract Liaison**
>	**Input Required**: False

>	**Description**: Name of the liaison for the contract.


## **Contract Liaison Type**
>	**Input Required**: False

>	**Description**: type of liaison.


## **Contract Liaison Property Name**
>	**Input Required**: False

>	**Description**: 

