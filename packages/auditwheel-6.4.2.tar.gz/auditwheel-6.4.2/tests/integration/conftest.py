from __future__ import annotations

collect_ignore = ["quick_check_numpy.py"]
