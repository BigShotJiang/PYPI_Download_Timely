from __future__ import annotations

from ._nonpy_rpath import crypt_something

__all__ = ["crypt_something"]
