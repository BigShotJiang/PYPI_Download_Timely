#pragma once
#include <string>

std::string crypt_something(void);
