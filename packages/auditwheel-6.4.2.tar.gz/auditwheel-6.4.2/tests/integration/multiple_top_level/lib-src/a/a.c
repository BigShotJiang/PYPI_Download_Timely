#include "b.h"


int fa(void) {
    return 1 + fb();
}
