int fa(void);
