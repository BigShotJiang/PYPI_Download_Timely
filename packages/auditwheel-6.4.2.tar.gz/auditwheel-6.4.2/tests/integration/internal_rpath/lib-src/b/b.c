int fb(void) {
    return 10;
}
