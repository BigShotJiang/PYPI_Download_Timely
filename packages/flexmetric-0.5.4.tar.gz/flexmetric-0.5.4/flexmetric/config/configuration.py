CA_PATH = "/app/secrets/ca.pem"
CERT_PATH = "/app/secrets/cert"
KEY_PATH = "/app/secrets/key"
GATEWAY_URL="https://0.0.0.0:8000"
