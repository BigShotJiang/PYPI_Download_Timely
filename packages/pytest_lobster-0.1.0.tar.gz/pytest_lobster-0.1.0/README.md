# pytest-lobster

This is a [pytest](http://pytest.org) plugin that writes test information into a
[lobster](https://github.com/bmw-software-engineering/lobster) json file.
