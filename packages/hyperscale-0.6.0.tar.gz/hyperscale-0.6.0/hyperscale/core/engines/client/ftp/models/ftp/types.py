from typing import Literal

ConnectionType = Literal['control', 'data']