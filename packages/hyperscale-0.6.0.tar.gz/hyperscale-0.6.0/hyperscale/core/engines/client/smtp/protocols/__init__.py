from .connection import SMTPConnection as SMTPConnection
