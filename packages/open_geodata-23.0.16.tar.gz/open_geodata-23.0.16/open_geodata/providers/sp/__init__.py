from .cetesb import div_admin
from .tjsp import div_admin
