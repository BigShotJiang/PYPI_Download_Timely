"""
_summary_
"""

import os


dddd = 'https://arquivos.receitafederal.gov.br/dados/cnpj/dados_abertos_cnpj/2025-06/'


if __name__ == "__main__":
    from open_geodata.providers.br.receita_federal.rfb import RFB
