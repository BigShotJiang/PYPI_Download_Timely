A note for users of Microsoft Windows
-------------------------------------

To read the text files in this directory (README.rst, LICENSE.rst,
etc.), right-click, choose "Open", and open with "WordPad".
("Notepad" will not display the files properly.)
