
#include "token_stream.hpp"

std::string ANTLRToken::encoding = "latin-1";
