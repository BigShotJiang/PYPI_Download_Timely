from pya2l import DB


db = DB()
db.export_a2l("ASAP2_Demo_V161", "asap_export.a2l")
