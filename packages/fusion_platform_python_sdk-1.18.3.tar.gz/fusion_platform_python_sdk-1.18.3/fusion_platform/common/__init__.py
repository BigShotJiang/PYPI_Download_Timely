"""
This sub-module contains common code for the SDK.

&copy; [Digital Content Analysis Technology Ltd](https://www.d-cat.co.uk)
"""
