"""Python client for pccs quantum api"""

from pcss_qapi.auth import AuthorizationService

__all__ = ["AuthorizationService"]
