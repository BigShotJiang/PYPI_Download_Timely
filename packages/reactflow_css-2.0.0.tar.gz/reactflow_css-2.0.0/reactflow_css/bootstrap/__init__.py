"""
Bootstrap styling module for ReactPy.
"""

from .Configuration import configure as configure_boots, default_css as default_boots

__all__ = ['configure_boots', 'default_boots']