"""Chemistry Creative Server - Fast exploration with Chemeleon and MACE"""

__version__ = "0.1.0"