"""AI Assistant CLI - A command line tool powered by Gemini AI"""

__version__ = "1.0.1"
__author__ = "carellihoula"