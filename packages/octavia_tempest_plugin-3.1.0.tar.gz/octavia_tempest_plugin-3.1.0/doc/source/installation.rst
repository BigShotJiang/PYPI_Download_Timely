============
Installation
============

At the command line::

    $ pip install octavia-tempest-plugin

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv octavia-tempest-plugin
    $ pip install octavia-tempest-plugin
