from ..basic_types.base import *  # basic_types 中定义的抽象基类完全满足去实现复合类型



