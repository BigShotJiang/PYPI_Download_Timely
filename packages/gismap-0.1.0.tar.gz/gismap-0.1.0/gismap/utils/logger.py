import logging

logger = logging.getLogger("GisMap")
"""Default logging interface."""
