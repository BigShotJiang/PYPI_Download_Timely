# History

## Roadmap

- Offline DBLP
- Customized collaboration graphs
  - Colors and size
  - Groups

## 0.1.0 (2025-07-24): First release

- First release on PyPI.
- Online DBLP and HAL DB implemented
- Lab stuctures implemented
- Early version of collaboration graph available
