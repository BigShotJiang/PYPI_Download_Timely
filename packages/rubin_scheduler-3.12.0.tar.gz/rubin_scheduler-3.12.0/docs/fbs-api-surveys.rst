.. py:currentmodule:: rubin_scheduler.scheduler

.. _fbs-api-surveys:

Surveys
^^^^^^^

.. automodule:: rubin_scheduler.scheduler.surveys
    :imported-members:
    :members:
    :show-inheritance:
