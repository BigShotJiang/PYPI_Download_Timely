.. py:currentmodule:: rubin_scheduler.scheduler

.. _fbs-api-sim-runner:

Sim Runner
^^^^^^^^^^

.. automodule:: rubin_scheduler.scheduler.sim_runner
    :members:
    :show-inheritance:
