
from . import anova1,anova1rm
from . import anova2,anova2nested,anova2rm,anova2onerm
from . import anova3,anova3nested,anova3rm,anova3tworm,anova3onerm
from . import regress
from . import t1,t2,t2nonspher,tpaired
from . import ci1, cipaired, ci2
from . import normality

