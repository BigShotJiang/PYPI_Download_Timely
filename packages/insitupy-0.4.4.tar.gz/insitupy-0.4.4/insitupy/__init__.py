"""Top-level package for insitupy."""

__author__ = """M3 Works LLC"""
__email__ = 'info@m3works.io'
__version__ = '0.4.4'
