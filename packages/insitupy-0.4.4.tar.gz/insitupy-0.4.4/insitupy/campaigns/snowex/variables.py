from pathlib import Path

HERE = Path(__file__).parent.resolve()


snowex_variables_yaml = HERE / "snowexprimaryvariables.yaml"
snowex_metadata_yaml = HERE / "snowexmetadatavariables.yaml"
