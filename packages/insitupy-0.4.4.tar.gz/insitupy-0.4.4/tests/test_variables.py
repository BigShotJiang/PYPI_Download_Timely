import pytest

# from insitupy.campaigns.variables import ProfileVariables


class TestVariables:
    # TODO: these test
    @pytest.mark.skip("Not done yet")
    def test_variable_attributes(self):
        pass

    def test_variable_list(self):
        pass
