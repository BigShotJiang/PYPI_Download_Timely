"""
VoxTerm - Run as module

This allows running VoxTerm with: python -m voxterm
"""

from .launcher import main

if __name__ == "__main__":
    main()