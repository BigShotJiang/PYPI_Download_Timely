from .comic import ComicInfo
from .page import PageInfo
