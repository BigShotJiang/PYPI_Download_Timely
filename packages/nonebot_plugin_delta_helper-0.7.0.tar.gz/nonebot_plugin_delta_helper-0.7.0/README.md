<div align="center">
  <a href="https://v2.nonebot.dev/store"><img src="https://github.com/A-kirami/nonebot-plugin-template/blob/resources/nbp_logo.png" width="180" height="180" alt="NoneBotPluginLogo"></a>
  <br>
  <p><img src="https://github.com/A-kirami/nonebot-plugin-template/blob/resources/NoneBotPlugin.svg" width="240" alt="NoneBotPluginText"></p>
</div>

<div align="center">

# nonebot-plugin-delta-helper

_✨ 三角洲助手插件 ✨_


<a href="./LICENSE">
    <img src="https://img.shields.io/github/license/BraveCowardp/nonebot-plugin-delta-helper.svg" alt="license">
</a>
<a href="https://pypi.python.org/pypi/nonebot-plugin-delta-helper">
    <img src="https://img.shields.io/pypi/v/nonebot-plugin-delta-helper.svg" alt="pypi">
</a>
<img src="https://img.shields.io/badge/python-3.10+-blue.svg" alt="python">

</div>

## 📖 介绍

三角洲助手插件，目前主要是验证打通了登录流程，有登录和自动播报战绩功能，后续功能待开发

欢迎提建议和issue

## 💿 安装

<details open>
<summary>使用 nb-cli 安装(目前还未发布到插件市场)</summary>
在 nonebot2 项目的根目录下打开命令行, 输入以下指令即可安装

    nb plugin install nonebot-plugin-delta-helper

</details>

<details>
<summary>使用包管理器安装</summary>
在 nonebot2 项目的插件目录下, 打开命令行, 根据你使用的包管理器, 输入相应的安装命令

<details>
<summary>pip</summary>

    pip install nonebot-plugin-delta-helper
</details>
<details>
<summary>pdm</summary>

    pdm add nonebot-plugin-delta-helper
</details>
<details>
<summary>poetry</summary>

    poetry add nonebot-plugin-delta-helper
</details>
<details>
<summary>conda</summary>

    conda install nonebot-plugin-delta-helper
</details>

打开 nonebot2 项目根目录下的 `pyproject.toml` 文件, 在 `[tool.nonebot]` 部分追加写入

    plugins = ["nonebot_plugin_delta_helper"]

</details>

## 🎉 使用
### 更新数据模型 <font color=#fc8403 >使用必看！！！！！</font>
本插件使用了官方推荐的`nonebot-plugin-orm`插件操作数据库，安装插件或更新插件版本后，在启动机器人前，都需要执行此命令。
```shell
nb orm upgrade
```
手动执行下列命令检查数据库模式是否与模型定义一致。机器人启动前也会自动运行此命令，并在检查失败时阻止启动。
```shell
nb orm check
```
看到`没有检测到新的升级操作`字样时，表明数据库模型已经成功创建或更新，可以启动机器人
### 指令表
| 指令 | 参数 | 权限 | 需要@ | 范围 | 说明 |
|:----|:----|:----|:----|:----|:----|
| 三角洲帮助 | 无 | 群员 | 否 | 群聊/私聊 | 查看帮助 |
| 三角洲登录 | 无 | 群员 | 否 | 建议群聊 | 通过扫码登录三角洲账号，如果是在群聊，登录后会自动播报百万撤离或百万战损战绩 |
| 三角洲信息 | 无 | 群员 | 否 | 群聊/私聊 | 查看三角洲基本信息 |
| 三角洲密码 | 无 | 群员 | 否 | 群聊/私聊 | 查看今日密码门密码 |
| 三角洲特勤处 | 无 | 群员 | 否 | 群聊/私聊 | 查看三角洲特勤处制造状态 |
| 三角洲特勤处提醒开启 | 无 | 群员 | 否 | 群聊/私聊 | 开启特勤处提醒功能，制造完成后提醒玩家 |
| 三角洲特勤处提醒关闭 | 无 | 群员 | 否 | 群聊/私聊 | 关闭特勤处提醒功能 |

## TODO
- [ ] 开发其他功能，想要做成信息卡片的形式（个人信息、战绩之类），但是不了解图片排版和渲染，欢迎提建议和issue、PR