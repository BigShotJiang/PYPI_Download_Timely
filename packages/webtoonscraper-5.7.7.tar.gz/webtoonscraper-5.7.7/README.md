# WebtoonScraper

[![Sponsoring](https://img.shields.io/badge/Sponsoring-Patreon-blue?logo=patreon&logoColor=white)](https://www.patreon.com/ilotoki0804)
![Hits](https://hitscounter.dev/api/hit?url=https%3A%2F%2Fgithub.com%2Filotoki0804%2FWebtoonScraper&label=Hits&icon=github&color=%234dc81f)
[![Download Status](https://img.shields.io/pypi/dm/WebtoonScraper)](https://pypi.org/project/WebtoonScraper/)
[![License](https://img.shields.io/pypi/l/WebtoonScraper.svg)](https://github.com/ilotoki0804/WebtoonScraper/blob/main/LICENSE)
[![Supported Python Versions](https://img.shields.io/pypi/pyversions/WebtoonScraper.svg)](https://pypi.org/project/WebtoonScraper/)
[![Latest Version](https://img.shields.io/pypi/v/WebtoonScraper)](https://pypi.org/project/WebtoonScraper/)
[![uv](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json)](https://github.com/ilotoki0804/WebtoonScraper/blob/main/pyproject.toml)

쉽고 빠르게 많은 웹사이트에서 웹툰을 다운로드받는 프로그램입니다.

자세한 설명은 [문서](https://webtoonscraper.readthedocs.io/)를 참고해 주세요.

This program provides a quick and easy way to download webtoons from many websites.

For detailed information, see the [documentation](https://webtoonscraper.readthedocs.io/).
