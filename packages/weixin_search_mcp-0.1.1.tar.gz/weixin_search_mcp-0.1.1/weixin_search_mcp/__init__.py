"""
XHS MCP Server - 小红书自动化工具
"""

__version__ = "0.1.0" 