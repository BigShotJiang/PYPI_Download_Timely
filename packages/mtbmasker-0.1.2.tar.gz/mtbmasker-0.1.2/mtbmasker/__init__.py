"""
mtbmasker - Genome masking tool for Mycobacterium tuberculosis.
"""
__version__ = "0.1.2"
