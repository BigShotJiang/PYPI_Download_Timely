"""Data models for Energy Assistant."""
