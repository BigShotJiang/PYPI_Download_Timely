"""API for configurations."""
