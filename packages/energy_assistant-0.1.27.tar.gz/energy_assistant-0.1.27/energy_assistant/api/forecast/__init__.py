"""API for forecasts."""
