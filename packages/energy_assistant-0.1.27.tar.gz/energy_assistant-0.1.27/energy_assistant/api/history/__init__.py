"""API for history data."""
