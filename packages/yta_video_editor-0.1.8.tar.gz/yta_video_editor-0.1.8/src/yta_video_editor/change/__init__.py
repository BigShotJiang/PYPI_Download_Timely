"""
Module to include all the specific
modifications we can do in a video about
its core moviepy attributes.
"""