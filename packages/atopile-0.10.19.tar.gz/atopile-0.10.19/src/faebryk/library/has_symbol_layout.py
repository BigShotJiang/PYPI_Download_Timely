# This file is part of the faebryk project
# SPDX-License-Identifier: MIT

import faebryk.library._F as F


class has_symbol_layout(F.Symbol.TraitT):
    translations: str
