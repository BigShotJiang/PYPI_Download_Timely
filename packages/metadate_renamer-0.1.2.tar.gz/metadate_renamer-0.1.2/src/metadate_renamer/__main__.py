from metadate_renamer import main

main()
