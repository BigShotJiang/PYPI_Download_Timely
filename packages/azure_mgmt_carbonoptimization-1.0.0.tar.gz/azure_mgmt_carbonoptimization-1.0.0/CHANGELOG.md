# Release History

## 1.0.0 (2025-07-21)

### Other Changes

  - First GA

## 1.0.0b1 (2025-05-08)

### Other Changes

  - Initial version
