class ConFigue:
    """Base Configuration Object"""
