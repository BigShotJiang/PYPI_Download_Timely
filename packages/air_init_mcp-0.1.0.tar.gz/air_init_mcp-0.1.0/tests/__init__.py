"""Unit test package for air_init_mcp."""
