# Air Init MCP

![PyPI version](https://img.shields.io/pypi/v/air-init-mcp.svg)
[![Documentation Status](https://readthedocs.org/projects/air-init-mcp/badge/?version=latest)](https://air-init-mcp.readthedocs.io/en/latest/?version=latest)

The Air Init MCP server provides initialization and scaffolding tools for LLMs building websites with the Air web framework.

* PyPI package: https://pypi.org/project/air-init-mcp/
* Free software: MIT License
* Documentation: https://air-init-mcp.readthedocs.io.

## Features

* TODO

## Credits

This package was created with [Cookiecutter](https://github.com/audreyfeldroy/cookiecutter) and the [audreyfeldroy/cookiecutter-pypackage](https://github.com/audreyfeldroy/cookiecutter-pypackage) project template.
