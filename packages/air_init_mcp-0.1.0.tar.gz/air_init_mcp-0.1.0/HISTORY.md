# History

## 0.1.0 (2025-07-28)

* First release on PyPI.
