"""Top-level package for Air Init MCP."""

__author__ = """Audrey M. Roy Greenfeld"""
__email__ = "audrey@feldroy.com"
