# Usage

To start the Air Init MCP server:

```sh
fastmcp run src/air_init_mcp/air_init_mcp.py:mcp
```
