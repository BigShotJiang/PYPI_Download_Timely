def vilo(a, b):
    """
    Adds two numbers and returns the result.

    Args:
        a (int or float): First number.
        b (int or float): Second number.

    Returns:
        int or float: The sum of a and b.
    """