_instruments = ("langchain_core >= 0.1.0", "futureagi >= 0.0.1")
_supports_metrics = False
