from .contact.content import IContact, Contact  # NOQA
from .entity.content import IEntity, Entity  # NOQA
