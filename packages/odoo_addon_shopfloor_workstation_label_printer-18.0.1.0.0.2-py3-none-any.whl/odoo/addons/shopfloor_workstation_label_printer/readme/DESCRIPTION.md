With this module a default label printer can be linked to a shopfloor
workstation profile and to an Odoo user profile.

When the user select a workstation profile on the mobile application is
default label printer will change on Odoo side.
