__version__ = "0.2.0"
__author__ = "Samet Çopur"
__email__ = "sametcopur@yahoo.com"
__license__ = "MIT"


from .algorithm import Explainer, Result

__all__ = ["Explainer", "Result"]

