import amethyst_facet
if __name__ == "__main__":
    amethyst_facet.cli.commands.facet.facet()