import click

@click.command
def version():
    """Print version and exit
    """
    print("Facet v. 1.1.0 (July 20, 2025)")