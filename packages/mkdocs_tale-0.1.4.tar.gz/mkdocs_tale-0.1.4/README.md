# mkdocs-tale

Tale is a theme of mkdocs, it's modified from [Tale](https://github.com/chesterhow/tale)
