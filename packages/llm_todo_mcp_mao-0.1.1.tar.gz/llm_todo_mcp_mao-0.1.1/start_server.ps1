# 启动FastMCP服务器的PowerShell脚本
Write-Host "🚀 启动FastMCP服务器..." -ForegroundColor Green
uv run todo-mcp-server serve-fastmcp --port 8000