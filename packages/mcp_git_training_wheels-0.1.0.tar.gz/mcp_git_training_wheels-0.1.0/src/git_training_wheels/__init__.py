"""MCP Git Training Wheels - Git tools with retry logic for MCP."""

__version__ = "0.1.0"
