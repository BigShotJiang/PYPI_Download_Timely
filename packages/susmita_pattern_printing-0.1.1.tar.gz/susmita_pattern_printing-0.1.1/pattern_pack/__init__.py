from .pattern1 import (pyramid,right_angle,left_angle)
__all__=["pyramid","right_angle","left_angle"]