# pattern_pack
This a simple package to print a patterns

## Installation

Install it using pip:

pip install Susmita_Pattern_printing

from pattern_pack import (pyramid,right_angle,left_angle)


# pyramid
pyramid(5)

# output
    * 
   * * 
  * * * 
 * * * * 
* * * * * 

# right_angle

right_angle(4)

# output

*
**
***
****

# left_angle

left_angle(4)

# output

  *
 **
***