# Contributions to `teslajsonpy`

## Owners

-   Sergey Isachenko [GitHub](https://github.com/zabuldon)

## Maintainers

-   Alan Tse [GitLab](https://gitlab.com/alandtse) [GitHub](https://github.com/alandtse)

## Contributors

-   ultratoto14 [GitHub](https://github.com/ultratoto14)
-   johanjongsma [GitHub](https://github.com/johanjongsma)
-   hobbe [GitHub](https://github.com/hobbe)
-   megabytemb [GitHub](https://github.com/megabytemb)
-   giachello [Github](https://github.com/giachello)
-   danielp370 [Github](https://github.com/danielp370)
-   carleeno [Github](https://github.com/carleeno)
-   shred [Github](https://github.com/shred86)
-   InTheDaylight14 [Github](https://github.com/InTheDaylight14)
-   Bre77 [Github](https://github.com/Bre77)
-   craigrouse [Github](https://github.com/craigrouse)
-   thierryVT [Github](https://github.com/thierryvt)
-   llamafilm [Github](https://github.com/llamafilm)
-   ericdegroot [Github](https://github.com/ericdegroot)
-   flaviorighi [Github](https://github.com/flaviorighi)
-   djbadders [Github](https://github.com/djbadders)
