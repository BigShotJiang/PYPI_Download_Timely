# laddu-amplitudes

`laddu-amplitudes` is an **internal sub-crate** of the [laddu](https://crates.io/crates/laddu) library, supplying private utility functions.

**Important Note**: This crate is **not intended for external usage**. Please refer to the main [laddu crate](https://crates.io/crates/laddu) for intended usage.

