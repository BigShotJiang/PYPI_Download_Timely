from abc import ABC, abstractmethod


class ActionHandler(ABC):
	def __init__(self):
		"""Creates an instance of ActionHandler"""
		pass

