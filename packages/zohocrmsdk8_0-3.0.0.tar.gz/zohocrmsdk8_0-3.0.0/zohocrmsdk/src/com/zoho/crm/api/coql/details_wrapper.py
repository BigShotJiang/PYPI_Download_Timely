from abc import ABC, abstractmethod


class DetailsWrapper(ABC):
	def __init__(self):
		"""Creates an instance of DetailsWrapper"""
		pass

