from abc import ABC, abstractmethod


class ResponseHandler(ABC):
	def __init__(self):
		"""Creates an instance of ResponseHandler"""
		pass

