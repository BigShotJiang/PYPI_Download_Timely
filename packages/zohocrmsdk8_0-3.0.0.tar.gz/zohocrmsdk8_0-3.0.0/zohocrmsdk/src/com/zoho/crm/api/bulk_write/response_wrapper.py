from abc import ABC, abstractmethod


class ResponseWrapper(ABC):
	def __init__(self):
		"""Creates an instance of ResponseWrapper"""
		pass

