def hello():
    print("GPU!!!")