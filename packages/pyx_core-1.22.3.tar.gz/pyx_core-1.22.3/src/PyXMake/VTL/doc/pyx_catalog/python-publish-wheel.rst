----------------------------------------
Create and publish generic python wheels
----------------------------------------

.. literalinclude:: ../../../templates/python-publish-wheel/template.yml
   :language: yaml