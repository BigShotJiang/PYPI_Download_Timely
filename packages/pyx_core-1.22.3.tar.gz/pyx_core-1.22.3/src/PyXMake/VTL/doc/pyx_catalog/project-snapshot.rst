-----------------------------------------
Create a docker data image of the project
-----------------------------------------

.. literalinclude:: ../../../templates/project-snapshot/template.yml
   :language: yaml