var namespace_py_x_make_1_1_a_p_i =
[
    [ "Backend", "class_py_x_make_1_1_a_p_i_1_1_backend.html", "class_py_x_make_1_1_a_p_i_1_1_backend" ],
    [ "Base", "class_py_x_make_1_1_a_p_i_1_1_base.html", "class_py_x_make_1_1_a_p_i_1_1_base" ],
    [ "Frontend", "class_py_x_make_1_1_a_p_i_1_1_frontend.html", "class_py_x_make_1_1_a_p_i_1_1_frontend" ]
];