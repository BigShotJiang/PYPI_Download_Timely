var class_py_x_make_1_1_tools_1_1_utility_1_1_abstract_method =
[
    [ "__init__", "class_py_x_make_1_1_tools_1_1_utility_1_1_abstract_method.html#ab7d6bf4befcd9e17a85ad61a5a496984", null ],
    [ "__get__", "class_py_x_make_1_1_tools_1_1_utility_1_1_abstract_method.html#a942a3528d351c8206387f855ab1db863", null ]
];