﻿import json
def render_json(tree_obj):
    return json.dumps(tree_obj, indent=2)
