=====
Usage
=====

The best way to get started with geogals is to try out the `Tutorials <https://github.com/astrobenji/GeoGals/tree/main/docs/tutorials>`_.
