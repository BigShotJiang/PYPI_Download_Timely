#!/usr/bin/env python

"""Tests for `geogals` package."""


import unittest

from geogals import geogals


class TestGeogals(unittest.TestCase):
    """Tests for `geogals` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
