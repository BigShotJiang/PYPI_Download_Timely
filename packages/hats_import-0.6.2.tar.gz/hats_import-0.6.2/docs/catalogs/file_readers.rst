File Readers
======================================

TODO - placeholder for longer discussion of ``file_readers``.

Issue https://github.com/astronomy-commons/hats-import/issues/527