from sqlmesh.integrations.github.cicd.config import GithubCICDBotConfig

CICDBotConfig = GithubCICDBotConfig
