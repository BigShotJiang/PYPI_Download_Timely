# -*- coding: utf-8 -*-

from tccli.services.omics.omics_client import action_caller
    