"""HTML report generation for llm-contracts."""

from .html_generator import generate_html_report

__all__ = ["generate_html_report"] 