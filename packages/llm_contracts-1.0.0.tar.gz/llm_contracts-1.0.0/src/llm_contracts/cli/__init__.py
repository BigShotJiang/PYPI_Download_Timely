"""Command-line interface for llm-contracts."""

from .main import main

__all__ = ["main"] 