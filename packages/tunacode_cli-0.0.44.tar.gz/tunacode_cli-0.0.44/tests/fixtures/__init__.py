"""Test fixtures for TunaCode tests."""
