from django.apps import AppConfig


class NativeShortuuidConfig(AppConfig):
    name = 'native_shortuuid'
