"""
evrima.py - The Isle: Evrima RCON made easy for Python
"""

__version__ = "0.2.1"

from .rcon import Client
