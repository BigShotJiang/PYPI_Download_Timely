

class Helping:
    def __init__(self) -> None:
        pass
    def lamports_to_sol(self, lamports: int) -> float:
        return lamports / 1_000_000_000