# SPDX-FileCopyrightText: 2025-present phdenzel <phdenzel@gmail.com>
# SPDX-FileNotice: Part of pyverto. Distributed as-is with no warranty.
# SPDX-License-Identifier: MIT
"""Dynamic versioning."""
__version__ = "0.1.8"
