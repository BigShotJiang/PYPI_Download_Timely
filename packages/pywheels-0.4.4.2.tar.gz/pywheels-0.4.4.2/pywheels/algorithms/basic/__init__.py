from .monotonic_stack import next_greater_element
from .monotonic_stack import next_smaller_element


__all__ = [
    "next_greater_element",
    "next_smaller_element",
]