# notify-service

![PyPI version](https://img.shields.io/pypi/v/nic_notify.svg)
[![Documentation Status](https://readthedocs.org/projects/nic_notify/badge/?version=latest)](https://notify-service.readthedocs.io/en/latest/?version=latest)

Python Boilerplate contains all the boilerplate you need to create a Python package.

* Free software: MIT License
* Documentation: https://nic_notify.readthedocs.io.

## Features

* TODO

## Credits

This package was created with [Cookiecutter](https://github.com/audreyfeldroy/cookiecutter) and the [audreyfeldroy/cookiecutter-pypackage](https://github.com/audreyfeldroy/cookiecutter-pypackage) project template.
