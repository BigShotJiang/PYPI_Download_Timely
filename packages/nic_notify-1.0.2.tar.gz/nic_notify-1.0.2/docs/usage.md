# Usage

To use notify-service in a project:

```python
import nic_notify
```
