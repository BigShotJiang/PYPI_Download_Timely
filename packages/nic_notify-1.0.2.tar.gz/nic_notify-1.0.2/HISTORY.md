# History

## 1 (2025-07-25)

* First release on PyPI.
