from django.apps import AppConfig

class NotifyServiceConfig(AppConfig):
    name = 'nic_notify'

    
