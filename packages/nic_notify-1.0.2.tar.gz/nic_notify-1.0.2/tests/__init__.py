"""Unit test package for notify_service."""
