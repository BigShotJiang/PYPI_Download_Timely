
from enum import StrEnum

class QualityScore(StrEnum):
    BAD = "bad"
    GOOD = "good"
    NEUTRAL = "neutral"
