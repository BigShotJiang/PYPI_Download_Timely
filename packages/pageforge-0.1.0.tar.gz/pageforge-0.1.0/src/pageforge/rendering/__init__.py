"""
PageForge Rendering Module
Contains components for styling and font handling in document rendering.
"""
