"""
PageForge Core Module
Contains essential components for document generation including models and exceptions.
"""
