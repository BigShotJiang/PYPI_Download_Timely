from setuptools import setup, find_packages

# Let setuptools handle everything based on pyproject.toml configuration
setup(
    include_package_data=True,
    packages=["keprompt"],
)