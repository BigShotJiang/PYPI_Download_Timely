# NiWrap wrappers for [MRTrix3Tissue](https://3tissue.github.io/)

MRtrix3Tissue is a fork of the MRtrix3 project. It aims to add capabilities for 3-Tissue CSD modelling and analysis to a complete version of the MRtrix3 software.

MRTrix3Tissue is made by MRTrix3Tissue Developers.

This package contains wrappers only and has no affiliation with the original authors.
