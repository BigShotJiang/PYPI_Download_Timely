
from .model.higgs_audio import HiggsAudioConfig, HiggsAudioModel

__version__ = '0.0.2'