from .const import (
    DEFAULT_NOTIFICATION_TEXT,
)


__all__ = [
    # const
    'DEFAULT_NOTIFICATION_TEXT',
]
