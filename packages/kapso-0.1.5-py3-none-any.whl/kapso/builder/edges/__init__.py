"""
Kapso SDK edges module.
"""

from kapso.builder.edges.edge import Edge, create_edge

__all__ = ["Edge", "create_edge"]
