"""
Constants used in the Kapso SDK agent module.
"""

START_NODE = "__start__"
END_NODE = "__end__"
