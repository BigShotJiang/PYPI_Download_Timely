"""
Utils package for shared utility functions.
"""
