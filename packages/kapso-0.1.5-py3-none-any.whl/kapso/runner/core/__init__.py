"""
Core module for the application.
"""

# Import utility functions for easier access
from kapso.runner.core.flow_utils import get_next_pending_tool_call
