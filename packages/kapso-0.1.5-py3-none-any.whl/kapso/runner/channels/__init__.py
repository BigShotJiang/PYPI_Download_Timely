# Register default adapters here

