StarRail_version = "3.4.0"
