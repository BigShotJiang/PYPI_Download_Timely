import swe
import sys

sys.exit(swe.main())
