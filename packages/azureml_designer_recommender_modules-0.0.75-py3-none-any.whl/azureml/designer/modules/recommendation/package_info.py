VERSION = '0.0.75'
PACKAGE_NAME = 'azureml-designer-recommender-modules'
DESCRIPTION = 'Modules to train and inference recommendation models based on deep neural network.'
