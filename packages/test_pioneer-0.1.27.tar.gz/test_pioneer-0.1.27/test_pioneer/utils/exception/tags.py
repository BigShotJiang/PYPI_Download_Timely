wrong_yaml_tag = "Invalid YAML tag format"
wrong_input = "Invalid input"
cant_save_yaml_error = "Unable to save YAML file"
can_not_run_gui_error = "You need to install test-pioneer with the GUI dependency"