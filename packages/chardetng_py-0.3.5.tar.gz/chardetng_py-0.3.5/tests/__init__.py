"""Test suite for the chardetng_py package."""
