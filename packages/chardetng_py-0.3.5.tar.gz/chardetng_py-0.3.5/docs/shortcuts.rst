Shortcuts
=========

.. automodule:: chardetng_py.shortcuts
   :members:
