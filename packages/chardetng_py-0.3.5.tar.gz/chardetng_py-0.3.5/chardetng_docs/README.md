For convience, the chardetng docs and/or comments are copied to this
folder so that they can be included in the documentation for this project.

chardetng is copyright Mozilla Foundation.
