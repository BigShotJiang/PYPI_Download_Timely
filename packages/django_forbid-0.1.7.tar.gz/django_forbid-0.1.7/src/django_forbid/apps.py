from django.apps import AppConfig


class ForbidConfig(AppConfig):
    name = "django_forbid"
