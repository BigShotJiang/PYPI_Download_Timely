"""European Central Bank Foreign Exchange Rates."""

from .core import CurrencyRates

__all__ = ["CurrencyRates"] 