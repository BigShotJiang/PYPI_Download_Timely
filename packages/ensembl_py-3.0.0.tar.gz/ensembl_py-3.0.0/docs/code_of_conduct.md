---
hide:
  - toc
---

# Code of Conduct

The Ensembl project is built on a foundation of collaboration, mutual respect and equality with a diverse and global community. We do not condone discrimination or abusive behaviour of any form. We encourage participation and engagement for everyone, in a professional manner, and wish all members of our community to adhere to the same principles.
