"""
=========
Utilities
=========

This package contains a collection of helper modules and files. It serves as a
central repository for common operations, filepaths, and configuration data.

"""
