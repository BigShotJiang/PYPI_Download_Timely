.. _glossary:

========
Glossary
========

.. todo::

   Add some terms to glossary
