.. _cli:

===============================
EasyLink Command-Line Interface
===============================

.. toctree::
   :maxdepth: 2

.. click:: easylink.cli:easylink
   :prog: easylink
   :nested: full
   :commands: run, generate-dag

``easylink.cli`` module
=======================

.. automodule:: easylink.cli

