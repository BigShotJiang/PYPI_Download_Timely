===============
Snakemake Rules
===============

.. automodule:: easylink.rule
