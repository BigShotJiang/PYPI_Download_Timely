API Reference
=============

.. automodule:: easylink

.. toctree::
    :maxdepth: 2
    :glob:

    cli
    *
    */index
