============
Contributing
============

To run or develop easylink tests or documentation, you can install easylink with the ``[dev]`` extra::

    $ git clone git@github.com:ihmeuw/easylink.git # or git clone https://github.com/ihmeuw/easylink.git
    $ cd easylink
    $ pip install -e .[dev]

.. todo::
    Show how to run the tests and build the documentation