from django.apps import AppConfig


class DBMIClientConfig(AppConfig):
    name = "dbmi_client"
    verbose_name = "DBMI Client"
