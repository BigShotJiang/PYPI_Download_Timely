from dbmi_client.settings import dbmi_settings

# Get the app logger
import logging

logger = logging.getLogger(dbmi_settings.LOGGER_NAME)

# Create your views here.
