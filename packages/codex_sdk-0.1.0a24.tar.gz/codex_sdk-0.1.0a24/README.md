# Codex SDK

<!-- prettier-ignore -->
[![PyPI version](https://img.shields.io/pypi/v/codex-sdk.svg?label=pypi%20(stable))](https://pypi.org/project/codex-sdk/)

This library is not meant to be used directly. Refer to https://pypi.org/project/cleanlab-codex/ instead.
