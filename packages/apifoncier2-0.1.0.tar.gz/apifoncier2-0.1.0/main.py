def main():
    print("Hello from apifoncier!")


if __name__ == "__main__":
    main()
