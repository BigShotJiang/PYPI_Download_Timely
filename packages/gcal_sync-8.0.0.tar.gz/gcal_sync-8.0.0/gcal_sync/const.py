"""Constants for gcal_sync."""

# Local storage constants
CALENDAR_LIST_SYNC = "calendar_list_sync"
EVENT_SYNC = "event_sync"
ITEMS = "items"
SYNC_TOKEN = "sync_token"
SYNC_TOKEN_VERSION = "sync_token_version"
