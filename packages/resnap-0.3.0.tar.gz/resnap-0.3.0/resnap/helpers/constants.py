EXT = ".resnap"
SEPARATOR = "/"
