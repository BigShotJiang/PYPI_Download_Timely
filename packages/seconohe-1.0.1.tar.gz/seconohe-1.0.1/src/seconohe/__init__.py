"""
.. include:: ../../README.md
"""
import os


__version__ = "1.0.1"
JS_PATH = os.path.join(os.path.dirname(__file__), "js")
