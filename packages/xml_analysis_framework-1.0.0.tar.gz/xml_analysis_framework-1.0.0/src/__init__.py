"""
XML Analysis Framework

A comprehensive framework for analyzing XML documents with specialized handlers
for different document types and AI/ML processing preparation.
"""

__version__ = "1.0.0"
__author__ = "AI Building Blocks"