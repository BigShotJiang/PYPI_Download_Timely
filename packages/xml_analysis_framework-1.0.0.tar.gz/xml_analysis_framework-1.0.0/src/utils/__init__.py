"""
XML Analysis Utilities

Utility functions and classes for XML processing and analysis.
"""