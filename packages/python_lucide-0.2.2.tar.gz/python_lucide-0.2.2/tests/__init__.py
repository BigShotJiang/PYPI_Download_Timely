"""Tests for the python-lucide package."""
