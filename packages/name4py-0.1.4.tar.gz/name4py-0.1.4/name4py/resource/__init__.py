import os

__PATH__ = os.path.dirname(os.path.abspath(__file__))
