class ActivityStreamDecodeError(Exception):
    pass


class ActivityStreamTypeError(Exception):
    pass


class ActivityStreamValidationError(Exception):
    pass
