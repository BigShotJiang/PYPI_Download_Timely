import prismarine_client as pc


class ItemModel(pc.ItemModel):
    pass
