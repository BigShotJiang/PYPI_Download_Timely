import pygame
from importlib import resources

from platformer_world.settings import *


def import_image(*path, alpha=True, format="png"):
    """Load a single image using importlib.resources."""
    package = "platformer_world"
    if path:
        package += "." + ".".join(path[:-1])
    filename = f"{path[-1]}.{format}"

    with resources.open_binary(package, filename) as f:
        img = pygame.image.load(f)
        return img.convert_alpha() if alpha else img.convert()


def import_folder(*path):
    """Load all images from a folder into a list."""
    package = "platformer_world." + ".".join(path)
    frames = []

    folder = resources.files(package)
    for file in sorted(
    [f for f in folder.iterdir() if f.suffix in {".png", ".jpg"}],
    key=lambda f: int(''.join(filter(str.isdigit, f.stem)))
    ):
        with file.open("rb") as f:
            img = pygame.image.load(f).convert_alpha()
            frames.append(img)
    return frames


def import_folder_dict(*path):
    """Load all images from a folder into a dict {name: Surface}."""
    package = "platformer_world." + ".".join(path)
    frame_dict = {}

    folder = resources.files(package)
    for file in folder.iterdir():
        if file.suffix in {".png", ".jpg"}:
            with file.open("rb") as f:
                surface = pygame.image.load(f).convert_alpha()
                frame_dict[file.stem] = surface
    return frame_dict


def import_sub_folders(*path):
    """Load all subfolders as keys into a dict {subfolder: [frames]}."""
    base_package = "platformer_world." + ".".join(path)
    frame_dict = {}

    base = resources.files(base_package)
    for subfolder in base.iterdir():
        if subfolder.is_dir():
            sub_package = base_package + f".{subfolder.name}"
            frame_dict[subfolder.name] = import_folder(*path, subfolder.name)
    return frame_dict

