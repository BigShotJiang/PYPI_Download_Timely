from .base import BaseFrameworkSetup
from php_framework_detector.core.models import FrameworkType
from typing import List


class SymfonySetup(BaseFrameworkSetup):
    def __init__(self):
        super().__init__(FrameworkType.SYMFONY)

    def get_setup_commands(self) -> List[str]:
        return [
            "docker compose down -v",
            "docker compose build",
            "docker compose up -d",
            "docker compose exec -w /app app php bin/console cache:clear --no-interaction --no-ansi",
            "docker compose exec -w /app app php bin/console doctrine:database:create --if-not-exists --no-interaction --no-ansi",
            "docker compose exec -w /app app php bin/console doctrine:schema:update --force --no-interaction --no-ansi"
        ]

    def get_routes_command(self) -> str:
        return "docker compose exec -w /app app php -d error_reporting=~E_DEPRECATED bin/console debug:router --format=json --no-interaction --no-ansi"
