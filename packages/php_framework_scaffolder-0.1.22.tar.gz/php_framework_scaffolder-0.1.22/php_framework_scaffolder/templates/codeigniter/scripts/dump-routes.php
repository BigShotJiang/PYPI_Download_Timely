<?php
define("BASEPATH", true);
include '/app/application/config/routes.php';
echo json_encode($route);