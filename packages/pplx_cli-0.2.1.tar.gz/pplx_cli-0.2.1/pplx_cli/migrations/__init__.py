"""
Database migration utilities for pplx-cli RAG system.
"""