# v0.0.5

- Docs, docs, docs
- Rewind & Skip added
- Random wave added
- set_default_wave added
- Bugfixes in richcompare
- Various refactors

# v0.0.4

- BREAKING CHANGE: sine and cosine are reset to the origin
- BREAKING CHANGE: square wave now starts at 0 and switches up to 1
- one and zero waves added
- Limited cycles
- Bugfixes

# v0.0.3

- when misunderstanding return data leads to a memory leak

# v0.0.2

lfo - A low frequency oscillator for python, to control all kinds of things
(mostly in game projects)


