def add(*args):
    """Sum objects and add 1"""
    return sum(args) + 1


def append(*args):
    """Return positional arguments as a tuple"""
    return args
