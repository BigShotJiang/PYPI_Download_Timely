def addfunc(arg):
    """Add 1 to the first argument"""
    return arg + 1
