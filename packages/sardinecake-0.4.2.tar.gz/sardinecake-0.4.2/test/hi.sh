#!/bin/sh

echo hi
