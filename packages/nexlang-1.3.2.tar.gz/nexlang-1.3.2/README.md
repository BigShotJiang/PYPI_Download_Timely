**This library was developed by a professional Python programmer.**

`A private library for encryption and encryption implementation with a private interpreter.`

# Super Library | Created By Devil ~~ Telegram —> @NeXlAnGpY #

__You Can Use Library Using__

```import nex

nex.encode(input('YourFileName:  '))
```

**The encryption will be saved in the nex.py file.**

# Execute Encrypt #

```import nex

nex._exec('Obfuscation')
```

**Now You Can Execute Code For Safe**