# Formating's Constant Codes For Controlling Many Formats In Terminal
RESET = "[0m"

SET_BOLD = "[1m"
RESET_BOLD = "[22m"

SET_DIM = "[2m"
RESET_DIM = "[22m"

SET_ITALIC = "[3m"
RESET_ITALIC = "[23m"

SET_UNDER_LINE = "[4m"
RESET_UNDER_LINE = "[24m"

SET_BLINK = "[5m"
RESET_BLINK = "[25m"

SET_REVERSE = "[7m"
RESET_REVERSE = "[27m"

SET_HIDE = "[8m"
RESET_HIDE = "[28m"

SET_STRIKE_LINE = "[9m"
RESET_STRIKE_LINE = "[29m"
