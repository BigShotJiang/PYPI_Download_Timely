This module allows to restrict surveys per company.
