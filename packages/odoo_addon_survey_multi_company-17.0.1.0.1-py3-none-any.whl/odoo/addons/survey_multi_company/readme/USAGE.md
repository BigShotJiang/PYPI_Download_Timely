To restrict a survey to a certain company:

1.  Go to to *Surveys* and select the survey you want to edit.
2.  Set the desired company.

Only the users in that company will be able to access the survey.
