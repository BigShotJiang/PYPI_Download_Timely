"""
Shared domain components.

This package contains shared entities, constants, and utilities
used across different parts of the domain layer.
"""
