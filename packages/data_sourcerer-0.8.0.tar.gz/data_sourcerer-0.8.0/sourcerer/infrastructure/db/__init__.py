"""
Database infrastructure module.

This package provides database-related components, including models,
configuration, and utilities for database access and management.
"""
