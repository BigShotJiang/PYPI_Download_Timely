from checkov.cloudformation.checks.resource.aws import *  # noqa
