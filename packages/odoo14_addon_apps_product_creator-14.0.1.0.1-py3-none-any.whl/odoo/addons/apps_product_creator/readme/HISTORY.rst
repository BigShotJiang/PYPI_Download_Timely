14.0.1.0.0 (2021-08-02)
~~~~~~~~~~~~~~~~~~~~~~~

* Migration to 14.0

13.0.1.0.0 (2020-07-10)
~~~~~~~~~~~~~~~~~~~~~~~

* Migration to 13.0

12.0.1.0.0 (2019-04-10)
~~~~~~~~~~~~~~~~~~~~~~~

* Migration to 12.0

11.0.1.1.2 (2018-10-02)
~~~~~~~~~~~~~~~~~~~~~~~

* Publish the modules automatically on the website

11.0.1.1.0 (2018-10-02)
~~~~~~~~~~~~~~~~~~~~~~~

* [ADD] Added dependency on github_connector_oca to display development_status
  (`#19 <https://github.com/OCA/apps-store/pull/19>`_)
