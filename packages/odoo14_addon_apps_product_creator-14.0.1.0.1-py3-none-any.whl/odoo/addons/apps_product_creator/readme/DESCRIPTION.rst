This module extends the functionality of the module Github connector to create a product for every module found.
A variant is also created for every version of the module.
