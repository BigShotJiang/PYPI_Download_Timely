* Alex Comba <alex.comba@agilebg.com>
* Antonio Esposito <a.esposito@onestein.nl>
* Eric Caudal <eric.caudal@elico-corp.com>
* François Honoré <francois.honore@acsone.eu>
* Nicola Malcontenti <nicola.malcontenti@agilebg.com>
* Roel Adriaans <roel@road-support.nl>
* Ruchir Shukla <ruchir@bizzappdev.com>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Victor M.M. Torres
  * Carlos Roca
  * Alexandre D. Díaz
  * Ernesto Tejeda
