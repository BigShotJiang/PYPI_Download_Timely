"""
System Prompt Learning (SPL) plugin module initialization.
"""
