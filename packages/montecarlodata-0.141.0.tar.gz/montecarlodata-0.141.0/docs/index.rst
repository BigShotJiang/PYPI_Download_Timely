.. click:: montecarlodata.cli:entry_point
   :prog: montecarlo
   :nested: full
