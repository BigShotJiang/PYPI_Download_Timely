#!/bin/bash
cd tests && python run_all_tests.py && cd .. 
