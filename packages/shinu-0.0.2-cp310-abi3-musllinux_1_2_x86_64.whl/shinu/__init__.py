from .shinu import *

__doc__ = shinu.__doc__
if hasattr(shinu, "__all__"):
    __all__ = shinu.__all__