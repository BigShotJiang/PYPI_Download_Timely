from discodos import log
log=log.logger_init()
