from . import test_sale_customer_rank
