import os

DATA_DIR: str = os.path.dirname(os.path.abspath(__file__)).replace('\\','/') + '/'
