""" Base interface to simplify interaction with LegacyRest/Redfish data and Remote/Local
connections."""
