from hidp.accounts.models import BaseUser


class CustomUser(BaseUser):
    pass
