class NoOtpDeviceError(Exception):
    pass


class MultipleOtpDevicesError(Exception):
    pass
