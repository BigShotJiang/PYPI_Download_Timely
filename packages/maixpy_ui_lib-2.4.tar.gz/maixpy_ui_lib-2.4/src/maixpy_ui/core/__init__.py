from .ui_manager import Page, UIManager
from .resolution_adapter import ResolutionAdapter