# myoverlay_oce4nm4n/main.py

from .side_panel_app import SidePanelApp

def main():
    SidePanelApp().run()
