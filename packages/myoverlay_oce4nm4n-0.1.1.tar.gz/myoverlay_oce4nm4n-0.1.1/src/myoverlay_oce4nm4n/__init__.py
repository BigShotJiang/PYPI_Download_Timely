from .side_panel_app import SidePanelApp

__version__ = "0.1.0"
__all__ = ["SidePanelApp"]
