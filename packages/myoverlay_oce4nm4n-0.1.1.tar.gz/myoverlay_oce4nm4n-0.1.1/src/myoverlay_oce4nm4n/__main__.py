# myoverlay_oce4nm4n/__main__.py

from .side_panel_app import SidePanelApp

def main():
    SidePanelApp().run()

if __name__ == "__main__":
    main()
