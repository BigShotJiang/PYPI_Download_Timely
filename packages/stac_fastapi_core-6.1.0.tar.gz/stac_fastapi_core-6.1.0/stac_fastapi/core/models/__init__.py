"""stac_fastapi.elasticsearch.models module."""
