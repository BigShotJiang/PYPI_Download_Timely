# Safe dummy package: numpy-base
