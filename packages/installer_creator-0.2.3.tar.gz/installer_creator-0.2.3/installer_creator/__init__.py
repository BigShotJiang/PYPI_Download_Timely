"""
Python installer creator package for compiling Python projects with Nuitka
and creating installers using Wix Toolset.
"""

__version__ = "0.2.3"
