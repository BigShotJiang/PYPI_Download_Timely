"""Высокоуровневый API для доступа к Битрикс24"""

from fast_bitrix24.bitrix import Bitrix, BitrixAsync
