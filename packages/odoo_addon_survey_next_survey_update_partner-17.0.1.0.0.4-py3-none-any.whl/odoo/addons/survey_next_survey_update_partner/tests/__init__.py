from . import test_next_survey_update_partner
