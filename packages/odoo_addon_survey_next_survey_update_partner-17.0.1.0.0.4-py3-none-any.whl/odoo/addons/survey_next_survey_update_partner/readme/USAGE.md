Just configure the base modules. When the values in the second survey change, the generated
contact will be updated.

We can also add new info to the survey, so the partner gets updated with it as well.
