This module acts as a bridge of `survey_contact_generation` and `survey_answer_generation` so
when we link contact generation questions, the values that change in the next survey update
those of the created partner.
