When we have contact generation linked answers it's expected that we update the values
from the first survey.
