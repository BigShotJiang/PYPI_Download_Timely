#
# This file was auto-generated from the API references found at
# https://apireference.connect.worldline-solutions.com
#
