select
    substring(a from 'abc') as b
from my_table
