create database my_database
