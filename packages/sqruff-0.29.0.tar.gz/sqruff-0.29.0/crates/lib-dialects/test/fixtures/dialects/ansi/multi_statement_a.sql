select a from tbl1  /*comment here*/ ;  /*and here*/  select b from tbl2;   -- trailling ending comment
