select a
/*
)
*/
from b
