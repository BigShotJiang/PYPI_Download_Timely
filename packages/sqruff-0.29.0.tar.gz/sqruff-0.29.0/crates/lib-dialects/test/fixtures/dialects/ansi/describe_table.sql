describe table "my_table";
