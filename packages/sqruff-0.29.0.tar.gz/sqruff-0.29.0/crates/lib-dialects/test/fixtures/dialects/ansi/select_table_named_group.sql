select 1 from group;
select 1 from groups;
