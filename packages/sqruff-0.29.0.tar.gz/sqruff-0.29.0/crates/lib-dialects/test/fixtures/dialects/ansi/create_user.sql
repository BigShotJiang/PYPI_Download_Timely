CREATE USER foo_user
