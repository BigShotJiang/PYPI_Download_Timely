DROP TYPE typename;

DROP TYPE IF EXISTS typename;

DROP TYPE typename CASCADE;

DROP TYPE typename RESTRICT;
