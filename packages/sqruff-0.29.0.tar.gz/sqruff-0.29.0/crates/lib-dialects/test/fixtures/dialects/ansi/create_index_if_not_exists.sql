CREATE INDEX IF NOT EXISTS transaction_updated ON transaction_master (last_updated);
