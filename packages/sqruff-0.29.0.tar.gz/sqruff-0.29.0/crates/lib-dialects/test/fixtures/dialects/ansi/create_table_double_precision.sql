CREATE TABLE test ( angle double precision );
