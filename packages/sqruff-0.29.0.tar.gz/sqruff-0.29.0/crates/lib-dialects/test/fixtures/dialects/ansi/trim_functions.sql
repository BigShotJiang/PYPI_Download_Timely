SELECT trim('    SparkSQL   ');

SELECT trim(BOTH FROM '    SparkSQL   ');

SELECT trim(LEADING FROM '    SparkSQL   ');

SELECT trim(TRAILING FROM '    SparkSQL   ');

SELECT trim('SL' FROM 'SSparkSQLS');

SELECT trim(BOTH 'SL' FROM 'SSparkSQLS');

SELECT trim(LEADING 'SL' FROM 'SSparkSQLS');

SELECT trim(TRAILING 'SL' FROM 'SSparkSQLS');
