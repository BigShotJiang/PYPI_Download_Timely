-- It's possible to have multiple semicolons between statements.
SELECT foo FROM bar;;
SELECT foo FROM bar;
;
;
SELECT foo FROM bar;
