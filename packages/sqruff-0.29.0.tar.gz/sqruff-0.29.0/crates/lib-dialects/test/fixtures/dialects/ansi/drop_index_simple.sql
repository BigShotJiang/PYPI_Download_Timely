DROP INDEX transaction_updated;
