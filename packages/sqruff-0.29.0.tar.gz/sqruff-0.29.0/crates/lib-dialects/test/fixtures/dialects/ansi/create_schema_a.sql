create schema my_schema
