(SELECT 1);

((SELECT 1));

(((SELECT 1)));
