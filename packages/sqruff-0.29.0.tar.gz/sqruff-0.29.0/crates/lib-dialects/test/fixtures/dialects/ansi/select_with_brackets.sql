select * from (my_table);

select * from (my_table tt);

select * from ((my_table tt));

select * from (((my_table tt)));
