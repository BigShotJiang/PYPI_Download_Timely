ALTER TABLE old_table_name RENAME TO new_table_name;
