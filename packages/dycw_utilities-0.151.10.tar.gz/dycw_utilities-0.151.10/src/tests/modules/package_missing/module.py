from __future__ import annotations

from missing_package import missing_obj  # pyright: ignore[reportMissingImports]

_ = missing_obj
