"""
Common network port numbers for use in diagnostics and scanning utilities.
"""
COMMON_PORTS = [21, 22, 23, 25, 53, 80, 110, 143, 443, 3306, 8080, 8443, 9000, 27017]
