gRPC Python Status Proto
===========================

Reference package for GRPC Python status proto mapping.


Dependencies
------------

Depends on the `grpcio` package, available from PyPI via `pip install grpcio`.
