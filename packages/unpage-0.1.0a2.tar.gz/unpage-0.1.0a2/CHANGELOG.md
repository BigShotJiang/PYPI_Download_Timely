# CHANGELOG

<!-- version list -->

## v0.1.0-alpha.2 (2025-07-25)

### Features

- Start on an Unpage mascot ([#8](https://github.com/aptible/unpage/pull/8),
  [`7f41a4d`](https://github.com/aptible/unpage/commit/7f41a4d3c42fde8f9bc3c04a6103e20c927855c3))


## v0.1.0-alpha.1 (2025-07-25)

### Features

- Add support for disabling telemetry ([#7](https://github.com/aptible/unpage/pull/7),
  [`037798c`](https://github.com/aptible/unpage/commit/037798cbaec8ded81b316762421f00ba3c2b1bae))


## v0.0.1-alpha.1 (2025-07-25)

- Initial Release
