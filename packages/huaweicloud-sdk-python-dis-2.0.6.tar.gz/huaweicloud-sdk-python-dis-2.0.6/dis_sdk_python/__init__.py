#!/usr/bin/python
# -*- coding:utf-8 -*-
from __future__ import absolute_import
from dis_sdk_python.com.huaweicloud.dis.sdk.python.client.disclient import disclient
from dis_sdk_python.com.huaweicloud.dis.sdk.python.models.base_model import IS_PYTHON2
from dis_sdk_python.com.huaweicloud.dis.sdk.python.models import DumpTask
import json
__all__ = ['disclient','IS_PYTHON2','json', 'DumpTask']