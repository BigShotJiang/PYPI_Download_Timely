"""
NOIV Utils Package
"""

from .http_client import quick_test

__all__ = ["quick_test"]
