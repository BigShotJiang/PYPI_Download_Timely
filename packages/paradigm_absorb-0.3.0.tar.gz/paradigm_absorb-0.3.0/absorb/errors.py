class NameParseError(Exception):
    """Raised when string parsing fails"""


class ConfirmError(Exception):
    """Raised when confirmation fails"""
