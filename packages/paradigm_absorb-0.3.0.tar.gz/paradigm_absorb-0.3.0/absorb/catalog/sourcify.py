# follow https://docs.sourcify.dev/docs/repository/file-repositories/#download
# 1. get manifest from https://repo-backup.sourcify.dev/
# 2. download all files in manifest
# data is non-tabular, need an alternative to Table
