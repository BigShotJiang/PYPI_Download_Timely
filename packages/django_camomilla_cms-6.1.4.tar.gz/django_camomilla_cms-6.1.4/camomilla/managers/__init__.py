from .pages import PageQuerySet

__all__ = ["PageQuerySet"]
