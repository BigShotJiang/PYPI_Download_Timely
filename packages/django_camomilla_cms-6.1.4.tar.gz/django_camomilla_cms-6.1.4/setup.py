from setuptools import setup

__version__ = "6.1.4"

setup(version=__version__)
