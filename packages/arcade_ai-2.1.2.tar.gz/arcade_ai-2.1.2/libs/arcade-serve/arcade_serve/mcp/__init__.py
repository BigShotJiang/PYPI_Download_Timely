"""
MCP (Model Context Protocol) support for Arcade workers.
"""

from arcade_serve.mcp.stdio import StdioServer

__all__ = ["StdioServer"]
