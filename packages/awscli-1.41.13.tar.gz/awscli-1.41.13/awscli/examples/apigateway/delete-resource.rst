**To delete a resource in an API**

Command::

  aws apigateway delete-resource --rest-api-id 1234123412 --resource-id a1b2c3
