# schwifty registry update

Install requirements 

  $ pip install -r requirements.txt

and then execute the respective update scripts from the root dir, e.g.

  $ python scripts/get_bank_registry_de.py
