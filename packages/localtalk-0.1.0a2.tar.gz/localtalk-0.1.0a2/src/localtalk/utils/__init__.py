"""Utility functions for the Local Talk App."""
