def testbybnr():
    print("Greeting from Stream33 app")
    return {"status_code":200,
            "message": "Hello from testbybnr"}