"""Texventure - A text-based adventure game generator and engine."""

__version__ = "0.1.0"
