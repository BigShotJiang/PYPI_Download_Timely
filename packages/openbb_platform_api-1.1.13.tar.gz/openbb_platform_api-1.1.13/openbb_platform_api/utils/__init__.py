"""OpenBB Platform API Utils."""
