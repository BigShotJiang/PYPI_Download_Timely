import sys

APP_NAME = sys.argv[0]

INDENT = "  "     # Initial indentation for all lines (2 spaces)
OPTION_WIDTH = 30  # Width for the option name only
OPTION_PADDING = 2  # Padding between option and description
TOTAL_WIDTH = 120  # Total desired width for the help text
