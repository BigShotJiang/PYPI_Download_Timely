from setuptools import setup, find_packages

setup(
    name="triple-equals",
    version="10.0.2",
    author="seeker0x",
    author_email="seeker0x@wearehackerone.com",
    description="Malicious package for dependency confusion attack",
    packages=find_packages(),
    install_requires=['requests'],
)
