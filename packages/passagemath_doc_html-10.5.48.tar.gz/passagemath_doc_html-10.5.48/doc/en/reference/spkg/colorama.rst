.. _spkg_colorama:

colorama: Cross-platform colored terminal text
========================================================

Description
-----------

Cross-platform colored terminal text

License
-------

Upstream Contact
----------------

https://pypi.org/project/colorama/


Type
----

standard


Dependencies
------------

- $(PYTHON)
- $(PYTHON_TOOLCHAIN)

Version Information
-------------------

package-version.txt::

    0.4.6

version_requirements.txt::

    colorama


Equivalent System Packages
--------------------------

(none known)

