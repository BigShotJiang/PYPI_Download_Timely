# PaperBase

**PaperBase** is a lightweight, file-based, plug-and-play database engine designed for quick data storage using native Python and optional C++ authentication handling.

It is perfect for small projects, prototyping, or when you need a no-server, local-first database structure.

---

## 🔧 Features

- File-system-based hierarchical database
- Insert, retrieve, edit, and delete key-value data
- User authentication using hashed passwords (with C++ auth handler)
- Easy project switching with `connect()`
- Modular access via `auth`, `config`, and `pdb`

---

## 🚀 Installation

```
pip install paperbase
```

## 🧠 Usage
```
from paperbase import config
from paperbase import auth
from paperbase import pdb

# === CONFIG MODULE ===

# Create a new project (prints its UID)
config.createNewProject("TestProject")

# Optional: List all available projects
config.listProjects()

# Optional: Delete a project by name
# config.deleteProject("TestProject")

# Connect to a project by UID (from printed createNewProject())
config.connect("YOUR_KEY")


# === AUTH MODULE ===

# Create a new user
auth.createUser("Aritra@gmail.com", "password123")

# Sign in an existing user
auth.signInUser("Aritra@gmail.com", "password123")

# Delete a user
# auth.deleteUser("Aritra@gmail.com")


# === PDB MODULE (DATABASE) ===

# Create a new PaperBase called "Users"
pdb.newPaperBase("Users")

# Create subbases (e.g., per user/email)
pdb.newPaperSubBase("Users", "Aritra@gmail.com")
pdb.newPaperSubBase("Users", "Paper@gmail.com")

# Insert data into subbases
pdb.insertData("Users", subpath="Aritra@gmail.com", key="Name", value="Aritra")
pdb.insertData("Users", subpath="Paper@gmail.com", key="Name", value="Paper")
pdb.insertData("Users", subpath="Aritra@gmail.com", key="Role", value="Admin")

# Retrieve specific data
data = pdb.retrieveData("Users", "Name", subpath="Aritra@gmail.com")
print("Retrieved Name for Aritra:", data)

# Edit existing data
pdb.editData("Users", subpath="Aritra@gmail.com", key="Role", new_value="SuperAdmin")

# Retrieve again to verify edit
updated_role = pdb.retrieveData("Users", "Role", subpath="Aritra@gmail.com")
print("Updated Role for Aritra:", updated_role)

# Retrieve all subbases under "Users"
subbases = pdb.retrieveSubBases("Users")
print("All subbases under 'Users':", subbases)

# Retrieve all key-values in a subbase
all_data = pdb.retrieveSubBaseDatas("Users", "Aritra@gmail.com")
print("All data in Aritra's subbase:", all_data)

# Delete specific data field
pdb.deleteData("Users", subpath="Paper@gmail.com", key="Name")

# Delete a subbase
pdb.deletePaperSubBase("Users", "Paper@gmail.com")

# Delete entire PaperBase
# pdb.deletePaperBase("Users")

```
---
## 📃 License
This project is licensed under the MIT License.

### `LICENSE` (MIT License)
```
MIT License

Copyright (c) 2025 YOUR_NAME

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the “Software”), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```