class GenLayerError(Exception):
    """
    An error raised by GenLayer.
    """
