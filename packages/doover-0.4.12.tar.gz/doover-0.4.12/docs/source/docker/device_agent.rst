.. py:currentmodule:: pydoover

Device Agent
============

.. autoclass:: pydoover.docker.DeviceAgentInterface
    :members:
