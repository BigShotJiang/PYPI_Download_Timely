
class SmbZfsError(Exception):
    """Custom exception for module errors."""

    pass
