import irsim

env = irsim.make('empty_world.yaml')
env.show()
