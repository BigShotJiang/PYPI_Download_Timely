'''
Objects: A list of all objects in the environment
Logger: A logger object to log messages
Platform: The operating system platform
'''

import platform

objects = []
logger = None
GeometryTree = None
platform_name = platform.system()
