# coffy/graph/__init__.py
# author: nsarathy

from .graphdb_nx import GraphDB as GraphDB

__all__ = ["GraphDB"]
