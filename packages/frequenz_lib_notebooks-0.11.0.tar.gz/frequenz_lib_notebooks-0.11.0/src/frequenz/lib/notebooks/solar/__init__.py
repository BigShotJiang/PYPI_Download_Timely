# License: MIT
# Copyright © 2025 Frequenz Energy-as-a-Service GmbH

"""Initialise the solar related modules."""
