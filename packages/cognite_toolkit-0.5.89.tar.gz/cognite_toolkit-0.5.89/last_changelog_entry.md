## cdf 

### Improved

- [alpha] The `cdf profile` commands now skips repeated values in the
table terminal output. This is to increase the readability.

## templates

No changes.