# Main Cognite Modules modules folder

Modules in this folder come bundled with the `cdf-tk` tool. They are managed
from a [public repository](https://github.com/cognitedata/toolkit).

See the [documentation](https://docs.cognite.com/cdf/deploy/cdf_toolkit/references/module_reference) for
an introduction.
