from omu.identifier import Identifier

IDENTIFIER = Identifier.from_key("com.omuapps:chat")
