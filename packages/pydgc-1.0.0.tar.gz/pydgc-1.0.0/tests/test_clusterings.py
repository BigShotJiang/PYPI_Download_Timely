# -*- coding: utf-8 -*-
"""
@Time: 2025/4/16 12:46 
@Author: Benyu Wu
@Email: bywu109@163.com
@Version: 1.0.0
"""

if __name__ == "__main__":
    print("Hello, world!")
