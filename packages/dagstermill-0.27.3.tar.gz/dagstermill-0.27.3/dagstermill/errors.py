from dagster_shared.error import DagsterError


class DagstermillError(DagsterError):
    """Base class for errors raised by dagstermill."""
