* `TAKOBI <https://takobi.online>`_:

  * Simone Rubino <sir@takobi.online>
* Giuseppe Borruso - Dinamiche Aziendali srl <gborruso@dinamicheaziendali.it>
* `Aion Tech <https://aiontech.company/>`_:

  * Simone Rubino <simone.rubino@aion-tech.it>
