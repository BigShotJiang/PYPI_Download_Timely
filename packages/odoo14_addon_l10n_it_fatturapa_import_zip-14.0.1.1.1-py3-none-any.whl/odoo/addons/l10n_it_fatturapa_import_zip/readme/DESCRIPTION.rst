**Italiano**

Questo modulo aggiunge una vista per importare diversi file XML di fatture elettroniche (OUT/IN) tramite file ZIP.

**English**

This module adds a view to import several XML e-invoice files (OUT/IN) via ZIP file.
