**Italiano**

 * Andare in Fatturazione -> Configurazione -> Fiscalità italiana -> Import E-bill ZIP Files
 * Caricare un file ZIP contenente i file XML di fatture elettroniche (OUT/IN)
 * Eseguire "Import Invoices" per creare le fatture in bozza

**English**

 * Go to Accounting -> Configuration -> Italian Localization -> Import E-bill ZIP Files
 * Upload ZIP file including XML e-invoice files (OUT/IN)
 * Run "Import Invoices" to create a draft invoices/bills
