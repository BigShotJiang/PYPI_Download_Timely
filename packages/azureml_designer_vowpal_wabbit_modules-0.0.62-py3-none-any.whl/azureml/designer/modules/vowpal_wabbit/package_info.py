VERSION = '0.0.62'
PACKAGE_NAME = 'azureml-designer-vowpal-wabbit-modules'
DESCRIPTION = 'Modules to train and inference models based on Vowpal Wabbit framework.'
