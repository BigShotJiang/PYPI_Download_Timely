EXTERNAL_API_BASE = "https://api.zylosystems.com/v1"
