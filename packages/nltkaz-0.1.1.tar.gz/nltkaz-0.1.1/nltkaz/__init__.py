from nltkaz.stem import Stemmer
from nltkaz.stopwords import load, remove