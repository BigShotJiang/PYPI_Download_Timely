"""The moneyball strategy features module."""
