import {
  _AnyLoader,
  _ExpressionLoader,
  _PrimitiveLoader,
  _UnionLoader,
  _RecordLoader,
  _URILoader,
  _ArrayLoader,
  _EnumLoader,
  _IdMapLoader,
  _MapLoader,
  _TypeDSLLoader,
  _SecondaryDSLLoader,
  TypeGuards,
  ${generated_class_imports}
} from './Internal'

${loader_instances}