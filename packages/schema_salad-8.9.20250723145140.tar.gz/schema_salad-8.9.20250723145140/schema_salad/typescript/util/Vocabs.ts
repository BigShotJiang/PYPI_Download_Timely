export const VOCAB = {
  ${vocab}
}
export const RVOCAB = {
  ${rvocab}
}
