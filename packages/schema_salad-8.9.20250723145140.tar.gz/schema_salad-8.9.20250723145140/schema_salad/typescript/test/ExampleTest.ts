
import { loadDocument, loadDocumentByString } from '../'
import fs from 'fs'
import url from 'url'

describe('Example Tests', () => {
${tests}
})
