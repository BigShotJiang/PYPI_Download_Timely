﻿#pragma warning disable IDE1006, IDE0090
using OneOf;
using OneOf.Types;

namespace ${project_name};

internal static class LoaderInstances
{
${loader_instances}
}
