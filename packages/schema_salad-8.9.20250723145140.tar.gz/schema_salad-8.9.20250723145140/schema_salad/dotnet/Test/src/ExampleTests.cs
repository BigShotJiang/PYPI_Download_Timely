using System;
using System.IO;
using ${project_name};
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OneOf;
using OneOf.Types;

namespace Test;

[TestClass]
public class ExampleTests
{
${tests}
}
