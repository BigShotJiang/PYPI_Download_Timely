package ${package}.utils;

import java.util.List;
import ${package}.*;

public class LoaderInstances {
${loader_instances}
}
