package ${package}.utils;

public interface Saveable {
  // TODO: implement writable interface
  // public abstract void save(boolean top, String baseUrl, boolean relativeUris);
}
