package ${package}.utils;

public class SaveableImpl implements Saveable {
  public SaveableImpl(Object doc, String baseUri, LoadingOptions loadingOptions, String docRoot) {}
}
