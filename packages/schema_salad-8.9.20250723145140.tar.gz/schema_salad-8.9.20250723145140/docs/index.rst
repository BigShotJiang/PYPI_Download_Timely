.. include:: ../README.rst

.. toctree::
   :maxdepth: 2

   cli
   typeshed
   autoapi/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

.. _RDF: https://www.w3.org/RDF/
