Command Line Options
====================

.. autoprogram:: schema_salad.main:arg_parser()
   :prog: schema-salad-tool

.. autoprogram:: schema_salad.makedoc:arg_parser()
   :prog: schema-salad-doc


