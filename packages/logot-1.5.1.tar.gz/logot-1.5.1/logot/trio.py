"""
Integration API for :mod:`trio`.

.. seealso::

    See :doc:`/integrations/trio` usage guide.
"""

from __future__ import annotations

from logot._trio import TrioWaiter as TrioWaiter
