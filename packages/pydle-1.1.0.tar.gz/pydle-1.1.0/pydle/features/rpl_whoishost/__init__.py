"""
Adds support for RPL_WHOISHOST (reply type 378)
"""

from .rpl_whoishost import RplWhoisHostSupport

__all__ = ["RplWhoisHostSupport"]
