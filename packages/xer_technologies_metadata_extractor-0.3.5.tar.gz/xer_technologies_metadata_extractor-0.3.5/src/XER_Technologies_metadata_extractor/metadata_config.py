"""
Metadata Configuration Module

This module defines which metadata fields to extract from CSV files.
It provides a centralized, easily modifiable configuration for metadata extraction.
"""

from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from enum import Enum


class MetadataCategory(Enum):
    """Categories of metadata fields."""
    TIMING = "timing"
    POWER = "power"
    GENERATOR = "generator"
    ENGINE = "engine"
    TEMPERATURE = "temperature"
    VOLTAGE = "voltage"
    CURRENT = "current"
    THROTTLE = "throttle"
    POST_PROCESSING = "post_processing"
    FILE_INFO = "file_info"
    VALIDATION = "validation"


@dataclass
class MetadataField:
    """Definition of a metadata field to extract."""
    name: str
    category: MetadataCategory
    required: bool = True
    unit: Optional[str] = None
    description: str = ""
    calculation_method: str = "direct"  # direct, min, max, avg, range, duration
    source_columns: Optional[List[str]] = None
    validation_rules: Optional[Dict[str, Any]] = None


class MetadataConfig:
    """Configuration for metadata extraction."""
    
    def __init__(self):
        """Initialize with default metadata fields."""
        self.fields = self._get_default_fields()
    
    def _get_default_fields(self) -> List[MetadataField]:
        """Get the default metadata fields to extract."""
        return [
            # === CRUCIAL INFORMATION (FIRST) ===
            
            # Timing Information
            MetadataField(
                name="log_duration",
                category=MetadataCategory.TIMING,
                required=True,
                unit="HH:MM:SS",
                description="Total log duration",
                calculation_method="duration",
                source_columns=["time", "timestamp"]
            ),
            MetadataField(
                name="start_time",
                category=MetadataCategory.TIMING,
                required=True,
                unit="HH:MM:SS",
                description="Flight start time (UTC)",
                calculation_method="first",
                source_columns=["time", "timestamp"]
            ),
            MetadataField(
                name="end_time",
                category=MetadataCategory.TIMING,
                required=True,
                unit="HH:MM:SS",
                description="Flight end time (UTC)",
                calculation_method="last",
                source_columns=["time", "timestamp"]
            ),
            MetadataField(
                name="flight_date",
                category=MetadataCategory.TIMING,
                required=True,
                unit="YYYY-MM-DD",
                description="Flight date",
                calculation_method="date_from_time",
                source_columns=["time", "timestamp"]
            ),
            
            # Engine Data (Crucial)
            MetadataField(
                name="total_engine_starts",
                category=MetadataCategory.ENGINE,
                required=True,
                unit="count",
                description="Total number of engine starts",
                calculation_method="engine_starts",
                source_columns=["isGeneratorRunning", "time"]
            ),
            MetadataField(
                name="total_engine_hours",
                category=MetadataCategory.ENGINE,
                required=True,
                unit="hours",
                description="Total engine working hours",
                calculation_method="engine_hours",
                source_columns=["isGeneratorRunning", "time"]
            ),
            MetadataField(
                name="total_flight_hours",
                category=MetadataCategory.ENGINE,
                required=True,
                unit="hours",
                description="Total flight hours",
                calculation_method="flight_hours",
                source_columns=["droneInFlight", "time"]
            ),
            MetadataField(
                name="generator_runtime",
                category=MetadataCategory.GENERATOR,
                required=True,
                unit="HH:MM:SS",
                description="Total generator runtime",
                calculation_method="duration_conditional",
                source_columns=["time", "isGeneratorRunning"],
                validation_rules={"condition": "isGeneratorRunning == 1"}
            ),
            
            # File Information (Crucial)
            MetadataField(
                name="serial_number",
                category=MetadataCategory.FILE_INFO,
                required=True,
                unit="",
                description="Device serial number",
                calculation_method="serial_number",
                source_columns=["SN", "serial"]
            ),
            MetadataField(
                name="file_type",
                category=MetadataCategory.FILE_INFO,
                required=True,
                unit="",
                description="File type",
                calculation_method="file_type",
                source_columns=[]
            ),
            MetadataField(
                name="timestamp",
                category=MetadataCategory.FILE_INFO,
                required=True,
                unit="",
                description="Extraction timestamp",
                calculation_method="timestamp",
                source_columns=["time", "timestamp"]
            ),
            
           
            
            # === DYNAMIC STATISTICS ===
            # All avg_*, max_*, and std_dev_* statistics are now calculated automatically
            # for every column with more than 10 rows of valid numeric data during flight
        ]
    
    def get_fields_by_category(self, category: MetadataCategory) -> List[MetadataField]:
        """Get all fields for a specific category."""
        return [field for field in self.fields if field.category == category]
    
    def get_required_fields(self) -> List[MetadataField]:
        """Get all required fields."""
        return [field for field in self.fields if field.required]
    
    def get_optional_fields(self) -> List[MetadataField]:
        """Get all optional fields."""
        return [field for field in self.fields if not field.required]
    
    def add_field(self, field: MetadataField) -> None:
        """Add a new metadata field."""
        self.fields.append(field)
    
    def remove_field(self, field_name: str) -> None:
        """Remove a metadata field by name."""
        self.fields = [field for field in self.fields if field.name != field_name]
    
    def get_field(self, field_name: str) -> Optional[MetadataField]:
        """Get a specific field by name."""
        for field in self.fields:
            if field.name == field_name:
                return field
        return None
    
    def update_field(self, field_name: str, **kwargs) -> bool:
        """Update a field's properties."""
        field = self.get_field(field_name)
        if field:
            for key, value in kwargs.items():
                if hasattr(field, key):
                    setattr(field, key, value)
            return True
        return False


# Global configuration instance
metadata_config = MetadataConfig() 