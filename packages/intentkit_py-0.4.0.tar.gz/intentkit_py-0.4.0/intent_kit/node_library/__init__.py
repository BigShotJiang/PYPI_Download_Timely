"""Reusable node implementations for demos, evaluation, and integration across IntentKit."""
