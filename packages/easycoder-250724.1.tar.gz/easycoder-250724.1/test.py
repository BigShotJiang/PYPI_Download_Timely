#!/bin/python3

from easycoder import Program

Program('test.ecs').start()
