# includes

## Syntax:
`{value} includes {element}`

## Examples:
``if Animals includes `cat` stop` ``

## Description:
Tests if the array - usually a variable - has the named element as one of its members.

Next: [is](is.md)  
Prev: [has property](hasProperty.md)

[Back](../../README.md)
