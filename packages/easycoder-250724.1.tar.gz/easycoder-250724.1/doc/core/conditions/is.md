# is

## Syntax:
`{value} is {second value}`

## Examples:
``if Animal is `cat` stop` ``

## Description:
Tests if the value is identical to the second value.

Next: [less](less.md)  
Prev: [includes](includes.md)

[Back](../../README.md)
