# memory

## Syntax:
`[the] memory`

## Examples:
`print the memory`

## Description:
Gets the amount of memory used by the process, in megabytes.

Next: [modification](modification.md)  
Prev: [lowercase](lowercase.md)

[Back](../../README.md)
