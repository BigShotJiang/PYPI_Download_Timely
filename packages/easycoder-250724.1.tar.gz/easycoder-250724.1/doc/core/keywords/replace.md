# replace

## Syntax:
`replace {value} with {value} in {variable}`
## Examples:
``replace `one` with `two` in Sentence``  
`replace Template with Value in Text`

## Description:
Replaces all occurrences of one string with another in a string [variable](variable.md).

Next: [return](return.md)  
Prev: [release](release.md)

[Back](../../README.md)
