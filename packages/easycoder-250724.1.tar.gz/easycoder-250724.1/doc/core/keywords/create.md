# create

## Syntax:
`create directory {name}`
## Examples:
`create directory Items`
## Description:
Create a directory, giving the full path in `{name}`. 

Next: [debug](debug.md)  
Prev: [close](close.md)

[Back](../../README.md)
