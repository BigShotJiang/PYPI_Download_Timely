"""
Models for YouTube Searcher.
"""

from .video import Video

__all__ = ["Video"] 