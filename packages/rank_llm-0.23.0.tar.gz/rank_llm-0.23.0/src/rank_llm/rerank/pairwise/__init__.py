from .duot5 import DuoT5

__all__ = ["DuoT5"]
