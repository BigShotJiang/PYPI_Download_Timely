class Build:
    PLATFORM = 'Python'
    API_VERSION = '1.9.0'
