class DefaultFlagValues:
    STRING=''
    INT=0
    FLOAT=0.0
    BOOLEAN=False