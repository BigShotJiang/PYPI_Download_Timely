class NoOpLogger:
    def debug(self, message, ex=None):
        pass

    def error(self, message, ex=None):
        pass

    def warn(self, message, ex=None):
        pass
