from collections import namedtuple

TargetGroupModel = namedtuple('TargetGroupModel', ['id', 'condition'])
