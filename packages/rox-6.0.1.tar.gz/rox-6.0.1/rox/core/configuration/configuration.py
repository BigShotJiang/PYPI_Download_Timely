from collections import namedtuple

Configuration = namedtuple('Configuration', ['experiments', 'target_groups', 'signature_date'])

