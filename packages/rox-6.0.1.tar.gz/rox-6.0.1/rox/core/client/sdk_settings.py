from collections import namedtuple

SdkSettings = namedtuple('SdkSettings', ['api_key', 'dev_mode_secret'])
