class FlagTypes:
    STRING = str
    INT = int
    FLOAT = float
    BOOLEAN = bool