from .eternalegypt import Modem, Error
