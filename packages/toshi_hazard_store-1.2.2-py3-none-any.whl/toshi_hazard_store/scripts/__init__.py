'''
TODO: this is needed for mypy at least if we want the sub-packages core etc to live here.

ref: https://stackoverflow.com/q/63871252/23763843
'''
