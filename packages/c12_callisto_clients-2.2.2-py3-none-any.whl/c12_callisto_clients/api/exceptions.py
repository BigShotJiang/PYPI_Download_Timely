class ApiError(Exception):
    """
    Class that represent C12 simulator error with ID's
    depending on the error.
    """

    pass
