<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="en_US">
<context>
    <name>EzQt_App</name>
    <message>
        <source>Home</source>
        <translation>Home</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Settings</translation>
    </message>
    <message>
        <source>Theme</source>
        <translation>Theme</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Language</translation>
    </message>
    <message>
        <source>Notifications</source>
        <translation>Notifications</translation>
    </message>
    <message>
        <source>Auto Save</source>
        <translation>Auto Save</translation>
    </message>
    <message>
        <source>Save Interval</source>
        <translation>Save Interval</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation>minutes</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Light</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Dark</translation>
    </message>
    <message>
        <source>English</source>
        <translation>English</translation>
    </message>
    <message>
        <source>Français</source>
        <translation>French</translation>
    </message>
    <message>
        <source>Español</source>
        <translation>Spanish</translation>
    </message>
    <message>
        <source>Choose the application theme</source>
        <translation>Choose the application theme</translation>
    </message>
    <message>
        <source>Interface language</source>
        <translation>Interface language</translation>
    </message>
    <message>
        <source>Enable system notifications</source>
        <translation>Enable system notifications</translation>
    </message>
    <message>
        <source>Automatically save modifications</source>
        <translation>Automatically save modifications</translation>
    </message>
    <message>
        <source>Interval between automatic saves</source>
        <translation>Interval between automatic saves</translation>
    </message>
    <message>
        <source>Active Theme</source>
        <translation>Active Theme</translation>
    </message>
    <message>
        <source>MyApplication</source>
        <translation>MyApplication</translation>
    </message>
    <message>
        <source>This is an example description</source>
        <translation>This is an example description</translation>
    </message>
    <message>
        <source>Welcome to EzQt_App</source>
        <translation>Welcome to EzQt_App</translation>
    </message>
    <message>
        <source>This is an example of translation system</source>
        <translation>This is an example of translation system</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Help</translation>
    </message>
    <message>
        <source>Change Language</source>
        <translation>Change Language</translation>
    </message>
    <message>
        <source>Current language: {}</source>
        <translation>Current language: {}</translation>
    </message>
    <message>
        <source>This is a test message</source>
        <translation>This is a test message</translation>
    </message>
    <message>
        <source>The translation system is working correctly</source>
        <translation>The translation system is working correctly</translation>
    </message>
    <message>
        <source>How to use translations</source>
        <translation>How to use translations</translation>
    </message>
    <message>
        <source>Use self.tr('text') to make text translatable</source>
        <translation>Use self.tr('text') to make text translatable</translation>
    </message>
    <message>
        <source>Example</source>
        <translation>Example</translation>
    </message>
    <message>
        <source>Made with ❤️ by EzQt_App</source>
        <translation>Made with ❤️ by EzQt_App</translation>
    </message>
    <message>
        <source>v1.0.0</source>
        <translation>v1.0.0</translation>
    </message>
</context>
</TS> 