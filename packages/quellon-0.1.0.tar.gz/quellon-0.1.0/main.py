def main():
    print("Hello from quellon!")


if __name__ == "__main__":
    main()
