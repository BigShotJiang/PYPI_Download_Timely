"""Test suite for the dvc-studio-client package."""
