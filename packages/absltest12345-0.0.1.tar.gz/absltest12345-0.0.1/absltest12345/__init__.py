# Safe dummy package: absltest12345
