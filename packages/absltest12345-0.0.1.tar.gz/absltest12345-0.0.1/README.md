# absltest12345
This is a safe dummy PoC package.