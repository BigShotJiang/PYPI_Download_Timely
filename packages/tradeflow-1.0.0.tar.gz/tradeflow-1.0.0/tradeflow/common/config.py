from pathlib import Path

LIBTRADEFLOW_SHARED_LIBRARY_DIRECTORY = Path(__file__).parent.parent
