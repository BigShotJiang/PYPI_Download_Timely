import pathlib

PACKAGE_DIR = pathlib.Path(__file__).parent

LIB_TRADEFLOW = "libtradeflow"
