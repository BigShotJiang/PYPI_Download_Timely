# recipe/__init__.py

from .cli import cook

__all__ = ['cook']
