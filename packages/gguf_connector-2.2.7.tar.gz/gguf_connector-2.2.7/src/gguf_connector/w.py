import webbrowser
print("activating the default browser...")
webbrowser.open("https://gguf.us")