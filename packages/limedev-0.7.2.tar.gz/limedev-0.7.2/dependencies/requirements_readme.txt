yamdog >= 0.6.0
