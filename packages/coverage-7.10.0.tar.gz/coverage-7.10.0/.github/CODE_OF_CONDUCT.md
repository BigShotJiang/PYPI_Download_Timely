# Treat each other well

Everyone participating in the coverage.py project, and in particular in the
issue tracker, pull requests, and social media activity, is expected to treat
other people with respect and to follow the guidelines articulated in the
[Python Community Code of Conduct][psf_coc].

[psf_coc]: https://www.python.org/psf/codeofconduct/
