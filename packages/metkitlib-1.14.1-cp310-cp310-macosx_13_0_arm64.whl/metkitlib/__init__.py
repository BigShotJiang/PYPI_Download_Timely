__version__ = '1.14.1'
__commit_hash__ = 'd5e971c6903df3d733ebe78c76206999eb63817d'
findlibs_dependencies = ["eckitlib", "eccodeslib"]
