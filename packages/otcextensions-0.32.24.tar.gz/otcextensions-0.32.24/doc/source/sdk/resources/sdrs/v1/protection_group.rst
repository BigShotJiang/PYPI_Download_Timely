otcextensions.sdk.sdrs.v1.protection_group.ProtectionGroup
==========================================================

.. automodule:: otcextensions.sdk.sdrs.v1.protection_group

The SDRS Protection group Class
-------------------------------

The ``ProtectionGroup`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.sdrs.v1.protection_group.ProtectionGroup
   :members:
