otcextensions.sdk.sdrs.v1.dr_drill.DRDrill
==========================================

.. automodule:: otcextensions.sdk.sdrs.v1.dr_drill

The SDRS Disaster Recovery Drill Class
--------------------------------------

The ``DRDrill`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.sdrs.v1.dr_drill.DRDrill
   :members:

.. autoclass:: otcextensions.sdk.sdrs.v1.dr_drill.DrillServers
   :members:
