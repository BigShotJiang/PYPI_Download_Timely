otcextensions.sdk.vpc.v1.bandwidth
==================================

.. automodule:: otcextensions.sdk.vpc.v1.bandwidth

The VPC Bandwidth Class
-----------------------

The ``Bandwidth`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.vpc.v1.bandwidth.Bandwidth
   :members:
