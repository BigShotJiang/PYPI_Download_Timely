otcextensions.sdk.function_graph.v2.log
=======================================

.. automodule:: otcextensions.sdk.function_graph.v2.log

The Log Class
---------------

The ``Log`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.function_graph.v2.log.Log
   :members:
