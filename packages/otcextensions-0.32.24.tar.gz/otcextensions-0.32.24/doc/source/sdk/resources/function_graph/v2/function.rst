otcextensions.sdk.function_graph.v2.function
============================================

.. automodule:: otcextensions.sdk.function_graph.v2.function

The Function Class
------------------

The ``Function`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.function_graph.v2.function.Function
   :members:
