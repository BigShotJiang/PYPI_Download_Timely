otcextensions.sdk.function_graph.v2.alias
=========================================

.. automodule:: otcextensions.sdk.function_graph.v2.alias

The Alias Class
---------------

The ``Alias`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.function_graph.v2.alias.Alias
   :members:
