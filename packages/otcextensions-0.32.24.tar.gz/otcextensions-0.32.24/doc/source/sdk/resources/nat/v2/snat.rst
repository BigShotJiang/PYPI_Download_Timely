otcextensions.sdk.nat.v2.snat
=============================

.. automodule:: otcextensions.sdk.nat.v2.snat

The SNAT Rule Class
--------------------

The ``Snat`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.nat.v2.snat.Snat
   :members:
