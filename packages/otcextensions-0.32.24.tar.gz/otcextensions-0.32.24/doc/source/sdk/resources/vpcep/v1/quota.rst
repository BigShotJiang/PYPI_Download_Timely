otcextensions.sdk.vpecp.v1.quota
====================================

.. automodule:: otcextensions.sdk.vpcep.v1.quota

The VPCEP Quota Class
---------------------

The ``Quota`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.vpcep.v1.quota.Quota
   :members:
