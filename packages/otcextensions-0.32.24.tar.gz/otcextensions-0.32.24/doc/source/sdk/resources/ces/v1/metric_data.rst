otcextensions.sdk.ces.v1.metric_data
====================================

.. automodule:: otcextensions.sdk.ces.v1.metric_data

The CES Metric Data Class
-------------------------

The ``Metric Data`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.ces.v1.metric_data.MetricData
   :members:
