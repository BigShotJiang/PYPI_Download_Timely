otcextensions.sdk.ces.v1.metric
===============================

.. automodule:: otcextensions.sdk.ces.v1.metric

The CES Metric Class
--------------------

The ``Metric`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.ces.v1.metric.Metric
   :members:
