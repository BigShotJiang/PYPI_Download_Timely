Simple Message Notification Service Resources
=============================================

.. toctree::
   :maxdepth: 1

   v2/message
   v2/sms
   v2/subscription
   v2/template
   v2/topic
