otcextensions.sdk.smn.v2.topic
==============================

.. automodule:: otcextensions.sdk.smn.v2.topic

The SMN Topic Class
-------------------

The ``Topic`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.smn.v2.topic.Topic
   :members:

.. autoclass:: otcextensions.sdk.smn.v2.topic.TopicAttribute
   :members:

.. autoclass:: otcextensions.sdk.smn.v2.topic.AttributeSpec
   :members:
