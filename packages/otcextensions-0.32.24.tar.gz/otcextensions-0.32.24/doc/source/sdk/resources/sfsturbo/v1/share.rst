otcextensions.sdk.sfsturbo.v1.share
===================================

.. automodule:: otcextensions.sdk.sfsturbo.v1.share

The Share Class
---------------

The ``Share`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.sfsturbo.v1.share.Share
   :members:
