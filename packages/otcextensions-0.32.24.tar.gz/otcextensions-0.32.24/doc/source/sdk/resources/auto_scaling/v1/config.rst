otcextensions.sdk.auto_scaling.v1.config
========================================

.. automodule:: otcextensions.sdk.auto_scaling.v1.config

The AS Configuration Class
--------------------------

The ``Config`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.auto_scaling.v1.config.Config
   :members:
