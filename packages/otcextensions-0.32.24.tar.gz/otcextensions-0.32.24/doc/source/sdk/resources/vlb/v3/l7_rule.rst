otcextensions.sdk.vlb.v3.l7_rule
==================================

.. automodule:: otcextensions.sdk.vlb.v3.l7_rule

The L7Rule Class
------------------

The ``L7Rule`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.vlb.v3.l7_rule.L7Rule
   :members:
