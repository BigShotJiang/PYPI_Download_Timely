otcextensions.sdk.vlb.v3.health_monitor
=======================================

.. automodule:: otcextensions.sdk.vlb.v3.health_monitor

The HealthMonitor Class
-----------------------

The ``HealthMonitor`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.vlb.v3.health_monitor.HealthMonitor
   :members:
