otcextensions.sdk.mrs.v1.job
============================

.. automodule:: otcextensions.sdk.mrs.v1.job

The MRS Job Class
-----------------

The ``Job`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.mrs.v1.job.Job
   :members:
