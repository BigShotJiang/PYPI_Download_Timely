otcextensions.sdk.dcs.v1.config
=================================

.. automodule:: otcextensions.sdk.dcs.v1.config

The DCS Config Class
--------------------

The ``Config`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dcs.v1.config.Config
   :members:
