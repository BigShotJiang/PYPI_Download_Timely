otcextensions.sdk.dcs.v1.statistic
==================================

.. automodule:: otcextensions.sdk.dcs.v1.statistic

The DCS Statistic Class
-----------------------

The ``Statistic`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dcs.v1.statistic.Statistic
   :members:
