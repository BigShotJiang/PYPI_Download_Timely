otcextensions.sdk.dcs.v1.availability_zone
==============================================

.. automodule:: otcextensions.sdk.dcs.v1.availability_zone

The DCS Availability Zone Class
-----------------------------------

The ``AvailabilityZone`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dcs.v1.availability_zone.AvailabilityZone
   :members:
