otcextensions.sdk.dcs.v1.quota
==============================

.. automodule:: otcextensions.sdk.dcs.v1.quota

The DCS Service Quota Class
---------------------------

The ``Quota`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource` and
:class:`~otcextensions.sdk.quotamixin.QuotaProxyMixin`.

.. autoclass:: otcextensions.sdk.dcs.v1.quota.Quota
   :members:
