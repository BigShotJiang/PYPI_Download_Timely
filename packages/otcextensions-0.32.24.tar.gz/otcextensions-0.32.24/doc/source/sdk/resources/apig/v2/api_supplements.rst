otcextensions.sdk.apig.v2.api_supplements
=========================================

.. automodule:: otcextensions.sdk.apig.v2.api_supplements

The PublishApi Class
--------------------

The ``PublishApi`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.api_supplements.PublishApi
   :members:

The CheckApi Class
------------------

The ``CheckApi`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.api_supplements.CheckApi
   :members:

The DebugApi Class
------------------

The ``DebugApi`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.api_supplements.DebugApi
   :members:

The PublishApis Class
---------------------

The ``PublishApis`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.api_supplements.PublishApis
   :members:

The RuntimeDefinitionApi Class
------------------------------

The ``RuntimeDefinitionApi`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.api_supplements.RuntimeDefinitionApi
   :members:

The VersionsApi Class
---------------------

The ``VersionsApi`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.api_supplements.VersionsApi
   :members:
