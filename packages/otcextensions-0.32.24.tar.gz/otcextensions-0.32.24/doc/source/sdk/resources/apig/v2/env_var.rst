otcextensions.sdk.apig.v2.apienvironmentvar
===========================================

.. automodule:: otcextensions.sdk.apig.v2.apienvironmentvar

The ApiEnvironmentVar Class
---------------------------

The ``ApiEnvironment`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.apienvironmentvar.ApiEnvironmentVar
   :members:
