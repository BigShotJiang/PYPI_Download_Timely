otcextensions.sdk.apig.v2.az
============================

.. automodule:: otcextensions.sdk.apig.v2.az

The AZ Class
------------------

The ``AZ`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.az.AZ
   :members:
