otcextensions.sdk.apig.v2.gateway_features
==========================================

.. automodule:: otcextensions.sdk.apig.v2.gateway_features

The GatewayFeatures Class
-------------------------

The ``GatewayFeatures`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.gateway_features.GatewayFeatures
   :members:
