otcextensions.sdk.apig.v2.acl_policy
====================================

.. automodule:: otcextensions.sdk.apig.v2.acl_policy

The AclPolicy Class
------------------------

The ``AclPolicy`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.acl_policy.AclPolicy
   :members:
