otcextensions.sdk.apig.v2.gateway
=================================

.. automodule:: otcextensions.sdk.apig.v2.gateway

The Gateway Class
------------------

The ``Gateway`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.gateway.Gateway
   :members:
