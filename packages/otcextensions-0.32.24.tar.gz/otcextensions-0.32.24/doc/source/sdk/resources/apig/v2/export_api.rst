otcextensions.sdk.apig.v2.export_api
====================================

.. automodule:: otcextensions.sdk.apig.v2.export_api

The ExportApi Class
-------------------

The ``ExportApi`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.export_api.ExportApi
   :members:

The ImportApi Class
-------------------

The ``ImportApi`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.export_api.ImportApi
   :members:
