otcextensions.sdk.apig.v2.signature_binding
===========================================

.. automodule:: otcextensions.sdk.apig.v2.signature_binding

The SignatureBind Class
-----------------------

The ``SignatureBind`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.signature_binding.SignatureBind
   :members:

The NotBoundApi Class
---------------------

The ``NotBoundApi`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.signature_binding.NotBoundApi
   :members:

The BoundApi Class
------------------

The ``BoundApi`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.apig.v2.signature_binding.BoundApi
   :members:
