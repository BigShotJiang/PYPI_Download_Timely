otcextensions.sdk.dcaas.v2.virtual_interface
============================================

.. automodule:: otcextensions.sdk.dcaas.v2.virtual_interface

The Virtual Interface Class
---------------------------

The ``VirtualInterface`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dcaas.v2.virtual_interface.VirtualInterface
   :members:
