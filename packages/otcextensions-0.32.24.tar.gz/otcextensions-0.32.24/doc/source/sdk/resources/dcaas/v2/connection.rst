otcextensions.sdk.dcaas.v2.connection
=====================================

.. automodule:: otcextensions.sdk.dcaas.v2.connection

The Connection Class
---------------------

The ``Connection`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dcaas.v2.connection.Connection
   :members:
