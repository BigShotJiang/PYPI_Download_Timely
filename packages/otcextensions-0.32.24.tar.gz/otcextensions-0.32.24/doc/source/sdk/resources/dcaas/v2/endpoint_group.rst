otcextensions.sdk.dcaas.v2.endpoint_group
=========================================

.. automodule:: otcextensions.sdk.dcaas.v2.endpoint_group

The Endpoint Group Class
-------------------------

The ``DirectConnectEndpointGroup`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dcaas.v2.endpoint_group.DirectConnectEndpointGroup
   :members:
