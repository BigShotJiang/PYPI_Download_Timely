RDS Resources
=============

RDS v1
^^^^^^

.. toctree::
   :maxdepth: 1

   v1/configuration
   v1/flavor
   v1/instance

RDS v3
^^^^^^

.. toctree::
   :maxdepth: 1

   v3/configuration
   v3/flavor
   v3/instance
