otcextensions.sdk.dns.v2.zone
=============================

.. automodule:: otcextensions.sdk.dns.v2.zone

The DNS Zone Class
------------------

The ``Zone`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dns.v2.zone.Zone
   :members:
