openstack.identity.v3.project
=============================

.. automodule:: openstack.identity.v3.project

The Project Class
-----------------

The ``Project`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.project.Project
   :members:
