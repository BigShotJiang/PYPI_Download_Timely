otcextensions.sdk.ctsv3.v3.quota
================================

.. automodule:: otcextensions.sdk.ctsv3.v3.quota

The CTS Quota Class
-----------------------

The ``Quota`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.ctsv3.v3.quota.Quota
   :members:
