otcextensions.sdk.ctsv3.v3.key_event
====================================

.. automodule:: otcextensions.sdk.ctsv3.v3.key_event

The CTS Key Event Class
-----------------------

The ``Key Event`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.ctsv3.v3.key_event.KeyEvent
   :members:
