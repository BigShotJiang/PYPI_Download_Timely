otcextensions.sdk.cts.v1.tracker
================================

.. automodule:: otcextensions.sdk.cts.v1.tracker

The CTS Tracker Class
---------------------

The ``Tracker`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.cts.v1.tracker.Tracker
   :members:
