otcextensions.sdk.modelartsv1.v1.model
========================================

.. automodule:: otcextensions.sdk.modelartsv1.v1.model

The AS Configuration Class
--------------------------

The ``Config`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.modelartsv1.v1.model.Model
   :members:
