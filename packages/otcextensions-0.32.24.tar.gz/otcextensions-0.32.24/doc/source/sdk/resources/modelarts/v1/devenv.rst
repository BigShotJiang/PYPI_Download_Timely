otcextensions.sdk.modelartsv1.v1.devenv
========================================

.. automodule:: otcextensions.sdk.modelartsv1.v1.devenv

The AS Configuration Class
--------------------------

The ``Config`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.modelartsv1.v1.devenv.Devenv
   :members:
