otcextensions.sdk.dws.v1.tag
=============================

.. automodule:: otcextensions.sdk.dws.v1.tag

The DWS Tag Class
-----------------

The ``Tag`` class represents tags associated with DWS clusters and
inherits from :class:`~openstack.sdk.resource.Resource`.

.. autoclass:: otcextensions.sdk.dws.v1.tag.Tag
   :members:
