otcextensions.sdk.deh.v1.host_type
==================================

.. automodule:: otcextensions.sdk.deh.v1.host_type

The DeH Host Type Class
-----------------------

The ``HostType`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.deh.v1.host_type.HostType
   :members:
