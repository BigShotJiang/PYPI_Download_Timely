otcextensions.sdk.dcs.v1.message
================================

.. automodule:: otcextensions.sdk.dms.v1.message

The DMS Message Class
---------------------

The ``Message`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dms.v1.message.Message
   :members:
