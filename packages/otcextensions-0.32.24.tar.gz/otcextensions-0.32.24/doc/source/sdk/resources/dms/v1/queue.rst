otcextensions.sdk.dcs.v1.queue
==============================

.. automodule:: otcextensions.sdk.dms.v1.queue

The DMS Queue Class
-------------------

The ``Queue`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dms.v1.queue.Queue
   :members:
