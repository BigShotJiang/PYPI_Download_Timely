otcextensions.sdk.dds.v3.job
================================

.. automodule:: otcextensions.sdk.dds.v3.job

The Job Class
-------------------

The ``Job`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dds.v3.job.Job
   :members:
