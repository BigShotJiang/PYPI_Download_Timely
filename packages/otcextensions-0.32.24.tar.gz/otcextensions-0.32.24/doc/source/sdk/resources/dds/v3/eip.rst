otcextensions.sdk.dds.v3.eip
================================

.. automodule:: otcextensions.sdk.dds.v3.eip

The Eip Class
-------------------

The ``Eip`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.dds.v3.eip.Eip
   :members:
