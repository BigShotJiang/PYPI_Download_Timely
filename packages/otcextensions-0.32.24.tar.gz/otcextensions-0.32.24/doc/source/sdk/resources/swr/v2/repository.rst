otcextensions.sdk.swr.v2.repository
===================================

.. automodule:: otcextensions.sdk.swr.v2.repository

The Repository Class
--------------------

The ``repository`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.swr.v2.repository.Repository
   :members:

The Repository Permission Class
-------------------------------

The ``Permission`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.swr.v2.repository.Permission
   :members:
