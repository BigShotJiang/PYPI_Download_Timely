otcextensions.sdk.swr.v2.domain
===============================

.. automodule:: otcextensions.sdk.swr.v2.domain

The Domain Class
----------------

The ``domain`` class inherits from
:class:`~otcextensions.sdk.sdk_resource.Resource`.

.. autoclass:: otcextensions.sdk.swr.v2.domain.Domain
   :members:
