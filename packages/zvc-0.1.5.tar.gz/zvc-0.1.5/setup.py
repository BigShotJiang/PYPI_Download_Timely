#!/usr/bin/env python3
"""Setup script for zvc package."""

from setuptools import setup

if __name__ == "__main__":
    setup(
        packages=["zvc"],
    )
