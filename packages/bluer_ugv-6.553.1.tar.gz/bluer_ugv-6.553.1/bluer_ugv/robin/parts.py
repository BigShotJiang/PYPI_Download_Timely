dict_of_parts = {
    "4-ch-transceiver": "",
    "2xAA-battery-holder": "",
    "4xAA-battery-holder": "",
}
