from letschatty.models.base_models.singleton import SingletonMeta

