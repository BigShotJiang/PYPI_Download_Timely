Lucterios mailing
=================

Help about featuring of mailing tool.

Contents:
=========

.. toctree::
   :maxdepth: 2

   configuration.rst
   mailing.rst

