Mailings
========

Since the menu *Office/Mailing/Messages* you can create a mail courier.

Once you finish writing your message, you can associate it addressed queries.
It's queries of research, similar to the contact search tools will be evaluated at the time of the courier generation.
So even a recently added or modified contacts may be affected by this message.

Once validated the message you can either:
 - generated PDF output of all letters to send customized with the header of each contact
 - either sent by email if your configuration is valid. Of course, in this case, only the contacts having an address will be impacted by this sends.
