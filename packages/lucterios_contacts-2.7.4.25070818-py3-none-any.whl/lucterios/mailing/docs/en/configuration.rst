Email Setup
===========

Here you can configure settings for sending E-MAIL.

The SMTP server will allow the software to directly send messages to your contacts such as sending a new login password. 
Remember then specify a small explanatory message.

You can also specify how you want to use your email browser for feature 'write to all': 'To', 'Copy' or 'Copy cached'.