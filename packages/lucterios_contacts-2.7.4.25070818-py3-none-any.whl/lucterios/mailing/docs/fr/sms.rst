Envoi de SMS
============

     Menu *Bureautique/Publipostage/Messages SMS*

Création d'un message
---------------------

L'envoi de SMS se fait via une interface proche de celle d'envoie de couriels.

Notons les différences:

- Spécificité de création de message

	Vous devez précisez quel champ (tel1, tel2 ou un champ textuel personalisé) vous souhaitez utiliser pour envoyer vos messages.
	Notez qu'il est possible d'envoyer à plusieurs numéro pour un même contact.

- La taille du message de celui-ci s'affiche.

	Notez que certain caractère, comme les accents, peuvent compter double.

- Il n'est pas possible d'ajouter de document joint comme pour les courriels.


Validation & transmission
-------------------------

Une fois le message validé vous pouvez l'envoyer par SMS, si celui-ci est correctement configuré.
Bien sur, dans ce cas, seuls les contacts possédant une numéro de téléphone valide (voir configuration) seront impactés par cet envoi.

De plus, vous pouvez consulter le rapport de transmission. 
Celui-ci vous indique les SMS envoyés et les éventuelles erreurs d'acheminement.
