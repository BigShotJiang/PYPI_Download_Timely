Lucterios contacts
==================

Aide relative aux fonctionnalités de gestion de contacts moraux ou physiques.

.. toctree::
   :maxdepth: 2

   individual.rst
   legal_entity.rst
   possession.rst
   configuration.rst


