Lucterios contacts
==================

Help about featuring of contacts management (legacy entity and individual).

Contents:
=========

.. toctree::
   :maxdepth: 2

   individual.rst
   legal_entity.rst
   configuration.rst



