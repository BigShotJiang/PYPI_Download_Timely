# Torna a classe SnapshotManager acessível a partir do pacote 'snapshots'.

from .manager import SnapshotManager

__all__ = ["SnapshotManager"]
