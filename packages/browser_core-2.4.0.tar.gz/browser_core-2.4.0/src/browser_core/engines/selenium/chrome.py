from __future__ import annotations

from .base_engine import SeleniumBaseEngine


class SeleniumChromeEngine(SeleniumBaseEngine):
    """Engine Selenium especializado para o Chrome."""
