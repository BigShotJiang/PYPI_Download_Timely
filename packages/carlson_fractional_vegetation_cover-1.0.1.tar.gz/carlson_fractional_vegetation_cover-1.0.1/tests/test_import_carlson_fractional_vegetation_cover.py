def test_import_carlson_fractional_vegetation_cover():
    import carlson_fractional_vegetation_cover
