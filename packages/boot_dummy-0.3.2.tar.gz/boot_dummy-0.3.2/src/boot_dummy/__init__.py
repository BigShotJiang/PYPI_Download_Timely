"""
Dummy data generator.

Creates a DataFrame with fake data.
"""

from .dummy import GenerateData

__version__ = "0.3.2"
__all__ = ["GenerateData"]
