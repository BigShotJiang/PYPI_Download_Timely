"""
test the generated data
"""