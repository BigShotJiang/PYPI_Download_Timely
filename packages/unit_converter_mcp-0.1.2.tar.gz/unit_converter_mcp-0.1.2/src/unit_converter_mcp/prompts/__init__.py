"""Prompts package for unit converter MCP."""
