"""Unit Converter MCP Server package."""

__version__ = "0.1.2"

from .server import app

__all__ = ["app"]
