# Sphinx-Table-Support

A collection of directives for different table languages
