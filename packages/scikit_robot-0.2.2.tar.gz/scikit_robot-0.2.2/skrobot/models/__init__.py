# flake8: noqa

from skrobot.models.fetch import Fetch
from skrobot.models.kuka import Kuka
from skrobot.models.panda import Panda
from skrobot.models.pr2 import PR2
