from .base import StaticFiles

__all__ = ["StaticFiles"]
