import asyncio

from anthropic import Anthropic, AsyncAnthropic
from .base import ModelProvider, ModelResponse

class AnthropicProvider(ModelProvider):
    def __init__(self, max_concurrency: int = 5):
        super().__init__()

        self.client = Anthropic()
        self.async_client = AsyncAnthropic()
        self.semaphore = asyncio.Semaphore(max_concurrency)


    def generate(self, prompt: str, **kwargs) -> str:
        """
        Get a completion for the given prompt using Anthropic's API.

        Args:
            prompt (str): The input prompt to complete.
            **kwargs: Additional parameters for the model.

        Returns:
            str: The model's completion for the prompt.
        """
        message = self.client.messages.create(
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": prompt
                        }
                    ]
                }
            ],
            **kwargs
            )


        return ModelResponse(
            text=message.content[0].text,
            prompt=prompt,
            token_count=0,
            cost=0,
            response_time_ms=0,
            metadata={},
            raw_response=message
            )
    
    async def agenerate(self, prompt: str, **kwargs) -> str:
        """
        Asynchronously get a completion for the given prompt using Anthropic's API.

        Args:
            prompt (str): The input prompt to complete.
            **kwargs: Additional parameters for the model.

        Returns:
            str: The model's completion for the prompt.
        """
        async with self.semaphore:
            message = await self.async_client.messages.create(
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": prompt
                            }
                        ]
                    }
                ],
                **kwargs
                )

            return ModelResponse(
                text=message.content[0].text,
                prompt=prompt,
                token_count=0,
                cost=0, 
                response_time_ms=0,
                metadata={},
                raw_response=message
                )
    
    def get_tokens(self, prompt: str) -> int:
        """
        Calculate the number of input tokens for the given prompt.

        Args:
            prompt (str): The input prompt to analyze.

        Returns:
            int: The number of input tokens in the prompt.
        """
        pass


    def get_cost(self, input_tokens: int, output_tokens: int) -> float:
        """
        Calculate the cost for the given input and output tokens.

        Args:
            input_tokens (int): The number of input tokens.
            output_tokens (int): The number of output tokens.

        Returns:
            float: The cost for the completion.
        """
        pass