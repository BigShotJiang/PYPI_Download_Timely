{{cookiecutter.project}} project
===================

Read the `Documentation <https://camptocamp.github.io/c2cgeoportal/{{cookiecutter.geomapfish_main_version}}/>`_

Checkout
--------

.. code::

   git clone git@github.com:camptocamp/{{cookiecutter.project}}.git

   cd {{cookiecutter.project}}

Build
-----

.. code::

  ./build

Run
---

.. code::

   docker compose up -d

.. Feel free to add project-specific things.
