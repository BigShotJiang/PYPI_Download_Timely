# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from typing_extensions import TypeAlias

from .match import Match

__all__ = ["FindTextResponse"]

FindTextResponse: TypeAlias = List[Match]
