# medimm
PyTorch Medical 3D Image Models

## Installation
Make sure that you have installed [torch](https://pytorch.org/) compatible with your CUDA version.

Then install via pip
```
pip install medimm
```