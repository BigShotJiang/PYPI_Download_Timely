def test_it_imports():
    import obsidiana  # noqa: F401, PLC0415
