"""This package will contain models for FIWAREs NGSI-LD APIs"""
