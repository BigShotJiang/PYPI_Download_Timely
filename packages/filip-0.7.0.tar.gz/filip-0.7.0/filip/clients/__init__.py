"""
Clients to interact with FIWARE's APIs
"""
