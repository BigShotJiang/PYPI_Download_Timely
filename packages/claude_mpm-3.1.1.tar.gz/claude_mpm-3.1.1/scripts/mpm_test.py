#!/usr/bin/env python3
"""Simple test script that prints Hello World."""


def main():
    """Print Hello World."""
    print("Hello World")


if __name__ == "__main__":
    main()