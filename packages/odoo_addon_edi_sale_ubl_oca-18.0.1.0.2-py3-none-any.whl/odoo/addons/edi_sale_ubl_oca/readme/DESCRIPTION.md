Configuration and special behaviors for EDI UBL exchanges related to sales.

Takes care of:

* define SO and SO line states (according to PEPPOL states definition)
* compute the edi state for SO and SO line
* add state info on SO views
