from dataclasses import dataclass


@dataclass
class FeeId:
    fee_id: int
