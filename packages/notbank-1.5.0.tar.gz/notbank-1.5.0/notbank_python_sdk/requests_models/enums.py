# requests_models/get_enums.py
from dataclasses import dataclass


@dataclass
class GetEnumsRequest:
    pass
