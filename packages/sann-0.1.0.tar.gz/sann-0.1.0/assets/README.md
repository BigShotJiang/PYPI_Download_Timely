# Asset Information

The robot-love logo was obtained from
[https://www.svgrepo.com/svg/452659/robot-love](https://www.svgrepo.com/svg/452659/robot-love).
It is part of the Creative Commons [CC-BY](https://creativecommons.org/licenses/by/4.0/)
licenced Doodle Library by [Vector Doodle](https://vectordoodle.gumroad.com/).

The original file was edited to create the three versions found within this
directory: black, white and grey.