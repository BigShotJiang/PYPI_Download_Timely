"""
인증 관련 유틸리티, 토큰 파서, 인증 상태 객체 등을 정의합니다.
예: access token 유효성 검증 함수 등
"""

def sample_verify_token(token: str) -> bool:
    return token == "valid-token"
