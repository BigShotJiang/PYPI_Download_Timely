"""
시스템 전역에서 사용하는 상수 정의 (상태값, 역할, 키 등)
"""

SYSTEM_NAME = "OASIS-SHARED"
