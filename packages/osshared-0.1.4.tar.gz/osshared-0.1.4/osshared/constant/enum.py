from enum import Enum

class enumSampleStatus(str, Enum):
    OK = "ok"
    ERROR = "error"
