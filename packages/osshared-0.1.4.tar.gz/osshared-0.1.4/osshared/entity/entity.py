"""
공통 도메인 엔티티 정의 (예: BaseEntity, Timestamp 등)
"""

class BaseEntity:
    created_at: str = ""
    updated_at: str = ""
