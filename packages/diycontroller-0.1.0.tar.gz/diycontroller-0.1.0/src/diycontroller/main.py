# stress-timer_oce4nm4n/main.py

from .receiver import main as receiver_main

def main():
    receiver_main()
