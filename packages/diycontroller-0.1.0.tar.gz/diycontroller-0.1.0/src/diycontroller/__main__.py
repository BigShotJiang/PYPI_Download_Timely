# stress-timer_oce4nm4n/__main__.py

from .receiver import main as receiver_main

def main():
    receiver_main()

if __name__ == "__main__":
    main()
