---
adr_id: "{{id}}"        # YYYY-MM-DD-nnn
title: "{{title}}"
status: "Proposed | Accepted | Superseded | Deprecated"
deciders: ["{{architect_name}}", "{{pm_name}}", …]
date: "{{ISO-8601}}"
supersedes: []          # older ADR ids
---

# Context
(Why this decision is needed)

# Decision
(We chose X over Y because…)

# Consequences
(Positive/negative trade-offs)

# Alternatives
(List rejected options with short rationale)