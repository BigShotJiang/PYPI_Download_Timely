---
epic_id: "{{id}}"
source_prd: "{{prd_section}}"
owner: "{{to-be-filled}}"
---

# Epic {{id}} — {{title}}

## Goal

(One sentence)

## Acceptance Criteria

- [ ] …

## Out-of-Scope

- …

## Notes

(Dependencies, risks, links to UI mocks, etc.)
