The source code is coped from [0491df2](https://github.com/pprcht/gfnff/tree/0491df2ff1fe3cd80fc6a8630fea16f9b6840996) in [pprcht/gfnff](https://github.com/pprcht/gfnff/).
