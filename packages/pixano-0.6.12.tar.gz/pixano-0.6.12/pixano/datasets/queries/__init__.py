# =====================================
# Copyright: CEA-LIST/DIASI/SIALV/LVA
# Author : pixano@cea.fr
# License: CECILL-C
# =====================================

from .table import TableQueryBuilder


__all__ = ["TableQueryBuilder"]
