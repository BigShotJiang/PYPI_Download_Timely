from django.dispatch import Signal

search_filter = Signal()
update_cache_document = Signal()
search_index_rebuilt = Signal()
