from django.apps import AppConfig


class TorqueConfig(AppConfig):
    name = "torque"
