"""Git-Glance: A CLI tool to track multiple Git repositories"""
__version__ = "1.3.0"
__author__ = "Harshit Thota"
__description__ = "Git-Glance: A CLI tool to track multiple Git"