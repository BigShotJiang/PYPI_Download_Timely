# How to enable debug logging?
1. Add in **connection_config.ini** file from the root directory of the project:
```
[debug]
__DEV = true
```
