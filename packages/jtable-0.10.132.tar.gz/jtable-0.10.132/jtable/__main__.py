#!/usr/bin/env python3
import jtable.main

jtable.main.main()