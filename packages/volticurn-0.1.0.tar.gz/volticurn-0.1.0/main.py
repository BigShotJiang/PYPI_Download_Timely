def main():
    print("Hello from volticurn!")


if __name__ == "__main__":
    main()
