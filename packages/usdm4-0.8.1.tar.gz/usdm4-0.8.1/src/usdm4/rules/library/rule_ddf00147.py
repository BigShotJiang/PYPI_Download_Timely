from usdm3.rules.library.rule_ddf00147 import RuleDDF00147 as V3Rule


class RuleDDF00147(V3Rule):
    pass
