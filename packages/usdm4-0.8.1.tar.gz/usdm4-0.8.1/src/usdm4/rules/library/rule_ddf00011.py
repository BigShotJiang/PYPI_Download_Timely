from usdm3.rules.library.rule_ddf00011 import RuleDDF00011 as V3Rule


class RuleDDF00011(V3Rule):
    pass
