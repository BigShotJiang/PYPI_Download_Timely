from rich.theme import Theme

poly_theme = Theme(
    {
        "data": "#999966",
        "proj": "#8A2BE2",
        "comp": "#32CD32",
        "base": "#6495ED",
    }
)

check_emoji = ":heavy_check_mark:"
