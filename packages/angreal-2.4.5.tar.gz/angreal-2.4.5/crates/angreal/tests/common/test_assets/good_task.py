import json


def task():
    data = dict(test='data')
    data = json.load(data)
    print(data)
    return
