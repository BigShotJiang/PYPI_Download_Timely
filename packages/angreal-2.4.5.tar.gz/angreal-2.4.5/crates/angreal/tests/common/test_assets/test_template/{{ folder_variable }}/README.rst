{{ variable_text }}
