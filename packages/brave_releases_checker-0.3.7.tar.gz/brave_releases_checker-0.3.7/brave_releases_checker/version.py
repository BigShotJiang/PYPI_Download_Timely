#!/usr/bin/env python3
# -*- coding: utf-8 -*-

__version__: str = '0.3.7'
