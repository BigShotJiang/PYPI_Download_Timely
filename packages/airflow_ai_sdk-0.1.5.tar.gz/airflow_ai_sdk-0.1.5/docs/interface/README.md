# Public Interface Documentation

This directory contains auto-generated documentation for the public interface of the `airflow_ai_sdk` package. The files are organized into folders that match the SDK's package layout. To regenerate these files run:

```bash
uv run python scripts/generate_interface_docs.py
```
