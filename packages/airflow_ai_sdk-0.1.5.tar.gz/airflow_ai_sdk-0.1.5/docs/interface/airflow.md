# airflow_ai_sdk.airflow

This module provides compatibility layer for Airflow 2.x and 3.x by importing the necessary
decorators, operators, and context utilities from the appropriate Airflow version.
