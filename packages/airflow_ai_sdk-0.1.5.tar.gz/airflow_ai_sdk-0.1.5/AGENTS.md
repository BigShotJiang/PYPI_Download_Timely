Refer to .github/workflows/ci.yaml for examples on how to run tests and linting.
