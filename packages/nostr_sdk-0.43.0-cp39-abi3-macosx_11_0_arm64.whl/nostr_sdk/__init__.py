from nostr_sdk.nostr_sdk import *
from nostr_sdk.nostr_sdk import uniffi_set_event_loop
