"""Módulo de inicialización para el analizador léxico de Cobra."""
