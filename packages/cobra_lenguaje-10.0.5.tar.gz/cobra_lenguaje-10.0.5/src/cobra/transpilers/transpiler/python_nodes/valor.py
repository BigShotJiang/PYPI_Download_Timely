def visit_valor(self, nodo):
    self.codigo += self.obtener_valor(nodo)
