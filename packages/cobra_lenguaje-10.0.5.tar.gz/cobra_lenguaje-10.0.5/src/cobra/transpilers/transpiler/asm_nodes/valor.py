def visit_valor(self, nodo):
    self.agregar_linea(self.obtener_valor(nodo))
