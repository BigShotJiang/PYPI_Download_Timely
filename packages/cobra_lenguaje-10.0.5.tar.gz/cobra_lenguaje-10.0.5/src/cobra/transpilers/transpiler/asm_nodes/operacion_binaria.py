def visit_operacion_binaria(self, nodo):
    self.agregar_linea(self.obtener_valor(nodo))
