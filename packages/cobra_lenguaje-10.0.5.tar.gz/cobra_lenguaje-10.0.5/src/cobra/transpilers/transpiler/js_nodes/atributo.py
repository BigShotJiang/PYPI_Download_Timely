def visit_atributo(self, nodo):
    self.agregar_linea(self.obtener_valor(nodo))
