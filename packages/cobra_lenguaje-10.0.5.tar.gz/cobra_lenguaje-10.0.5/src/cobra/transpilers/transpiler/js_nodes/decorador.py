# Este nodo no genera salida directa; se maneja en visit_funcion

def visit_decorador(self, nodo):
    pass
