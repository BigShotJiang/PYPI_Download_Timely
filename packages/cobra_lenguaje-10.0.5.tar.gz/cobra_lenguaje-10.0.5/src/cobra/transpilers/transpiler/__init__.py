"""Herramientas para convertir el AST de Cobra a otros lenguajes."""

# Este módulo define herramientas de transpilación a diferentes lenguajes.
