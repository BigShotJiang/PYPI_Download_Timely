"""Herramientas experimentales de inteligencia artificial aplicadas a Cobra."""
