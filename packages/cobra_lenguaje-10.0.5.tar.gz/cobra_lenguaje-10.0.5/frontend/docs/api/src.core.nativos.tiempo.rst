src.core.nativos.tiempo module
------------------------------

.. automodule:: src.core.nativos.tiempo
   :members:
   :undoc-members:
   :show-inheritance:
