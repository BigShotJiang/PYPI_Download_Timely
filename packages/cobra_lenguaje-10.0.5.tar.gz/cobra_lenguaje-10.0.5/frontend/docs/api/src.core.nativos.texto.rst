src.core.nativos.texto module
-----------------------------

.. automodule:: src.core.nativos.texto
   :members:
   :undoc-members:
   :show-inheritance:
