﻿tests.make\_all\_bytes
======================

.. currentmodule:: tests

.. autodata:: make_all_bytes
