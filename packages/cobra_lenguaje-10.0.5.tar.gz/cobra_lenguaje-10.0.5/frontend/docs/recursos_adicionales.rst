Recursos adicionales
====================

Enlaces útiles relacionados con Cobra.

- `Guía básica <../../docs/guia_basica.md>`_
- `Especificación técnica <../../docs/especificacion_tecnica.md>`_
- `Cheatsheet (LaTeX) <../../docs/cheatsheet.tex>`_ – compílalo a PDF
- `Casos de uso reales <../../docs/casos_reales.md>`_
