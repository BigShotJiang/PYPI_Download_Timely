from .dynamodb import DynamoDBAthenaSynchronizer

__all__ = [
    "DynamoDBAthenaSynchronizer",
]
