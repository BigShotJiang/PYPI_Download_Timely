import uuid


class ExecutorObj(object):
    def __init__(self):
        self.id = str(uuid.uuid4())
