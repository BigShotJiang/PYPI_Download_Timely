#!/usr/bin/env python3
"""
Entry point for running ai_audio_detector as a module.
"""

from ai_audio_detector import main

if __name__ == "__main__":
    main()
