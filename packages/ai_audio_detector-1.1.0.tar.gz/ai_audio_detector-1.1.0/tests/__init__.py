"""
Test suite for AI Audio Detector
"""
