This addon is a base module used for all iot modules.
