def greet(name="Developer"):
    return f"Hello, {name}! Welcome to pydevplus."
