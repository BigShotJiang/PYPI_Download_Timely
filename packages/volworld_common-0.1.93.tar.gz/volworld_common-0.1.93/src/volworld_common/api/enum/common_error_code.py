from aenum import IntEnum


class CommonErrorCode(IntEnum):
    NoError = -1
