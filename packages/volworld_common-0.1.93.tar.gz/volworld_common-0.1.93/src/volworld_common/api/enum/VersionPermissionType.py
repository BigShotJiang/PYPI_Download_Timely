from enum import IntEnum

class VersionPermissionType(IntEnum):
    Private = 0
    Public = 1
    AdminBlocked = 2


