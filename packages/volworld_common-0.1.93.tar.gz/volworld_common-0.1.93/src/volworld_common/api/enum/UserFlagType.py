from enum import IntEnum

class UserFlagType(IntEnum):
    FirstLogin = 1,
    CompletedTutorialStage = 2,
