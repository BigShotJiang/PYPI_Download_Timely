from typing import Final

class UraniaDefaultTutorialLane:
    class InitTutorial:
        UUID: Final[str] = "6219eda6-329e-4aa7-adbf-1ac4501cba34"