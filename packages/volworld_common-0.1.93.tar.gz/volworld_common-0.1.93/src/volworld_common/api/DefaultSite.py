from typing import Final

class GaiaDefaultTutorialSite:
    class InitTutorial1:
        UUID: Final[str] = "c42edc7f-f382-40c6-b042-68858daa8ec3"
    class InitTutorial2:
        UUID: Final[str] = "26630f2f-ab60-417f-bae9-a3cb7385692f"
    class InitTutorial3:
        UUID: Final[str] = "5a2edb29-5d2b-49af-8456-57e332a33e8f"
    class InitTutorial4:
        UUID: Final[str] = "608eb0b8-8472-44db-82a8-46ec6fc390c8"
    class InitTutorial5:
        UUID: Final[str] = "ff34c88d-9f61-4002-98f9-aa54689f02f4"
