# codingnow/core.py

def hello_world():
    return "Hello, CodingNow!"