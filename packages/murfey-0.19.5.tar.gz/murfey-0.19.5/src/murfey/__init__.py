from __future__ import annotations

__version__ = "0.19.5"
__supported_client_version__ = "0.19.5"
