#!/usr/bin/env python

from __future__ import annotations

from setuptools import setup

if __name__ == "__main__":
    # Do not add any parameters here. Edit pyproject.toml instead.
    setup()
