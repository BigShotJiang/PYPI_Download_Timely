# `gima` quick manual

`gima` is a `Python` software which simplifies managing many git repositories through the console. It stands for [GI]t [MA]nager.

[bold magenta]World[/bold magenta]

## Important links:

	Home page: https://gitlab.com/ahypki/gima/
	Issues: https://gitlab.com/ahypki/gima/-/issues/

