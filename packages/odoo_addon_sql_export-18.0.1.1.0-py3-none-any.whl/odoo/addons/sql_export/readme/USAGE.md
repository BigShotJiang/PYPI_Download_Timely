Dashboards \> Sql Export

**Specific use with parameters**

- %(company_id)s allows to set in the query the company id of the user
- %(user_id)s allows to set in the query the user id
- for any created property, you can use it with %(Property String)s
  syntax
