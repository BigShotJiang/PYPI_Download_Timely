"""
Exports FlowMarkup class for styled text rendering in flowmotion.
"""

from .flow_markup import FlowMarkup

__all__ = ["FlowMarkup"]
