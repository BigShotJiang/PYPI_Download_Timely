Shiny App
----------

The web version of copepodTCR tool can be accessed at http://copepodtcr.cshl.edu/