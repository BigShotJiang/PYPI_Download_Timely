"""
Core logic, handler classes, and utilities for the main Janito CLI orchestration and sub-command processing.
Contains modules for setters, getters, event logger, and runner pipelines.
"""
