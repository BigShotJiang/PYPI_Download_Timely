from rich.console import Console

shared_console = Console()
