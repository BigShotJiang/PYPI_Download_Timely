var namespace_py_x_make_1_1_plugin =
[
    [ "__build", "namespace_py_x_make_1_1_plugin_1_1____build.html", [
      [ "build", "namespace_py_x_make_1_1_plugin_1_1____build.html#aca354d68db5f90dab88452a31cbd82c1", null ]
    ] ],
    [ "__git", "namespace_py_x_make_1_1_plugin_1_1____git.html", [
      [ "main", "namespace_py_x_make_1_1_plugin_1_1____git.html#a57c9362a3600794aa54cb19681362e3a", null ],
      [ "setup", "namespace_py_x_make_1_1_plugin_1_1____git.html#a8e79393c0e9bcf7044fe5d8a7cf82e7a", null ],
      [ "update", "namespace_py_x_make_1_1_plugin_1_1____git.html#a3153fa7e5f78cd587af74df0205a3088", null ]
    ] ],
    [ "__gitlab", "namespace_py_x_make_1_1_plugin_1_1____gitlab.html", [
      [ "check", "namespace_py_x_make_1_1_plugin_1_1____gitlab.html#a12ac8a5aee93cb5329f8bb0c232fad40", null ],
      [ "housekeeping", "namespace_py_x_make_1_1_plugin_1_1____gitlab.html#ae265e6640350400d8b38046536cb5dbf", null ],
      [ "main", "namespace_py_x_make_1_1_plugin_1_1____gitlab.html#ab863e16067c5f2f48c096da250b3af7d", null ],
      [ "release", "namespace_py_x_make_1_1_plugin_1_1____gitlab.html#a64f98e813c8446b83ddde0b7089470f5", null ]
    ] ],
    [ "__poetry", "namespace_py_x_make_1_1_plugin_1_1____poetry.html", "namespace_py_x_make_1_1_plugin_1_1____poetry" ],
    [ "main", "namespace_py_x_make_1_1_plugin.html#ac94bd3c49fc6def7667f52c323745792", null ]
];