var searchData=
[
  ['handle_0',['handle',['../namespace_py_x_make_1_1_v_t_l_1_1api.html#a671644b7f4ec7457c902333653acd2b0',1,'PyXMake::VTL::api']]],
  ['housekeeping_1',['housekeeping',['../namespace_py_x_make_1_1_plugin_1_1____gitlab.html#ae265e6640350400d8b38046536cb5dbf',1,'PyXMake::Plugin::__gitlab']]]
];
