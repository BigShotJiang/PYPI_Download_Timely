--------------------------------
Create an archive of the project
--------------------------------

.. literalinclude:: ../../../templates/project-archive/template.yml
   :language: yaml