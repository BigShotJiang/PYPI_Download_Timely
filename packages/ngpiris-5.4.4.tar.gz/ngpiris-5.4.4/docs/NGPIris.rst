NGPIris package
===============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   NGPIris.cli
   NGPIris.hci
   NGPIris.hcp
   NGPIris.parse_credentials
   NGPIris.utils

Module contents
---------------

.. automodule:: NGPIris
   :members:
   :undoc-members:
   :show-inheritance:
