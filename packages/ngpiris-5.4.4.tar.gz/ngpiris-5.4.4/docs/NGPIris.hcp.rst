NGPIris.hcp package
===================

Submodules
----------

NGPIris.hcp.exceptions module
-----------------------------

.. automodule:: NGPIris.hcp.exceptions
   :members:
   :undoc-members:
   :show-inheritance:

NGPIris.hcp.hcp module
----------------------

.. automodule:: NGPIris.hcp.hcp
   :members:
   :undoc-members:
   :show-inheritance:

NGPIris.hcp.helpers module
--------------------------

.. automodule:: NGPIris.hcp.helpers
   :members:
   :undoc-members:
   :show-inheritance:

NGPIris.hcp.statistics module
-----------------------------

.. automodule:: NGPIris.hcp.statistics
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: NGPIris.hcp
   :members:
   :undoc-members:
   :show-inheritance:
