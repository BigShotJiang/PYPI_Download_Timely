from .trainee import DirectTrainee

__all__ = [
    "DirectTrainee"
]
