# cycles
[![View build status](https://github.com/feihoo87/cycles/actions/workflows/workflow.yml/badge.svg)](https://github.com/feihoo87/cycles/)
[![Coverage Status](https://coveralls.io/repos/github/feihoo87/cycles/badge.svg?branch=main)](https://coveralls.io/github/feihoo87/cycles?branch=main)
[![PyPI version](https://badge.fury.io/py/pycycles.svg)](https://pypi.org/project/pycycles/)

Permutation and permutation groups

## Reporting Issues
Please report all issues [on github](https://github.com/feihoo87/cycles/issues).

## License

[MIT](https://opensource.org/licenses/MIT)
