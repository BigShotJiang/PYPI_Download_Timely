#ifndef __CYCLES_H__
#define __CYCLES_H__

#include <stdint.h>

#endif /* __CYCLES_H__ */