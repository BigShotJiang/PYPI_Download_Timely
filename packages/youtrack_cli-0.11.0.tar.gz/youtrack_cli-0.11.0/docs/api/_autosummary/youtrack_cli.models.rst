youtrack\_cli.models
====================

.. automodule:: youtrack_cli.models


   .. rubric:: Classes

   .. autosummary::

      ApiResponse
      CachedResponse
      CredentialVerificationResult
      YouTrackArticle
      YouTrackAttachment
      YouTrackBoard
      YouTrackComment
      YouTrackCustomField
      YouTrackErrorResponse
      YouTrackIssue
      YouTrackIssueTag
      YouTrackLocale
      YouTrackLocaleSettings
      YouTrackProject
      YouTrackReport
      YouTrackSearchResult
      YouTrackTimeTracking
      YouTrackUser
      YouTrackWorkItem
