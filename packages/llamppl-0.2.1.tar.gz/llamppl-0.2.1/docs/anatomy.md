# Anatomy of a LLaMPPL model
