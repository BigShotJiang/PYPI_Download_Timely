tagname = "v0.0.6"
version = tagname[1:]
