from .noise import NativeNoise as NativeNoise
