from lmms_eval.models.video_chatgpt.model.video_chatgpt import (
    VideoChatGPTConfig,
    VideoChatGPTLlamaForCausalLM,
)
