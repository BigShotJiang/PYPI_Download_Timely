from .nlpg import get_password
from .nlpg import NaturalLanguagePassword

__version__ = "v0.1.1"

__all__ = [
    "NaturalLanguagePassword",
    "get_password",
]
