from toyaikit.__version__ import __version__
