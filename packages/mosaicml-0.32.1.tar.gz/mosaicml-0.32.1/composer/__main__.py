# Copyright 2022 MosaicML Composer authors
# SPDX-License-Identifier: Apache-2.0

"""Runs the Composer CLI."""

from composer.cli import __main__  # noqa: F401
