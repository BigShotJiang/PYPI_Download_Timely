<!--
SPDX-FileCopyrightText: 2025 Free Software Foundation Europe e.V. <mp-explore@fsfe.org>

SPDX-License-Identifier: AGPL-3.0-or-later
-->

# MP Scrape CLI

> MP Scrape has been renamed to MP Explore.
> Replace all references from mp-scrape* to mp-explore*
> 
> Thank you for your understanding

https://git.fsfe.org/mp-explore
