# SPDX-FileCopyrightText: 2025 Free Software Foundation Europe e.V. <mp-explore@fsfe.org>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

if __name__ == "__main__":
    print("╔════════════════════════════════════════════════════════╗")
    print("║        MP Scrape has been renamed to MP Explore        ║")
    print("║  Replace all references from mp-scrape* to mp-explore* ║")
    print("║            Thank you for your understanding            ║")
    print("║                                                        ║")
    print("║ MP Explore Team                                        ║")
    print("║ https://git.fsfe.org/mp-explore                        ║")
    print("║ contact@fsfe.org                                       ║")
    print("╚════════════════════════════════════════════════════════╝")