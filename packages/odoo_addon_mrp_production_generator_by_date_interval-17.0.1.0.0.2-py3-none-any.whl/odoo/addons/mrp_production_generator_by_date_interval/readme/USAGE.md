1. Go to _Manufacturing > Planning > Production Generator_
2. Select the product and the BoM to be used
3. Select the period during which the orders should be created
4. Select the time at which the orders should be scheduled
5. Press **Create Productions**

You will see all the production orders created for each day
