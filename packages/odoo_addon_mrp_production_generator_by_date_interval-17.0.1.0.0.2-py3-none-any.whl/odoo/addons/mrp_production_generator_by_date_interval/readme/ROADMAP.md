This module does not take into account
that more than one MO may be generated per day.
