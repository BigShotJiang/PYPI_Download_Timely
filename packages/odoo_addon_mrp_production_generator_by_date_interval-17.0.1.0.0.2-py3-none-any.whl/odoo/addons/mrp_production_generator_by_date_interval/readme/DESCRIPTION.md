This module allows planning multiple manufacturing orders in a single action using
a wizard that lets you define a period during which the orders will be created and
at what time they should be scheduled, based on a product and a bill of materials.
