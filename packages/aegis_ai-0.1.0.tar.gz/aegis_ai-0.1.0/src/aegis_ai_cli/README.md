# Aegis built in CLI

A minimal cli (based on click) mainly for testing purposes

```commandline
uv run aegis suggest-impact "CVE-2024-12345"
```
