# Aegis web

A minimal web server (based on fastapi) mostly to illustrate how to integrate Aegis and test with it.

```commandline
uv run uvicorn src.aegis_ai_web.main:app --port 8000
```

## Developer console

## REST-API

