# Example chat


To start up chat web application:
```commandline
uv run uvicorn aegis_chat.chat_app:app --port 9001 --reload
```