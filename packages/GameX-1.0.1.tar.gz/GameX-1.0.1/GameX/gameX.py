# 英文名：GameX
import pygame
import os
import sys
import math

print("Welcome to GameX, a product developed using Pygame!")

# 游戏窗口对象（通过display.set_window初始化）
screen = pygame.display.set_mode
# 游戏时钟对象（通过display.set_window初始化，用于控制帧率）
clock = pygame.time.Clock
# 存储所有角色/绘图对象的列表，用于图层管理和渲染
role_list = list()


def _get_image(i):
    """
    处理角色/绘图对象的图像变换（缩放、旋转、翻转、透明度）
    :param i: 角色(role)或绘图(pen)对象
    :return: 处理后的Pygame图像对象
    """
    # 获取当前造型图像
    image = i.sculpt_list[i.sculpt_number]
    # 获取图像原始尺寸
    width, high = image.get_size()
    # 处理缩放（结合整体缩放比例和宽高单独缩放比例）
    image = pygame.transform.scale(
        image,
        (i.scale * i.width_scale * width, i.scale * i.high_scale * high)
    )
    # 处理旋转（基于面向角度）
    image = pygame.transform.rotate(image, i.facing_angle)
    # 处理翻转（左右/上下翻转）
    image = pygame.transform.flip(image, i.flip_x, i.flip_y)
    # 处理透明度（alpha范围0-100，转换为Pygame的0-255）
    image.set_alpha(255 - i.alpha * 2.55)
    return image


class display:
    """窗口管理类，负责游戏窗口的初始化、刷新、标题设置等"""

    @staticmethod
    def set_window(size=(800, 600), title="GameX!"):
        """
        初始化Pygame并创建游戏窗口
        :param size: 窗口尺寸，默认为(800, 600)
        :param title: 窗口标题，默认为"GameX!"
        """
        pygame.init()
        global screen, clock
        screen = screen(size)  # 初始化窗口
        clock = pygame.time.Clock()  # 初始化时钟
        pygame.display.set_caption(title)  # 设置窗口标题

    @staticmethod
    def set_title(title):
        """
        修改窗口标题
        :param title: 新标题字符串
        """
        global screen
        pygame.display.set_caption(title)

    @staticmethod
    def fill(rgb: tuple = (255, 255, 255)):
        """
        用指定颜色填充屏幕
        :param rgb: RGB颜色元组，默认为白色(255,255,255)
        """
        screen.fill(rgb)

    @staticmethod
    def enable_exit():
        """检测窗口关闭事件，触发时退出程序"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()

    @staticmethod
    def update():
        """
        刷新屏幕，渲染所有角色和绘图对象
        按role_list中的顺序渲染（靠前元素层级更低）
        """
        # 遍历所有角色/绘图对象并渲染
        for i in role_list:
            if isinstance(i, role):
                # 跳过无造型或不显示的角色
                if i.sculpt_number is None or not i.show:
                    continue
                # 获取处理后的图像
                image = _get_image(i)
                width, high = image.get_size()
                # 计算绘制坐标（图像中心与角色位置对齐）
                x = i.position.real_x - width * 0.5
                y = i.position.real_y - high * 0.5
                screen.blit(image, (x, y))  # 绘制角色
            elif isinstance(i, pen):
                # 绘制绘图层（pen对象）
                screen.blit(i.layer, (0, 0))
        # 更新屏幕显示
        pygame.display.update()

    @staticmethod
    def tick(FPS):
        """
        控制游戏帧率
        :param FPS: 每秒刷新次数（帧率）
        """
        global clock
        clock.tick(FPS)


class position:
    """坐标处理类，采用以屏幕中心为原点的坐标系统"""

    def __init__(self, x, y):
        """
        初始化坐标
        :param x: 相对于屏幕中心的X坐标（右为正）
        :param y: 相对于屏幕中心的Y坐标（上为正）
        """
        self.x = x
        self.y = y

    @property
    def real_x(self):
        """转换为屏幕绝对X坐标（左上角为原点）"""
        return screen.get_size()[0] * 0.5 + self.x

    @property
    def real_y(self):
        """转换为屏幕绝对Y坐标（左上角为原点）"""
        return screen.get_size()[1] * 0.5 - self.y


class role:
    """游戏角色类，支持角色移动、造型切换、碰撞检测等功能"""

    def __init__(self):
        super().__init__()
        self.position = position(0, 0)  # 角色坐标（基于position类）
        self.sculpt_list = list()  # 角色造型列表（存储Pygame图像对象）
        self.sculpt_number = None  # 当前造型索引（None表示无造型）
        self.scale = 1  # 整体缩放比例（1表示100%）
        self.width_scale = 1  # 宽度单独缩放比例
        self.high_scale = 1  # 高度单独缩放比例
        self.facing_angle = 0  # 面向角度（度，0为右，逆时针递增）
        self.show = True  # 是否显示角色
        self.flip_x = False  # 是否左右翻转
        self.flip_y = False  # 是否上下翻转
        self.mask = None  # 碰撞掩码（用于精确碰撞检测）
        self.alpha = 0  # 透明度（0不透明，100完全透明）
        role_list.append(self)  # 将角色加入全局列表

    def add_sculpt(self, *sculpt_path_list):
        """
        向角色添加造型（仅支持gif格式）
        :param sculpt_path_list: 一个或多个造型文件路径
        :raises FileFindError: 文件不存在时触发
        :raises FileFormatError: 文件格式不是gif时触发
        """
        for i in sculpt_path_list:
            if not os.path.exists(i):
                raise f"FileFindError: Can not find {i}"
            if os.path.splitext(os.path.basename(i))[1] not in ['.gif']:
                raise "FileFormatError: The file format is incorrect"
            self.sculpt_list.append(pygame.image.load(i))
        # 若未设置当前造型，默认使用第一个
        if self.sculpt_number is None:
            self.sculpt_number = 0

    def next_sculpt(self, number=1):
        """
        切换到下一个造型（循环切换）
        :param number: 切换次数（正数向后，负数向前）
        :raises SculptError: 角色无造型时触发
        """
        if self.sculpt_number is None:
            raise "SculptError: Role has not sculpt"
        else:
            self.sculpt_number = (self.sculpt_number + number) % len(self.sculpt_list)

    def forward(self, number: int):
        """
        沿角色面向角度移动指定距离
        :param number: 移动距离（正数向前，负数向后）
        """
        # 将角度转换为弧度，计算X/Y方向位移
        x = number * math.cos(math.radians(self.facing_angle))
        y = number * math.sin(math.radians(self.facing_angle))
        self.position.x += x
        self.position.y += y

    def left_right_flip(self):
        """切换角色左右翻转状态（不改变面向角度）"""
        self.flip_x = bool(1 - self.flip_x)

    def up_down_flip(self):
        """切换角色上下翻转状态（不改变面向角度）"""
        self.flip_y = bool(1 - self.flip_y)

    def adjust_layer(self, mode: str):
        """
        调整角色在渲染层级中的位置
        :param mode: 调整模式（'up'上移一层/'down'下移一层/'top'移至顶层/'bottom'移至背景上一层）
        :raises TypeError: 背景角色（层级0）移动时触发
        """

        def get_layer(i):
            """获取对象在role_list中的索引（即层级）"""
            return role_list.index(i)

        me_layer = get_layer(self)
        if me_layer == 0:
            raise TypeError('Background cannot move the layers')
        if mode == 'up':
            # 上移一层（已在顶层则不操作）
            if me_layer == len(role_list) - 1:
                return
            # 交换当前角色与上一层角色的位置
            temp = role_list[me_layer + 1]
            role_list[me_layer + 1] = role_list[me_layer]
            role_list[me_layer] = temp
        elif mode == 'down':
            # 下移一层（已在背景层上方则不操作）
            if me_layer == 1:
                return
            temp = role_list[me_layer - 1]
            role_list[me_layer - 1] = role_list[me_layer]
            role_list[me_layer] = temp
        elif mode == 'top':
            # 移至顶层
            role_list.pop(me_layer)
            role_list.append(self)
        elif mode == 'bottom':
            # 移至背景层上方
            role_list.pop(me_layer)
            role_list.insert(1, self)
        else:
            raise ValueError('Please select one of the options [up, down, top, bottom] for the pattern')

    def collide(self, target):
        """
        检测与目标对象的碰撞（基于图像掩码）
        :param target: 碰撞目标（角色或角色组）
        :return: 若碰撞返回目标对象，否则返回False
        :raises ValueError: 目标类型不支持时触发
        """
        self.mask = pygame.mask.from_surface(_get_image(self))
        if isinstance(target, role):
            target.mask = pygame.mask.from_surface(_get_image(target))
            # 计算目标相对于当前角色的偏移量
            x_offset = target.position.x - self.position.x
            y_offset = target.position.y - self.position.y
            # 检测掩码重叠
            result = self.mask.overlap(target.mask, (x_offset, y_offset))
            return target if result else False
        elif isinstance(target, pygame.sprite.Group):
            # 检测与角色组中所有角色的碰撞
            for temp in target:
                temp.mask = pygame.mask.from_surface(_get_image(temp))
                x_offset = temp.position.x - self.position.x
                y_offset = self.position.y - temp.position.y
                result = self.mask.overlap(temp.mask, (x_offset, y_offset))
                if result:
                    return temp
            return False
        else:
            raise ValueError('Two parties involved in collision detection must be two roles or a role and a role group')

    def died(self):
        """从游戏中移除角色（从全局列表和所有组中删除）"""
        self.kill()
        role_list.remove(self)

    def rotate(self, center_position: tuple[int, int], angle_degrees):
        """
        绕指定中心点旋转角色
        :param center_position: 中心点坐标（基于屏幕中心的相对坐标）
        :param angle_degrees: 旋转角度（度，逆时针为正）
        """
        theta = math.radians(angle_degrees)
        # 将中心点相对坐标转换为屏幕绝对坐标
        cx, cy = center_position[0] + screen.get_size()[0] * 0.5, screen.get_size()[0] * 0.5 - center_position[1]
        cos_theta = math.cos(theta)
        sin_theta = math.sin(theta)
        # 应用旋转公式计算新坐标（绝对坐标）
        x_prime = cx + (self.position.real_x - cx) * cos_theta - (self.position.real_y - cy) * sin_theta
        y_prime = cy + (self.position.real_x - cx) * sin_theta + (self.position.real_y - cy) * cos_theta
        # 将绝对坐标转回相对坐标
        self.position.x = x_prime - screen.get_size()[0] * 0.5
        self.position.y = screen.get_size()[1] * 0.5 - y_prime

    @staticmethod
    def new_group():
        """创建一个新的角色组（用于批量管理角色）"""
        return pygame.sprite.Group()


class mouse:
    """鼠标交互类，用于检测鼠标输入和碰撞"""

    def collide(self, role: role):
        """
        检测鼠标是否与角色碰撞
        :param role: 目标角色
        :return: 碰撞返回True，否则返回False
        """
        image = _get_image(role)
        role.mask = pygame.mask.from_surface(image)
        width, height = image.get_size()
        # 计算角色图像在屏幕上的矩形区域
        role_x, role_y = role.position.real_x - width * 0.5, role.position.real_y - height * 0.5
        # 先检测鼠标是否在矩形范围内，再检测掩码碰撞
        if role_x <= pygame.mouse.get_pos()[0] <= role_x + width and \
                role_y <= pygame.mouse.get_pos()[1] <= role_y + height:
            if role.mask.get_at((pygame.mouse.get_pos()[0] - role_x, pygame.mouse.get_pos()[1] - role_y)):
                return True
        return False

    def click(self, which):
        """
        检测指定鼠标按键是否被按下
        :param which: 按键标识（0/left：左键；1/middle：中键；2/right：右键）
        :return: 按下返回True，否则返回False
        :raises "ERROR": 按键标识无效时触发
        """
        if which == 0 or which == "left":
            return pygame.mouse.get_pressed()[0]
        elif which == 1 or which == "middle":
            return pygame.mouse.get_pressed()[1]
        elif which == 2 or which == "right":
            return pygame.mouse.get_pressed()[2]
        else:
            raise "ERROR"

    @property
    def x(self):
        """鼠标X坐标（基于屏幕中心的相对坐标，右为正）"""
        return pygame.mouse.get_pos()[0] - screen.get_size()[0] * 0.5

    @property
    def y(self):
        """鼠标Y坐标（基于屏幕中心的相对坐标，上为正）"""
        return screen.get_size()[1] * 0.5 - pygame.mouse.get_pos()[1]


class key:
    """键盘交互类，用于检测键盘输入"""

    @staticmethod
    def press(Key):
        """
        检测指定按键是否被按下
        :param Key: 按键名称（如"a"、"esc"等，支持Pygame按键常量对应字符串）
        :return: 按下返回True，否则返回False
        """
        if Key == "esc":
            return pygame.key.get_pressed()[pygame.key.key_code("escape")]
        return pygame.key.get_pressed()[pygame.key.key_code(Key)]


class sound:
    """音频管理类，用于加载和控制音频"""

    def __init__(self):
        """初始化音频 mixer 并创建音频字典"""
        pygame.mixer.init()
        self.music_dict = dict()  # 存储音频对象（键：音频名称，值：Pygame Sound对象）

    def load_sound(self, sound_name, sound_path):
        """
        加载音频文件并命名
        :param sound_name: 音频名称（用于后续调用）
        :param sound_path: 音频文件路径（支持mp3、wav）
        :raises FileFindError: 文件不存在时触发
        :raises FileFormatError: 文件格式不是mp3/wav时触发
        """
        if not os.path.exists(sound_path):
            raise f"FileFindError: Can not find {sound_path}"
        if os.path.splitext(os.path.basename(sound_path))[1] not in ['.mp3', '.wav']:
            raise "FileFormatError: The file format is incorrect.Pleace choice file.mp3 or file.wav"
        self.music_dict[sound_name] = pygame.mixer.Sound(sound_path)

    def play_sound(self, sound_name, channel=None, loops=1):
        """
        播放指定音频
        :param sound_name: 音频名称（加载时指定）
        :param channel: 播放通道（None为默认通道）
        :param loops: 循环次数（-1为无限循环）
        """
        if channel is None:
            self.music_dict[sound_name].play(loops=loops)
        else:
            self.music_dict[sound_name].play(channel, loops=loops)

    def set_channel(self, number: int):
        """
        设置音频播放通道数量
        :param number: 通道数量
        """
        pygame.mixer.set_num_channels(number)

    def set_volume(self, sound_name, volume):
        """
        设置音频音量
        :param sound_name: 音频名称
        :param volume: 音量值（0.0-1.0）
        """
        self.music_dict[sound_name].set_volume(volume)

    def stop_sound(self, sound_name):
        """
        停止指定音频播放
        :param sound_name: 音频名称
        """
        self.music_dict[sound_name].stop()

    def stop(self):
        """停止所有音频播放"""
        pygame.mixer.stop()

    def fadeout(self, sound_name, time: int):
        """
        平滑停止音频（音量逐渐减小至0）
        :param sound_name: 音频名称
        :param time: 淡出时间（毫秒）
        """
        self.music_dict[sound_name].fadeout(time)


class pen:
    """绘图工具类，用于在屏幕上绘制图形"""

    def __init__(self, width=None, high=None):
        """
        初始化绘图层
        :param width: 绘图层宽度（None为屏幕宽度）
        :param high: 绘图层高度（None为屏幕高度）
        """
        if not width or not high:
            width, high = screen.get_size()
        # 创建透明绘图表面（用于绘制图形）
        self.layer = pygame.surface.Surface((width, high)).convert_alpha()
        self.layer.fill((0, 0, 0, 0))  # 初始为全透明
        self.color = [0, 0, 0]  # 默认绘图颜色（黑色）
        role_list.append(self)  # 加入全局列表

    def draw_line(self, left_up: tuple[int, int], right_down: tuple[int, int]):
        """
        绘制直线
        :param left_up: 起点坐标（基于屏幕中心的相对坐标）
        :param right_down: 终点坐标（基于屏幕中心的相对坐标）
        """
        # 转换为屏幕绝对坐标
        x_1, y_1 = left_up[0] + screen.get_size()[0] * 0.5, screen.get_size()[1] * 0.5 - left_up[1]
        x_2, y_2 = right_down[0] + screen.get_size()[0] * 0.5, screen.get_size()[1] * 0.5 - right_down[1]
        pygame.draw.aaline(self.layer, self.color, (x_1, y_1), (x_2, y_2))

    def draw_rect(self, left_up: tuple[int, int], width, high):
        """
        绘制矩形
        :param left_up: 左上角坐标（基于屏幕中心的相对坐标）
        :param width: 矩形宽度
        :param high: 矩形高度
        """
        x_1, y_1 = left_up[0] + screen.get_size()[0] * 0.5, screen.get_size()[1] * 0.5 - left_up[1]
        pygame.draw.rect(self.layer, self.color, pygame.rect.Rect((x_1, y_1), (width, high)))

    def set_color(self, color_name):
        """
        设置绘图颜色（预设颜色）
        :param color_name: 颜色名称（支持red/orange/yellow/green/blue/black/white/cyan）
        :raises TypeError: 颜色名称不支持时触发
        """
        match color_name:
            case "red":
                self.color = [255, 0, 0]
            case "orange":
                self.color = [255, 165, 0]
            case "yellow":
                self.color = [255, 255, 0]
            case "green":
                self.color = [0, 255, 0]
            case "blue":
                self.color = [0, 0, 255]
            case "black":
                self.color = [0, 0, 0]
            case "white":
                self.color = [255, 255, 255]
            case "cyan":
                self.color = [0, 255, 255]
            case _:
                return TypeError("The preset color cannot be found")

    def adjust_layer(self, mode: str):
        """
        调整绘图层的渲染层级
        :param mode: 调整模式（'up'上移一层/'down'下移一层/'top'移至顶层/'bottom'移至背景上一层）
        :raises TypeError: 背景层（层级0）移动时触发
        """

        def get_layer(i):
            return role_list.index(i)

        me_layer = get_layer(self)
        if me_layer == 0:
            raise TypeError('背景角色不能移动图层！')
        if mode == 'up':
            if me_layer == len(role_list) - 1:
                return
            temp = role_list[me_layer + 1]
            role_list[me_layer + 1] = role_list[me_layer]
            role_list[me_layer] = temp
        elif mode == 'down':
            if me_layer == 1:
                return
            temp = role_list[me_layer - 1]
            role_list[me_layer - 1] = role_list[me_layer]
            role_list[me_layer] = temp
        elif mode == 'top':
            role_list.pop(me_layer)
            role_list.append(self)
        elif mode == 'bottom':
            role_list.pop(me_layer)
            role_list.insert(1, self)
        else:
            raise ValueError('请选择[up, down, top, bottom]中的一种模式！')

    def died(self):
        """从游戏中移除绘图层"""
        role_list.remove(self)


# 背景角色（特殊角色，作为游戏最底层背景）
background = role()

# 调试代码
if __name__ == "__main__":
    print("Xytore")


# 帮助文档函数（输出各模块使用说明）
def help(cont=None):
    __display__ = \
        '''
    -------------------display模块-------------------
    update()：
        刷新屏幕
    set_window(size,title):
        参数可选， 分别对应窗口的大小和标题
        初始化游戏库
    set_title(str):
        str => 标题内容（强制转为string类型）
    fill(rgb):
        rbg => RGB元组（默认为（255， 255， 255））
        用指定色彩填充屏幕
    enable_exit():
        检测鼠标点击关闭键
    tick(FPS):
        FPS => int
        设置游戏刻（每秒运行的次数）
    '''

    __background__ = \
        '''
    -------------------background-------------------

    '''

    __mouse__ = \
        '''
    -------------------mouse-------------------
    collide(role):
        role => Role对象
        测试鼠标是否和role碰撞

    click(which):
        which => int/str(0、1、2、left、middle、right)
        检测某个鼠标按键是否按下
    x => 鼠标的x坐标
    y => 鼠标的y坐标
    '''

    __sound__ = \
        '''
    -------------------sound-------------------
    load_sound(sound_name, sound_path):
        sound_name => int/str
        sound_path => file_path(要加载的文件路径)
        加载一个音乐到内存中，并命名为sound_name

    play_sound(sound_name, channel=None, loops=1):
        sound_name => 加载时填入的sound_name
        channel => int(播放时使用的通道，默认有0~7)
        播放名称为sound_name的音乐

    fadeout(self, sound_name, time):
        sound_name => 加载时填入的sound_name
        time => int(音量减小到0的时间，单位毫秒)
        逐渐减小名称为sound_name的音乐的音量至0并停止

    stop(self):
        停止所有正在播放的音乐

    stop_sound(self, sound_name):
        sound_name => 加载时填入的sound_name
        停止名称为sound_name的音乐

    set_volume(self, sound_name, volume):
        sound_name => 加载时填入的sound_name
        volume => 要设置的音量
        设置名称为sound_name的音乐的音量为volume

    set_channel(self, number):
        number => int(要设置的通道数，未设置时为8)
        设置通道数为number
    '''

    __pen__ = \
        '''
    -------------------pen-------------------
    draw_line(left_up, right_down):
        left_up => tuple[int, int](线的左上角坐标)
        right_down => tuple[int, int](线的右下角坐标)
        绘制一条线

    def set_color(color_name):
        color_name => str(要设置的预设颜色名称)
        设置画笔颜色为预设颜色之一(目前支持：red红、orange橙、blue蓝、green绿、white白、black黑、cyan青)

    def draw_rect(self, left_up, width, high):
        left_up => tuple[int, int](左上角顶点坐标)
        width => 矩形的宽
        high => 矩形的高
        绘制一个矩形

    adjust_layer(mode):
        mode => str
        切换画笔的图层（模式：up上移一层， down下移一层， top移至顶层， bottom移至背景图层上方
    '''

    __key__ = \
        '''
    -------------------key-------------------
    key_state(key) return bool 检测目标按键的状态（True为按下， False为没按下）
    '''

    __role__ = \
        '''
    -------------------role-------------------
    position    角色Position属性
    sculpt_number    角色的当前造型编号（起始为0）
    scale 角色的缩放(使用百分制，1表示100%)
    show => bool 角色是否显示
    width_scale 角色的宽度缩放(使用百分制，1表示100%)
    high_scale 角色的高度缩放(使用百分制，1表示100%)
    facing_angle => 角度值    角色的面向角度（正值为逆时针旋转，负值为顺时针旋转）
    alpha => 透明度(0为不透明， 100为完全透明)
    add_sculpt(self, *sculpt_path_list):
        sculpt_path_list => 若干个str 要添加的造型图片的文件路径（目前仅支持gif）
        向角色造型列表添加一张或多张图片
    next_sculpt(self, number=1)：
        number => int 且 number > 0
        切换number次造型（负数为切换number次上一个造型）
    forward(number):
        number => int/float
        面向角色的角度前进number个距离
    left_right_flip():
        左右翻转角色（翻转角色的贴图，不影响角度）
    up_down_flip()：
        上下翻转角色（翻转角色的贴图，不影响角度）
    adjust_layer(mode):
        mode => str
        警告：背景角色移动图层会引发错误！
        切换角色的图层（模式：up上移一层， down下移一层， top移至顶层， bottom移至背景图层上方
    collide(other):
        other => Role/Group
        检测与other对象是否碰撞（若other为Group，则检测其中所有目标）
        return => bool
    died():
        将角色从所有Group组对象中删除
    new_group():
        return => Group对象
        创建一个Group“组”对象 
    rotate(center_position, angle_degrees):
        center_position => tuple[int, int](中心点的坐标)
        angle_degrees => 要旋转的角度
        绕center_position旋转angle_degrees度
    '''

    if cont == 'all':
        print(__display__)
        print(__background__)
        print(__mouse__)
        print(__sound__)
        print(__pen__)
        print(__key__)
        print(__role__)
    elif cont == ('display'):
        print(__display__)
    elif cont == ('background'):
        print(__background__)
    elif cont == ('mouse'):
        print(__mouse__)
    elif cont == ('sound'):
        print(__sound__)
    elif cont == ('pen'):
        print(__pen__)
    elif cont == ('key'):
        print(__key__)
    elif cont == ('role'):
        print(__role__)
    else:
        raise ValueError()