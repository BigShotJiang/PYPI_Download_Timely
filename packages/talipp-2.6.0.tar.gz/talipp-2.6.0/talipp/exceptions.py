"""Exception definitions."""


class TalippException(Exception):
    """Base talipp exception class."""
    pass
