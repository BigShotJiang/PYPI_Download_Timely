# EulerKit

This is a Python Library inspired by the functions that are needed to solve many Project Euler problems. It also includes some utilities that I personally enjoy very much.
