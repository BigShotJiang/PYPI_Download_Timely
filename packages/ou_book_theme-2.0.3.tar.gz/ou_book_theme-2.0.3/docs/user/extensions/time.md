# Time

The `{time}` block is used to indicate that something will take a given amount of time and is generally used with
`{activity}`:

::::{code-block} markdown
:::{time} 20 minutes
:::
::::

:::{time} 20 minutes
:::
