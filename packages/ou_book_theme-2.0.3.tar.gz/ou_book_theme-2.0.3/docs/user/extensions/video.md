# Video

The `{video}` block is used to embed a video:

::::{code-block} markdown
:::{video} https://video.ocl.open.ac.uk/ui/#/embed/51b632d5-0144-421b-800c-bf7b5f420542
:::
::::

:::{video} https://video.ocl.open.ac.uk/ui/#/embed/51b632d5-0144-421b-800c-bf7b5f420542
:::
