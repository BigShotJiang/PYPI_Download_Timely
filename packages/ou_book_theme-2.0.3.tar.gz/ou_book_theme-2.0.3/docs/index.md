# OU Book Theme

The OU Book Theme is an extension of the [Sphinx Book Theme](https://sphinx-book-theme.readthedocs.io), adding Open University specific theming,
as well as custom directives and roles. It is meant for use with [Sphinx](https://www.sphinx-doc.org).
