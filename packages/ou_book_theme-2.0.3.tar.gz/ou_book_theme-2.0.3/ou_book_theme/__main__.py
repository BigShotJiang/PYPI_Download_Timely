"""Run the OU Book Theme CLI."""

from ou_book_theme.cli import cli

if __name__ == "__main__":
    cli()
