from . import __version__, run

def install_v():
    run()
