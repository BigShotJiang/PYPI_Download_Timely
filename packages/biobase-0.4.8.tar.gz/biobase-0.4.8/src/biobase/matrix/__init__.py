from biobase.matrix import sub_matrix

_Matrix = sub_matrix._Matrix
Blosum = sub_matrix.Blosum
Pam = sub_matrix.Pam
Identity = sub_matrix.Identity
Match = sub_matrix.Match
