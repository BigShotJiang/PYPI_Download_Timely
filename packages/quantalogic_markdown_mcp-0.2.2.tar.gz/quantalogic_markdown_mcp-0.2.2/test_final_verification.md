# Test Document for Header Duplication Fix

## Introduction

This is a test document to verify the header duplication fix.

## Chapter 1

This is the original content for Chapter 1.

## Chapter 2

This is content for Chapter 2.
