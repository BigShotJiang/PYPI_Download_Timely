"""custom classes for warnings"""

__all__ = ["DeepOriginWarning"]


class DeepOriginWarning(UserWarning):
    """Deep Origin warning"""

    pass
