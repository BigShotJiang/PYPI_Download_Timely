::: pySWATPlus.types.ParamChange

::: pySWATPlus.types.ParamSpec

::: pySWATPlus.types.FileParams

::: pySWATPlus.types.ParamsType
