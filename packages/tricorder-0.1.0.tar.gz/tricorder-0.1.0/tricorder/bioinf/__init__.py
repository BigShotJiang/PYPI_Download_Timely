#this module contains codes related to bioinformatics

#the scripts in this module can be either used by importing the class or function, or calling the scripts by sending command-line arguments