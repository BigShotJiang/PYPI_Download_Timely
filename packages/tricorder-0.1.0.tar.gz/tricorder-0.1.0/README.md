# Tricorder
A collection of small frequently used tools updated regularly, focusing on MRI, PyTorch, Bioinformatics, and Pythoin.

The name of this project "Tricorder" was selected as a tribute to Star Trek.
A tricorder will be a multifunction hand-held device useful for data sensing, analysis, and recording, with many specialised abilities which will make it an asset to crews aboard starships and space stations as well as on away missions.
