"""Tests for sigstore-a2a library."""
