def main():
    print("Hello from mellem!")


if __name__ == "__main__":
    main()
