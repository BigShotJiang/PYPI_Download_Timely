from setuptools import setup, find_packages

setup(
    name='xianb',
    version='2.0.2',
    author='jxjiang',
    author_email='723137901@qq.com',
    description='很大的修改，改到颠了，不想干了',
    python_requires='>=3.8',
    install_requires=[],
    packages=find_packages()
)
