from xianbao.ui.main_window import MainWindow

def run():
    """启动GUI应用程序"""
    app = MainWindow()
    app.mainloop()

if __name__ == "__main__":
    run()