"""
Module to wrap the functionality related to
basic video edition.
"""
