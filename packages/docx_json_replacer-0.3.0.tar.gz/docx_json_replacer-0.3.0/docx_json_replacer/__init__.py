from .docx_replacer import DocxReplacer, replace_docx_template

__version__ = "0.1.0"
__all__ = ["DocxReplacer", "replace_docx_template"]