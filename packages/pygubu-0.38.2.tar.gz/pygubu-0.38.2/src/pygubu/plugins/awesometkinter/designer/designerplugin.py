from pygubu.api.v1 import IPluginBase, IDesignerPlugin
import pygubu.plugins.awesometkinter.designer.properties


class AwesometkinterPlugin(IDesignerPlugin):
    ...
