"""pyfian: Tools for financial analysis and data processing."""

__version__ = "0.1.0"
