# UserType


## Enum

* `USER` (value: `'user'`)

* `DATA_PLANE` (value: `'data_plane'`)

* `SERVICE_ACCOUNT` (value: `'service_account'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


