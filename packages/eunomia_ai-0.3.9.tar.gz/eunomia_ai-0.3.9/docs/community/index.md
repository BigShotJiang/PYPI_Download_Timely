We are committed to building a community around Eunomia, for people that are interested in authorization for LLM-based applications.

There you can ask questions, share feedback and ideas, and get help from other users.

[Join the Discord :fontawesome-brands-discord:][eunomia-discord]{ .md-button }

[eunomia-discord]: https://discord.gg/TyhGZtzg3G
