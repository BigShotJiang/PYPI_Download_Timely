# Snakemake storage plugin: s3

A Snakemake storage plugin for S3 API storage (AWS S3, MinIO, etc.).
For documentation and usage instructions, see the [Snakemake plugin catalog](https://snakemake.github.io/snakemake-plugin-catalog/plugins/storage/s3.html).