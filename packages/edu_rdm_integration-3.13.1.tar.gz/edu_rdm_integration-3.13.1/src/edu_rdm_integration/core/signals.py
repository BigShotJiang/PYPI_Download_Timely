from django.dispatch import (
    Signal,
)


manager_created = Signal()
