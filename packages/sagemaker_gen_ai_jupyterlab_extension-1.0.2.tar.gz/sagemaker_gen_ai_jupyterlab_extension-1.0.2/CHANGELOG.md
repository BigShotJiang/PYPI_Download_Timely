# Changelog

<!-- <START NEW CHANGELOG ENTRY> -->

<!-- <END NEW CHANGELOG ENTRY> -->

# 1.0.2
- Updated File Path to work in Lightning Use Case also

# 1.0.1
- Updated Flare widget icon and placement
- Added Telemetry
- Disabled Buggy Context Commands

# 1.0.0
- Production-ready release incorporating all bug fixes and improvements identified during testing phase

## 0.1.0
- Initial test version deployed to validate core concepts and functionality