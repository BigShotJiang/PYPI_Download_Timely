Authors
=======
All these versions would not be possible without volunteers!

This is a complete list for each major version.

A big "thank you" to everybody who helped out.

Pymodbus version 3 family
-------------------------
Thanks to

- ahcm-dev
- AKJ7
- Alex
- Alex Ruddick
- Alexander Lanin
- Alexandre CUER
- alexis-care
- Alois Hockenschlohe
- Andy Walker
- Arjan
- André Srinivasan
- andrew-harness
- banana-sun
- Blaise Thompson
- Breina
- brherger
- CapraTheBest
- cgernert
- corollaries
- Chandler Riehm
- Chris Hung
- Christian Krause
- Christian Pfisterer
- daanwtb
- Daniel Rauber
- dhoomakethu
- doelki
- DominicDataP
- Dominique Martinet
- Dries
- duc996
- efdx
- Erlend E. Aasland
- Esco441-91
- Farzad Panahi
- Fredo70
- Gao Fang
- Ghostkeeper
- Hangyu Fan
- Hayden Roche
- igorbga
- Iktek
- Ilkka Ollakka
- Jakob Ruhe
- Jakob Schlyter
- James Braza
- James Cameron
- James Hilliard
- jan iversen
- Jerome Velociter
- Joe Burmeister
- John Miko
- Jonathan Reichelt Gjertsen
- JorisW
- julian
- Justin Standring
- Kenny Johansson
- Kürşat Aktaş
- laund
- Logan Gunthorpe
- Luke Hoggatt
- Mark Deneen
- Marko Luther
- Martyy
- Máté Szabó
- Matthias Straka
- Matthias Urlichs
- Maxime LEURENT
- Michel F
- Mickaël Schoentgen
- Pavel Kostromitinov
- peufeu2
- Philip Couling
- Philip Jones
- Robin Trabert
- Qi Li
- Sebastian Machuca
- Sefa Keleş
- Steffen Beyer
- sumguytho
- Szewcson
- Thijs W
- Totally a booplicate
- WouterTuinstra
- wriswith
- Yash Jani
- Yohrog
- yyokusa
- zaid bin saeed

Pymodbus version 2 family
-------------------------
Thanks to

- alecjohanson
- Alexey Andreyev
- Andrea Canidio
- Carlos Gomez
- Cougar
- Christian Sandberg
- dhoomakethu
- dices
- Dmitri Zimine
- Emil Vanherp
- er888kh
- Eric Duminil
- Erlend Egeberg Aasland
- hackerboygn
- Jian-Hong Pan
- Jose J Rodriguez
- Justin Searle
- Karl Palsson
- Kim Hansen
- Kristoffer Sjöberg
- Kyle Altendorf
- Lars Kruse
- Malte Kliemann
- Memet Bilgin
- Michael Corcoran
- Mike
- sanjay
- Sekenre
- Siarhei Farbotka
- Steffen Vogel
- tcplomp
- Thor Michael Støre
- Tim Gates
- Ville Skyttä
- Wild Stray
- Yegor Yefremov


Pymodbus version 1 family
-------------------------
Thanks to

- Antoine Pitrou
- Bart de Waal
- bashwork
- bje-
- Claudio Catterina
- Chintalagiri Shashank
- dhoomakethu
- dragoshenron
- Elvis Stansvik
- Eren Inan Canpolat
- Everley
- Fabio Bonelli
- fleimgruber
- francozappa
- Galen Collins
- Gordon Broom
- Hamilton Kibbe
- Hynek Petrak
- idahogray
- Ingo van Lil
- Jack
- jbiswas
- jon mills
- Josh Kelley
- Karl Palsson
- Matheus Frata
- Patrick Fuller
- Perry Kundert
- Philippe Gauthier
- Rahul Raghunath
- sanjay
- schubduese42
- semyont
- Semyon Teplitsky
- Stuart Longland
- Yegor Yefremov


Pymodbus version 0 family
-------------------------
Thanks to

- Albert Brandl
- Galen Collins

Import to github was based on code from:

- S.W.A.C. GmbH, Germany.
- S.W.A.C. Bohemia s.r.o., Czech Republic.
- Hynek Petrak
- Galen Collins
