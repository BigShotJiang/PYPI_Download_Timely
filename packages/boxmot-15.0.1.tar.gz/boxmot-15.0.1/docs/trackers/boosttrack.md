# BoostTrack

::: boxmot.trackers.boosttrack.boosttrack.BoostTrack