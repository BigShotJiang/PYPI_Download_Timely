# DeepOcSort

::: boxmot.trackers.deepocsort.deepocsort.DeepOcSort