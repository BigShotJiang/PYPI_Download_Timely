<!-- docs/api/trackers/bytetrack.md -->
# ByteTrack

::: boxmot.trackers.bytetrack.bytetrack.ByteTrack