from models_evaluation.tools import convert_two_letter_name_to_country_name_in_json

convert_two_letter_name_to_country_name_in_json("./results/new/fasttext_256.json")
convert_two_letter_name_to_country_name_in_json("./results/new/fasttext_512.json")
