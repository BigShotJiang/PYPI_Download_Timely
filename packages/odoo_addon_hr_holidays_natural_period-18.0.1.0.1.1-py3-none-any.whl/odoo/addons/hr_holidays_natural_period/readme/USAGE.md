For using natural period on leaves:

1.  Go to *Leaves \> Dashboard*.
2.  Select dragging on the calendar the days you want to be on leave, or
    go to the form view for selecting start and end dates.
3.  Select the proper "Leave Type" that has "Natural day" selected in
    "Request unit".
4.  If no leave type is yet specified, then default configuration is to
    exclude public holidays.
5.  The number of days will be computed without employee calendar used.
