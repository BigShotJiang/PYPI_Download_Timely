DO_NOT_ESCAPE_UNICODE = '\nDo not escape unicode characters.\n'
