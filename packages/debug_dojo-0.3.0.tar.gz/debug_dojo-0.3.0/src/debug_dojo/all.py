"""Install all debugging tools for the debug_dojo package by import."""

from .installers import install_all

install_all()
