The source code is coped from [584cec4](https://github.com/pprcht/gfn0/commit/584cec4b47da23bf3634ef0dd798a1639fcc5e47) in [pprcht/gfn0](https://github.com/pprcht/gfn0/).
