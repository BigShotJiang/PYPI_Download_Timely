"""Tests for adeptus_administratum are located here."""
