"""CLI game in 40k setting."""

from adeptus_administratum.greetings import app

__all__ = ["app"]
