"""
This package contains all the configuration related to Graphql and Channels
"""
