#!!!!! do not change this file !!!!!
app_version="4.24"
app_bulld_anchor="Noh_2025-07-24 14:12:11.378741"
app_name="ryry-cli"
import sys, os
if getattr(sys, 'frozen', False):
    base_path = sys._MEIPASS
else:
    base_path = os.path.dirname(os.path.abspath(__file__))

