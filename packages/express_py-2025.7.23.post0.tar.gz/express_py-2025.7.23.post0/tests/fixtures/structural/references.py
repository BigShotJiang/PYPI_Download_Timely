"""
Reference values for the InChI test calculations within ExPrESS
"""
INCHI_DATA = {"inchi": "1S/CH4/h1H4", "inchi_key": "VNWKTOKETHGBQD-UHFFFAOYSA-N"}
