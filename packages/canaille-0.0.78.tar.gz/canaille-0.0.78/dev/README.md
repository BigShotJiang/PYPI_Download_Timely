# Development environment

To check out how canaille looks like, or to start contributions, just run the development server:
- with `docker-compose up` to install and run it in preconfigured docker containers
- or with the `runserver` script to run it locally!

Please check the details on [the documentation](https://canaille.readthedocs.io/en/latest/development/contributing.html).
