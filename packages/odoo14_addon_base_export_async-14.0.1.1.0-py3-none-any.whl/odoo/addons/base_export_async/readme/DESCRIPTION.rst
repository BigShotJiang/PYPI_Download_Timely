Standard Export can be delayed in asynchronous jobs executed in the background and then send by email to the user.
