* Arnaud Pineux (ACSONE SA/NV) authored the initial prototype.
* Guewen Baconnier (Camptocamp)
