"""LinkNote - A web-based bookmark manager with search and tagging capabilities."""

__version__ = '0.1.0'
