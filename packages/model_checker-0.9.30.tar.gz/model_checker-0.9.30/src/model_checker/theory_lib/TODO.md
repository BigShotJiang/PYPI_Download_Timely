# TODO

- [x] imposition theory
  - [x] get `./Code/run_tests.py imposition` to pass
  - [x] make examples match `/logos/subtheories/counterfactual/examples.py`
  - [x] get comparison to work
