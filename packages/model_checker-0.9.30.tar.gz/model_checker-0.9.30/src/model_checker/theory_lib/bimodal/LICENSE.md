[LICENSE PLACEHOLDER - GPL-3.0]
Copyright (c) 2025 Benjamin Brast-McKie