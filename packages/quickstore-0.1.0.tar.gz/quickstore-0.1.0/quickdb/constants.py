DB_PATH = "quickstore.json"
FILE_META_PATH = "filemeta.json" 