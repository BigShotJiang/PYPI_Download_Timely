import importlib.metadata

__version__ = importlib.metadata.version(__package__ or "git_copilot_commit")
