# SPDX-License-Identifier: GPL-3.0-or-later
from .service import AzurePublishingMetadata, AzureService  # noqa: F401
