"""PUDiag subpackage."""
