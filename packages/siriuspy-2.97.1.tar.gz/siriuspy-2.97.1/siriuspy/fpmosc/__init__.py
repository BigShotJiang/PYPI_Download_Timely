"""Filling Pattern info subpackage."""

from .main import FPMOscApp
