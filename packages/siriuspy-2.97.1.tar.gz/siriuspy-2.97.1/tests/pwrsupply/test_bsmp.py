#!/usr/bin/env python-sirius
"""Test pwrsupply bsmp module."""
from unittest import mock
