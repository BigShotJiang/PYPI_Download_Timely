Files in this directory are help for `help syntax`.

A list of sub-names is obtained by `Dir.glob('*.txt')` in this directory.

Each file name without the trailing `.txt` is the name of the help subcategory under `help syntax`.

The first line in the file is a summary shown in help summary. Lines 3 on are shown as help text.
