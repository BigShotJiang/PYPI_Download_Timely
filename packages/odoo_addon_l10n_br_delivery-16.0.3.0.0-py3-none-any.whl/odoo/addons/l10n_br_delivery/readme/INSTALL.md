This module depends on:

- l10n_br_sale_stock
- delivery
- delivery_carrier_partner
