melobot.protocols
=================

协议部件
-----------

.. autoclass:: melobot.protocols.ProtocolStack
    :members:

内置协议支持
--------------

- :doc:`melobot.protocols.onebot <../ob_api/index>`
