melobot.mixin
=============

.. autoclass:: melobot.mixin.FlagMixin
    :members:

.. autoclass:: melobot.mixin.AttrReprMixin
    :members:

.. autoclass:: melobot.mixin.HookMixin
    :members:
