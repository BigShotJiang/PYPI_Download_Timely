melobot.plugin
==============

插件层组件
-----------

.. autoclass:: melobot.plugin.PluginPlanner
    :members: __init__

.. autoclass:: melobot.plugin.PluginInfo
    :members:
    :exclude-members: version, desc, docs, keywords, url, author

.. autoclass:: melobot.plugin.PluginLifeSpan
    :members:

.. autoclass:: melobot.plugin.AsyncShare
    :members:

.. autoclass:: melobot.plugin.SyncShare
    :members:
