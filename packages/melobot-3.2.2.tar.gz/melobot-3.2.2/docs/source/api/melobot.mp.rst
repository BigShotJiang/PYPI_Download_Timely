melobot.mp
==========

多进程支持
-------------

.. autoclass:: melobot.mp.Process
    :members:
    :exclude-members: owned

.. autoclass:: melobot.mp.SpawnProcess
    :members:
    :exclude-members: owned

.. autoclass:: melobot.mp.ProcessPool
    :members:

.. autoclass:: melobot.mp.SpawnProcessPool
    :members:

.. autoclass:: melobot.mp.ProcessPoolExecutor
    :members:

.. autoclass:: melobot.mp.SpawnProcessPoolExecutor
    :members:

.. autoclass:: melobot.mp.PBox
    :members:
