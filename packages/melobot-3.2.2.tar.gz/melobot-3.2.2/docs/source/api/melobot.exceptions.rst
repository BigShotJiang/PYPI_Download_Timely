melobot.exceptions
==================

.. automodule:: melobot.exceptions
    :exclude-members: __init__
