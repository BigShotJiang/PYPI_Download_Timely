melobot.ctx
===========

.. autoclass:: melobot.ctx.Context
    :members:

.. autoclass:: melobot.ctx.EventOrigin
    :exclude-members: __init__
    :members: adapter, in_src
