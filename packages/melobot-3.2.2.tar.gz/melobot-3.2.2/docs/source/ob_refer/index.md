# OneBot 相关

本章节主要包含对 OneBot 标准各种概念、术语的解释，以及在 melobot 中的支持细节。

**建议按顺序阅读**，这样不会“突然出现”没有解释过的概念。

```{toctree}
:maxdepth: 1

onebot
impl
event-action
msg
forward-msg
preprocess
```
