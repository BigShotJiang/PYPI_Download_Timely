# melobot 历史版本

## melobot v1

melobot v1，本质上只是一个 qq 机器人程序。它以异步支持和模板扩展为主要特色，实现了对 qq 消息事件的监听和简单处理。

**v1 版本现已完全停止维护**，不建议继续使用。如果您对 v1 感兴趣，可以看看这些：

v1 源代码：[commit/386b531](https://github.com/Meloland/melobot/tree/386b531904829ed5603d491656567f5a22fa32bf)

v1 文档仓库：[aicorein/Qbot-MeloBot-docs](https://github.com/aicorein/Qbot-MeloBot-docs)

v1 文档地址：[Qbot-MeloBot-docs](https://aicorein.github.io/Qbot-MeloBot-docs/)

## melobot v2

melobot v2，是一个只适用于 onebot 协议的，用于 qq 机器人的开发框架。

**v2 版本现已完全停止维护**，不建议继续使用。如果您对 v2 感兴趣，可以看看这些：

v2 源代码：[commit/1a332d1](https://github.com/Meloland/melobot/tree/1a332d1cfdad08016eacf08eb2112ea8bfd382fd)
