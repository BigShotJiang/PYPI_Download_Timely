import npc_stim


def test_import_package():
    pass
