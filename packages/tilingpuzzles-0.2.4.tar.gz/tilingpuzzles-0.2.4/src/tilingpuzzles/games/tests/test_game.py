from tilingpuzzles.games.game import Game


def test_Game():
    Game(((1,0),(0,1)))
    pass

