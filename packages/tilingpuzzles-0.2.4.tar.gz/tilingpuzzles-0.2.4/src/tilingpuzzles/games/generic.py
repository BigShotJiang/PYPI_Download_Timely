from .game import Game

#TODO  should allow all Stones not only those of order k

class Generic(Game):
    pass


