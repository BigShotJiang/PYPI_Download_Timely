# examples

Handcraftet examples of Pentomino games.