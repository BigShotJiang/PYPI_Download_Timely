#!/usr/bin/env bash

set -x

PYTHONPATH=. pytest -v tests
