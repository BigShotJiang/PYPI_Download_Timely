# Create your devotion story and share to others as blessing ❤️

**Story Maker**  

* Need to create a folder first by pressing the **save** button.
* Than click the folder.
  * Inside the empty folder than start to make a story and **save**.
* The **'<'** button is going back to folders area.
* The **'>'** button is going back to files area.
* The **delete** button:
  * Delete a file.
  * Folder empty, wil delete the folder.
* Pressing ```Ctrl + D``` buttons will delete all contents of all fields.  
  > **WARNING!**  
  _Be careful not to delete everything before save it._
* You can edit existing story by click it, and it will loads to the story fields.

**NOTE:**  
In the folders area, if press **save** button, will create another folder.

## Free Stories to start reading

* BlessingPro → 4 stories
  * In version 1.0.8
  * **WARNING:** In case of firewall, please move it manually 🙏

**To start Story Maker:**

  ```Terminal
  # Mac-OS
  % SMD 

  # Windows
  > SMD
  ```

![starter](pictures/starter.png)

![devotion](pictures/devotion.png)

![devotion_complete](pictures/devotion_complete.png)

![story_maker](pictures/story_maker.png)
