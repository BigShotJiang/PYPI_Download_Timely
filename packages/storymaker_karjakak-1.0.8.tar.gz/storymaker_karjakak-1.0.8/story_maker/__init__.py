from .main_frame import story_maker
from .blessing_pro import main