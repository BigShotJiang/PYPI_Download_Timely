Silicon Heaven CLI Elektroline extension
========================================

The extension for the Silicon Heaven CLI access application to provide utilities
to work with Elektroline developed SHV systems.

* `📃 Sources <https://gitlab.com/elektroline-predator/shvcli-ell>`__
* `⁉️ Issue tracker <https://gitlab.com/elektroline-predator/shvcli-ell/-/issues>`__
* `Silicon Heaven CLI <https://gitlab.com/silicon-heaven/shvcli>`__
