"""Simple counter of strings of this package name.

This package is base for the packages to be implemented.
"""

from .__version__ import VERSION

__all__ = ["VERSION"]
