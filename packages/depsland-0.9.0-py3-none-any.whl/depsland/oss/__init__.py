from .get_oss import T
from .get_oss import get_oss as get_oss_server
from .get_oss import get_oss as get_oss_client
