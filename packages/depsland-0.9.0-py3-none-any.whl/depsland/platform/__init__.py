from . import launcher
from . import system_info as sysinfo
from .launcher import create_desktop_shortcut
from .launcher import create_launcher
