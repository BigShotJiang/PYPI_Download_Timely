"""
for windows only
"""
from .bat_2_exe_1 import add_icon_to_exe
# from .bat_2_exe_1 import bat_2_exe as bat_2_exe_legacy
# from .bat_2_exe_2 import bat_2_exe
from .make_exe import bat_2_exe
from .make_exe import make_exe
