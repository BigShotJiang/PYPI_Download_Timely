from .app import setup_ui
from .setup_wizard import main as setup_wizard
