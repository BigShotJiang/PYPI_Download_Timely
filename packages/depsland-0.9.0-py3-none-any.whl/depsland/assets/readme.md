
## Source Info

```yaml
depsland:
  source_name: raivo
  source_link: https://parsefiles.back4app.com/JPaQcFfEEQ1ePBxbf6wvzkPMEqKYHhPYv8boI1Rc/4626cfa4067e3d3a08749b7a53203810_nC881bdtqc.icns
  author: leftover-waffle (https://macosicons.com/#/u/leftover-waffle)
python:
  source_name: python
  source_link: https://parsefiles.back4app.com/JPaQcFfEEQ1ePBxbf6wvzkPMEqKYHhPYv8boI1Rc/9160170b3709f7b7a8ac6aedb95f3032_A9gkJcIgbJ.icns
  author: Jxck (https://macosicons.com/#/u/Jxck)
```

## How To Build

the origin file is ".icns" format. to generate ".png" and ".ico", run:

```sh
python sidework/image_converter.py all build/icon/launcher.icns
```
