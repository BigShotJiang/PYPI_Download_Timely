Init generation or refresh assets in this directory:

Please run `py build/backup_project_resources.py`
