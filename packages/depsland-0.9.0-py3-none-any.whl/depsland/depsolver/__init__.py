# from . import version_crawler
# from .poetry_lock_resolver import T
# from .poetry_lock_resolver import resolve_poetry_lock
from .poetry_lock_resolver_2 import T
# from .poetry_lock_resolver_2 import resolve_poetry_lock
# from .requirements_lock import T
# from .requirements_lock import resolve_requirements_lock
from .resolver import resolve_dependencies
