# Safe dummy package: libwebp-base
