from setuptools import setup

__version__ = "1.1.1"

setup(version=__version__)
