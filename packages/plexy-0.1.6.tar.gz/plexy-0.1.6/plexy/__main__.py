from plexy.cli import plexy

if __name__ == '__main__':
    plexy()
