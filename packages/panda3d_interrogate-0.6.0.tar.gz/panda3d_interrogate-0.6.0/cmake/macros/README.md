Directory Info
--------------
**Directory:** /cmake/macros  
**License:** Unlicense  
**Description:** This directory is used for CMake modules which may be _unsafe_
to use outside of a Panda3D project.  These modules may rely on Panda3D specific
cmake variables, Panda3D's directory structure, or some other dependency.
They are not intended to be included in other projects directly, though you
are free to copy and adapt them to your own needs.
