#pragma once

#include <inttypes.h>
#include <netinet/in.h>

struct hostent;
struct netent;
struct protoent;
struct servent;
