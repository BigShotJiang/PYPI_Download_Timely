#pragma once

typedef int pid_t;
typedef long int off_t;
typedef unsigned int mode_t;

struct flock;
