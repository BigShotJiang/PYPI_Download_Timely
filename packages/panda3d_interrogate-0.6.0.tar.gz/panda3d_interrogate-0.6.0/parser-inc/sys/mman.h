#include <sys/types.h>

struct posix_typed_mem_info;
