#pragma once

struct timeval;
struct fd_set;
struct timezone;
