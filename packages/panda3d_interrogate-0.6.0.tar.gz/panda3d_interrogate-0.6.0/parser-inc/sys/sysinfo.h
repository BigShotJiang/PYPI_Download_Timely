struct sysinfo;
