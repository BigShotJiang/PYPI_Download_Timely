#ifndef STDARG_H
#define STDARG_H

typedef __builtin_va_list va_list;

#endif
