#pragma once

#define EM_JS(ret, name, params, ...)
