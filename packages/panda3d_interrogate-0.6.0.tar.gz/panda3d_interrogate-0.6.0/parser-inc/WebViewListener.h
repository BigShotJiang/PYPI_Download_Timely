namespace Awesomium {
  class WebViewListener;
  class JSArguments;
};
