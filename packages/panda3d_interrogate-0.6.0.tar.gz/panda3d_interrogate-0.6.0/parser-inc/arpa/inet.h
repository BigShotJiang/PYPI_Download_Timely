#pragma once

#include <inttypes.h>
#include <netinet/in.h>
