struct OggVorbis_File;
