#pragma once

class vrpn_Button_Remote;
typedef void vrpn_BUTTONCB;
