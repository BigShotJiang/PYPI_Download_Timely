#ifndef _CXCORE_H_
#define _CXCORE_H_

//Python stub

#endif
