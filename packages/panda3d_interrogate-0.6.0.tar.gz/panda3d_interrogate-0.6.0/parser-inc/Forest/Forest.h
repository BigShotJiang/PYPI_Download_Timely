// SpeedTree.

namespace SpeedTree {
  class CTree;
  class CForest {
    class SPopulationStats;
  };
};
