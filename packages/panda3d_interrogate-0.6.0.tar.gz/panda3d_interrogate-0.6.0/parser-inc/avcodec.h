#ifndef AVCODEC_H
#define AVCODEC_H

typedef struct AVCodec AVCodec;
typedef struct AVCodecContext AVCodecContext;
typedef struct AVFrame AVFrame;

#endif /* AVCODEC_H */
