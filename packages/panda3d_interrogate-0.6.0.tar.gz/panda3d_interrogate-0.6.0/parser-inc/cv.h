#ifndef _CV_H_
#define _CV_H_

typedef struct CvCapture CvCapture;

typedef struct CvMemStorage CvMemStorage;
typedef struct CvHaarClassifierCascade CvHaarClassifierCascade;
#endif