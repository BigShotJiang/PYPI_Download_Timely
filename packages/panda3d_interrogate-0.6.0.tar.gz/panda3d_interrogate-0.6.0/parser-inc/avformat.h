#ifndef AVFORMAT_H
#define AVFORMAT_H
typedef struct AVFormat AVFormat;
typedef struct AVFormatContext AVFormatContext;
#endif /* AVFORMAT_H */

