# History

## 0.0.1 (2025-07-26)

* First release on PyPI.
