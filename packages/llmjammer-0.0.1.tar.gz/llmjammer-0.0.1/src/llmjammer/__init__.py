"""Top-level package for llmjammer."""

__author__ = """Eric Spencer"""
__email__ = 'espencer2@luc.edu'
__version__ = '0.0.1'

from llmjammer.llmjammer import Obfuscator, install_git_hooks, create_github_action
