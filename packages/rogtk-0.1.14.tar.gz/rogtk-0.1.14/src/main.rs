fn main() {
    println!("Hello, rusty world!");
}
