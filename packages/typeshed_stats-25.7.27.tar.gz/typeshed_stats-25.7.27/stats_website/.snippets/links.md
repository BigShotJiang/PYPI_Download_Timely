[typeshed]: https://github.com/python/typeshed "A repository providing typing stubs for the Python standard library and various third-party packages"
[stubtest]: https://mypy.readthedocs.io/en/stable/stubtest.html "A tool shipped with the mypy type checker for automatically verifying that stubs are consistent with the runtime package"
[pyright]: https://github.com/microsoft/pyright
[cli-tool]: https://pypi.org/project/typeshed-stats/ "pip install the CLI tool from PyPI"
[PEP 561]: https://peps.python.org/pep-0561 "PEP 561 – Distributing and Packaging Type Information"
