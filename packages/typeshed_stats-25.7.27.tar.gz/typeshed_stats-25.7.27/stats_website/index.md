---
hide:
  - navigation
  - footer
---

# Welcome to typeshed-stats

<img src="big_logo.png" width="700" alt="A huge Python in front of a shed in the middle of a field of wheat">

This website provides statistics on [typeshed][]'s stubs packages.

This project was created by Alex Waygood.
It is not necessarily endorsed by any of the other typeshed maintainers.
