"""Top-level package for the download-toolbox."""

__author__ = "British Antarctic Survey"
__copyright__ = "British Antarctic Survey"
__email__ = "jambyr@bas.ac.uk"
__license__ = "MIT"
__version__ = "0.0.6"
