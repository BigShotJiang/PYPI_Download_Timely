This page is automatically generated via the readme.

Check out the [usage](usage.md) section for further information, including how to [install](usage.md#installation) the project.

Check out the [API](api.md) if you're keen to go deep.

!!! note

    This project is under active development.

{!README.md!}
