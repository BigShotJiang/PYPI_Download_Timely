# Usage

## Installation

To use the download-toolbox, first install it using pip:

```console
(.venv) $ pip install download-toolbox
```

