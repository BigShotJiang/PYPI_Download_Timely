# History

## 0.0.* (2024)

* These are the first implementations forking the codebase from the original
  icenet implementations that the library is derived from. Experimental at best!
* Co-developed alongside the 0.4.0 development strand of icenet and associated repositories.
