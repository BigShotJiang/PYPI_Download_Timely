homepage_url = 'https://pseudopolis.eu/pino/krrez'
version = '10.0.1291'
