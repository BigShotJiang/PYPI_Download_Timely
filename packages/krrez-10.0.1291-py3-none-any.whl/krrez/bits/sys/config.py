# SPDX-FileCopyrightText: © 2023 Josef Hahn
# SPDX-License-Identifier: AGPL-3.0-only
import krrez.api


class Bit(krrez.api.Bit):
    """
    Pseudo Bit without own functionality that TODO   use .SPECIAL. instead ?!?!
    """
