class BalancesQuery:
    query: str
