class FinancialActionsQuery:
    payment_id: str
    action_id: str
    reference: str
    limit: int
    pagination_token: str
