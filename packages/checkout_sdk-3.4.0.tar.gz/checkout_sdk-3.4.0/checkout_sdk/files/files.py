class FileRequest:
    file: str
    purpose: str
