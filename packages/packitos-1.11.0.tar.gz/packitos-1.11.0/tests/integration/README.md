# Integration tests without recording
