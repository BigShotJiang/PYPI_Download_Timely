#!/bin/bash
set -eux

packit --version
packit --help
