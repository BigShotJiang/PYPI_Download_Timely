# Any extra env vars like license are inserter as line 2 !
docker_base = """



"""
