# xax

JAX library for fast experimentation.

## Installation

```bash
pip install xax
```
