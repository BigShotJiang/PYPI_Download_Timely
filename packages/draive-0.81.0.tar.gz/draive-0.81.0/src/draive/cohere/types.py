__all__ = ("CohereException",)


class CohereException(Exception):
    pass
