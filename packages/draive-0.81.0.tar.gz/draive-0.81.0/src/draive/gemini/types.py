from draive.lmm.types import LMMException

__all__ = ("GeminiException",)


class GeminiException(LMMException):
    pass
