__all__ = ("AgentException",)


class AgentException(Exception):
    pass
