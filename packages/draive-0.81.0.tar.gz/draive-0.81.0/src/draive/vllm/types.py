__all__ = ("VLLMException",)


class VLLMException(Exception):
    pass
