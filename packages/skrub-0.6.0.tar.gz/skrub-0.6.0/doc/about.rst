
About
-----

skrub shares much of its DNA with `scikit-learn
<https://scikit-learn.org>`__.

skrub is the continuation of `dirty-cat <http://dirty-cat.github.io>`_
with a broader scope and a broader ambition.

skrub is a young project born from research. We really need people
giving feedback on successes and failures with the different techniques on real
world data, and pointing us to open datasets on which we can do more
empirical work.

skrub received funding from `project DirtyData
<https://project.inria.fr/dirtydata/>`_ (ANR-17-CE23-0018).
