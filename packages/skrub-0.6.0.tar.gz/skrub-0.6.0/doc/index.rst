.. title:: Home

.. toctree::
   :maxdepth: 2

.. currentmodule:: skrub

.. toctree::
   :hidden:

   install
   documentation
   reference/index
   auto_examples/index
   learning_materials
   CHANGES
   development
   CONTRIBUTING
