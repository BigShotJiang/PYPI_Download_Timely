The icons in this directory were downloaded from https://icons.getbootstrap.com/
(The accompanying MIT license is in `LICENSE` in this directory)

When adding new icons, remove the width and height if any is specified in the
svg. This makes the icon fill the available space and we can size it with css.
Bootstrap may add some classes to the svg element, those can be removed too (but
don't have to).
