class NoAvailableVersionsError(Exception):
    """
    Raised when we can't find any available versions for a mod.
    """
