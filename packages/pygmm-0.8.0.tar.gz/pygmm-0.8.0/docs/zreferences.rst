.. _references:

.. The 'z' is added to the file name such that is gets compiled last.

==========
References
==========

.. bibliography:: references.bib
    :style: alpha
