=======
License
=======

.. include:: ../LICENSE
   :literal:
