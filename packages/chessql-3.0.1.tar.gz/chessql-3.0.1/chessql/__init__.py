# __init__.py
# Copyright 2017 Roger Marsh
# Licence: See LICENCE (BSD licence)

"""Chess Query Language (CQL) parser.

The reference document used while writing this package is:

Chess Query Language documentation version 5.1 from http://www.gadycosteff.com

"""
