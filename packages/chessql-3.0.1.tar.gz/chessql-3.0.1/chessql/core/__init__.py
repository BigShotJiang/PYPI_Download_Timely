# __init__.py
# Copyright 2017 Roger Marsh
# Licence: See LICENCE (BSD licence)
"""Chess Query Language (CQL) parser."""
