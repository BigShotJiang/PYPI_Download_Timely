from histopath.ray.datasource.openslide_metadatasource import OpenSlideMetaDatasource

__all__ = ["OpenSlideMetaDatasource"]
