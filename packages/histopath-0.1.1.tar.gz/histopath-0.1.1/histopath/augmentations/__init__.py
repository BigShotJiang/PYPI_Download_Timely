from histopath.augmentations.stain_augmentor import StainAugmentor

__all__ = ["StainAugmentor"]
