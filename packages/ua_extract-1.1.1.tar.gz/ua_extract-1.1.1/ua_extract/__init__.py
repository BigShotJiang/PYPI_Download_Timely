__version__ = '1.1.1'
from .settings import *
from .parser import *
from .device_detector import DeviceDetector
from .update_regex import Regexes