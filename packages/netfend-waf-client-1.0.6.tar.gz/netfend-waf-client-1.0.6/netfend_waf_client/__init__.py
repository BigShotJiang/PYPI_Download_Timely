# netfend_waf_client/__init__.py

from .client import WAFClient
