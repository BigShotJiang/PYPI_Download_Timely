# `base` module

::: pyfredapi._base