"""The exceptions module provides the exceptions for pyfredapi."""

from .exceptions import APIKeyNotFound, FredAPIRequestError, InvalidAPIKey
