class HandlerError(Exception):
    pass


class ImageError(Exception):
    pass


class PlotterError(Exception):
    pass


class ComparisonError(Exception):
    pass
