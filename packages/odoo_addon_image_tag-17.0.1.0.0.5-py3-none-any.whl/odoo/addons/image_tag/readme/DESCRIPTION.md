This addon provide only one basic model used to define image's tags.
These tags are used by other addons to enrich the image's information of
an image linked to an other model. The fs_product_multi_image addon use
this model.
