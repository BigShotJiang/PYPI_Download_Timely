To manage the list of available tags, you must have the
`Image Tag Manager` role.
