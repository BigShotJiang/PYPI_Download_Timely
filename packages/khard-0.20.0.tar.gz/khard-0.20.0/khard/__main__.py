#!/usr/bin/env python3

import sys

from .khard import main

sys.exit(main())
