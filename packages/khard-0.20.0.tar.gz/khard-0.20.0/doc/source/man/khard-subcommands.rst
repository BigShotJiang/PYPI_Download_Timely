khard subcommands
=================

These are all the subcommands and accepted arguments of :manpage:`khard(1)`.

.. argparse::
  :module: khard.cli
  :func: _sphinxarg_helper
  :prog: khard

See also
--------

:manpage:`khard(1)`.
