Man pages
=========

The following man pages are available for khard:

.. toctree::
   :maxdepth: 1

   khard(1) <man/khard>
   khard-subcommands(1) <man/khard-subcommands>
   khard.conf(5) <man/khard.conf>
