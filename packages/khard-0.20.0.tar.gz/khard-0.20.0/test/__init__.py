"""Module to make it possible to import the test folder as a python package and
hence make it possible to run all unittests from the top level directory with

        python -m unittest [discover]
"""
