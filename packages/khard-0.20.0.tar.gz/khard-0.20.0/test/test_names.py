"""Tests for the Name class"""

import unittest

import vobject

#from khard.contacts import Name


class SimpleNames(unittest.TestCase):
    pass
