# Legal Information

This package is distributed as part of the **scjson** project.
All original code in this directory is released under the BSD&nbsp;1-Clause license.

The package references assets from the W3C SCXML specification and includes
examples derived from Alex Zhornyak's *SCXML Editor Tutorial*.
Those third-party materials remain under their respective licenses as documented
in the repository's top-level `LEGAL.md` file.

For complete license terms please consult that document.


