#
# PROGRAM: CONJUNO
# MODULE : _version
#

version_info = (0, 1, 8)
__version__ = ".".join(map(str, version_info))
