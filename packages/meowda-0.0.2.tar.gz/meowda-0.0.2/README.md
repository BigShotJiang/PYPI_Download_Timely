# Meowda <img src="https://www.gstatic.com/android/keyboard/emojikitchen/20230301/u1f61c/u1f61c_u1f431.png" alt="🐱" width="20px"/> <sub><samp>—— 「喵哒」</samp></sub>

Meowda, manage multiple Python virtual environments with ease. It's based on [uv](https://docs.astral.sh/uv/), and provides a conda-like CLI (_NOT_ a replacement) for Python virtual environments management.

## Installation

TODO...

## Usage

TODO...

## Acknowledgement

TODO...
