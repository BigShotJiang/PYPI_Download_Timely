# MSM documentation

Refer to:
- [Quick example](../../../README.md#quick-example) for using the MSM class.
- [Forward simulation](../../../notebooks/forward_simulation.ipynb) for an explanation of how the forward algorithm works
- [Transition simulation](../../../notebooks/transition_simulation.ipynb) for an explanation of the optimized factor transition.