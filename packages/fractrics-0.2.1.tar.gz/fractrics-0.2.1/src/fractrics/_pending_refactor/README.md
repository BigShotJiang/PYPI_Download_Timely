# Deprecated Code

This folder contains legacy code that is no longer part of the main package interface.

- `_pending_refactor/`: Scripts that need to be restructured.

**This code is not maintained and should not be used in production.**
