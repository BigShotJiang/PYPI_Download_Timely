--- Description
--- !doctype module
--- @class autodoc
autodoc = {}

--- Description.
function autodoc.meow() end
