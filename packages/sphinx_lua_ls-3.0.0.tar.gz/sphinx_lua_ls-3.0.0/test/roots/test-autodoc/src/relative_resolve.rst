Relative resolve
================

.. container:: regression

   .. lua:autoobject:: relative_resolve
