Autoindex
=========

.. container:: regression

   .. lua:autoobject:: object_types
      :index-table:
      :no-index:

   .. lua:autoobject:: object_types
      :index-title: Custom index title
      :no-index:
