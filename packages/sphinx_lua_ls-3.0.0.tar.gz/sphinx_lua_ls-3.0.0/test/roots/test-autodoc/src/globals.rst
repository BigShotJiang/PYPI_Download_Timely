Globals
=======

.. container:: regression

   .. lua:autoobject:: globals
      :members:
      :recursive:
      :globals:
