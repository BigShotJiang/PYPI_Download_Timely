--- Description.
local inner = {}

--- Description.
--- @type integer
INNER_GLOBAL = 0

--- Description.
function inner.bar() end

--- Description.
--- @class mod.inner.Bar

return inner
