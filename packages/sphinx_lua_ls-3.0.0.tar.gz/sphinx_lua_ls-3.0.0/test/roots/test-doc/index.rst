Test documentation
==================

.. toctree::

   src/annotations.rst
   src/autoindex.rst
   src/directives.rst
   src/inherited.rst
   src/modules.rst
   src/refs.rst
