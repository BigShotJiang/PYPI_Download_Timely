__version__ = '2025.7.27'
git_version = 'f6bb8cc87a2da666fe42188a4d9697f8736f7775'
pytorch_version = '2.9.0.dev20250727'
