from enum import Enum


class ScrollDirection(Enum):
    UP = 'up'
    DOWN = 'down'
