Lightweight Python library for data fitting with an emphasis on AMO (Atomic Molecular
and Optical physics) and Quantum Information.

See the documentation at: https://oxionics.github.io/ionics_fits/
