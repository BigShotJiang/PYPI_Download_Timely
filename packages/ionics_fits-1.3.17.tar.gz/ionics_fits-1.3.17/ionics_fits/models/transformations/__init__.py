"""Models that change the behaviour of other models."""
