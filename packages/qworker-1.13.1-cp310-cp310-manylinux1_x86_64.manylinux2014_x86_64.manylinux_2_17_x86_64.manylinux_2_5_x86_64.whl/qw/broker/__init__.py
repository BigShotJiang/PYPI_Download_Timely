"""Qworker Broker.

Producer/Consumer broker for Qworker, using RabbitMQ as the message broker.
"""
