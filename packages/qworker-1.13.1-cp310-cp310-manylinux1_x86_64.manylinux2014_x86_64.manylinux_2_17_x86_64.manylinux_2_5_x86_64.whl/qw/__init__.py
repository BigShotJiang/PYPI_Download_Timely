"""QWorker.

Simple Worker for managing distributed tasks.
"""

from .version import __author__, __description__, __title__, __version__
