# Running bots inside Workers.
