Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/dang_simpletest.py
    :caption: examples/dang_simpletest.py
    :linenos:
