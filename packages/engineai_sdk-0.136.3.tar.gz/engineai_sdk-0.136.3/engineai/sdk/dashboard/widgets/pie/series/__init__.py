"""Specs for Pie Widget Series."""
