"""Specs for axis of a Cartesian widget."""
