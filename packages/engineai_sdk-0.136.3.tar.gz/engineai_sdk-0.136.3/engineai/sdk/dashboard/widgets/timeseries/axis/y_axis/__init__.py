"""Specs for Timeseries Y Axis."""
