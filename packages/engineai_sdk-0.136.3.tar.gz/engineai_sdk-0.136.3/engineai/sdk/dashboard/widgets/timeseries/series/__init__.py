"""Specs for series in a Timeseries chart."""
