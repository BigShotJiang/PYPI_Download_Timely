"""Items Text Styling Package."""
