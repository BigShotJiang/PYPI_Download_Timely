"""Specs for AxisLine."""
