"""Series Entities."""
