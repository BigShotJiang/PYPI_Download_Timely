"""Specifications for columns in Table widget."""
