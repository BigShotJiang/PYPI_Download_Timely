"""Specifications for Table Column Charts."""
