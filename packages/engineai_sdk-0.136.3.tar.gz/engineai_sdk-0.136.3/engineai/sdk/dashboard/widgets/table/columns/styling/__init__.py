"""Styling specs for columns in Table widget."""
