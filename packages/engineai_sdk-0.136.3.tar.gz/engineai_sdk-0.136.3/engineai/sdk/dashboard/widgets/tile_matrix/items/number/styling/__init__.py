"""Specs for Tile Matrix number item stylings."""
