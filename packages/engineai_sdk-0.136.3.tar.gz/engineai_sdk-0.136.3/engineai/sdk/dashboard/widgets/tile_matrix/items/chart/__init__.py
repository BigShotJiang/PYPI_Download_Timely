"""Specs for Tile Matrix chart items."""
