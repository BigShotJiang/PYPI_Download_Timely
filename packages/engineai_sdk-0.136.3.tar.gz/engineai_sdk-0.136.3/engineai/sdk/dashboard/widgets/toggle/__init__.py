"""Specs for Toggle widget."""

from .toggle import Toggle

__all__ = [
    "Toggle",
]
