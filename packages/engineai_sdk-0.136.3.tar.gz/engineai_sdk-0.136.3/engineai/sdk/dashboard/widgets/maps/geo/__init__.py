"""Map Geo resources."""
