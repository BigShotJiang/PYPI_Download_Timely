"""Specs for dashboard collapsible layout elements."""
