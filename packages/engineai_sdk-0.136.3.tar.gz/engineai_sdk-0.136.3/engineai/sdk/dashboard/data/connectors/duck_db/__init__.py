"""DuckDB connector for dashboard data retrieval."""
