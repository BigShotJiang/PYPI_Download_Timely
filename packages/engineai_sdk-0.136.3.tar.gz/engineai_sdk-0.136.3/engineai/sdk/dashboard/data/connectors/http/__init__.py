"""HTTP connector for dashboard data retrieval."""
