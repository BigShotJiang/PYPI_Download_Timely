# `wattmaven-solarnetwork-tools` examples

## How to run the examples

```bash
# Go to the directory of the example you want to run
cd basic

# Copy the .env.example file to .env (and fill in missing values)
cp .env.example .env

# Run the example
python main.py
```
