## v0.4.0 (2025-07-28)

### Feat

- add rate limting support (#45)

### Refactor

- move exceptions (#53)

## v0.3.0 (2025-04-19)

### Feat

- add no auth (#20)

## v0.2.0 (2025-02-12)

### Feat

- add request method (#6)

## v0.1.1 (2025-02-12)

Update package documentation and bundle.

## v0.1.0 (2025-02-07)

### Feat

- initial commit
