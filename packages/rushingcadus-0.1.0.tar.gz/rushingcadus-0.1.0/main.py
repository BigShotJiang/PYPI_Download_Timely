def main():
    print("Hello from rushingcadus!")


if __name__ == "__main__":
    main()
