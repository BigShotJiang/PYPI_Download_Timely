# 📦 UpgradeDB
Instalação:
pip install UpgradeDB

