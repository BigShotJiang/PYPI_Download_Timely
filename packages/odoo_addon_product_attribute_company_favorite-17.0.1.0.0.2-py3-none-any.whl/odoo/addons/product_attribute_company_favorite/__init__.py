# SPDX-FileCopyrightText: 2023 Coop IT Easy SC
#
# SPDX-License-Identifier: AGPL-3.0-or-later
from . import models
from .post_init_hook import initialize_attribute_is_favorite_field
