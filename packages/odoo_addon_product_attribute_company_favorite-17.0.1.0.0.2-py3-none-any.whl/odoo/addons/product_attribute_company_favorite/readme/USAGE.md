At installation, all attributes will be set to favorites for all
companies.
