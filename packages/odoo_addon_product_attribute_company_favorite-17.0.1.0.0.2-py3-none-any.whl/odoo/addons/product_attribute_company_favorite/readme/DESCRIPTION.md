Set favorite product attributes and attribute values per company. Only
the favorite attributes and values will be displayed in the dropdown
menu in a product template form.
