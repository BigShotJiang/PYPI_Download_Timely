There is two setting to allow to set new attribute and new attribute
values as favorites at creation for all companies, instead of the user's
current company only.

Go to Settings\>Inventory\>Products and check - "Set new attribute as
favorite for all companies" - "Set new attribute value as favorite for
all companies"
