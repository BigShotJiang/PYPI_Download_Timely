from . import product_attribute_is_favorite_mixin
from . import product_attribute
from . import product_attribute_value
from . import product_template_attribute_line
from . import res_config_settings
