### scraper2-hj3415

#### Introduction 
Gathering the stock data by playwright

