__copyright__ = "Copyright (c) 2024-2025 Alex Laird"
__license__ = "MIT"
__version__ = "4.0.12"
