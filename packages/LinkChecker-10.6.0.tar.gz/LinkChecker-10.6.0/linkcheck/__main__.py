from .command.linkchecker import linkchecker

linkchecker()
