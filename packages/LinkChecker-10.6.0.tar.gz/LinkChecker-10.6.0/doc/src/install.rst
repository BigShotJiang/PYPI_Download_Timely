Installation
============
If you are upgrading from older versions of LinkChecker you should
also read the upgrading documentation stored in :doc:`upgrading`.

.. include:: ../install.txt
   :start-line: 5
