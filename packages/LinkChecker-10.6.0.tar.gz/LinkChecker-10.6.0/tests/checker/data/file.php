<a href="anchor.html">Bla</a>
<!-- URLs with processing instructions are ignored -->
<a href="test_<? echo $module ?>">PHP 1</a>
<a href="test_<?php echo $module ?>">PHP 2</a>
