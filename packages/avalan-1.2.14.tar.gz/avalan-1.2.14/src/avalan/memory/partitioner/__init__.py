from typing import Literal

Encoding = Literal["utf8"]


class PartitionerException(BaseException):
    pass
