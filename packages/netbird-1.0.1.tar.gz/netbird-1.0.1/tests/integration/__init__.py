"""
Integration tests for NetBird Python Client.
"""
