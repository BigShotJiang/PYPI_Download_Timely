"""
NetBird Python Client Tests

Test suite for the NetBird API client library.
"""
