"""
Unit tests for NetBird Python Client.
"""
