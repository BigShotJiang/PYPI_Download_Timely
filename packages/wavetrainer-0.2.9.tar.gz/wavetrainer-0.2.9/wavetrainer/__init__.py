"""The wavetrain main module."""

from .create import create

__VERSION__ = "0.2.9"
__all__ = ("create",)
