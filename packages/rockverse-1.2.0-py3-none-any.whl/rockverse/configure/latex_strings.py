LATEX_STRINGS = {
    'um': r'$\mu$m',
}
