CLIENT_ID: str = "azzbmgahm4n02w8z6ohmcnnaeug0af"
CLIENT_SECRET: str = "ck5fk7njrfz58u0orzrqs30dqkkbcx"

cooldown = 20  #sec