"""package housing the interfaces of nrtk."""
