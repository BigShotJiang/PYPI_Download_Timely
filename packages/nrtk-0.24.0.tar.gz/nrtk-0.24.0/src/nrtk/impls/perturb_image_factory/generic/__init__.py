"""Module for generic implementations of PerturbImageFactory."""
