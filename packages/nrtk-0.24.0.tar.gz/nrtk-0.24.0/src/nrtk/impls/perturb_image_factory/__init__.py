"""Module for all implementations of PerturbImageFactory."""
