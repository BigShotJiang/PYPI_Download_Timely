"""Module for the scoring implementations."""
