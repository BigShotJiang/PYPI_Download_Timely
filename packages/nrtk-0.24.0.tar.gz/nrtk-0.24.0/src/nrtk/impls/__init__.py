"""Module for all implementations of nrtk interfaces."""
