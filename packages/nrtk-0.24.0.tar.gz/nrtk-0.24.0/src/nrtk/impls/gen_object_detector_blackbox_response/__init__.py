"""Module for implementations of GenerateObjectDetectorBlackboxResponse interface."""
