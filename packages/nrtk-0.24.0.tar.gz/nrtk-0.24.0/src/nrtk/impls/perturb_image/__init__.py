"""Module for all PerturbImage implementations."""
