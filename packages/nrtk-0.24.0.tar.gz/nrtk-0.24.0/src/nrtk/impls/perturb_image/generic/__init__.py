"""Module for all generic implementations of PerturbImage."""
