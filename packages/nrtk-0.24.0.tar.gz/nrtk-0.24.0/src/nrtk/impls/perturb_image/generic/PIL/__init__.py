"""Module for PIL based implementations of PerturbImage."""
