"""Module for skimage based implementations of PerturbImage."""
