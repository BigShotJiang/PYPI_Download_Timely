"""Module for cv2 based implementations of PerturbImage."""
