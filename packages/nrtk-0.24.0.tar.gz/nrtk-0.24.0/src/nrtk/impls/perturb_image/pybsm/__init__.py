"""Module for PyBSM based implementations of PerturbImage."""
