"""Module for implementations of ImageMetric interface."""
