# -*- coding: utf-8 -*-

from .atom_tab import get_atom_widgets
from .bader_tab import get_bader_widgets
from .grid_tab import get_grid_widgets
from .view_tab import get_view_widgets
