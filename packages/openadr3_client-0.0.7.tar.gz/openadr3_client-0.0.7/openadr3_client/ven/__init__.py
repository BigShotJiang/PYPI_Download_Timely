"""
Virtual End Node (BL) module of the OpenADR3 Client.

This module provides VEN specific logic and implementations for the OpenADR3 Client.
"""
