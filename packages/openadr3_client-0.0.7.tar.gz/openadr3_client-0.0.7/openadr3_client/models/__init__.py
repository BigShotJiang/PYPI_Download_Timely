"""
Domain module of the OpenADR3 Client.

This module implements all the domain objects and domain logic of the OpenADR3 Client library.
"""
