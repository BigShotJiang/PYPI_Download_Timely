"""Contains common types and logic for the event conversion module."""
