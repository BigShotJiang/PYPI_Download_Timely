# jsonchain
 A small library to aid in chaining techniques taught by Structural Python
