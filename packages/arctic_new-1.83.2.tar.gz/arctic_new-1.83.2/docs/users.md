Are you using Arctic?  If so, please do let us know.

## Current Users

* [Man Group](https://www.man.com/)
* * [AHL](https://www.ahl.com/tick-data-storage)
* * [Numeric](https://www.numeric.com/)
* * [GLG](https://www.glgpartners.com/)
* * [FRM](https://www.frmhedge.com/)
* 7 Chord, LLC
