# Development moved to ArcticDB GitHub Repository

This repository and project are now in maintenance mode. Development has migrated to [ArcticDB](https://github.com/man-group/ArcticDB).

---

Information on how to set up, install and use Arctic has been moved to [README-arctic.md](README-arctic.md). 
