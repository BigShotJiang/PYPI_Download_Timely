from ..llm import LLM


class Claude(LLM):
    def __init__(self):
        pass
