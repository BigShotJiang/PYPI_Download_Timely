from mcpclient.dev import open_local_chat
open_local_chat()