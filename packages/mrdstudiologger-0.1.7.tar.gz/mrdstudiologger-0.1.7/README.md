# mrd-studio-logger

🌈 Rich-powered two-column logging middleware for FastAPI.
- Left column: API access logs (colored by HTTP code)
- Right column: Custom logs from OCR or any other context

## Install

```bash
pip install mrd-studio-logger
