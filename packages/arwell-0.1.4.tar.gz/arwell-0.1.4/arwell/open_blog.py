import webbrowser

def open_blog():
    """跳转到 jingliangwei.github.io/blog 网页"""
    webbrowser.open("https://jingliangwei.github.io/blog")