"""
sh2mp4 - Records shell commands to MP4 videos
"""

__version__ = "0.2.0"
