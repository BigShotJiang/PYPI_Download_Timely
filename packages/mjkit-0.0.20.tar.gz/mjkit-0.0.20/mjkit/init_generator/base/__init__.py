"""
자동 생성 파일입니다. 직접 수정하지 마세요.
생성일자: 2025-07-24
생성 위치: init_generator/base/__init__.py
"""
from .base_init_generator import BaseInitGenerator

__all__ = [
    "BaseInitGenerator"
]
