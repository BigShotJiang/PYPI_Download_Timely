"""
SCRUMS-CLI: Your AI meeting assistant for real-time transcription
"""

__version__ = "0.1.0"
__author__ = "Rachit Gandhi"
__description__ = "Cause Real Devs do Scrums in CLI"