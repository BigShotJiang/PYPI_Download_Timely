# Makes meetings a package for editable installs
