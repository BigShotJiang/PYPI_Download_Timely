TwineW Macro v0.0.3 by WilsonSTW

Open source endurance macro used for Fortnite: Save the World.