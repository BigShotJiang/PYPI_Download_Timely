# `category` module

::: pyfredapi.category