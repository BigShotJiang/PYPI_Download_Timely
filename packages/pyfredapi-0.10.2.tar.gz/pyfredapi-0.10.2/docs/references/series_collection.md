# `series_collection` module

::: pyfredapi.series_collection