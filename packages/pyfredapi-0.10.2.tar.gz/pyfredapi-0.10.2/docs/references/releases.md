# `releases` module

::: pyfredapi.releases