# `series` module

::: pyfredapi.series