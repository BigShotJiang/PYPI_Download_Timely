# `tags` module

::: pyfredapi.tags