from pylucas.fileops.Function import ListFiles, FilesCopyer, FilesClear
from pylucas.fileops.Class import ConfigEditor