from pylucas.log.Class import LogManager
from pylucas.log.Function import ASCII_Art