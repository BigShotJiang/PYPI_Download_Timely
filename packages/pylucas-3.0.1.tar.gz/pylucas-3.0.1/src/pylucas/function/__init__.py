from pylucas.function.Function import GetTimeStamp, GetCurrentFrameInfo, lindex, rindex
