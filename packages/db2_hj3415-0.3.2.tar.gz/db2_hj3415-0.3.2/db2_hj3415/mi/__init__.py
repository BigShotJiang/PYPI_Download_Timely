DB_NAME = 'mi'
DATE_FORMAT = "%Y.%m.%d"

from db2_hj3415.common import connection
from db2_hj3415.common.utils import *
from db2_hj3415.common.db_ops import *

from .models import *