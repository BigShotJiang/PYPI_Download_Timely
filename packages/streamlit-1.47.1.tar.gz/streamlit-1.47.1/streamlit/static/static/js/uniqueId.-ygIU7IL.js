import{K as a,g as d}from"./index.CbQtRkVt.js";var r,u;function q(){if(u)return r;u=1;var e=a(),i=0;function n(t){var o=++i;return e(t)+o}return r=n,r}var s=q();const I=d(s);export{I as u};
