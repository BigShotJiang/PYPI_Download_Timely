#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#----------------#
# Import modules #
#----------------#

import numpy as np
import scipy.optimize as sco

#------------------#
# Define functions #
#------------------#

# Polynomial regression #
#-----------------------#

# Linear #

# Quadratic #

# Cubic #
