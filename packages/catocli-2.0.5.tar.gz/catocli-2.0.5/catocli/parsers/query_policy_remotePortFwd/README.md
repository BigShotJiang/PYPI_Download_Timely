
## CATO-CLI - query.policy.remotePortFwd:
[Click here](https://api.catonetworks.com/documentation/#query-remotePortFwd) for documentation on this operation.

### Usage for query.policy.remotePortFwd:

`catocli query policy remotePortFwd -h`
