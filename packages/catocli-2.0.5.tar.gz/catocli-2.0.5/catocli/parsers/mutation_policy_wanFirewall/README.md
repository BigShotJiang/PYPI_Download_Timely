
## CATO-CLI - mutation.policy.wanFirewall:
[Click here](https://api.catonetworks.com/documentation/#mutation-wanFirewall) for documentation on this operation.

### Usage for mutation.policy.wanFirewall:

`catocli mutation policy wanFirewall -h`
