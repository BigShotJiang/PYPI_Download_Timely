
## CATO-CLI - mutation.sites:
[Click here](https://api.catonetworks.com/documentation/#mutation-sites) for documentation on this operation.

### Usage for mutation.sites:

`catocli mutation sites -h`
