
## CATO-CLI - query.policy.socketLan:
[Click here](https://api.catonetworks.com/documentation/#query-socketLan) for documentation on this operation.

### Usage for query.policy.socketLan:

`catocli query policy socketLan -h`
