
## CATO-CLI - mutation.policy.remotePortFwd:
[Click here](https://api.catonetworks.com/documentation/#mutation-remotePortFwd) for documentation on this operation.

### Usage for mutation.policy.remotePortFwd:

`catocli mutation policy remotePortFwd -h`
