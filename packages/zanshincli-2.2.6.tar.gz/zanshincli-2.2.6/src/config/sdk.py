from src.lib.models import OutputFormat

entries: int = 1
profile: str
format: OutputFormat
debug: bool
verbose: bool
