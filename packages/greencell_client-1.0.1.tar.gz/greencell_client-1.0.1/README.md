# Greencell Client library

This library is a collection of classes used by the Home Assistant integration for Greencell devices and not directly using the Home Assistant function.
