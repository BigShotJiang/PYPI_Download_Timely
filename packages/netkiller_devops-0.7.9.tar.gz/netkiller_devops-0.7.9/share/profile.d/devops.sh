export PATH=$PATH:/srv/devops/bin
