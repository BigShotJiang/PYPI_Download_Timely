"""
Initialize the openSAMPL package.

Adding this to ensure backwards compatibility with older versions of opensampl where orm import was:
from opensampl import orm
"""
