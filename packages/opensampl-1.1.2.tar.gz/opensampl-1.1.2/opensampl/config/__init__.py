"""
Configuration module for openSAMPL.

This module provides configuration management functionality for the openSAMPL package,
including environment variable handling and settings validation.
"""
