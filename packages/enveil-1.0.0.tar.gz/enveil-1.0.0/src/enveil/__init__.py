"""
Enveil - A secure, cross-platform tool to gather system environment information.
"""
from .api import EnveilAPI

__all__ = ["EnveilAPI"]
