"""
<< DOCSTRING_01>>
"""
from typing import Any
from .module import *
import sys

_instance = NoModule()
_instance.xcpt = NoBaseError

sys.modules[__name__] = _instance # type: ignore[assignment]

def __call__(
    code: int,
    *,
    message: str = "",
    soften: bool = False
) -> None: 
    """
    << DOCSTRING_02>>
    """
    ...

def __getattr__(name: str) -> Any:
    """
    << DOCSTRING_03>>
    """

    if name == "xcpt":
        return _instance.xcpt
    if name == "no":
        return _instance
    
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")

def register(
    code: int,
    message: str = "",
    *,
    soften: bool = False
) -> None:
    """
    << DOCSTRING_04>>
    """
    _instance.register(code, message, soft=soften)