"""IO handler tests"""
