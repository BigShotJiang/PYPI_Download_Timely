"""CLI tests"""
