"""Spotter - Production-grade spot instance scheduling for EKS worker nodes."""

__version__ = "1.0.0"
