# the content of the file is replaced with the real version in the odiglet DOCKERFILE
VERSION = "development"