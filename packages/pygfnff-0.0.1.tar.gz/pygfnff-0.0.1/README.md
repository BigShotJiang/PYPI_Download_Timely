![](abstract.png)


# PyGFNFF

This is a Python version for [GFN-FF](https://github.com/pprcht/gfnff).



### Reference
1. S.Spicher, S.Grimme. Robust Atomistic Modeling of Materials, Organometallic, and Biochemical Systems (2020), DOI: https://doi.org/10.1002/anie.202004239
