from textual.widgets import Footer as Footer  # noqa: F401
