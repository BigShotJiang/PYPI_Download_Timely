default_jit_options = {"cache": True}

MAX_STR_LENGTH = 2 ** 31 - 1
