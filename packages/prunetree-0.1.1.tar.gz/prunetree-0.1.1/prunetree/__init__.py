# prunedtree/__init__.py
from .tree import PrunedDecisionTreeClassifier

__all__ = ["PrunedDecisionTreeClassifier"]