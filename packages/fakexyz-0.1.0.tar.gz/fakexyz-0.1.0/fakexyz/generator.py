from .data_loader import load_data
import random

data = load_data()

def get_random_profile():
    address = random.choice(data['addresses'])
    profile_info = {
        "name": address['name'],
        "gender": address['gender'],
        "phone_number": address['phone_number'],
        "email": data['profile']['email'],
        "dob": data['profile']['dob']['date'],
        "nid": data['profile']['nid'],
        "ssn": data['profile']['ssn'],
        "birth_certificate_number": data['profile']['birth_certificate_number'],
        "street_address": address['street_address'],
        "city": address['city'],
        "state": address['state'],
        "postal_code": address['postal_code'],
        "avatar_url": address['avatar_url'],
    }
    return profile_info
