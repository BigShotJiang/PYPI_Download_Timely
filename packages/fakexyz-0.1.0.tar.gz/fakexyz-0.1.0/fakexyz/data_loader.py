import os
import json

def load_data():
    current_dir = os.path.dirname(__file__)
    file_path = os.path.join(current_dir, "data", "ae.json")
    with open(file_path, encoding="utf-8") as f:
        return json.load(f)
