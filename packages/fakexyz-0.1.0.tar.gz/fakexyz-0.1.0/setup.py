from setuptools import setup, find_packages

setup(
    name="fakexyz",
    version="0.1.0",
    packages=find_packages(),
    include_package_data=True,
    package_data={"fakexyz": ["data/*.json"]},
    description="Generate UAE-based fake user and address information.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Your Name",
    author_email="your@email.com",
    url="https://github.com/yourusername/fakexyz",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent"
    ],
    python_requires=">=3.7",
)
