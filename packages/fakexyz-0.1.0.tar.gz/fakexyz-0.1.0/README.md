# fakexyz

Generate UAE-based fake user and address data from a structured JSON.

## Installation

```bash
pip install fakexyz
