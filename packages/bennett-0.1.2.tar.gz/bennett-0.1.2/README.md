# bennett

A simple wrapper to send prompts to Groq’s LLaMA-3 models using streaming.

## Installation

```bash
pip install bennett
