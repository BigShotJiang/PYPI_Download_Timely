from django.apps import AppConfig


class DjangoFormulaireAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'formulaire_app'
