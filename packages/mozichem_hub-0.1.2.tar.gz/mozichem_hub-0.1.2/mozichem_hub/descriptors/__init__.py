from .mcp_descriptor import MCPDescriptor

__all__ = [
    'MCPDescriptor',
]
