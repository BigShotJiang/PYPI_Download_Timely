# Version

[Rootloader Index](../README.md#rootloader-index) / [Rootloader](./index.md#rootloader) / Version

> Auto-generated documentation for [rootloader.version](../../rootloader/version.py) module.
- [Version](#version)
