# Safe dummy package: openjpeg
