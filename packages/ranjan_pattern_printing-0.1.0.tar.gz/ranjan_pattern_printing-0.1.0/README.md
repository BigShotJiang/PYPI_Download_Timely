# Pattern

This is simple package to print patterns

# Installation

Install it using pip:

pip install Ranjan_pattern_printing

from pattern import (pyramid,right_angle,left_angle)

# pyramid

pyramid(5)

    * 
   * *
  * * *
 * * * *
* * * * *