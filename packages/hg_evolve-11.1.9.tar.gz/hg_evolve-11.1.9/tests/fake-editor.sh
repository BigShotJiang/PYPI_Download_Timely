#!/bin/sh
sleep 5
echo "new desc" >> $1
