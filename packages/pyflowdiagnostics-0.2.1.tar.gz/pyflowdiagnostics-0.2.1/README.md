# Flow Diagnostics Toolkit

- **Documentation:** https://GEG-ETHZ.github.io/pyflowdiagnostics
- **Source Code:** https://github.com/GEG-ETHZ/pyflowdiagnostics
- **Bug reports:** https://github.com/GEG-ETHZ/pyflowdiagnostics/issues
- **Zenodo:** https://doi.org/10.5281/zenodo.15625397

Available through `conda` and `pip`; consult the
[documentation](https://GEG-ETHZ.github.io/pyflowdiagnostics) for detailed
installation instructions.
