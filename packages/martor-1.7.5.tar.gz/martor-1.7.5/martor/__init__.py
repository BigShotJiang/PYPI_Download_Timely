__version__ = "1.7.5"
__release_date__ = "26-Jul-2025"
__author__ = "Agus Makmun (Summon Agus)"
__author_email__ = "summon.agus@gmail.com"
