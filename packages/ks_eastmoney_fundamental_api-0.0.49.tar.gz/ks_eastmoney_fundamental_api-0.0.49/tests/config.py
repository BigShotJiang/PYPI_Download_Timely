EXCHANGE = 'SEHK'
PRODUCT = 'EQUITY'
CONFIGS = [
    { 'config_name': '.ttvntrader_eastmoney', 'gateway_name': 'KS_EASTMONEY', 'setting': {'enable_short': False}},  
    # { 'config_name': '.ttvntrader_tiger', 'gateway_name': 'KS_TIGER', 'setting': {'enable_short': False}},  
    # { 'config_name': '.ttvntrader_mm', 'gateway_name': 'KS_MM', 'gateway_config': { "trade_api": {"setting": {"acc_id.us": 633812, "acc_id.hk": 633808}}}, 'setting': {'enable_short': False}},
    # { 'config_name': '.ttvntrader_longport', 'gateway_name': 'KS_LONGPORT', 'setting': {'enable_short': False}},
    # { 'config_name': '.ttvntrader_ibkr', 'gateway_name': 'KS_IBKR', 'setting': {'enable_short': False}},

]