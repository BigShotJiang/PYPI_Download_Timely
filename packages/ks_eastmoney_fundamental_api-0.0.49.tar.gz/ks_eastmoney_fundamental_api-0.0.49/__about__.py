# SPDX-FileCopyrightText: 2024-present liuyanzhi08 <702368372@qq.com>
#
# SPDX-License-Identifier: MIT
# __version__ = "0.0.30"
# __version__ = "0.0.32" # 增加YOYOR,YOYNI,CAGRTOR
# __version__ = "0.0.35" # 增加css_mry函数，支持批量获取最近N年年报数据
# __version__ = "0.0.36" # 增加css_mry和css_mrq的自动化测试用例
# __version__ = "0.0.39" # 增加毛利率
# __version__ = "0.0.40" # 修正css_mry的顺序问题
# __version__ = "0.0.41" # 修正css_mry的顺序问题
# __version__="0.0.42" # 增加净利率，经营活动现金流净值多年数据
# __version__="0.0.44" # 增加股息率，胜利支付率
# __version__="0.0.45" # 增加股息率TTM，PETTM
# __version__="0.0.48" # 增加ctr专题函数支持 https://quantapi.eastmoney.com/Cmd/ChioceTopicReport?from=web
__version__="0.0.49" # 增加CASHFLOWSTATEMENT_CASHEND(会计期末的现金及现金等价物余额)

