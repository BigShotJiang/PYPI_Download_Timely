from mlflow.server.auth.cli import commands

if __name__ == "__main__":
    commands()
