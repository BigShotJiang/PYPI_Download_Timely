"""Update the harp type CSV file"""

from aind_data_schema_models._generators.dev_utils import update_harp_types


if __name__ == "__main__":

    update_harp_types()
