"""
AgentSociety Benchmark package
"""

from .runner import BenchmarkRunner

__all__ = [
    "BenchmarkRunner"
]