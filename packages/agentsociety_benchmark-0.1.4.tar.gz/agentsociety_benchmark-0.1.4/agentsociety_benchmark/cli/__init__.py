"""
CLI module for agentsociety-benchmark
"""

from .config import BenchmarkConfig

__all__ = ["BenchmarkConfig"]