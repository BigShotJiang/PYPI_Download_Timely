"""Entry point for running claude-dash as a module"""

from .main import main

if __name__ == "__main__":
    main()