"""Claude Dash version information"""

__version__ = "0.9.2"
__version_info__ = (0, 9, 2)