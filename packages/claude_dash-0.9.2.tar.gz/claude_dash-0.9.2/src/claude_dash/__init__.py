"""Claude Dash - Monitor your Claude usage and subscription value"""

from .__version__ import __version__, __version_info__
from .main import main

__all__ = ["main", "__version__", "__version_info__"]