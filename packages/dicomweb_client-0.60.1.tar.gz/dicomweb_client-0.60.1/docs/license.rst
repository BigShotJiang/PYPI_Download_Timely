.. _license:

License
=======

*DICOMweb Client* is free and open source software licensed under the permissive `MIT license <https://opensource.org/licenses/MIT>`_.
