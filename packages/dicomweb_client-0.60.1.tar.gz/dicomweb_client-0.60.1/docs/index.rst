.. DICOMweb Client documentation master file, created by
   sphinx-quickstart on Fri Mar 16 11:19:16 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Documentation of the DICOMweb Client package
============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   introduction
   installation
   usage
   development
   conformance
   license
   package



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
