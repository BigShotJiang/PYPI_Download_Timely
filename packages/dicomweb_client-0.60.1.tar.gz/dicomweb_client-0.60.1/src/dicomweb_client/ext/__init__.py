"""Vendor-specific extensions of the `dicomweb_client` package."""
