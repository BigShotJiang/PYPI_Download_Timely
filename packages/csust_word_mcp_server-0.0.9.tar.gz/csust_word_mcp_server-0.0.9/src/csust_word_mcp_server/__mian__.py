from csust_word_mcp_server import main
main()