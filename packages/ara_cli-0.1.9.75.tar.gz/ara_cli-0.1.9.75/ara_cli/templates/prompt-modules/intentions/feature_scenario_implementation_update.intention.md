### INTENTION and CONTEXT
The Scenario `{scenario_name}` which is described in detail in the given feature file `{feature_file_name}` was modified.

My intention is to adapt the current implementation to the updated behaviour of Scenario `{scenario_name}`  
Focus on this scenario only. The other described scenarios are not to be considered.

{Further implementation specific context ...}

