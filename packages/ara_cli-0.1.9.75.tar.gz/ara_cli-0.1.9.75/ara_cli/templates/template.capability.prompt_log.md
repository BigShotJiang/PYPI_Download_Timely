# Capability Exploration: <descriptive title of exploration challenge>

- [Capability Exploration: ](#capability-exploration-)
- [initial exploration ...](#initial-exploration-)

# initial exploration ...
...