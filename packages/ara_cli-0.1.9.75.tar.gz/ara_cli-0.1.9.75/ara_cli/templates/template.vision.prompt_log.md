# Vision Exploration: <descriptive title of exploration challenge>

- [Vision Exploration: ](#vision-exploration-)
- [initial exploration ...](#initial-exploration-)

# initial exploration ...
...