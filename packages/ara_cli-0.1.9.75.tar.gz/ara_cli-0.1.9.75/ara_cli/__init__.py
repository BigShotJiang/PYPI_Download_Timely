from .version import __version__

whitelisted_commands = ["RERUN", "SEND", "EXTRACT", "LOAD_IMAGE", "CHOOSE_MODEL", "CURRENT_MODEL", "LIST_MODELS"]
