from .container_error import ContainerError


class ResolverError(ContainerError):
    pass
