from .container_error import ContainerError


class ExecutionError(ContainerError):
    pass
