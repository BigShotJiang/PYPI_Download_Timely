TEMPLATES = {
    "communities-metadata": "templates/communities_metadata.py.jinja2",
}
