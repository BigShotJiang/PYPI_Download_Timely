TEMPLATES = {
    "record-communities-test-resources": "templates/test_resources.py.jinja2",
    "record-communities-parent-conftest": "templates/parent_conftest.py.jinja2",
}
