TEMPLATES = {
    "communities-conftest": "templates/conftest.py.jinja2",
}
