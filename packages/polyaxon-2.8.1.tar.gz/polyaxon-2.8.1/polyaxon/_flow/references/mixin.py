class RefMixin:
    def get_kind_value(self):
        raise NotImplementedError
