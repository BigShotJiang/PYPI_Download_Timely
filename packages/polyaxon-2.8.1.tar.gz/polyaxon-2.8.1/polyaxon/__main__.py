from polyaxon.cli import cli

cli(auto_envvar_prefix="POLYAXON_CLI")
