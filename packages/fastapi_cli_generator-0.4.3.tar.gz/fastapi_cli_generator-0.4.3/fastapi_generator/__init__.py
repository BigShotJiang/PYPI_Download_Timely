"""
FastAPI Project Generator - A CLI tool for creating FastAPI projects
"""

__version__ = "0.2.0"
__author__ = "FastAPI Generator Team"
__description__ = "A command-line tool for generating FastAPI projects with different architectural patterns"
