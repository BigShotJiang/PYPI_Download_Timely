# Credits

## Project Lead

- Marília Barandas <marilia.barandas@fraunhofer.pt>

## Project Contributors

<!-- ```shell
git shortlog -nse
``` -->

Ivo Façoco <ivo.facoco@fraunhofer.pt>
Pedro Matias <pedro.matias@fraunhofer.pt>
Joana Rebelo <joana.rebelo@fraunhofer.pt>
Ana Morgado <ana.morgado@fraunhofer.pt>
Telmo Baptista <telmo.baptista@fraunhofer.pt>
Bruno Ribeiro <bruno.ribeiro@fraunhofer.pt>
Ana Sampaio <ana.sampaio@fraunhofer.pt>
João Miguel <joao.miguel@fraunhofer.pt>

Have an idea that you want to contribute to this project? Check out our [CONTRIBUTING](docs/CONTRIBUTING.md) guide!
