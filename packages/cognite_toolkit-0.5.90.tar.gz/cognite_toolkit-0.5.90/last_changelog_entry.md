## cdf 

### Added

- [alpha] The `cdf profile raw/transformations` will now prompt an
interactive select if you do not set destination.

## templates

No changes.