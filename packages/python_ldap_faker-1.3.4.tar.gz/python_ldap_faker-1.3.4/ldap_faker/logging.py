import logging

logger = logging.getLogger("ldapfaker")
