from typing import NewType

TopicName = NewType("TopicName", str)

ModelName = NewType("ModelName", str)
ModelVersion = NewType("ModelVersion", str)
