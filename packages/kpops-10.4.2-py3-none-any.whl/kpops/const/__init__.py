__version__ = "10.4.2"
KPOPS = "KPOps"
KPOPS_MODULE = "kpops."
