# # Info
# VERSION = "1.2.6"

# Header
USER_AGENT = "User-Agent"
AUTHORIZATION = "Authorization"
CONTENT_TYPE = "Content-Type"

# Content-Type
APPLICATION_JSON = "application/json"

UTF_8 = "UTF-8"


SLEEP_BASE_TIME = 0.1
