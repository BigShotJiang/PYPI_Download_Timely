"""Module for RDBMS dialects."""
