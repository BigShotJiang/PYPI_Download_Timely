"""RedisConnector.

TODO: Implement RedisConnector.
"""


class RedisConnector:
    """RedisConnector."""

    pass
