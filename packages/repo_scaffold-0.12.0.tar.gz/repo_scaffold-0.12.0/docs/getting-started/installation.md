# Installation

## Quick Install

```bash
# Using uvx (recommended)
uvx install repo-scaffold

# Using pip
pip install repo-scaffold
```

## Verify

```bash
repo-scaffold --version
```

## Requirements

- Python 3.12+