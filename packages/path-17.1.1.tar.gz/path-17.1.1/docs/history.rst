:tocdepth: 1

.. _changes:

History
*******

.. include:: ../NEWS (links).rst
