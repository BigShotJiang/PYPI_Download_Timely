"""Main module for boot_dummy package.

I think CLI usage would go here.
"""

from .dummy import GenerateData

if __name__ == "__main__":
    pass
