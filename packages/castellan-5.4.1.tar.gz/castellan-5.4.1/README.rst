=========
Castellan
=========

Generic Key Manager interface for OpenStack.

* License: Apache License, Version 2.0
* Documentation: https://docs.openstack.org/castellan/latest
* Source: https://opendev.org/openstack/castellan
* Bugs: https://bugs.launchpad.net/castellan
* Release notes: https://docs.openstack.org/releasenotes/castellan
* Wiki: https://wiki.openstack.org/wiki/Castellan

Team and repository tags
========================

.. image:: https://governance.openstack.org/tc/badges/castellan.svg
    :target: https://governance.openstack.org/tc/reference/tags/index.html
