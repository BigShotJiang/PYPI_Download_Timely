============
Installation
============

At the command line::

    $ pip install castellan

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv castellan
    $ pip install castellan
