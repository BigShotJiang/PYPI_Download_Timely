__version__ = "0.2.2alpha0"
print(f"SCIPPlan Version: {__version__}")
__release__ = "v0.2.2a0"
__author__ = "Ari Gestetner, Buser Say"
__email__ = "ari.gestetner@monash.edu, buser.say@monash.edu"
