from mindtrace.core.config.config import Config

__all__ = ["Config"]
