"""Constants for the rtl_433_discoverandsubmit integration."""

DOMAIN = "rtl_433_discoverandsubmit"
DATA_DEVICES = "devices"
DATA_PENDING = "pending"
OPTION_DEVICES = "devices"
