# SPDX-License-Identifier: MPL-2.0
"""Basic test module."""

from __future__ import annotations


def fn() -> None:
    """Test function."""


class Cls:
    """Test class."""
