API
===

.. module:: session_info2
.. autofunction:: session_info
.. autoclass:: SessionInfo
   :members:
   :private-members: _repr_mimebundle_
   :special-members: __repr__
