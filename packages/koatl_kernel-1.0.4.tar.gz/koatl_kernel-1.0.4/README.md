This is the jupyter kernel for koatl.
