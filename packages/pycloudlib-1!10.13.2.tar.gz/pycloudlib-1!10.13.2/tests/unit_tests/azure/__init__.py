"""Tests related to pycloudlib.azure module."""
