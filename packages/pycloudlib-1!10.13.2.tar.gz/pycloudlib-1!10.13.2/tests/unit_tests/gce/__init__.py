# This file is part of pycloudlib. See LICENSE file for license information.
"""Main GCE tests module __init__."""
