"""EC2 integration tests."""
