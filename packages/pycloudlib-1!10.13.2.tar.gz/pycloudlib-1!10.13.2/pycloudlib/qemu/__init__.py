"""Main QEMU module __init__."""
