# This file is part of pycloudlib. See LICENSE file for license information.
"""Constants."""

from pycloudlib.util import _get_local_ubuntu_arch

LOCAL_UBUNTU_ARCH = _get_local_ubuntu_arch()
