# SPDX-License-Identifier: GPL-3.0-or-later
from starmap_client.client import StarmapClient

__all__ = ["StarmapClient"]
