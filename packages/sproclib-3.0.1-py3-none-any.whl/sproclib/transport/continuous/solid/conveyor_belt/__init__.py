"""
ConveyorBelt Package

This package provides ConveyorBelt models for solid transport.
"""

from .conveyor_belt import ConveyorBelt

__all__ = ['ConveyorBelt']
