from truefoundry.ml.log_types.image.image import Image

__all__ = ["Image"]
