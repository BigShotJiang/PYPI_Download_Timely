from setuptools import setup,find_packages

setup(
    name="mangekyu",
    version='0.1',
    author='kaushik',
    author_email='pubgkaushik@gmail.com',
    description='this is speech to text package created by Kaushik')
install_requirment=[
    'selenium',
    'webdriver_manager'
]