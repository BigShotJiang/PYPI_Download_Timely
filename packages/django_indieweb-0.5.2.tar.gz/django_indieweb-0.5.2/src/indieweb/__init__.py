"""
includes indieauth, micropub, and webmention endpoints
"""

__version__ = "0.5.2"
