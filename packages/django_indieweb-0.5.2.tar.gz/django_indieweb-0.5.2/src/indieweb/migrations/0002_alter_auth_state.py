# Generated manually to fix state field type

from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("indieweb", "0001_initial"),
    ]

    operations = [
        migrations.AlterField(
            model_name="auth",
            name="state",
            field=models.CharField(max_length=32),
        ),
    ]
