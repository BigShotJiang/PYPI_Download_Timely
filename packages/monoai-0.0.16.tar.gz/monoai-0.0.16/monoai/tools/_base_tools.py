class BaseTool:

    def get_tool(self):
        return self._tool()

    
