:icon: material/file-outline

Files
=====

Newer instruments implement file system commands, that can be used to
manage, browse or retrieve files from the device.

.. toctree::
    :maxdepth: 1

    list
    download
