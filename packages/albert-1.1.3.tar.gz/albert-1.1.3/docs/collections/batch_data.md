::: albert.collections.batch_data.BatchDataCollection
