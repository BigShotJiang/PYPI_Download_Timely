class X:
    def __init__(self, x):
        self.x = x


class Y:
    def __init__(self, x):
        self.x = x
