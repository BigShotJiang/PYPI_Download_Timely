class X:
    def __init__(self, x):
        self.x = x
