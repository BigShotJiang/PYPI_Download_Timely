def visit_operacion_binaria(self, nodo):
    self.codigo += self.obtener_valor(nodo)
