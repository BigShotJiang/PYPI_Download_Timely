def visit_romper(self, nodo):
    self.codigo += f"{self.obtener_indentacion()}break\n"
