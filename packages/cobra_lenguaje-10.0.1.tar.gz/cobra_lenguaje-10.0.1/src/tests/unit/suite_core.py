import pathlib
import pytest
import sys


def main():
    root = pathlib.Path(__file__).parent
    sys.exit(pytest.main([str(root), '-k', 'not cli']))


if __name__ == '__main__':
    main()
