# Yumbox (Yadgiri Machine Toolbox -- also yummy!)

Provides tools for:

- Caching results of functions
- Setting up logger and cache dir using config
- Image and text data loaders
- Easily create instances of ML models
- Evaluation metrics
- NLP tools

# TODO:

- [ ] Better json dumps!
    - Handles conversion of set to list.
    - Handles conversion of float('nan') to str. (it already natively supports an arg!)

- [ ] FS:
    - An API that wraps popular save/load functions and makes them safe.

- [ ] Better logging?
    - ```python
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
    )
    logger = logging.getLogger(__name__)
      ```

- [ ] mlflow:
    - kill and cleanup child process on run all configs

- [ ] NLP tools:
    - defaultname feat: change default of a cluster

- [ ] Cache:
    - A super cache function with all cache abilities!

- [ ] MLFlow:
    - Aggregate metrics specify extra cols to show in terminal print

# CLI

metrics-cli analyze \
    --storage-path /path/to/mlflow/storage \
    --select-metrics acc loss \
    --metrics-to-mean acc loss \
    --mean-metric-name avg_score \
    --sort-metric acc \
    --run-mode both \
    --output-csv metrics.csv \
    --x-metric acc \
    --y-metric loss \
    --color-metric avg_score \
    --title "My Metrics Plot" \
    --theme plotly_dark

`hatch run sphinx-build -b html docs docs/_build`

TODO: checkpoint remover should keep the checkpoints where the highest score appeared first not last, so we do not keep the overfit model if value does not change.
