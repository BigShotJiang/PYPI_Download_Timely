import unittest

import yumbox


class TestCalculator(unittest.TestCase):

    def setUp(self):
        self.resolver = yumbox.nlp.tools.defaultname()


if __name__ == "__main__":
    unittest.main()
