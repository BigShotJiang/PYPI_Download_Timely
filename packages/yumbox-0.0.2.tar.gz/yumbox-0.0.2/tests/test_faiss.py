from time import time

import numpy as np

import yumbox


def test_indexes(
    features: np.ndarray,
    queries: np.ndarray,
    k: int = 10,
    use_gpu: bool = False,
    verbose: bool = False,
) -> dict:
    """
    Tests build and search times for all index types.

    Args:
        features (np.ndarray): Feature vectors to index [n_samples, embed_size]
        queries (np.ndarray): Query vectors [n_queries, embed_size]
        k (int): Number of nearest neighbors to search (default: 10)
        use_gpu (bool): Use GPU acceleration if available (default: False)

    Returns:
        dict: Results with build times, search times, distances, and indices
    """
    builder = yumbox.factory.FaissIndexBuilder(verbose=verbose)

    # Normalize for cosine similarity (inner product)
    features_norm = builder.normalize_vectors(features)
    queries_norm = builder.normalize_vectors(queries)

    index_types = {
        "FlatIP": builder.build_flat_ip_index,
        "IVF": builder.build_ivf_index,
        "HNSW": builder.build_hnsw_index,
        "PQ": builder.build_pq_index,
        "IVFPQ": builder.build_ivfpq_index,
    }

    results = {}
    for name, build_func in index_types.items():
        if verbose:
            print(f"\nTesting {name} Index")
            print("-" * 20)
        else:
            print(f"\nTesting {name} Index")

        # Build index with normalized features
        index = build_func(features_norm, use_gpu=use_gpu)

        # Test search speed with normalized queries
        start_time = time()
        distances, indices = index.search(queries_norm, k)
        search_time = time() - start_time

        if verbose:
            print(f"Search time for {k} neighbors: {search_time:.4f} seconds")
            print(f"Average distance: {np.mean(distances):.4f}")
            print(f"Result shape: distances={distances.shape}, indices={indices.shape}")
        else:
            print(f"Search time for {k} neighbors: {search_time:.4f} seconds")

        results[name] = {
            "distances": distances,
            "indices": indices,
            "search_time": search_time,
        }

    return results
