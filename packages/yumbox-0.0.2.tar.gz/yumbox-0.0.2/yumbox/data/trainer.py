import random
import warnings
from collections.abc import Callable
from typing import Any, Literal

import albumentations as A
import numpy as np
import torch
import torchvision.transforms.functional as F
from PIL import Image
from torch.utils.data import DataLoader, Dataset, Sampler, Subset
from torchvision.transforms.transforms import Compose


def MaybeToTensor(image: np.ndarray | torch.Tensor):
    if isinstance(image, torch.Tensor):
        return image
    return F.to_tensor(image)


class FlexibleDataset(Dataset):
    def __init__(
        self,
        mode: Literal["text", "image", "text_image"],
        texts: np.ndarray | list | None = None,
        images: np.ndarray | list | None = None,
        labels: np.ndarray | list | None = None,
        txt_callables: list[Callable] = None,
        img_callables: list[Callable] = None,
    ):
        self.texts = texts
        self.images = images
        self.mode = mode
        self.txt_callables = txt_callables
        self.img_callables = img_callables

        if mode == "text_image":
            assert len(self.texts) == len(self.images)

        self.dataset_size = len(self.texts) if mode == "text" else len(self.images)
        self.labels = np.arange(self.dataset_size) if labels is None else labels

        self._original_indices = np.arange(self.dataset_size)
        self._shuffled_indices = self._original_indices.copy()

    def __len__(self) -> int:
        return self.dataset_size

    def get_text(self, idx: int) -> np.ndarray | torch.Tensor:
        text = self.texts[idx]
        if self.txt_callables is not None:
            for callable in self.txt_callables:
                text = callable(text)
        return text

    def get_image(self, idx: int) -> np.ndarray | torch.Tensor:
        image_path = self.images[idx]
        image = Image.open(image_path).convert("RGB")
        if self.img_callables is not None:
            for callable in self.img_callables:
                # Check if transform is from torchvision
                if isinstance(callable, Compose):
                    # Convert PIL image to tensor if needed for torchvision
                    image = callable(image)
                # Check if transform is from albumentations
                elif isinstance(callable, A.Compose):
                    # Convert PIL image to numpy array for albumentations
                    image_np = np.array(image)
                    # Apply albumentations transform
                    augmented = callable(image=image_np)
                    image = augmented["image"]
                else:
                    # Assume callable is a custom function
                    image = callable(image)
        return image

    def __getitem__(self, index: int) -> dict[str, Any]:
        idx = self._shuffled_indices[index]
        lab = self.labels[idx]
        if self.mode == "text":
            return self.get_text(idx), lab
        if self.mode == "image":
            return self.get_image(idx), lab
        elif self.mode == "text_image":
            return (self.get_text(idx), self.get_image(idx)), lab

    def set_epoch(self, epoch: int) -> None:
        """Set the current epoch and update shuffle state.
        Use epoch as random seed to ensure consistent shuffling within epoch
        """
        # rng = np.random.RandomState(seed=epoch)
        rng = np.random.default_rng(epoch)
        self._shuffled_indices = self._original_indices.copy()
        rng.shuffle(self._shuffled_indices)

    def verify_dataset_size(self, expected_size: int) -> bool:
        """Verify that dataset size hasn't changed."""
        if self.dataset_size != expected_size:
            warnings.warn(
                f"Dataset size mismatch! Expected: {expected_size}, Actual: {self.dataset_size}"
            )
            return False
        return True


class FlexiblePairDataset(FlexibleDataset):
    def __init__(
        self,
        mode: Literal["text_pair", "image_pair", "text_image_pair"],
        texts1: np.ndarray | list | None = None,
        texts2: np.ndarray | list | None = None,
        images1: np.ndarray | list | None = None,
        images2: np.ndarray | list | None = None,
        labels: np.ndarray | list | None = None,
        txt_callables: list[Callable] = None,
        img_callables: list[Callable] = None,
    ):
        """
        Initialize the FlexiblePairDataset for handling pairs of data.

        Args:
            mode: The type of pair data ("text_pair", "image_pair", "text_image_pair").
            texts1: First list of texts (for text_pair or text_image_pair modes).
            texts2: Second list of texts (for text_pair or text_image_pair modes).
            images1: First list of image paths (for image_pair or text_image_pair modes).
            images2: Second list of image paths (for image_pair or text_image_pair modes).
            labels: Labels for the pairs (defaults to indices if None).
            txt_callables: List of transformations for text data.
            img_callables: List of transformations for image data.
        """
        self.mode = mode
        self.txt_callables = txt_callables
        self.img_callables = img_callables

        # Set up data based on mode and validate lengths
        if mode == "text_pair":
            assert (
                texts1 is not None and texts2 is not None
            ), "Both texts1 and texts2 must be provided for text_pair mode"
            assert len(texts1) == len(
                texts2
            ), "texts1 and texts2 must have the same length"
            self.texts1 = texts1
            self.texts2 = texts2
            self.dataset_size = len(texts1)
        elif mode == "image_pair":
            assert (
                images1 is not None and images2 is not None
            ), "Both images1 and images2 must be provided for image_pair mode"
            assert len(images1) == len(
                images2
            ), "images1 and images2 must have the same length"
            self.images1 = images1
            self.images2 = images2
            self.dataset_size = len(images1)
        elif mode == "text_image_pair":
            assert all(
                x is not None for x in [texts1, images1, texts2, images2]
            ), "All text and image lists must be provided for text_image_pair mode"
            assert (
                len(texts1) == len(images1) == len(texts2) == len(images2)
            ), "All lists must have the same length"
            self.texts1 = texts1
            self.images1 = images1
            self.texts2 = texts2
            self.images2 = images2
            self.dataset_size = len(texts1)
        else:
            raise ValueError(
                f"Invalid mode: {mode}. Must be 'text_pair', 'image_pair', or 'text_image_pair'"
            )

        # Set labels (default to indices if not provided)
        self.labels = np.arange(self.dataset_size) if labels is None else labels
        assert (
            len(self.labels) == self.dataset_size
        ), "Labels length must match dataset size"

        # Initialize shuffling indices
        self._original_indices = np.arange(self.dataset_size)
        self._shuffled_indices = self._original_indices.copy()

    def get_text_from_list(self, text_list, idx):
        """
        Retrieve and transform text from a specified list at the given index.

        Args:
            text_list: List of texts to process.
            idx: Index of the text to retrieve.

        Returns:
            Transformed text.
        """
        text = text_list[idx]
        if self.txt_callables is not None:
            for callable in self.txt_callables:
                text = callable(text)
        return text

    def get_image_from_list(self, image_list, idx):
        """
        Retrieve and transform an image from a specified list at the given index.

        Args:
            image_list: List of image paths to process.
            idx: Index of the image to retrieve.

        Returns:
            Transformed image.
        """
        image_path = image_list[idx]
        image = Image.open(image_path).convert("RGB")
        if self.img_callables is not None:
            for callable in self.img_callables:
                if isinstance(callable, Compose):
                    image = callable(image)
                elif isinstance(callable, A.Compose):
                    image_np = np.array(image)
                    augmented = callable(image=image_np)
                    image = augmented["image"]
                else:
                    image = callable(image)
        return image

    def __getitem__(self, index: int) -> tuple:
        """
        Retrieve a pair of items and their label at the specified index.

        Args:
            index: Index of the pair to retrieve.

        Returns:
            Tuple containing the pair of data and the label.
            - For text_pair: ((text1, text2), label)
            - For image_pair: ((image1, image2), label)
            - For text_image_pair: (((text1, image1), (text2, image2)), label)
        """
        idx = self._shuffled_indices[index]
        lab = self.labels[idx]

        if self.mode == "text_pair":
            text1 = self.get_text_from_list(self.texts1, idx)
            text2 = self.get_text_from_list(self.texts2, idx)
            return (text1, text2), lab
        elif self.mode == "image_pair":
            image1 = self.get_image_from_list(self.images1, idx)
            image2 = self.get_image_from_list(self.images2, idx)
            return (image1, image2), lab
        elif self.mode == "text_image_pair":
            text1 = self.get_text_from_list(self.texts1, idx)
            image1 = self.get_image_from_list(self.images1, idx)
            text2 = self.get_text_from_list(self.texts2, idx)
            image2 = self.get_image_from_list(self.images2, idx)
            return ((text1, image1), (text2, image2)), lab

    def __len__(self) -> int:
        """Return the size of the dataset."""
        return self.dataset_size


class FlexibleTripletDataset(FlexibleDataset):
    def __init__(
        self,
        mode: Literal["text_triplet", "image_triplet", "text_image_triplet"],
        texts1: np.ndarray | list | None = None,
        texts2: np.ndarray | list | None = None,
        texts3: np.ndarray | list | None = None,
        images1: np.ndarray | list | None = None,
        images2: np.ndarray | list | None = None,
        images3: np.ndarray | list | None = None,
        txt_callables: list[Callable] = None,
        img_callables: list[Callable] = None,
    ):
        """
        Initialize the FlexibleTripletDataset for handling triplets of data.

        Args:
            mode: The type of triplet data ("text_triplet", "image_triplet", "text_image_triplet").
            texts1: First list of texts (for text_triplet or text_image_triplet modes).
            texts2: Second list of texts (for text_triplet or text_image_triplet modes).
            texts3: Third list of texts (for text_triplet or text_image_triplet modes).
            images1: First list of image paths (for image_triplet or text_image_triplet modes).
            images2: Second list of image paths (for image_triplet or text_image_triplet modes).
            images3: Third list of image paths (for image_triplet or text_image_triplet modes).
            txt_callables: List of transformations for text data.
            img_callables: List of transformations for image data.
        """
        self.mode = mode
        self.txt_callables = txt_callables
        self.img_callables = img_callables

        # Set up data based on mode and validate lengths
        if mode == "text_triplet":
            assert all(
                x is not None for x in [texts1, texts2, texts3]
            ), "All texts1, texts2, and texts3 must be provided for text_triplet mode"
            assert (
                len(texts1) == len(texts2) == len(texts3)
            ), "texts1, texts2, and texts3 must have the same length"
            self.texts1 = texts1
            self.texts2 = texts2
            self.texts3 = texts3
            self.dataset_size = len(texts1)
        elif mode == "image_triplet":
            assert all(
                x is not None for x in [images1, images2, images3]
            ), "All images1, images2, and images3 must be provided for image_triplet mode"
            assert (
                len(images1) == len(images2) == len(images3)
            ), "images1, images2, and images3 must have the same length"
            self.images1 = images1
            self.images2 = images2
            self.images3 = images3
            self.dataset_size = len(images1)
        elif mode == "text_image_triplet":
            assert all(
                x is not None
                for x in [texts1, images1, texts2, images2, texts3, images3]
            ), "All text and image lists must be provided for text_image_triplet mode"
            assert (
                len(texts1)
                == len(images1)
                == len(texts2)
                == len(images2)
                == len(texts3)
                == len(images3)
            ), "All lists must have the same length"
            self.texts1 = texts1
            self.images1 = images1
            self.texts2 = texts2
            self.images2 = images2
            self.texts3 = texts3
            self.images3 = images3
            self.dataset_size = len(texts1)
        else:
            raise ValueError(
                f"Invalid mode: {mode}. Must be 'text_triplet', 'image_triplet', or 'text_image_triplet'"
            )

        # Initialize shuffling indices
        self._original_indices = np.arange(self.dataset_size)
        self._shuffled_indices = self._original_indices.copy()

    def get_text_from_list(self, text_list, idx):
        """
        Retrieve and transform text from a specified list at the given index.

        Args:
            text_list: List of texts to process.
            idx: Index of the text to retrieve.

        Returns:
            Transformed text.
        """
        text = text_list[idx]
        if self.txt_callables is not None:
            for callable in self.txt_callables:
                text = callable(text)
        return text

    def get_image_from_list(self, image_list, idx):
        """
        Retrieve and transform an image from a specified list at the given index.

        Args:
            image_list: List of image paths to process.
            idx: Index of the image to retrieve.

        Returns:
            Transformed image.
        """
        image_path = image_list[idx]
        image = Image.open(image_path).convert("RGB")
        if self.img_callables is not None:
            for callable in self.img_callables:
                if isinstance(callable, Compose):
                    image = callable(image)
                elif isinstance(callable, A.Compose):
                    image_np = np.array(image)
                    augmented = callable(image=image_np)
                    image = augmented["image"]
                else:
                    image = callable(image)
        return image

    def __getitem__(self, index: int) -> tuple:
        """
        Retrieve a triplet of items and their label at the specified index.

        Args:
            index: Index of the triplet to retrieve.

        Returns:
            Tuple containing the triplet of data and the label.
            - For text_triplet: ((text1, text2, text3), label)
            - For image_triplet: ((image1, image2, image3), label)
            - For text_image_triplet: (((text1, image1), (text2, image2), (text3, image3)), label)
        """
        idx = self._shuffled_indices[index]

        if self.mode == "text_triplet":
            text1 = self.get_text_from_list(self.texts1, idx)
            text2 = self.get_text_from_list(self.texts2, idx)
            text3 = self.get_text_from_list(self.texts3, idx)
            return (text1, text2, text3)
        elif self.mode == "image_triplet":
            image1 = self.get_image_from_list(self.images1, idx)
            image2 = self.get_image_from_list(self.images2, idx)
            image3 = self.get_image_from_list(self.images3, idx)
            return (image1, image2, image3)
        elif self.mode == "text_image_triplet":
            text1 = self.get_text_from_list(self.texts1, idx)
            image1 = self.get_image_from_list(self.images1, idx)
            text2 = self.get_text_from_list(self.texts2, idx)
            image2 = self.get_image_from_list(self.images2, idx)
            text3 = self.get_text_from_list(self.texts3, idx)
            image3 = self.get_image_from_list(self.images3, idx)
            return ((text1, image1), (text2, image2), (text3, image3))

    def __len__(self) -> int:
        """Return the size of the dataset."""
        return self.dataset_size


class ClusterSampler(Sampler):
    """Sample from clusters ensuring each batch contains samples from different clusters."""

    def __init__(
        self,
        dataset: FlexibleDataset,
        cluster_ids: list[int],
        samples_per_cluster: int,
        batch_size: int,
    ):
        """
        Initialize a sampler that creates batches with samples from each cluster.

        Args:
            dataset: The dataset to sample from
            cluster_ids: list of cluster IDs for each sample in the dataset
            samples_per_cluster: Number of samples to take from each cluster
            batch_size: Size of each batch
        """
        self.dataset = dataset
        assert len(cluster_ids) == len(dataset), "Cluster IDs must match dataset length"
        self.cluster_ids = cluster_ids
        self.samples_per_cluster = samples_per_cluster
        self.batch_size = batch_size

        # Group indices by cluster
        self.clusters: dict[int, list[int]] = {}
        for i, cluster_id in enumerate(cluster_ids):
            if cluster_id not in self.clusters:
                self.clusters[cluster_id] = []
            self.clusters[cluster_id].append(i)

    def __iter__(self):
        # Set random seed based on epoch for consistent shuffling
        random.seed(self.dataset.current_epoch)

        # Shuffle indices within each cluster
        shuffled_clusters = {}
        for cluster_id, cluster_indices in self.clusters.items():
            # Make a copy to avoid modifying the original
            indices = cluster_indices.copy()
            random.shuffle(indices)
            shuffled_clusters[cluster_id] = indices

        # Create batches with samples from each cluster
        batches = []
        remaining_clusters = list(shuffled_clusters.keys())

        while remaining_clusters:
            batch = []
            # Try to fill a batch from different clusters
            for cluster_id in list(
                remaining_clusters
            ):  # Create a copy for safe iteration
                if not shuffled_clusters[cluster_id]:
                    remaining_clusters.remove(cluster_id)
                    continue

                # Take samples from this cluster
                samples_to_take = min(
                    self.samples_per_cluster, len(shuffled_clusters[cluster_id])
                )
                batch.extend(shuffled_clusters[cluster_id][:samples_to_take])
                shuffled_clusters[cluster_id] = shuffled_clusters[cluster_id][
                    samples_to_take:
                ]

                # If batch is full, add it and start a new one
                if len(batch) >= self.batch_size:
                    batches.append(batch[: self.batch_size])
                    batch = batch[self.batch_size :]

            # Add any remaining samples
            if batch:
                batches.append(batch)

        # Flatten batches
        indices = []
        for batch in batches:
            indices.extend(batch)

        return iter(indices)

    def __len__(self) -> int:
        # This is an approximation
        return len(self.dataset)


class TripletSampler(Sampler):
    """
    Sampler that creates triplets (anchor, positive, negative) for triplet loss.
    Each triplet contains:
    - anchor: a sample
    - positive: a sample with the same label as the anchor
    - negative: a sample with a different label than the anchor
    """

    def __init__(
        self,
        dataset: FlexibleDataset,
        labels: list[int],
        batch_size: int,
        neg_to_pos_ratio: int = 1,
    ):
        """
        Initialize a sampler that creates triplets for triplet loss.

        Args:
            dataset: The dataset to sample from
            labels: list of labels for each sample in the dataset
            batch_size: Size of each batch (must be divisible by (neg_to_pos_ratio + 2))
            neg_to_pos_ratio: Number of negative samples per positive sample
        """
        self.dataset = dataset
        assert len(labels) == len(dataset), "Labels must match dataset length"
        self.labels = labels
        self.batch_size = batch_size
        self.neg_to_pos_ratio = neg_to_pos_ratio

        # Assert batch size is divisible by triplet size
        triplet_size = 2 + neg_to_pos_ratio  # anchor + positive + negatives
        assert (
            batch_size % triplet_size == 0
        ), f"Batch size must be divisible by {triplet_size}"

        # Group indices by label
        self.label_to_indices: dict[int, list[int]] = {}
        for i, label in enumerate(labels):
            if label not in self.label_to_indices:
                self.label_to_indices[label] = []
            self.label_to_indices[label].append(i)

        # Verify we have at least 2 samples per class
        for label, indices in self.label_to_indices.items():
            if len(indices) < 2:
                warnings.warn(
                    f"Label {label} has fewer than 2 samples, which may cause issues with triplet sampling."
                )

        # Verify we have at least 2 classes
        if len(self.label_to_indices) < 2:
            raise ValueError(
                "TripletSampler requires at least 2 different classes/labels."
            )

    def __iter__(self):
        # Set random seed based on epoch for consistent shuffling
        random.seed(self.dataset.current_epoch)

        # Calculate number of triplets
        triplets_per_batch = self.batch_size // (2 + self.neg_to_pos_ratio)
        triplets = []

        # Generate triplets
        labels = list(self.label_to_indices.keys())
        for _ in range(
            triplets_per_batch * 100
        ):  # Generate more than needed, we'll sample from these
            # Randomly select a label with at least 2 samples
            valid_labels = [l for l in labels if len(self.label_to_indices[l]) >= 2]
            if not valid_labels:
                break

            anchor_label = random.choice(valid_labels)

            # Select anchor and positive
            anchor_idx, pos_idx = random.sample(self.label_to_indices[anchor_label], 2)

            # Select negative labels (different from anchor)
            neg_labels = [l for l in labels if l != anchor_label]
            if not neg_labels:
                continue

            # Select negative samples
            neg_indices = []
            for _ in range(self.neg_to_pos_ratio):
                neg_label = random.choice(neg_labels)
                neg_idx = random.choice(self.label_to_indices[neg_label])
                neg_indices.append(neg_idx)

            # Add triplet
            triplet = [anchor_idx, pos_idx] + neg_indices
            triplets.append(triplet)

        # Shuffle and limit triplets
        random.shuffle(triplets)
        triplets = triplets[:triplets_per_batch]

        # Flatten triplets
        indices = []
        for triplet in triplets:
            indices.extend(triplet)

        return iter(indices)

    def __len__(self) -> int:
        # This is an approximation
        return len(self.dataset)


class SiameseSampler(Sampler):
    """
    Sampler that creates pairs (anchor, second) where second can be either
    from the same class (positive) or different class (negative).
    """

    def __init__(
        self,
        dataset: FlexibleDataset,
        labels: list[int],
        batch_size: int,
        pos_neg_ratio: float = 0.5,  # Ratio of positive pairs, e.g., 0.5 means half positive, half negative
    ):
        """
        Initialize a sampler that creates pairs for siamese networks.

        Args:
            dataset: The dataset to sample from
            labels: list of labels for each sample in the dataset
            batch_size: Size of each batch (must be divisible by 2)
            pos_neg_ratio: Ratio of positive pairs to all pairs
        """
        self.dataset = dataset
        assert len(labels) == len(dataset), "Labels must match dataset length"
        self.labels = labels
        self.batch_size = batch_size
        self.pos_neg_ratio = pos_neg_ratio

        # Assert batch size is divisible by 2
        assert batch_size % 2 == 0, "Batch size must be divisible by 2 for pairs"

        # Group indices by label
        self.label_to_indices: dict[int, list[int]] = {}
        for i, label in enumerate(labels):
            if label not in self.label_to_indices:
                self.label_to_indices[label] = []
            self.label_to_indices[label].append(i)

        # Verify we have at least 2 classes
        if len(self.label_to_indices) < 2:
            raise ValueError(
                "SiameseSampler requires at least 2 different classes/labels."
            )

    def __iter__(self):
        # Set random seed based on epoch for consistent shuffling
        random.seed(self.dataset.current_epoch)

        # Calculate number of pairs
        pairs_per_batch = self.batch_size // 2
        pos_pairs = int(pairs_per_batch * self.pos_neg_ratio)
        neg_pairs = pairs_per_batch - pos_pairs

        pairs = []

        # Generate positive pairs
        labels_with_multiple_samples = [
            l
            for l in self.label_to_indices.keys()
            if len(self.label_to_indices[l]) >= 2
        ]

        for _ in range(pos_pairs):
            if not labels_with_multiple_samples:
                break

            # Select a label with at least 2 samples
            label = random.choice(labels_with_multiple_samples)

            # Select two different samples from this label
            idx1, idx2 = random.sample(self.label_to_indices[label], 2)
            pairs.append((idx1, idx2))

        # Generate negative pairs
        all_labels = list(self.label_to_indices.keys())
        for _ in range(neg_pairs):
            if len(all_labels) < 2:
                break

            # Select two different labels
            label1, label2 = random.sample(all_labels, 2)

            # Select one sample from each label
            idx1 = random.choice(self.label_to_indices[label1])
            idx2 = random.choice(self.label_to_indices[label2])
            pairs.append((idx1, idx2))

        # Shuffle pairs
        random.shuffle(pairs)

        # Flatten pairs
        indices = []
        for idx1, idx2 in pairs:
            indices.extend([idx1, idx2])

        return iter(indices)

    def __len__(self) -> int:
        # This is an approximation
        return len(self.dataset)


class ContrastiveSampler(Sampler):
    """
    Sampler that creates batches suitable for contrastive learning.
    Each batch contains a mix of samples so that there are multiple instances of the same class.
    """

    def __init__(
        self,
        dataset: FlexibleDataset,
        labels: list[int],
        batch_size: int,
        num_classes_per_batch: int = 8,  # Number of different classes in each batch
        samples_per_class: int = 4,  # Number of samples per class in each batch
    ):
        """
        Initialize a sampler for contrastive learning.

        Args:
            dataset: The dataset to sample from
            labels: list of labels for each sample in the dataset
            batch_size: Size of each batch
            num_classes_per_batch: Number of different classes in each batch
            samples_per_class: Number of samples per class in each batch
        """
        self.dataset = dataset
        assert len(labels) == len(dataset), "Labels must match dataset length"
        self.labels = labels
        self.batch_size = batch_size
        self.num_classes_per_batch = min(num_classes_per_batch, len(set(labels)))
        self.samples_per_class = samples_per_class

        # Assert batch size is compatible
        assert (
            batch_size >= num_classes_per_batch * samples_per_class
        ), "Batch size must be at least num_classes_per_batch * samples_per_class"

        # Group indices by label
        self.label_to_indices: dict[int, list[int]] = {}
        for i, label in enumerate(labels):
            if label not in self.label_to_indices:
                self.label_to_indices[label] = []
            self.label_to_indices[label].append(i)

        # Filter out labels with too few samples
        self.valid_labels = [
            l
            for l in self.label_to_indices.keys()
            if len(self.label_to_indices[l]) >= samples_per_class
        ]

        if len(self.valid_labels) < num_classes_per_batch:
            warnings.warn(
                f"Only {len(self.valid_labels)} classes have {samples_per_class}+ samples. "
                f"Reducing num_classes_per_batch from {num_classes_per_batch} to {len(self.valid_labels)}."
            )
            self.num_classes_per_batch = len(self.valid_labels)

    def __iter__(self):
        # Set random seed based on epoch for consistent shuffling
        random.seed(self.dataset.current_epoch)

        # Shuffle the order of labels
        random.shuffle(self.valid_labels)

        # Calculate number of batches
        labels_per_batch = min(self.num_classes_per_batch, len(self.valid_labels))
        batches = []

        # Create a cycle of valid labels
        label_cycle = self.valid_labels.copy()

        while True:
            if len(label_cycle) < labels_per_batch:
                # Reshuffle and extend cycle if needed
                random.shuffle(self.valid_labels)
                label_cycle.extend(self.valid_labels)

            # Get labels for this batch
            batch_labels = label_cycle[:labels_per_batch]
            label_cycle = label_cycle[labels_per_batch:]

            # Create batch
            batch = []
            for label in batch_labels:
                # Shuffle indices for this label
                indices = self.label_to_indices[label].copy()
                random.shuffle(indices)

                # Take required number of samples
                samples_to_take = min(self.samples_per_class, len(indices))
                batch.extend(indices[:samples_to_take])

            batches.append(batch)

            # Stop when we have enough batches
            if len(batches) * self.batch_size >= len(self.dataset):
                break

        # Flatten batches
        indices = []
        for batch in batches:
            indices.extend(batch)

        return iter(indices[: len(self.dataset)])

    def __len__(self) -> int:
        return len(self.dataset)


def get_subset(
    dataset: Dataset,
    epoch: int,
    iteration: int,
    batch_size: int,
    batches_per_iteration: int,
    dataset_size: int | None = None,
    drop_last_batch=True,
    drop_last_iteration=False,
) -> tuple[DataLoader, dict]:
    if dataset_size is None:
        dataset_size = len(dataset)

    # Calculate total batches in the dataset
    if drop_last_batch:
        total_batches = dataset_size // batch_size
    else:
        total_batches = (dataset_size + batch_size - 1) // batch_size

    if drop_last_iteration:
        total_iterations = total_batches // batches_per_iteration
    else:
        total_iterations = (
            total_batches + batches_per_iteration - 1
        ) // batches_per_iteration

    # Next run
    iteration += 1
    if iteration >= total_iterations:
        iteration = 0
        epoch = epoch + 1

    # Calculate batch indices for this iteration
    start_batch = iteration * batches_per_iteration
    end_batch = min(start_batch + batches_per_iteration, total_batches)

    start_idx = start_batch * batch_size
    end_idx = min(end_batch * batch_size, dataset_size)

    # Ensure indices are valid
    if start_idx >= dataset_size:
        raise ValueError(f"Start index {start_idx} exceeds dataset size {dataset_size}")

    total_samples = end_idx - start_idx

    # Log metadata
    params_dict = {
        "epoch": epoch,
        "iteration": iteration,
        "batch_size": batch_size,
        "batches_per_iteration": batches_per_iteration,
        "total_batches": total_batches,
        "total_iterations": total_iterations,
        "dataset_size": dataset_size,
        "total_samples": total_samples,
        "start_batch": start_batch,
        "end_batch": end_batch,
        "start_idx": start_idx,
        "end_idx": end_idx,
    }

    # Verify dataset size
    dataset.verify_dataset_size(dataset_size)

    return params_dict


def get_dataloader(
    dataset: Dataset, start_idx: int, end_idx: int, batch_size: int, **dataloader_kwargs
):
    # Create subset for this iteration
    batch_indices = np.arange(start_idx, end_idx)
    subset = Subset(dataset, batch_indices)
    dataloader = DataLoader(
        subset,
        batch_size=batch_size,
        shuffle=False,  # Shuffling handled by dataset.set_epoch
        **dataloader_kwargs,
    )

    return dataloader
