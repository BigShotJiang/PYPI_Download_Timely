from ._video_surfer import VideoSurfer

__all__ = ["VideoSurfer"]
