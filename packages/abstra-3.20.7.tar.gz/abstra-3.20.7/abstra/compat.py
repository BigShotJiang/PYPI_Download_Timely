from abstra_internals.interface.sdk.compat import (
    use_legacy_threads,
)

__all__ = ["use_legacy_threads"]
