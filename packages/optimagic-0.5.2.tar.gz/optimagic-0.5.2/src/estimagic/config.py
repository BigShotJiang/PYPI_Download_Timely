from pathlib import Path

EXAMPLE_DIR = Path(__file__).parent / "examples"
