# window

## Syntax:
`[the] window left/top/width/height`

## Examples:
`the window height`

## Description:
Gets the specified attribute of the window. 

Next: [attribute](attribute.md)  
Prev: [attribute](attribute.md)

[Back](../../README.md)
