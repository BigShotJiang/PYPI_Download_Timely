# newline

## Syntax:
`newline`

## Examples:
`print Value cat newline`

## Description:
Returns a line-feed character (`\n`).

Next: [now](now.md)  
Prev: [modulo](modulo.md)

[Back](../../README.md)
