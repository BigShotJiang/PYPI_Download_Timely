# length

## Syntax:
`[the] length of {text}`

## Examples:
`put the length of Text into Length`

## Description:
Gets the length of a text string.

Next: [lowercase](lowercase.md)  
Prev: [left](left.md)

[Back](../../README.md)
