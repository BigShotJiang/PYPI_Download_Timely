#!/bin/python3

import os
from easycoder import Program

os.chdir('../../rbr/roombyroom/Controller/ui')
Program('rbr_ui.ecs').start()
