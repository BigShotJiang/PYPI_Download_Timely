========
pkgcheck
========

.. include:: pkgcheck/_synopsis.rst
.. include:: pkgcheck/_description.rst
.. include:: pkgcheck/_options.rst
.. include:: pkgcheck/_subcommands.rst

.. include:: pkgcheck/keywords.rst
.. include:: pkgcheck/checks.rst
.. include:: pkgcheck/reporters.rst

.. include:: config.rst

Reporting Bugs
==============

Please submit an issue via github:

https://github.com/pkgcore/pkgcheck/issues

See Also
========

**pkgcore**\(5)
