Welcome to pkgchecks's documentation!
=====================================

Contents:

.. toctree::
    :titlesonly:
    :maxdepth: 4

    news
    api
    man/pkgcheck

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
