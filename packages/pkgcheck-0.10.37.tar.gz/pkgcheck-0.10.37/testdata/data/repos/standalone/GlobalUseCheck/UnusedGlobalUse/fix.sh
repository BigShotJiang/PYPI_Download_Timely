#!/bin/bash
sed -i '/^unused -/d' profiles/use.desc
