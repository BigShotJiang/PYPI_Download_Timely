#!/bin/bash
chmod -x PkgDirCheck/ExecutableFile/files/executable
