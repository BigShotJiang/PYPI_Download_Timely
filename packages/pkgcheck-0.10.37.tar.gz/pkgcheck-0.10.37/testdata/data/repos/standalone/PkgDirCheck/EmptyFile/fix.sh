#!/bin/bash
rm PkgDirCheck/EmptyFile/files/empty
