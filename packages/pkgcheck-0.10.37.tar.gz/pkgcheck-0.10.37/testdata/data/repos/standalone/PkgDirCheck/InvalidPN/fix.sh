#!/bin/bash
mv PkgDirCheck/InvalidPN/InvalidPN.ebuild PkgDirCheck/InvalidPN/InvalidPN-0.ebuild
