#!/bin/bash
mv PkgDirCheck/MismatchedPN/Mismatched-1.ebuild PkgDirCheck/MismatchedPN/MismatchedPN-1.ebuild
