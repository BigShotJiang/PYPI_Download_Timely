#!/bin/bash
sed -i '/^unused/d' profiles/thirdpartymirrors
