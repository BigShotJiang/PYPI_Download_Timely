#!/bin/bash

cp $(type -P bash) ./
