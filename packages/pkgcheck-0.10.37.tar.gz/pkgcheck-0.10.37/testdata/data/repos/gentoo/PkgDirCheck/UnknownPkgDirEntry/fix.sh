#!/bin/bash
rm -rf PkgDirCheck/UnknownPkgDirEntry/{bar,foo}
