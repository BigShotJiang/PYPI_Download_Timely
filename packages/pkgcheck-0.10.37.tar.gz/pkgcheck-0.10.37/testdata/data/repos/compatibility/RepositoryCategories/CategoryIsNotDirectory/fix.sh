#!/bin/bash
rm CategoryIsNotDirectory
