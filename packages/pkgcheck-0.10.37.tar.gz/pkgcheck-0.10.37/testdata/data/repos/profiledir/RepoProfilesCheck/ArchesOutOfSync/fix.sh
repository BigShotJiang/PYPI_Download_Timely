#!/bin/bash
sed -i '/^unknown_arch/d' profiles/arch.list
