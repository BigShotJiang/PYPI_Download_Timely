from requests.exceptions import ConnectionError

responses = [ConnectionError("connection failed")]
