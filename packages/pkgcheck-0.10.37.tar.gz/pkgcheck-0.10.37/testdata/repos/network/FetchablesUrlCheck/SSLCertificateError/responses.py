from requests.exceptions import SSLError

responses = [SSLError("Certificate verification failed")]
