"""Database package."""

from .client import InfinityClient, get_client

__all__ = ["InfinityClient", "get_client"]
