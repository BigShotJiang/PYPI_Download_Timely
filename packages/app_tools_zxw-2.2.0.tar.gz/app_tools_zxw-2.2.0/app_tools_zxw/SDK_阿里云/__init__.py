# pip install aliyun-python-sdk-core
# pip install oss2
# pip install aliyun-python-sdk-sts

