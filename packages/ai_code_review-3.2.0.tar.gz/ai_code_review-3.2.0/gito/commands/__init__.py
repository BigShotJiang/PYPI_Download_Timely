# Command modules register themselves with the CLI app
