2025-07-22 Version: 2.2.0
- Support API ListTableDetails.


2025-07-17 Version: 2.1.0
- Support API AlterDatabase.
- Support API AlterTable.
- Support API CreateDatabase.
- Support API CreateTable.
- Support API DropDatabase.
- Support API DropTable.
- Support API GetDatabase.
- Support API GetTable.
- Support API ListDatabases.
- Support API ListTables.


2025-07-16 Version: 2.0.0
- Update API CreateCatalog: delete request parameters body.optimizationConfig.
- Update API ListRoleUsers: update request parameters maxResults' type has changed.
- Update API ListRoleUsers: update request parameters maxResults' format has changed.
- Update API ListUserRoles: update request parameters maxResults' type has changed.
- Update API ListUserRoles: update request parameters maxResults' format has changed.


2025-07-02 Version: 1.1.3
- Update API ListPermissions: add request parameters function.
- Update API ListPermissions: add request parameters view.


2025-07-02 Version: 1.1.3
- Update API ListPermissions: add request parameters function.
- Update API ListPermissions: add request parameters view.


2025-06-19 Version: 1.1.2
- Update API CreateCatalog: add request parameters body.type.


2025-06-11 Version: 1.1.1
- Generated python 2025-03-10 for DlfNext.

2025-06-09 Version: 1.1.0
- Support API GetCatalogSummary.
- Support API GetCatalogSummaryTrend.
- Support API GetCatalogToken.
- Support API GetDatabaseSummary.
- Support API GetTableSummary.
- Support API ListPartitionSummaries.


2025-05-20 Version: 1.0.0
- Generated python 2025-03-10 for DlfNext.

