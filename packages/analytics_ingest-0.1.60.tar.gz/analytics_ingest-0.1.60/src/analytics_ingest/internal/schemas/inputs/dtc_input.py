def make_dtc_input(batched_inputs: list[dict]):
    return {"input": batched_inputs}
