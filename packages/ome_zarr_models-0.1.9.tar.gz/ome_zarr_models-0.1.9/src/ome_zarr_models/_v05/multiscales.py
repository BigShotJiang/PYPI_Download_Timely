from ome_zarr_models.common.multiscales import Dataset, MultiscaleBase

__all__ = ["Dataset", "Multiscale"]


class Multiscale(MultiscaleBase):
    """
    An element of multiscales metadata.
    """
