# High Content Screening

::: ome_zarr_models.v04.hcs

## Plate metadata

::: ome_zarr_models.v04.plate
