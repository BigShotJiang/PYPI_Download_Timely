#-*- coding: utf-8 -*-

"""
Gedcom API

This package provides an API to parse and process Gedcom files.
"""

from .gedcom import Gedcom
