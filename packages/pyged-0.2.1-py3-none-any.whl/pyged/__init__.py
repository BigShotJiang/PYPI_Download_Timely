#-*- coding: utf-8 -*-

"""
Gedcom API

This package provides tools and APIs to parse Gedcom files
and produce various reports.
"""

__version__ = '0.1'

from .gedcom import Gedcom
