"""Tests for benchmarking and evaluation."""
