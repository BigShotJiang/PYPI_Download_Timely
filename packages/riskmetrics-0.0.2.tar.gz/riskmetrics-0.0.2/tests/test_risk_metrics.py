import numpy as np
from riskmetrics import RiskMetrics

def test_var():
    returns = np.array([-0.01, 0.02, -0.03, 0.01, 0.005])
    rm = RiskMetrics(returns)
    var = rm.value_at_risk(0.95)
    assert isinstance(var, float)
