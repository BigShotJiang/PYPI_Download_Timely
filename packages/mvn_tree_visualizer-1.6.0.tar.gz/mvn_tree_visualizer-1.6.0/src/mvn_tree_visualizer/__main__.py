if __name__ == "__main__":
    from mvn_tree_visualizer.cli import cli

    cli()
