"""Entry point for python -m modelscope_mcp_server."""

from . import main

if __name__ == "__main__":
    main()
