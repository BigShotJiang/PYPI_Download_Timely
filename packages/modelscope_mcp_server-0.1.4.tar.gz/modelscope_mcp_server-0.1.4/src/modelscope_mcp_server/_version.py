"""Version information for ModelScope MCP Server."""

__version__ = "0.1.4"
