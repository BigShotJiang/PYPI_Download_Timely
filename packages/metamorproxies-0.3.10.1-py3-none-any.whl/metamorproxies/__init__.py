from metamorproxies import soldier

all = [soldier]