Word embeddings
===============

Glove
-----

.. dm:datasets:: edu.stanford.glove text
