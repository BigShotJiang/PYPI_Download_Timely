Text datasets
=============

This section lists datasets that are made of **raw text**.

Book Corpus
------------

.. dm:datasets:: com.smashwords.bookcorpus
