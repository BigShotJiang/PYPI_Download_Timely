Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/pioasm_simpletest.py
    :caption: examples/pioasm_simpletest.py
    :linenos:
