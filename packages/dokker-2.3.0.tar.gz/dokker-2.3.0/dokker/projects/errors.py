from dokker.errors import DokkerError


class ProjectError(DokkerError):
    """Base class for all project errors."""

    pass
