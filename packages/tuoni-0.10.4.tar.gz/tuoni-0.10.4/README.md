# TuoniLib

Python library that gives easy to use access to [Tuoni](https://github.com/shell-dot/tuoni) C2 API.