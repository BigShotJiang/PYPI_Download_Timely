from grafo import trees

__all__ = ["trees"]
