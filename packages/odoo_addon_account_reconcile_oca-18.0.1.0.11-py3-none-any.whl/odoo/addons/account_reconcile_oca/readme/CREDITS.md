The system has been improved to handle currency amounts more effectively
with the financial support of Sygel Technology.
