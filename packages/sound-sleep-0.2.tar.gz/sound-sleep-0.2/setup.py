# sleep/setup.py
from setuptools import setup, find_packages

setup(
    name="sound-sleep",
    version="0.2",
    py_modules=['sleep_features']
)