# Account-V1
get_account_by_puuid = "https://{server_addr}/riot/account/v1/accounts/by-puuid/{puuid}"
get_account_by_riot_id = "https://{server_addr}/riot/account/v1/accounts/by-riot-id/{game_name}/{tag_line}"
get_active_shard_for_player = "https://{server_addr}/riot/account/v1/active-shards/by-game/{game}/by-puuid/{puuid}"
get_active_region = "https://{server_addr}/riot/account/v1/region/by-game/{game}/by-puuid/{puuid}"
get_account_by_access_token = "https://{server_addr}/riot/account/v1/accounts/me"
