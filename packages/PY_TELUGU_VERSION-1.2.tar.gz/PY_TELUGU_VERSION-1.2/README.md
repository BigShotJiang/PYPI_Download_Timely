<h1 align="center">Konichivasssss...</h1>

Ever wished you could write code in your **native language**? , well i did  (>'-'<) .....

> Introducing my python package that helps you to write python scripts in litereally telugu language.  
> It is still in prototype phases, but my end goal is to write programming in telugu ^_^.

---

## What do you mean to write in telugu?

- well, what u read is right.. now with help of my package you can write the python code in telugu language..
- I built this package like a wrapper of python language and json if else statements 
## WHY? PURPORSE ENTI  (ㆆ_ㆆ) ?
- just to flex my idea, ain't it cool to write programming in telugu... cool right ?
---
Anyways lets see the installation steps:

1. **Install the package**  
   Run:  
   ```bash
   pip install PY-TELUGU-VERSION
   ```
2. **running watcher command**
   - now open any python file and you have to run command in backgroung
   ```bash
   pythontel filename.py
    ```
   - this translates the keywords and stuff into telugu language
3. **To execute the file**
   - run this cmd to execute the telugu language py file
   ```bash
   pythonrun filename.py
   ```
and that's all , simple ain't it? <br>
---
**Issues** -
- first if you are using notepad , the changes won't visible suddenly you have to close and open file again
- if you are using pychram editor then click ctrl + s cm often as the terminal changes are not reflecting in editor correctly and besides if you are sing vs code make sure to on autosave or just enter ctrl + s everytime
---
This repo updates countinulsly , consider checking my work every week.......... <br> got any errors or suggestions , create issues I will try to resolve them