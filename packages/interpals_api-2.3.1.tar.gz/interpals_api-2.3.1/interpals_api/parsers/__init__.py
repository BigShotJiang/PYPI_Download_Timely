"""
Different HTML parser of the website.
"""
