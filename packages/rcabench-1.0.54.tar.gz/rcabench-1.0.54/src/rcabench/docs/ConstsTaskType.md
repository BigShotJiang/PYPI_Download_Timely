# ConstsTaskType


## Enum

* `TaskTypeRestartService` (value: `'RestartService'`)

* `TaskTypeRunAlgorithm` (value: `'RunAlgorithm'`)

* `TaskTypeFaultInjection` (value: `'FaultInjection'`)

* `TaskTypeBuildImage` (value: `'BuildImage'`)

* `TaskTypeBuildDataset` (value: `'BuildDataset'`)

* `TaskTypeCollectResult` (value: `'CollectResult'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


