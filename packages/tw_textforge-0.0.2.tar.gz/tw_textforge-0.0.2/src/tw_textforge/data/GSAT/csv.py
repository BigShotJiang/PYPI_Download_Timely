GSAT_DATA = [
    {"name": "國文", "url": "https://docs.google.com/spreadsheets/d/e/2PACX-1vRtnMPEutqfeoQS2BNu2MGvSfM-ti-dNJTIDkd3BxMyAh7E0w-bbIShMgafX805UHSyyexNs_LxU0So/pub?gid=0&single=true&output=csv"},
]