# autorpt


[![image](https://img.shields.io/pypi/v/autorpt.svg)](https://pypi.python.org/pypi/autorpt)
[![image](https://img.shields.io/conda/vn/conda-forge/autorpt.svg)](https://anaconda.org/conda-forge/autorpt)


**python package to create a grant management report**


-   Free software: MIT license
-   Documentation: https://VRConservation.github.io/autorpt
    

## Features

-   TODO
