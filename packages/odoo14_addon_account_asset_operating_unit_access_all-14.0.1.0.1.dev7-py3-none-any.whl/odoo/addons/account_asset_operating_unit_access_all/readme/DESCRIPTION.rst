This module allow a user to have access to all OUs' asset,
without having to add OUs in the user setting.
