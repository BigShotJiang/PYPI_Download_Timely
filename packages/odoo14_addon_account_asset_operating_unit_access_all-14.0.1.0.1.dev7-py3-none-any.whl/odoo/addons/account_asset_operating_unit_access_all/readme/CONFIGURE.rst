
To configure a user to have access to all OUs' asset (without all OUs access):

* Go to *Settings / Users & Companies / Users*
* For a user, select checkbox "Access all OUs' asset"
