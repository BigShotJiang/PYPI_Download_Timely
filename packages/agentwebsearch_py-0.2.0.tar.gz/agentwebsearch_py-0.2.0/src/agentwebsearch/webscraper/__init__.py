from agentwebsearch.webscraper.base import WebPageResult  # noqa
from agentwebsearch.webscraper.default import DefaultWebScraper  # noqa
