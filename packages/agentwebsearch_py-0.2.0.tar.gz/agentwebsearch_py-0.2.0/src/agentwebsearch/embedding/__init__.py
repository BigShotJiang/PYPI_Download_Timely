from agentwebsearch.embedding.openai import OpenAIEmbeddingModel  # noqa
