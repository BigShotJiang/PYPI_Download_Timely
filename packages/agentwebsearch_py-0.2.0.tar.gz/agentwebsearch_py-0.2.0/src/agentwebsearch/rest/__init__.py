from agentwebsearch.rest.server import WebSearchFastAPI  # noqa
