from agentwebsearch.mcp.server import WebSearchFastMCP  # noqa
