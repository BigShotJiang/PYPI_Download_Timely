from setuptools import setup, find_packages

setup(
    name='medicafe',
    version="0.250724.0",
    description='MediCafe',
    long_description="""
    # Project Overview: MediCafe

    ## Project Description
    MediCafe is a comprehensive suite designed to automate and streamline several aspects of medical administrative tasks within Medisoft, a popular medical practice management software. The system consists of two main components: MediBot and MediLink, each serving distinct functions but integrated to enhance the workflow of medical practices.

    ## MediBot Module
    MediBot is primarily focused on automating data entry processes in Medisoft. It utilizes AutoHotkey scripting to control and automate the GUI interactions required for inputting patient data into Medisoft. Key features and functionalities include:

    - **Error Handling and Logging:** MediBot aims to implement a robust error handling mechanism that can log issues and provide feedback for troubleshooting.
    - **Insurance Mode Adjustments:** The system can adjust data inputs based on specific requirements from various insurance providers, including Medicare.
    - **Diagnosis Entry Automation:** MediBot automates the extraction and entry of diagnosis codes from surgical schedules into Medisoft.
    - **Script Efficiency:** The module enhances the efficiency of scripts handling Medisoft's quirks, such as fields that are skipped or require special navigation.
    - **User Interface (UI) Enhancements:** Plans to develop a graphical user interface to help non-technical users manage and execute scripts more easily.
    - **Documentation and Support:** Comprehensive documentation and support channels are being established to assist users in setup, configuration, and troubleshooting.

    ## MediLink Module
    MediLink focuses on the backend processes related to medical claims submission, particularly handling communications with multiple endpoints like Availity, Optum, and PNT Data. Its main features include:

    - **Dynamic Configurations:** Supports multiple endpoints with environmental settings to ensure flexibility in claims submission.
    - **File Detection and Integrity Checks:** Enhances the detection of new claim files with detailed logging and integrity checks for preprocessing validation.
    - **Automated Response Handling:** Automates the process of receiving and integrating response files from endpoints into Medisoft, alerting users to exceptions.
    - **Endpoint Management:** Allows dynamic updating of endpoints based on insurance provider changes, ensuring accurate and efficient claims processing.
    - **User Interface (UI) Interactions:** Provides a user interface for managing claims submission, including confirming or adjusting suggested endpoints.

    ## Integration and Workflow
    The two modules work in tandem to provide a seamless experience. MediBot handles the initial data entry into Medisoft, preparing the system with up-to-date patient and treatment information. This data is then utilized by MediLink for preparing and submitting medical claims to various insurance providers. Errors and feedback from MediLink can prompt adjustments in MediBot's data entry processes, creating a feedback loop that enhances accuracy and efficiency.

    The integration aims to reduce the administrative burden on medical practices, decrease the incidence of data entry errors, and ensure timely submission of medical claims, thereby improving the revenue cycle management of healthcare providers.

    ## Target Users
    The system is intended for use by administrative staff in medical practices who are responsible for patient data management and claims processing. By automating these tasks, the system not only saves time but also reduces the potential for human error, leading to more accurate billing and improved operational efficiency.

    ## Future Directions
    Future enhancements may include the development of additional modules for other aspects of medical practice management, further integrations with healthcare systems, and continuous improvements in user interface design to accommodate an even broader range of users.
    """,
    long_description_content_type='text/markdown',
    keywords = 'medicafe python34 medibot medilink',
    url='https://github.com/katanada2',
    author='Daniel Vidaud',
    author_email='daniel@personalizedtransformation.com',
    license='MIT',
    packages=find_packages(),
    include_package_data=True,
    package_data={
        'MediBot': ['MediBot.bat'],
        'MediLink': ['MediLink_batch.bat', 'openssl.cnf', '*.html']
    },
    install_requires=[
        'requests==2.21.0',
        'argparse==1.4.0',
        'numpy==1.11.3; platform_python_implementation != "CPython" or sys_platform != "win32" or python_version > "3.5"',
        'numpy==1.11.3; platform_python_implementation == "CPython" and sys_platform == "win32" and python_version <= "3.5" and extra == "binary"',
        'pandas==0.20.0; platform_python_implementation != "CPython" or sys_platform != "win32" or python_version > "3.5"',
        'pandas==0.20.0; platform_python_implementation == "CPython" and sys_platform == "win32" and python_version <= "3.5" and extra == "binary"',
        'tqdm==4.14.0',
        'lxml==4.2.0; platform_python_implementation != "CPython" or sys_platform != "win32" or python_version > "3.5"',
        'lxml==4.2.0; platform_python_implementation == "CPython" and sys_platform == "win32" and python_version <= "3.5" and extra == "binary"',
        'python-docx==0.8.11',
        'PyYAML==5.2',
        'chardet==3.0.4',
        'cffi==1.8.2', # msal needs this and then pip install will fail because 1.15.X won't work on XP.
        'msal==1.26.0'
    ],
    zip_safe=False
)