from .core import dustmaps3d

__version__ = '2.1.24'
__all__ = ['dustmaps3d']
