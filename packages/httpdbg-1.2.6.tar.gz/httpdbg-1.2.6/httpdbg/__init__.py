# -*- coding: utf-8 -*-
from httpdbg.hooks.all import httprecord
from httpdbg.records import HTTPRecords


__version__ = "1.2.6"

__all__ = ["httprecord", "HTTPRecords"]
