Add the mixin edi.state.consumer.mixin to the model that will use
states.
