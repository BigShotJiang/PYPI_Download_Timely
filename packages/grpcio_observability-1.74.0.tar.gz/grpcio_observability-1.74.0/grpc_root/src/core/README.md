# gRPC core library

This shared library provides all of gRPC's core functionality through a low
level API. gRPC libraries for the other languages supported in this repo, are
built on top of this shared core library.

