lcvtoolbox.integrations.huggingface.dataset\_sync.repo\_exists
==============================================================

.. currentmodule:: lcvtoolbox.integrations.huggingface.dataset_sync

.. autofunction:: repo_exists