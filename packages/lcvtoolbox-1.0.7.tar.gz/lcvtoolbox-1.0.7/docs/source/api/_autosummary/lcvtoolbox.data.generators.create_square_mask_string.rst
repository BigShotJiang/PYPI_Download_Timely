lcvtoolbox.data.generators.create\_square\_mask\_string
=======================================================

.. currentmodule:: lcvtoolbox.data.generators

.. autofunction:: create_square_mask_string