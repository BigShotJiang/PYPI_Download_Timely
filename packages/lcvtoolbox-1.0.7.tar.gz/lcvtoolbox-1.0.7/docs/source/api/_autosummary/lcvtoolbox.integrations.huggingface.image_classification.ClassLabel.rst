lcvtoolbox.integrations.huggingface.image\_classification.ClassLabel
====================================================================

.. currentmodule:: lcvtoolbox.integrations.huggingface.image_classification

.. autoclass:: ClassLabel
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~ClassLabel.__init__
      ~ClassLabel.cast_storage
      ~ClassLabel.encode_example
      ~ClassLabel.int2str
      ~ClassLabel.str2int
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~ClassLabel.dtype
      ~ClassLabel.id
      ~ClassLabel.names
      ~ClassLabel.names_file
      ~ClassLabel.num_classes
      ~ClassLabel.pa_type
   
   