lcvtoolbox.vision.encoding.binary\_mask.decode\_mask\_from\_string
==================================================================

.. currentmodule:: lcvtoolbox.vision.encoding.binary_mask

.. autofunction:: decode_mask_from_string