lcvtoolbox.integrations.cvat.api.compile\_task
==============================================

.. automodule:: lcvtoolbox.integrations.cvat.api.compile_task
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      AnnotatedImage
      Any
      Callable
      CvatApi
      CvatApiJobDetails
      CvatApiMetainformationFrame
      CvatApiShape
      CvatApiTag
      CvatApiTaskAnnotations
      CvatApiTaskDetails
      CvatApiTaskMediasMetainformation
      CvatJob
      CvatTask
   
   

   
   
   



