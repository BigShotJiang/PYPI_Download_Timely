lcvtoolbox.core.schemas.CvatApiJobAnnotationsDict
=================================================

.. currentmodule:: lcvtoolbox.core.schemas

.. autoclass:: CvatApiJobAnnotationsDict
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CvatApiJobAnnotationsDict.__init__
      ~CvatApiJobAnnotationsDict.clear
      ~CvatApiJobAnnotationsDict.copy
      ~CvatApiJobAnnotationsDict.fromkeys
      ~CvatApiJobAnnotationsDict.get
      ~CvatApiJobAnnotationsDict.items
      ~CvatApiJobAnnotationsDict.keys
      ~CvatApiJobAnnotationsDict.pop
      ~CvatApiJobAnnotationsDict.popitem
      ~CvatApiJobAnnotationsDict.setdefault
      ~CvatApiJobAnnotationsDict.update
      ~CvatApiJobAnnotationsDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CvatApiJobAnnotationsDict.version
      ~CvatApiJobAnnotationsDict.tags
      ~CvatApiJobAnnotationsDict.shapes
      ~CvatApiJobAnnotationsDict.tracks
   
   