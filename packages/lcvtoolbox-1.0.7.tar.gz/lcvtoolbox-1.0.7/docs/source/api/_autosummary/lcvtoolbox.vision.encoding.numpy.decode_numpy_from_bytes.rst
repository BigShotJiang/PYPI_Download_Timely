lcvtoolbox.vision.encoding.numpy.decode\_numpy\_from\_bytes
===========================================================

.. currentmodule:: lcvtoolbox.vision.encoding.numpy

.. autofunction:: decode_numpy_from_bytes