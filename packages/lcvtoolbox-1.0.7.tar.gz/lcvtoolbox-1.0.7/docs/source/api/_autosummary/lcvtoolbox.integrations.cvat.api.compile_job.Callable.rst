lcvtoolbox.integrations.cvat.api.compile\_job.Callable
======================================================

.. currentmodule:: lcvtoolbox.integrations.cvat.api.compile_job

.. autoclass:: Callable
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~Callable.__init__
   
   

   
   
   