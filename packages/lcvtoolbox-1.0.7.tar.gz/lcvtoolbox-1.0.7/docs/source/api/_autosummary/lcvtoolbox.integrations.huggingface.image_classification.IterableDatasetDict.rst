lcvtoolbox.integrations.huggingface.image\_classification.IterableDatasetDict
=============================================================================

.. currentmodule:: lcvtoolbox.integrations.huggingface.image_classification

.. autoclass:: IterableDatasetDict
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~IterableDatasetDict.__init__
      ~IterableDatasetDict.cast
      ~IterableDatasetDict.cast_column
      ~IterableDatasetDict.clear
      ~IterableDatasetDict.copy
      ~IterableDatasetDict.filter
      ~IterableDatasetDict.fromkeys
      ~IterableDatasetDict.get
      ~IterableDatasetDict.items
      ~IterableDatasetDict.keys
      ~IterableDatasetDict.map
      ~IterableDatasetDict.pop
      ~IterableDatasetDict.popitem
      ~IterableDatasetDict.push_to_hub
      ~IterableDatasetDict.remove_columns
      ~IterableDatasetDict.rename_column
      ~IterableDatasetDict.rename_columns
      ~IterableDatasetDict.select_columns
      ~IterableDatasetDict.setdefault
      ~IterableDatasetDict.shuffle
      ~IterableDatasetDict.update
      ~IterableDatasetDict.values
      ~IterableDatasetDict.with_format
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~IterableDatasetDict.column_names
      ~IterableDatasetDict.num_columns
   
   