lcvtoolbox.core.schemas.encoding.CocoRleDict
============================================

.. currentmodule:: lcvtoolbox.core.schemas.encoding

.. autoclass:: CocoRleDict
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CocoRleDict.__init__
      ~CocoRleDict.clear
      ~CocoRleDict.copy
      ~CocoRleDict.fromkeys
      ~CocoRleDict.get
      ~CocoRleDict.items
      ~CocoRleDict.keys
      ~CocoRleDict.pop
      ~CocoRleDict.popitem
      ~CocoRleDict.setdefault
      ~CocoRleDict.update
      ~CocoRleDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CocoRleDict.size
      ~CocoRleDict.counts
   
   