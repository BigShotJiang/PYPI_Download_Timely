lcvtoolbox.vision.geometry.projection.project\_masks\_on\_road.polygonize
=========================================================================

.. currentmodule:: lcvtoolbox.vision.geometry.projection.project_masks_on_road

.. autofunction:: polygonize