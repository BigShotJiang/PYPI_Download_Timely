lcvtoolbox.vision.geometry.primitives.points\_array.Iterator
============================================================

.. currentmodule:: lcvtoolbox.vision.geometry.primitives.points_array

.. autoclass:: Iterator
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~Iterator.__init__
   
   

   
   
   