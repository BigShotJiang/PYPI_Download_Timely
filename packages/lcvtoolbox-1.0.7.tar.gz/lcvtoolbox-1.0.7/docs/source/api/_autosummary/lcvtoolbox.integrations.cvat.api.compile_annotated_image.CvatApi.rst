lcvtoolbox.integrations.cvat.api.compile\_annotated\_image.CvatApi
==================================================================

.. currentmodule:: lcvtoolbox.integrations.cvat.api.compile_annotated_image

.. autoclass:: CvatApi
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CvatApi.__init__
      ~CvatApi.download_all_job_chunks
      ~CvatApi.download_all_task_chunks
      ~CvatApi.download_job_data_chunk
      ~CvatApi.download_job_image
      ~CvatApi.download_job_images
      ~CvatApi.download_task_data_chunk
      ~CvatApi.download_task_image
      ~CvatApi.download_task_images
      ~CvatApi.get_auth_token
      ~CvatApi.get_job_annotations
      ~CvatApi.get_job_details
      ~CvatApi.get_job_media_metainformation
      ~CvatApi.get_label_details
      ~CvatApi.get_project_job_ids
      ~CvatApi.get_project_labels
      ~CvatApi.get_task_annotations
      ~CvatApi.get_task_details
      ~CvatApi.get_task_media_metainformation
   
   

   
   
   