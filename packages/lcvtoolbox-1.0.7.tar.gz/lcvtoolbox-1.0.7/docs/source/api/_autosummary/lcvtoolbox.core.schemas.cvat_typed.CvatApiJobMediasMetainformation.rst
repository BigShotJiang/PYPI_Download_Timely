lcvtoolbox.core.schemas.cvat\_typed.CvatApiJobMediasMetainformation
===================================================================

.. currentmodule:: lcvtoolbox.core.schemas.cvat_typed

.. autoclass:: CvatApiJobMediasMetainformation
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CvatApiJobMediasMetainformation.__init__
      ~CvatApiJobMediasMetainformation.clear
      ~CvatApiJobMediasMetainformation.copy
      ~CvatApiJobMediasMetainformation.fromkeys
      ~CvatApiJobMediasMetainformation.get
      ~CvatApiJobMediasMetainformation.items
      ~CvatApiJobMediasMetainformation.keys
      ~CvatApiJobMediasMetainformation.pop
      ~CvatApiJobMediasMetainformation.popitem
      ~CvatApiJobMediasMetainformation.setdefault
      ~CvatApiJobMediasMetainformation.update
      ~CvatApiJobMediasMetainformation.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CvatApiJobMediasMetainformation.start_frame
      ~CvatApiJobMediasMetainformation.stop_frame
      ~CvatApiJobMediasMetainformation.frame_filter
      ~CvatApiJobMediasMetainformation.frames
   
   