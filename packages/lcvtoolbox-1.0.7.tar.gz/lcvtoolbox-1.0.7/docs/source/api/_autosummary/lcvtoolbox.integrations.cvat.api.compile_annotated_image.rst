lcvtoolbox.integrations.cvat.api.compile\_annotated\_image
==========================================================

.. automodule:: lcvtoolbox.integrations.cvat.api.compile_annotated_image
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      AnnotatedImage
      CvatApi
      CvatApiShape
      CvatApiTag
   
   

   
   
   



