lcvtoolbox.data.generators.masks.encode\_mask\_to\_string
=========================================================

.. currentmodule:: lcvtoolbox.data.generators.masks

.. autofunction:: encode_mask_to_string