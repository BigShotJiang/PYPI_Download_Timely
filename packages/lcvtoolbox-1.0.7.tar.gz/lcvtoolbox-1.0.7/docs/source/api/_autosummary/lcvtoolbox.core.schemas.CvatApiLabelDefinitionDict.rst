lcvtoolbox.core.schemas.CvatApiLabelDefinitionDict
==================================================

.. currentmodule:: lcvtoolbox.core.schemas

.. autoclass:: CvatApiLabelDefinitionDict
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CvatApiLabelDefinitionDict.__init__
      ~CvatApiLabelDefinitionDict.clear
      ~CvatApiLabelDefinitionDict.copy
      ~CvatApiLabelDefinitionDict.fromkeys
      ~CvatApiLabelDefinitionDict.get
      ~CvatApiLabelDefinitionDict.items
      ~CvatApiLabelDefinitionDict.keys
      ~CvatApiLabelDefinitionDict.pop
      ~CvatApiLabelDefinitionDict.popitem
      ~CvatApiLabelDefinitionDict.setdefault
      ~CvatApiLabelDefinitionDict.update
      ~CvatApiLabelDefinitionDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CvatApiLabelDefinitionDict.id
      ~CvatApiLabelDefinitionDict.name
      ~CvatApiLabelDefinitionDict.color
      ~CvatApiLabelDefinitionDict.type
      ~CvatApiLabelDefinitionDict.attributes
   
   