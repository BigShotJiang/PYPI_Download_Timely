lcvtoolbox.vision.encoding.encode\_image\_adaptive
==================================================

.. currentmodule:: lcvtoolbox.vision.encoding

.. autofunction:: encode_image_adaptive