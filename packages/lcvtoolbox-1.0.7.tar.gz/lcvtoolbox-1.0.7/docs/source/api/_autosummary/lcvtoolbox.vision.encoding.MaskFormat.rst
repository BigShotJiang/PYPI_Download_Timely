lcvtoolbox.vision.encoding.MaskFormat
=====================================

.. currentmodule:: lcvtoolbox.vision.encoding

.. autoclass:: MaskFormat
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~MaskFormat.PNG_1BIT
      ~MaskFormat.PNG_L
      ~MaskFormat.RLE
      ~MaskFormat.COCO_RLE
      ~MaskFormat.PACKED_BITS
      ~MaskFormat.ZLIB_COMPRESSED
   
   