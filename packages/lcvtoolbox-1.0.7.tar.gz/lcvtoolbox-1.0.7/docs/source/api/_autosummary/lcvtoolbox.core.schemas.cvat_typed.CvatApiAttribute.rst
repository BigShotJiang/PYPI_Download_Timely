lcvtoolbox.core.schemas.cvat\_typed.CvatApiAttribute
====================================================

.. currentmodule:: lcvtoolbox.core.schemas.cvat_typed

.. autoclass:: CvatApiAttribute
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CvatApiAttribute.__init__
      ~CvatApiAttribute.clear
      ~CvatApiAttribute.copy
      ~CvatApiAttribute.fromkeys
      ~CvatApiAttribute.get
      ~CvatApiAttribute.items
      ~CvatApiAttribute.keys
      ~CvatApiAttribute.pop
      ~CvatApiAttribute.popitem
      ~CvatApiAttribute.setdefault
      ~CvatApiAttribute.update
      ~CvatApiAttribute.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CvatApiAttribute.id
      ~CvatApiAttribute.spec_id
      ~CvatApiAttribute.value
   
   