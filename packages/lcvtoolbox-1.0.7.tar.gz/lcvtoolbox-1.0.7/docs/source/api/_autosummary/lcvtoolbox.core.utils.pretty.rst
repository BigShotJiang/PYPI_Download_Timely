lcvtoolbox.core.utils.pretty
============================

.. currentmodule:: lcvtoolbox.core.utils

.. autofunction:: pretty