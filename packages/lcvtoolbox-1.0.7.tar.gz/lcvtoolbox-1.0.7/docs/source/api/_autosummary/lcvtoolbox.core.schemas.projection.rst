lcvtoolbox.core.schemas.projection
==================================

.. automodule:: lcvtoolbox.core.schemas.projection
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree: .
      :nosignatures:
   
      Field
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      BaseModel
      MaskProjectionParams
      Polygon
      UTMPolygonResult
      UTMReference
   
   

   
   
   



