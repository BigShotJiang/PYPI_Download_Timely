lcvtoolbox.core.schemas.huggingface.Logs
========================================

.. currentmodule:: lcvtoolbox.core.schemas.huggingface

.. autoclass:: Logs
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~Logs.__init__
      ~Logs.clear
      ~Logs.copy
      ~Logs.fromkeys
      ~Logs.get
      ~Logs.items
      ~Logs.keys
      ~Logs.pop
      ~Logs.popitem
      ~Logs.setdefault
      ~Logs.update
      ~Logs.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Logs.message
      ~Logs.level
      ~Logs.timestamp
   
   