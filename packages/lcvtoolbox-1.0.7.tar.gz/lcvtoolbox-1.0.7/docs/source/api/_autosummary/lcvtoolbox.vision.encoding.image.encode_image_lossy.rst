lcvtoolbox.vision.encoding.image.encode\_image\_lossy
=====================================================

.. currentmodule:: lcvtoolbox.vision.encoding.image

.. autofunction:: encode_image_lossy