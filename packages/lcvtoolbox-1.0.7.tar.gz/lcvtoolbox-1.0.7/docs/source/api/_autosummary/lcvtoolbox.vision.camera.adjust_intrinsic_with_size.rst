lcvtoolbox.vision.camera.adjust\_intrinsic\_with\_size
======================================================

.. currentmodule:: lcvtoolbox.vision.camera

.. autofunction:: adjust_intrinsic_with_size