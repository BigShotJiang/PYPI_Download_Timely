lcvtoolbox.vision.encoding.binary\_mask.encode\_mask\_to\_bytes
===============================================================

.. currentmodule:: lcvtoolbox.vision.encoding.binary_mask

.. autofunction:: encode_mask_to_bytes