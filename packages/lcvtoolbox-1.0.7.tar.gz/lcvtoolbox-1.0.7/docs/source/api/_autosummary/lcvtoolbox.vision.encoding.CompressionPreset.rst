lcvtoolbox.vision.encoding.CompressionPreset
============================================

.. currentmodule:: lcvtoolbox.vision.encoding

.. autoclass:: CompressionPreset
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CompressionPreset.LOSSLESS_MAX
      ~CompressionPreset.LOSSLESS_FAST
      ~CompressionPreset.LOSSLESS_WEBP
      ~CompressionPreset.HIGH_QUALITY
      ~CompressionPreset.BALANCED
      ~CompressionPreset.SMALL_SIZE
      ~CompressionPreset.TINY
   
   