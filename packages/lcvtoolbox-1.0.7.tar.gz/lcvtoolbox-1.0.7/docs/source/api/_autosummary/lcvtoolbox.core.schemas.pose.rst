lcvtoolbox.core.schemas.pose
============================

.. automodule:: lcvtoolbox.core.schemas.pose
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree: .
      :nosignatures:
   
      Field
      field_validator
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      BaseModel
      PoseRPYSchema
   
   

   
   
   



