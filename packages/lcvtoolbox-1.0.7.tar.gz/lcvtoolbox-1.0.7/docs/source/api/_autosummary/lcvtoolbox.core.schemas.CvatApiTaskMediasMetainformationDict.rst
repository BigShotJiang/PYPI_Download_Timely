lcvtoolbox.core.schemas.CvatApiTaskMediasMetainformationDict
============================================================

.. currentmodule:: lcvtoolbox.core.schemas

.. autoclass:: CvatApiTaskMediasMetainformationDict
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CvatApiTaskMediasMetainformationDict.__init__
      ~CvatApiTaskMediasMetainformationDict.clear
      ~CvatApiTaskMediasMetainformationDict.copy
      ~CvatApiTaskMediasMetainformationDict.fromkeys
      ~CvatApiTaskMediasMetainformationDict.get
      ~CvatApiTaskMediasMetainformationDict.items
      ~CvatApiTaskMediasMetainformationDict.keys
      ~CvatApiTaskMediasMetainformationDict.pop
      ~CvatApiTaskMediasMetainformationDict.popitem
      ~CvatApiTaskMediasMetainformationDict.setdefault
      ~CvatApiTaskMediasMetainformationDict.update
      ~CvatApiTaskMediasMetainformationDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CvatApiTaskMediasMetainformationDict.media_type
      ~CvatApiTaskMediasMetainformationDict.start_frame
      ~CvatApiTaskMediasMetainformationDict.stop_frame
      ~CvatApiTaskMediasMetainformationDict.frame_filter
      ~CvatApiTaskMediasMetainformationDict.frames
   
   