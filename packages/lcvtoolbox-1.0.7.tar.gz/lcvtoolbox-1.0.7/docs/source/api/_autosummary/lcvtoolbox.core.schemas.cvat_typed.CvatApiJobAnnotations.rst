lcvtoolbox.core.schemas.cvat\_typed.CvatApiJobAnnotations
=========================================================

.. currentmodule:: lcvtoolbox.core.schemas.cvat_typed

.. autoclass:: CvatApiJobAnnotations
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CvatApiJobAnnotations.__init__
      ~CvatApiJobAnnotations.clear
      ~CvatApiJobAnnotations.copy
      ~CvatApiJobAnnotations.fromkeys
      ~CvatApiJobAnnotations.get
      ~CvatApiJobAnnotations.items
      ~CvatApiJobAnnotations.keys
      ~CvatApiJobAnnotations.pop
      ~CvatApiJobAnnotations.popitem
      ~CvatApiJobAnnotations.setdefault
      ~CvatApiJobAnnotations.update
      ~CvatApiJobAnnotations.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CvatApiJobAnnotations.version
      ~CvatApiJobAnnotations.tags
      ~CvatApiJobAnnotations.shapes
      ~CvatApiJobAnnotations.tracks
   
   