lcvtoolbox.vision.encoding.numpy.decode\_numpy\_from\_string
============================================================

.. currentmodule:: lcvtoolbox.vision.encoding.numpy

.. autofunction:: decode_numpy_from_string