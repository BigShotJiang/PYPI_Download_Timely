lcvtoolbox.integrations.cvat.api.api\_requests.Callable
=======================================================

.. currentmodule:: lcvtoolbox.integrations.cvat.api.api_requests

.. autoclass:: Callable
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~Callable.__init__
   
   

   
   
   