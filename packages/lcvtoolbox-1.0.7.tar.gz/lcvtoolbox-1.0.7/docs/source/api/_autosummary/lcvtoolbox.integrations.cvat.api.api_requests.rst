lcvtoolbox.integrations.cvat.api.api\_requests
==============================================

.. automodule:: lcvtoolbox.integrations.cvat.api.api_requests
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree: .
      :nosignatures:
   
      pretty
      retry_with_backoff
      wraps
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      Any
      Callable
      CvatApi
      CvatApiJobAnnotations
      CvatApiJobDetails
      CvatApiJobMediasMetainformation
      CvatApiLabelDefinition
      CvatApiTaskAnnotations
      CvatApiTaskDetails
      CvatApiTaskMediasMetainformation
      Path
      TypeVar
   
   

   
   
   



