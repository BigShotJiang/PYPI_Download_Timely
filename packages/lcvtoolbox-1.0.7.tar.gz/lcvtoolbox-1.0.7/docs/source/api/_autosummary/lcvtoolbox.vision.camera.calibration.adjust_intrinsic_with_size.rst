lcvtoolbox.vision.camera.calibration.adjust\_intrinsic\_with\_size
==================================================================

.. currentmodule:: lcvtoolbox.vision.camera.calibration

.. autofunction:: adjust_intrinsic_with_size