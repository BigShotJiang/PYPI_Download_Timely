lcvtoolbox.vision.geometry.primitives.rotation\_vector
======================================================

.. automodule:: lcvtoolbox.vision.geometry.primitives.rotation_vector
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      Quaternion
      RPY
      RotationMatrix
      RotationVector
      Vector3D
   
   

   
   
   



