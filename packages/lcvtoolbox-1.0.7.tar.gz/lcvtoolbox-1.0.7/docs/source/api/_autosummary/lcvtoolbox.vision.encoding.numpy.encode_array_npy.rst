lcvtoolbox.vision.encoding.numpy.encode\_array\_npy
===================================================

.. currentmodule:: lcvtoolbox.vision.encoding.numpy

.. autofunction:: encode_array_npy