lcvtoolbox.vision.encoding.decode\_mask\_from\_bytes
====================================================

.. currentmodule:: lcvtoolbox.vision.encoding

.. autofunction:: decode_mask_from_bytes