lcvtoolbox.integrations.huggingface.mask.dataclass
==================================================

.. currentmodule:: lcvtoolbox.integrations.huggingface.mask

.. autofunction:: dataclass