lcvtoolbox.vision.encoding.numpy.encode\_numpy\_batch
=====================================================

.. currentmodule:: lcvtoolbox.vision.encoding.numpy

.. autofunction:: encode_numpy_batch