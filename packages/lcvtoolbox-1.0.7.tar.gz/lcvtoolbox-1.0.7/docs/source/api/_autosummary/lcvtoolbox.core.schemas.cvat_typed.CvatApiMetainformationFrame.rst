lcvtoolbox.core.schemas.cvat\_typed.CvatApiMetainformationFrame
===============================================================

.. currentmodule:: lcvtoolbox.core.schemas.cvat_typed

.. autoclass:: CvatApiMetainformationFrame
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CvatApiMetainformationFrame.__init__
      ~CvatApiMetainformationFrame.clear
      ~CvatApiMetainformationFrame.copy
      ~CvatApiMetainformationFrame.fromkeys
      ~CvatApiMetainformationFrame.get
      ~CvatApiMetainformationFrame.items
      ~CvatApiMetainformationFrame.keys
      ~CvatApiMetainformationFrame.pop
      ~CvatApiMetainformationFrame.popitem
      ~CvatApiMetainformationFrame.setdefault
      ~CvatApiMetainformationFrame.update
      ~CvatApiMetainformationFrame.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CvatApiMetainformationFrame.width
      ~CvatApiMetainformationFrame.height
      ~CvatApiMetainformationFrame.name
      ~CvatApiMetainformationFrame.related_files
   
   