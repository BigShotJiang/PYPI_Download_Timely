lcvtoolbox.vision.encoding.encode\_image\_to\_bytes
===================================================

.. currentmodule:: lcvtoolbox.vision.encoding

.. autofunction:: encode_image_to_bytes