lcvtoolbox.core.schemas.cvat\_typed
===================================

.. automodule:: lcvtoolbox.core.schemas.cvat_typed
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree: .
      :nosignatures:
   
      TypedDict
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      Any
      CvatApiAttribute
      CvatApiAttributeDefinition
      CvatApiJobAnnotations
      CvatApiJobDetails
      CvatApiJobMediasMetainformation
      CvatApiLabelDefinition
      CvatApiMetainformationFrame
      CvatApiShape
      CvatApiTag
      CvatApiTaskAnnotations
      CvatApiTaskDetails
      CvatApiTaskMediasMetainformation
   
   

   
   
   



