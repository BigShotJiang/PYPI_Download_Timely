lcvtoolbox.vision.encoding.binary\_mask.encode\_mask\_batch
===========================================================

.. currentmodule:: lcvtoolbox.vision.encoding.binary_mask

.. autofunction:: encode_mask_batch