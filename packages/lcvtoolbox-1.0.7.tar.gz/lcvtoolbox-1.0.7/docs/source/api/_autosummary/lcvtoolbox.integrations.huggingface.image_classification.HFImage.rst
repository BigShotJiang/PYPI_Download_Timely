lcvtoolbox.integrations.huggingface.image\_classification.HFImage
=================================================================

.. currentmodule:: lcvtoolbox.integrations.huggingface.image_classification

.. autoclass:: HFImage
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~HFImage.__init__
      ~HFImage.cast_storage
      ~HFImage.decode_example
      ~HFImage.embed_storage
      ~HFImage.encode_example
      ~HFImage.flatten
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~HFImage.decode
      ~HFImage.dtype
      ~HFImage.id
      ~HFImage.mode
      ~HFImage.pa_type
   
   