lcvtoolbox.integrations.cvat.api.compile\_task.CvatApiMetainformationFrame
==========================================================================

.. currentmodule:: lcvtoolbox.integrations.cvat.api.compile_task

.. autoclass:: CvatApiMetainformationFrame
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CvatApiMetainformationFrame.__init__
      ~CvatApiMetainformationFrame.construct
      ~CvatApiMetainformationFrame.copy
      ~CvatApiMetainformationFrame.dict
      ~CvatApiMetainformationFrame.from_orm
      ~CvatApiMetainformationFrame.json
      ~CvatApiMetainformationFrame.model_construct
      ~CvatApiMetainformationFrame.model_copy
      ~CvatApiMetainformationFrame.model_dump
      ~CvatApiMetainformationFrame.model_dump_json
      ~CvatApiMetainformationFrame.model_json_schema
      ~CvatApiMetainformationFrame.model_parametrized_name
      ~CvatApiMetainformationFrame.model_post_init
      ~CvatApiMetainformationFrame.model_rebuild
      ~CvatApiMetainformationFrame.model_validate
      ~CvatApiMetainformationFrame.model_validate_json
      ~CvatApiMetainformationFrame.model_validate_strings
      ~CvatApiMetainformationFrame.parse_file
      ~CvatApiMetainformationFrame.parse_obj
      ~CvatApiMetainformationFrame.parse_raw
      ~CvatApiMetainformationFrame.schema
      ~CvatApiMetainformationFrame.schema_json
      ~CvatApiMetainformationFrame.update_forward_refs
      ~CvatApiMetainformationFrame.validate
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CvatApiMetainformationFrame.model_computed_fields
      ~CvatApiMetainformationFrame.model_config
      ~CvatApiMetainformationFrame.model_extra
      ~CvatApiMetainformationFrame.model_fields
      ~CvatApiMetainformationFrame.model_fields_set
      ~CvatApiMetainformationFrame.width
      ~CvatApiMetainformationFrame.height
      ~CvatApiMetainformationFrame.name
      ~CvatApiMetainformationFrame.related_files
   
   