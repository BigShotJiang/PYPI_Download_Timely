lcvtoolbox.vision.encoding.decode\_mask\_from\_string
=====================================================

.. currentmodule:: lcvtoolbox.vision.encoding

.. autofunction:: decode_mask_from_string