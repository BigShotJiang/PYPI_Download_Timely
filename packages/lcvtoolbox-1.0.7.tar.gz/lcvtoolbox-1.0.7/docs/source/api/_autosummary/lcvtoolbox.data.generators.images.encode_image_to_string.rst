lcvtoolbox.data.generators.images.encode\_image\_to\_string
===========================================================

.. currentmodule:: lcvtoolbox.data.generators.images

.. autofunction:: encode_image_to_string