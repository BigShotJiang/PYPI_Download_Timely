lcvtoolbox.vision.geometry.projection.plane\_road\_store.CachedPoints3DEntry
============================================================================

.. currentmodule:: lcvtoolbox.vision.geometry.projection.plane_road_store

.. autoclass:: CachedPoints3DEntry
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CachedPoints3DEntry.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CachedPoints3DEntry.camera_matrix
      ~CachedPoints3DEntry.distortion
      ~CachedPoints3DEntry.pose
      ~CachedPoints3DEntry.image_size
      ~CachedPoints3DEntry.points3d
   
   