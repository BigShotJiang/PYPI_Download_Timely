lcvtoolbox.integrations.huggingface.sync\_strategy.SyncStrategy
===============================================================

.. currentmodule:: lcvtoolbox.integrations.huggingface.sync_strategy

.. autoclass:: SyncStrategy
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~SyncStrategy.from_string
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~SyncStrategy.ALWAYS
      ~SyncStrategy.IF_CHANGED
      ~SyncStrategy.NEVER
   
   