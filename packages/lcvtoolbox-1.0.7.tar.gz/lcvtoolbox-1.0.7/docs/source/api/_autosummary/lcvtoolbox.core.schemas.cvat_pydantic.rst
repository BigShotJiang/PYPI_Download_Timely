lcvtoolbox.core.schemas.cvat\_pydantic
======================================

.. automodule:: lcvtoolbox.core.schemas.cvat_pydantic
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree: .
      :nosignatures:
   
      Field
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      Any
      BaseModel
      ConfigDict
      CvatApiAttribute
      CvatApiAttributeDefinition
      CvatApiJobAnnotations
      CvatApiJobDetails
      CvatApiJobMediasMetainformation
      CvatApiLabelDefinition
      CvatApiMetainformationFrame
      CvatApiShape
      CvatApiTag
      CvatApiTaskAnnotations
      CvatApiTaskDetails
      CvatApiTaskMediasMetainformation
   
   

   
   
   



