lcvtoolbox.vision.encoding.image.encode\_image\_lossless\_bytes
===============================================================

.. currentmodule:: lcvtoolbox.vision.encoding.image

.. autofunction:: encode_image_lossless_bytes