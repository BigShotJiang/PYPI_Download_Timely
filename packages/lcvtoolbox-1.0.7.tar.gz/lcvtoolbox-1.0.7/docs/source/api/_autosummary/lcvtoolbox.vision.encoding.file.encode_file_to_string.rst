lcvtoolbox.vision.encoding.file.encode\_file\_to\_string
========================================================

.. currentmodule:: lcvtoolbox.vision.encoding.file

.. autofunction:: encode_file_to_string