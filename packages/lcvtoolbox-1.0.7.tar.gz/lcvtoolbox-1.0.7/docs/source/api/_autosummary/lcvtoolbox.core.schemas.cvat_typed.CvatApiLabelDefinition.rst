lcvtoolbox.core.schemas.cvat\_typed.CvatApiLabelDefinition
==========================================================

.. currentmodule:: lcvtoolbox.core.schemas.cvat_typed

.. autoclass:: CvatApiLabelDefinition
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CvatApiLabelDefinition.__init__
      ~CvatApiLabelDefinition.clear
      ~CvatApiLabelDefinition.copy
      ~CvatApiLabelDefinition.fromkeys
      ~CvatApiLabelDefinition.get
      ~CvatApiLabelDefinition.items
      ~CvatApiLabelDefinition.keys
      ~CvatApiLabelDefinition.pop
      ~CvatApiLabelDefinition.popitem
      ~CvatApiLabelDefinition.setdefault
      ~CvatApiLabelDefinition.update
      ~CvatApiLabelDefinition.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CvatApiLabelDefinition.id
      ~CvatApiLabelDefinition.name
      ~CvatApiLabelDefinition.color
      ~CvatApiLabelDefinition.type
      ~CvatApiLabelDefinition.attributes
   
   