lcvtoolbox.integrations.cvat.api.api\_requests.wraps
====================================================

.. currentmodule:: lcvtoolbox.integrations.cvat.api.api_requests

.. autofunction:: wraps