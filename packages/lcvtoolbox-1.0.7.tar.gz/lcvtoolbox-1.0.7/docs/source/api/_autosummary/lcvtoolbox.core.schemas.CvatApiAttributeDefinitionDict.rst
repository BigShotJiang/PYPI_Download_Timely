lcvtoolbox.core.schemas.CvatApiAttributeDefinitionDict
======================================================

.. currentmodule:: lcvtoolbox.core.schemas

.. autoclass:: CvatApiAttributeDefinitionDict
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CvatApiAttributeDefinitionDict.__init__
      ~CvatApiAttributeDefinitionDict.clear
      ~CvatApiAttributeDefinitionDict.copy
      ~CvatApiAttributeDefinitionDict.fromkeys
      ~CvatApiAttributeDefinitionDict.get
      ~CvatApiAttributeDefinitionDict.items
      ~CvatApiAttributeDefinitionDict.keys
      ~CvatApiAttributeDefinitionDict.pop
      ~CvatApiAttributeDefinitionDict.popitem
      ~CvatApiAttributeDefinitionDict.setdefault
      ~CvatApiAttributeDefinitionDict.update
      ~CvatApiAttributeDefinitionDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CvatApiAttributeDefinitionDict.id
      ~CvatApiAttributeDefinitionDict.name
      ~CvatApiAttributeDefinitionDict.mutable
      ~CvatApiAttributeDefinitionDict.input_type
      ~CvatApiAttributeDefinitionDict.default_value
   
   