lcvtoolbox.integrations.huggingface.endpoint.client.EndpointClient
==================================================================

.. currentmodule:: lcvtoolbox.integrations.huggingface.endpoint.client

.. autoclass:: EndpointClient
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~EndpointClient.__init__
      ~EndpointClient.call_with_image_path
      ~EndpointClient.call_with_pil_image
      ~EndpointClient.get_secret
      ~EndpointClient.wait_until_ready
   
   

   
   
   