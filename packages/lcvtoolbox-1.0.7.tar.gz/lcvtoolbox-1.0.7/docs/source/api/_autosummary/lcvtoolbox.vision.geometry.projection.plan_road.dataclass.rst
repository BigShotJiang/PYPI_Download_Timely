lcvtoolbox.vision.geometry.projection.plan\_road.dataclass
==========================================================

.. currentmodule:: lcvtoolbox.vision.geometry.projection.plan_road

.. autofunction:: dataclass