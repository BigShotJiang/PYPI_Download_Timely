lcvtoolbox.core.schemas.cvat\_typed.CvatApiTaskMediasMetainformation
====================================================================

.. currentmodule:: lcvtoolbox.core.schemas.cvat_typed

.. autoclass:: CvatApiTaskMediasMetainformation
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CvatApiTaskMediasMetainformation.__init__
      ~CvatApiTaskMediasMetainformation.clear
      ~CvatApiTaskMediasMetainformation.copy
      ~CvatApiTaskMediasMetainformation.fromkeys
      ~CvatApiTaskMediasMetainformation.get
      ~CvatApiTaskMediasMetainformation.items
      ~CvatApiTaskMediasMetainformation.keys
      ~CvatApiTaskMediasMetainformation.pop
      ~CvatApiTaskMediasMetainformation.popitem
      ~CvatApiTaskMediasMetainformation.setdefault
      ~CvatApiTaskMediasMetainformation.update
      ~CvatApiTaskMediasMetainformation.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CvatApiTaskMediasMetainformation.media_type
      ~CvatApiTaskMediasMetainformation.start_frame
      ~CvatApiTaskMediasMetainformation.stop_frame
      ~CvatApiTaskMediasMetainformation.frame_filter
      ~CvatApiTaskMediasMetainformation.frames
   
   