lcvtoolbox.core.schemas.cvat\_typed.CvatApiTaskAnnotations
==========================================================

.. currentmodule:: lcvtoolbox.core.schemas.cvat_typed

.. autoclass:: CvatApiTaskAnnotations
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CvatApiTaskAnnotations.__init__
      ~CvatApiTaskAnnotations.clear
      ~CvatApiTaskAnnotations.copy
      ~CvatApiTaskAnnotations.fromkeys
      ~CvatApiTaskAnnotations.get
      ~CvatApiTaskAnnotations.items
      ~CvatApiTaskAnnotations.keys
      ~CvatApiTaskAnnotations.pop
      ~CvatApiTaskAnnotations.popitem
      ~CvatApiTaskAnnotations.setdefault
      ~CvatApiTaskAnnotations.update
      ~CvatApiTaskAnnotations.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CvatApiTaskAnnotations.version
      ~CvatApiTaskAnnotations.tags
      ~CvatApiTaskAnnotations.shapes
      ~CvatApiTaskAnnotations.tracks
   
   