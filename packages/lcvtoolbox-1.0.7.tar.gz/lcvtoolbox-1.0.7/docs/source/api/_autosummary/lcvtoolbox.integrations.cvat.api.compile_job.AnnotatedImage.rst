lcvtoolbox.integrations.cvat.api.compile\_job.AnnotatedImage
============================================================

.. currentmodule:: lcvtoolbox.integrations.cvat.api.compile_job

.. autoclass:: AnnotatedImage
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~AnnotatedImage.__init__
      ~AnnotatedImage.close_image
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~AnnotatedImage.image
   
   