lcvtoolbox.vision.geometry.primitives.quaternion
================================================

.. automodule:: lcvtoolbox.vision.geometry.primitives.quaternion
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      Quaternion
      RPY
      RotationMatrix
   
   

   
   
   



