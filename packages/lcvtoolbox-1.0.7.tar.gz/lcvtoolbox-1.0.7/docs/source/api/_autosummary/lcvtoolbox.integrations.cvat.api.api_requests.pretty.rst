lcvtoolbox.integrations.cvat.api.api\_requests.pretty
=====================================================

.. currentmodule:: lcvtoolbox.integrations.cvat.api.api_requests

.. autofunction:: pretty