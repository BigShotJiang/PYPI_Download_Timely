lcvtoolbox.integrations.cvat.api.compile\_annotated\_image.AnnotatedImage
=========================================================================

.. currentmodule:: lcvtoolbox.integrations.cvat.api.compile_annotated_image

.. autoclass:: AnnotatedImage
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~AnnotatedImage.__init__
      ~AnnotatedImage.close_image
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~AnnotatedImage.image
   
   