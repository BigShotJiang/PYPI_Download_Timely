lcvtoolbox.integrations.huggingface.image\_classification.load\_dataset
=======================================================================

.. currentmodule:: lcvtoolbox.integrations.huggingface.image_classification

.. autofunction:: load_dataset