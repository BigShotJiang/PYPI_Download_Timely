lcvtoolbox.vision.geometry.projection.plane\_road\_store
========================================================

.. automodule:: lcvtoolbox.vision.geometry.projection.plane_road_store
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree: .
      :nosignatures:
   
      adjust_intrinsic_with_size
      dataclass
      example_usage
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      CachedPoints3DEntry
      Calibration
      CameraDistortionSchema
      CameraMatrixSchema
      OrderedDict
      PlaneRoadModel
      PlaneRoadStore
      PoseRPYSchema
   
   

   
   
   



