lcvtoolbox.vision.encoding.image.encode\_image\_adaptive\_bytes
===============================================================

.. currentmodule:: lcvtoolbox.vision.encoding.image

.. autofunction:: encode_image_adaptive_bytes