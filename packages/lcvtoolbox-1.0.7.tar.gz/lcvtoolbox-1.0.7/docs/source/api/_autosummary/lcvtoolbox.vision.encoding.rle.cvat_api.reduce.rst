lcvtoolbox.vision.encoding.rle.cvat\_api.reduce
===============================================

.. currentmodule:: lcvtoolbox.vision.encoding.rle.cvat_api

.. autofunction:: reduce