lcvtoolbox.vision.encoding.binary\_mask.encode\_mask\_png\_l
============================================================

.. currentmodule:: lcvtoolbox.vision.encoding.binary_mask

.. autofunction:: encode_mask_png_l