lcvtoolbox.integrations.huggingface.image\_classification.create\_repo
======================================================================

.. currentmodule:: lcvtoolbox.integrations.huggingface.image_classification

.. autofunction:: create_repo