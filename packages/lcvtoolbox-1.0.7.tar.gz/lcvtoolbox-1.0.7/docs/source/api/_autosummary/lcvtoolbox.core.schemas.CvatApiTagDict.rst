lcvtoolbox.core.schemas.CvatApiTagDict
======================================

.. currentmodule:: lcvtoolbox.core.schemas

.. autoclass:: CvatApiTagDict
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CvatApiTagDict.__init__
      ~CvatApiTagDict.clear
      ~CvatApiTagDict.copy
      ~CvatApiTagDict.fromkeys
      ~CvatApiTagDict.get
      ~CvatApiTagDict.items
      ~CvatApiTagDict.keys
      ~CvatApiTagDict.pop
      ~CvatApiTagDict.popitem
      ~CvatApiTagDict.setdefault
      ~CvatApiTagDict.update
      ~CvatApiTagDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CvatApiTagDict.id
      ~CvatApiTagDict.frame
      ~CvatApiTagDict.label_id
      ~CvatApiTagDict.source
      ~CvatApiTagDict.attributes
   
   