lcvtoolbox.core.schemas.huggingface
===================================

.. automodule:: lcvtoolbox.core.schemas.huggingface
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree: .
      :nosignatures:
   
      TypedDict
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      Annotation
      Any
      InputData
      Logs
      Parameters
      RawAnnotation
   
   

   
   
   



