lcvtoolbox.vision.encoding.encode\_mask\_to\_string
===================================================

.. currentmodule:: lcvtoolbox.vision.encoding

.. autofunction:: encode_mask_to_string