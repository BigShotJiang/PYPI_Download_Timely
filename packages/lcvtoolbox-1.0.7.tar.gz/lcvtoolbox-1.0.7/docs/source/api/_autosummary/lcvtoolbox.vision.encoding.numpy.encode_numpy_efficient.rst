lcvtoolbox.vision.encoding.numpy.encode\_numpy\_efficient
=========================================================

.. currentmodule:: lcvtoolbox.vision.encoding.numpy

.. autofunction:: encode_numpy_efficient