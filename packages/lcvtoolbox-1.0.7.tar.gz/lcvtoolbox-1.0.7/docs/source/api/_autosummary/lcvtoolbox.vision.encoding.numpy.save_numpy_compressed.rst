lcvtoolbox.vision.encoding.numpy.save\_numpy\_compressed
========================================================

.. currentmodule:: lcvtoolbox.vision.encoding.numpy

.. autofunction:: save_numpy_compressed