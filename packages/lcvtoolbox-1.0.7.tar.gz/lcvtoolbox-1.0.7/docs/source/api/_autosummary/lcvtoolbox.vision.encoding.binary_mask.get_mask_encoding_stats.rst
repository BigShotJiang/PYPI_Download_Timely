lcvtoolbox.vision.encoding.binary\_mask.get\_mask\_encoding\_stats
==================================================================

.. currentmodule:: lcvtoolbox.vision.encoding.binary_mask

.. autofunction:: get_mask_encoding_stats