lcvtoolbox.vision.encoding.numpy.Enum
=====================================

.. currentmodule:: lcvtoolbox.vision.encoding.numpy

.. autoclass:: Enum
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   

   
   
   