lcvtoolbox.vision.encoding.numpy.ArrayMetadata
==============================================

.. currentmodule:: lcvtoolbox.vision.encoding.numpy

.. autoclass:: ArrayMetadata
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~ArrayMetadata.__init__
      ~ArrayMetadata.from_dict
      ~ArrayMetadata.to_dict
   
   

   
   
   