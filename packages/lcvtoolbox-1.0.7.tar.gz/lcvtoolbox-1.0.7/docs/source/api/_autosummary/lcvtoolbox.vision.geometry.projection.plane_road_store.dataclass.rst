lcvtoolbox.vision.geometry.projection.plane\_road\_store.dataclass
==================================================================

.. currentmodule:: lcvtoolbox.vision.geometry.projection.plane_road_store

.. autofunction:: dataclass