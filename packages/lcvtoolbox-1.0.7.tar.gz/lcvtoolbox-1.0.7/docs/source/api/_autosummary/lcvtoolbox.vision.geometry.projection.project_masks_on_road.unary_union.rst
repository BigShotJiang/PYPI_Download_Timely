lcvtoolbox.vision.geometry.projection.project\_masks\_on\_road.unary\_union
===========================================================================

.. currentmodule:: lcvtoolbox.vision.geometry.projection.project_masks_on_road

.. autofunction:: unary_union