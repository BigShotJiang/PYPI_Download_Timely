lcvtoolbox.vision.geometry.projection.project\_masks\_on\_road
==============================================================

.. automodule:: lcvtoolbox.vision.geometry.projection.project_masks_on_road
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree: .
      :nosignatures:
   
      polygonize
      unary_union
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      BaseGeometry
      GPSCoordinates
      LineString
      MaskProjectionParams
      MultiPoint
      MultiPolygon
      Point
      Polygon
      ProjectMask
      UTMPolygonResult
      UTMReference
   
   

   
   
   



