lcvtoolbox.data.generators.masks.create\_square\_mask
=====================================================

.. currentmodule:: lcvtoolbox.data.generators.masks

.. autofunction:: create_square_mask