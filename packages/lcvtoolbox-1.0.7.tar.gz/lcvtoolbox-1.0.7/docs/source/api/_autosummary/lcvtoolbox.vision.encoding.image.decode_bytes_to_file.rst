lcvtoolbox.vision.encoding.image.decode\_bytes\_to\_file
========================================================

.. currentmodule:: lcvtoolbox.vision.encoding.image

.. autofunction:: decode_bytes_to_file