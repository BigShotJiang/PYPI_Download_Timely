lcvtoolbox.core.schemas.huggingface.TypedDict
=============================================

.. currentmodule:: lcvtoolbox.core.schemas.huggingface

.. autofunction:: TypedDict