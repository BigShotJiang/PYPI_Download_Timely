lcvtoolbox.vision.encoding.binary\_mask.decode\_mask\_from\_bytes
=================================================================

.. currentmodule:: lcvtoolbox.vision.encoding.binary_mask

.. autofunction:: decode_mask_from_bytes