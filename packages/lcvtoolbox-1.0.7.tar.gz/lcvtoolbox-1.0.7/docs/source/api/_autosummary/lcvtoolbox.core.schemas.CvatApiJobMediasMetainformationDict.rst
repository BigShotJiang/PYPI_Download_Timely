lcvtoolbox.core.schemas.CvatApiJobMediasMetainformationDict
===========================================================

.. currentmodule:: lcvtoolbox.core.schemas

.. autoclass:: CvatApiJobMediasMetainformationDict
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CvatApiJobMediasMetainformationDict.__init__
      ~CvatApiJobMediasMetainformationDict.clear
      ~CvatApiJobMediasMetainformationDict.copy
      ~CvatApiJobMediasMetainformationDict.fromkeys
      ~CvatApiJobMediasMetainformationDict.get
      ~CvatApiJobMediasMetainformationDict.items
      ~CvatApiJobMediasMetainformationDict.keys
      ~CvatApiJobMediasMetainformationDict.pop
      ~CvatApiJobMediasMetainformationDict.popitem
      ~CvatApiJobMediasMetainformationDict.setdefault
      ~CvatApiJobMediasMetainformationDict.update
      ~CvatApiJobMediasMetainformationDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CvatApiJobMediasMetainformationDict.start_frame
      ~CvatApiJobMediasMetainformationDict.stop_frame
      ~CvatApiJobMediasMetainformationDict.frame_filter
      ~CvatApiJobMediasMetainformationDict.frames
   
   