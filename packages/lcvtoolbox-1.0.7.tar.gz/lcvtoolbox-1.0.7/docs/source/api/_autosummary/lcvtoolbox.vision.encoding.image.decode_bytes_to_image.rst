lcvtoolbox.vision.encoding.image.decode\_bytes\_to\_image
=========================================================

.. currentmodule:: lcvtoolbox.vision.encoding.image

.. autofunction:: decode_bytes_to_image