lcvtoolbox.vision.geometry.projection.plane\_road\_store.adjust\_intrinsic\_with\_size
======================================================================================

.. currentmodule:: lcvtoolbox.vision.geometry.projection.plane_road_store

.. autofunction:: adjust_intrinsic_with_size