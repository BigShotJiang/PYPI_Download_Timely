lcvtoolbox.core.schemas.encoding.TypedDict
==========================================

.. currentmodule:: lcvtoolbox.core.schemas.encoding

.. autofunction:: TypedDict