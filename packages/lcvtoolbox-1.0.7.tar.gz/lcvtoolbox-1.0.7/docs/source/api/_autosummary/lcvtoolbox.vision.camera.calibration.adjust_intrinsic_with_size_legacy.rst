lcvtoolbox.vision.camera.calibration.adjust\_intrinsic\_with\_size\_legacy
==========================================================================

.. currentmodule:: lcvtoolbox.vision.camera.calibration

.. autofunction:: adjust_intrinsic_with_size_legacy