lcvtoolbox.data.metadata.frames
===============================

.. automodule:: lcvtoolbox.data.metadata.frames
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      FramesMetadata
   
   

   
   
   



.. rubric:: Modules

.. autosummary::
   :toctree: .
   :template: custom-module-template.rst
   :recursive:

   frames

