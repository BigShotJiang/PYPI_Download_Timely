lcvtoolbox.vision.encoding.file.get\_file\_metadata
===================================================

.. currentmodule:: lcvtoolbox.vision.encoding.file

.. autofunction:: get_file_metadata