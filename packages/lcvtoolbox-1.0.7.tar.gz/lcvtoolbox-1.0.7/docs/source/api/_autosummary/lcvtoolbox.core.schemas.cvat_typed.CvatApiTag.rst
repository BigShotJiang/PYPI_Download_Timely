lcvtoolbox.core.schemas.cvat\_typed.CvatApiTag
==============================================

.. currentmodule:: lcvtoolbox.core.schemas.cvat_typed

.. autoclass:: CvatApiTag
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CvatApiTag.__init__
      ~CvatApiTag.clear
      ~CvatApiTag.copy
      ~CvatApiTag.fromkeys
      ~CvatApiTag.get
      ~CvatApiTag.items
      ~CvatApiTag.keys
      ~CvatApiTag.pop
      ~CvatApiTag.popitem
      ~CvatApiTag.setdefault
      ~CvatApiTag.update
      ~CvatApiTag.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CvatApiTag.id
      ~CvatApiTag.frame
      ~CvatApiTag.label_id
      ~CvatApiTag.source
      ~CvatApiTag.attributes
   
   