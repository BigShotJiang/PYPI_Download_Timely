lcvtoolbox.vision.geometry.projection.plane\_road\_store.example\_usage
=======================================================================

.. currentmodule:: lcvtoolbox.vision.geometry.projection.plane_road_store

.. autofunction:: example_usage