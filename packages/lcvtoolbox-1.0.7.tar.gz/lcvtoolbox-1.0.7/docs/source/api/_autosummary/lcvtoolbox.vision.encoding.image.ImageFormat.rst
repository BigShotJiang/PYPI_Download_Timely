lcvtoolbox.vision.encoding.image.ImageFormat
============================================

.. currentmodule:: lcvtoolbox.vision.encoding.image

.. autoclass:: ImageFormat
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~ImageFormat.JPEG
      ~ImageFormat.PNG
      ~ImageFormat.WEBP
      ~ImageFormat.WEBP_LOSSLESS
   
   