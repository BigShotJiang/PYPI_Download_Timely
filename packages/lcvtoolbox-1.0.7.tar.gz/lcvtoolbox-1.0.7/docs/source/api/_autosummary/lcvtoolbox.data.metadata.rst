lcvtoolbox.data.metadata
========================

.. automodule:: lcvtoolbox.data.metadata
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   

   
   
   

   
   
   



.. rubric:: Modules

.. autosummary::
   :toctree: .
   :template: custom-module-template.rst
   :recursive:

   frames

