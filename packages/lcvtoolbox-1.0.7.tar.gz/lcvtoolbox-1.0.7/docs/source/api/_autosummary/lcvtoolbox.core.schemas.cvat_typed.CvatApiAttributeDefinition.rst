lcvtoolbox.core.schemas.cvat\_typed.CvatApiAttributeDefinition
==============================================================

.. currentmodule:: lcvtoolbox.core.schemas.cvat_typed

.. autoclass:: CvatApiAttributeDefinition
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CvatApiAttributeDefinition.__init__
      ~CvatApiAttributeDefinition.clear
      ~CvatApiAttributeDefinition.copy
      ~CvatApiAttributeDefinition.fromkeys
      ~CvatApiAttributeDefinition.get
      ~CvatApiAttributeDefinition.items
      ~CvatApiAttributeDefinition.keys
      ~CvatApiAttributeDefinition.pop
      ~CvatApiAttributeDefinition.popitem
      ~CvatApiAttributeDefinition.setdefault
      ~CvatApiAttributeDefinition.update
      ~CvatApiAttributeDefinition.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CvatApiAttributeDefinition.id
      ~CvatApiAttributeDefinition.name
      ~CvatApiAttributeDefinition.mutable
      ~CvatApiAttributeDefinition.input_type
      ~CvatApiAttributeDefinition.default_value
   
   