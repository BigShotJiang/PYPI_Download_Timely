lcvtoolbox.vision.encoding.image.decode\_string\_to\_image
==========================================================

.. currentmodule:: lcvtoolbox.vision.encoding.image

.. autofunction:: decode_string_to_image