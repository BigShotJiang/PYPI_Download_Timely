lcvtoolbox.integrations.huggingface.mask.EncodedRLE
===================================================

.. currentmodule:: lcvtoolbox.integrations.huggingface.mask

.. autoclass:: EncodedRLE
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~EncodedRLE.__init__
      ~EncodedRLE.clear
      ~EncodedRLE.copy
      ~EncodedRLE.fromkeys
      ~EncodedRLE.get
      ~EncodedRLE.items
      ~EncodedRLE.keys
      ~EncodedRLE.pop
      ~EncodedRLE.popitem
      ~EncodedRLE.setdefault
      ~EncodedRLE.update
      ~EncodedRLE.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~EncodedRLE.size
      ~EncodedRLE.counts
   
   