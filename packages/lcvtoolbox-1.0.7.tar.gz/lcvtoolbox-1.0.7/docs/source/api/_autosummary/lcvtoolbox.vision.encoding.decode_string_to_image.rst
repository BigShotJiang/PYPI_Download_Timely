lcvtoolbox.vision.encoding.decode\_string\_to\_image
====================================================

.. currentmodule:: lcvtoolbox.vision.encoding

.. autofunction:: decode_string_to_image