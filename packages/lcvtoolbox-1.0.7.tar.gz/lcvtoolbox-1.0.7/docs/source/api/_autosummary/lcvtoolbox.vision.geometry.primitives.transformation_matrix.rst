lcvtoolbox.vision.geometry.primitives.transformation\_matrix
============================================================

.. automodule:: lcvtoolbox.vision.geometry.primitives.transformation_matrix
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      AxisAngle
      EulerAngles
      Point3D
      Quaternion
      RPY
      RotationMatrix
      RotationVector
      TransformationMatrix
      TwoVectors
      Vector3D
   
   

   
   
   



