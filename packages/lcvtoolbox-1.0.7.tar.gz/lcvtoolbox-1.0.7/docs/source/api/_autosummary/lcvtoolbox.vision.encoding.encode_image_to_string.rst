lcvtoolbox.vision.encoding.encode\_image\_to\_string
====================================================

.. currentmodule:: lcvtoolbox.vision.encoding

.. autofunction:: encode_image_to_string