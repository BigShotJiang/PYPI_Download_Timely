lcvtoolbox.vision.geometry.projection.Calibration
=================================================

.. currentmodule:: lcvtoolbox.vision.geometry.projection

.. autoclass:: Calibration
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~Calibration.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Calibration.dist_coeffs
      ~Calibration.camera_matrix
   
   