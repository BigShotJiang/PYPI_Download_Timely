lcvtoolbox.integrations.cvat.api.compile\_job
=============================================

.. automodule:: lcvtoolbox.integrations.cvat.api.compile_job
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      AnnotatedImage
      Any
      Callable
      CvatApi
      CvatApiJobAnnotations
      CvatApiJobDetails
      CvatApiJobMediasMetainformation
      CvatApiMetainformationFrame
      CvatApiShape
      CvatApiTag
      CvatApiTaskDetails
      CvatJob
   
   

   
   
   



