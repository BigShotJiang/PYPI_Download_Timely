lcvtoolbox.core.schemas.CvatApiJobMediasMetainformation
=======================================================

.. currentmodule:: lcvtoolbox.core.schemas

.. autoclass:: CvatApiJobMediasMetainformation
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CvatApiJobMediasMetainformation.__init__
      ~CvatApiJobMediasMetainformation.construct
      ~CvatApiJobMediasMetainformation.copy
      ~CvatApiJobMediasMetainformation.dict
      ~CvatApiJobMediasMetainformation.from_orm
      ~CvatApiJobMediasMetainformation.json
      ~CvatApiJobMediasMetainformation.model_construct
      ~CvatApiJobMediasMetainformation.model_copy
      ~CvatApiJobMediasMetainformation.model_dump
      ~CvatApiJobMediasMetainformation.model_dump_json
      ~CvatApiJobMediasMetainformation.model_json_schema
      ~CvatApiJobMediasMetainformation.model_parametrized_name
      ~CvatApiJobMediasMetainformation.model_post_init
      ~CvatApiJobMediasMetainformation.model_rebuild
      ~CvatApiJobMediasMetainformation.model_validate
      ~CvatApiJobMediasMetainformation.model_validate_json
      ~CvatApiJobMediasMetainformation.model_validate_strings
      ~CvatApiJobMediasMetainformation.parse_file
      ~CvatApiJobMediasMetainformation.parse_obj
      ~CvatApiJobMediasMetainformation.parse_raw
      ~CvatApiJobMediasMetainformation.schema
      ~CvatApiJobMediasMetainformation.schema_json
      ~CvatApiJobMediasMetainformation.update_forward_refs
      ~CvatApiJobMediasMetainformation.validate
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CvatApiJobMediasMetainformation.model_computed_fields
      ~CvatApiJobMediasMetainformation.model_config
      ~CvatApiJobMediasMetainformation.model_extra
      ~CvatApiJobMediasMetainformation.model_fields
      ~CvatApiJobMediasMetainformation.model_fields_set
      ~CvatApiJobMediasMetainformation.start_frame
      ~CvatApiJobMediasMetainformation.stop_frame
      ~CvatApiJobMediasMetainformation.frame_filter
      ~CvatApiJobMediasMetainformation.frames
   
   