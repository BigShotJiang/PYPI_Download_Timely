lcvtoolbox.core.schemas.CvatApiAttributeDict
============================================

.. currentmodule:: lcvtoolbox.core.schemas

.. autoclass:: CvatApiAttributeDict
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CvatApiAttributeDict.__init__
      ~CvatApiAttributeDict.clear
      ~CvatApiAttributeDict.copy
      ~CvatApiAttributeDict.fromkeys
      ~CvatApiAttributeDict.get
      ~CvatApiAttributeDict.items
      ~CvatApiAttributeDict.keys
      ~CvatApiAttributeDict.pop
      ~CvatApiAttributeDict.popitem
      ~CvatApiAttributeDict.setdefault
      ~CvatApiAttributeDict.update
      ~CvatApiAttributeDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CvatApiAttributeDict.id
      ~CvatApiAttributeDict.spec_id
      ~CvatApiAttributeDict.value
   
   