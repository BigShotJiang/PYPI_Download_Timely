lcvtoolbox.vision.encoding.binary\_mask.encode\_mask\_packed\_bits
==================================================================

.. currentmodule:: lcvtoolbox.vision.encoding.binary_mask

.. autofunction:: encode_mask_packed_bits