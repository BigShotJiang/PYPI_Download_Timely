lcvtoolbox.integrations.huggingface.mask.TypedDict
==================================================

.. currentmodule:: lcvtoolbox.integrations.huggingface.mask

.. autofunction:: TypedDict