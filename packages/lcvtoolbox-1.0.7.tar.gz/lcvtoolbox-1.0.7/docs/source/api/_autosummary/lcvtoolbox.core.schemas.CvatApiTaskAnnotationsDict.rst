lcvtoolbox.core.schemas.CvatApiTaskAnnotationsDict
==================================================

.. currentmodule:: lcvtoolbox.core.schemas

.. autoclass:: CvatApiTaskAnnotationsDict
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CvatApiTaskAnnotationsDict.__init__
      ~CvatApiTaskAnnotationsDict.clear
      ~CvatApiTaskAnnotationsDict.copy
      ~CvatApiTaskAnnotationsDict.fromkeys
      ~CvatApiTaskAnnotationsDict.get
      ~CvatApiTaskAnnotationsDict.items
      ~CvatApiTaskAnnotationsDict.keys
      ~CvatApiTaskAnnotationsDict.pop
      ~CvatApiTaskAnnotationsDict.popitem
      ~CvatApiTaskAnnotationsDict.setdefault
      ~CvatApiTaskAnnotationsDict.update
      ~CvatApiTaskAnnotationsDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CvatApiTaskAnnotationsDict.version
      ~CvatApiTaskAnnotationsDict.tags
      ~CvatApiTaskAnnotationsDict.shapes
      ~CvatApiTaskAnnotationsDict.tracks
   
   