lcvtoolbox.vision.encoding.numpy.load\_numpy\_compressed
========================================================

.. currentmodule:: lcvtoolbox.vision.encoding.numpy

.. autofunction:: load_numpy_compressed