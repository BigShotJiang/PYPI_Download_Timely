lcvtoolbox.core.schemas.CvatApiMetainformationFrameDict
=======================================================

.. currentmodule:: lcvtoolbox.core.schemas

.. autoclass:: CvatApiMetainformationFrameDict
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~CvatApiMetainformationFrameDict.__init__
      ~CvatApiMetainformationFrameDict.clear
      ~CvatApiMetainformationFrameDict.copy
      ~CvatApiMetainformationFrameDict.fromkeys
      ~CvatApiMetainformationFrameDict.get
      ~CvatApiMetainformationFrameDict.items
      ~CvatApiMetainformationFrameDict.keys
      ~CvatApiMetainformationFrameDict.pop
      ~CvatApiMetainformationFrameDict.popitem
      ~CvatApiMetainformationFrameDict.setdefault
      ~CvatApiMetainformationFrameDict.update
      ~CvatApiMetainformationFrameDict.values
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CvatApiMetainformationFrameDict.width
      ~CvatApiMetainformationFrameDict.height
      ~CvatApiMetainformationFrameDict.name
      ~CvatApiMetainformationFrameDict.related_files
   
   