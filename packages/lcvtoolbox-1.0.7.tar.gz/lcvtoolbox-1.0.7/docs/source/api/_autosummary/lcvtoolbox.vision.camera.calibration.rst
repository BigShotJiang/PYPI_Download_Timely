lcvtoolbox.vision.camera.calibration
====================================

.. automodule:: lcvtoolbox.vision.camera.calibration
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree: .
      :nosignatures:
   
      adjust_intrinsic_with_size
      adjust_intrinsic_with_size_legacy
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      CameraDistortionSchema
      CameraMatrixSchema
   
   

   
   
   



