lcvtoolbox.vision.geometry.primitives.rotation\_matrix
======================================================

.. automodule:: lcvtoolbox.vision.geometry.primitives.rotation_matrix
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      RPY
      RotationMatrix
   
   

   
   
   



