lcvtoolbox.integrations.huggingface.push\_strategy.PushStrategy
===============================================================

.. currentmodule:: lcvtoolbox.integrations.huggingface.push_strategy

.. autoclass:: PushStrategy
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~PushStrategy.from_string
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~PushStrategy.ALWAYS
      ~PushStrategy.NEVER
   
   