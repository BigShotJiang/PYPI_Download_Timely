lcvtoolbox.vision.encoding.encode\_image\_lossy
===============================================

.. currentmodule:: lcvtoolbox.vision.encoding

.. autofunction:: encode_image_lossy