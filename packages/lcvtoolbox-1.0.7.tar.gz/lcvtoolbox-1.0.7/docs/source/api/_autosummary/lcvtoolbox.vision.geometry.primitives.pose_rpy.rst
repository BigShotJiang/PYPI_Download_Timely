lcvtoolbox.vision.geometry.primitives.pose\_rpy
===============================================

.. automodule:: lcvtoolbox.vision.geometry.primitives.pose_rpy
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      Point3D
      PoseRPY
      Quaternion
      RPY
      RotationMatrix
      TransformationMatrix
      Vector3D
   
   

   
   
   



