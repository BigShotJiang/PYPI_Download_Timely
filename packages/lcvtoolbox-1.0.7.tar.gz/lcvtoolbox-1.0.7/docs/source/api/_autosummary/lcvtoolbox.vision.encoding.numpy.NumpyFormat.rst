lcvtoolbox.vision.encoding.numpy.NumpyFormat
============================================

.. currentmodule:: lcvtoolbox.vision.encoding.numpy

.. autoclass:: NumpyFormat
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~NumpyFormat.NPZ_COMPRESSED
      ~NumpyFormat.NPY
      ~NumpyFormat.PICKLE
      ~NumpyFormat.JSON_FULL
      ~NumpyFormat.JSON_ROUNDED
      ~NumpyFormat.BYTES_RAW
      ~NumpyFormat.BYTES_COMPRESSED
      ~NumpyFormat.FLOAT16
      ~NumpyFormat.UINT8_SCALED
   
   