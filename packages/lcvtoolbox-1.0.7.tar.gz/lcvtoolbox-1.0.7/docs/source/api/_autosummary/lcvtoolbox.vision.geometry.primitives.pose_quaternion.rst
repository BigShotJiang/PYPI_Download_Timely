lcvtoolbox.vision.geometry.primitives.pose\_quaternion
======================================================

.. automodule:: lcvtoolbox.vision.geometry.primitives.pose_quaternion
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      Point3D
      PoseQuaternion
      Quaternion
      RPY
      RotationMatrix
      TransformationMatrix
      Vector3D
   
   

   
   
   



