lcvtoolbox.core.schemas.pose.field\_validator
=============================================

.. currentmodule:: lcvtoolbox.core.schemas.pose

.. autofunction:: field_validator