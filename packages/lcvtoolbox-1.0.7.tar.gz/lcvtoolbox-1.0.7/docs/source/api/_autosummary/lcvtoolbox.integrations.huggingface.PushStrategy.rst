lcvtoolbox.integrations.huggingface.PushStrategy
================================================

.. currentmodule:: lcvtoolbox.integrations.huggingface

.. autoclass:: PushStrategy
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~PushStrategy.from_string
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~PushStrategy.ALWAYS
      ~PushStrategy.NEVER
   
   