lcvtoolbox.integrations.huggingface.push\_image\_classification\_folders
========================================================================

.. currentmodule:: lcvtoolbox.integrations.huggingface

.. autofunction:: push_image_classification_folders