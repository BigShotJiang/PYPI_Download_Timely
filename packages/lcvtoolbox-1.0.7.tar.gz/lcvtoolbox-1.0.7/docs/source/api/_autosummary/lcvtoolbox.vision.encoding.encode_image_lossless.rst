lcvtoolbox.vision.encoding.encode\_image\_lossless
==================================================

.. currentmodule:: lcvtoolbox.vision.encoding

.. autofunction:: encode_image_lossless