lcvtoolbox.vision.geometry.primitives.axis\_angle
=================================================

.. automodule:: lcvtoolbox.vision.geometry.primitives.axis_angle
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      AxisAngle
      Quaternion
      RPY
      RotationMatrix
      RotationVector
      Vector3D
   
   

   
   
   



