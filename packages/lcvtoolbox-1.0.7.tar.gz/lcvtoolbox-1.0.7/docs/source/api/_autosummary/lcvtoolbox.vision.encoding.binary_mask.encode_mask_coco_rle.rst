lcvtoolbox.vision.encoding.binary\_mask.encode\_mask\_coco\_rle
===============================================================

.. currentmodule:: lcvtoolbox.vision.encoding.binary_mask

.. autofunction:: encode_mask_coco_rle