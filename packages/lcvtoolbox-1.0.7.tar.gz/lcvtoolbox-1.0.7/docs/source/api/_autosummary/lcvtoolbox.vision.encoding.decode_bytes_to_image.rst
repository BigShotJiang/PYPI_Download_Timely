lcvtoolbox.vision.encoding.decode\_bytes\_to\_image
===================================================

.. currentmodule:: lcvtoolbox.vision.encoding

.. autofunction:: decode_bytes_to_image