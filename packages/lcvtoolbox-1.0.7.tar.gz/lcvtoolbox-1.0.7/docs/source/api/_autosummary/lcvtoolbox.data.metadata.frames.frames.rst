lcvtoolbox.data.metadata.frames.frames
======================================

.. automodule:: lcvtoolbox.data.metadata.frames.frames
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      CameraDistortionSchema
      CameraMatrixSchema
      FrameMetadata
      FramesMetadata
      GPSPoint
      ImageMetadata
      Path
      PoseRPYSchema
   
   

   
   
   



