lcvtoolbox.vision.image.cropper.Cropper
=======================================

.. currentmodule:: lcvtoolbox.vision.image.cropper

.. autoclass:: Cropper
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__, __str__, __repr__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~Cropper.__init__
      ~Cropper.crop
      ~Cropper.crop_drawn_bbox
      ~Cropper.draw_bbox
      ~Cropper.find_bbox_from_drawn_rectangle
   
   

   
   
   