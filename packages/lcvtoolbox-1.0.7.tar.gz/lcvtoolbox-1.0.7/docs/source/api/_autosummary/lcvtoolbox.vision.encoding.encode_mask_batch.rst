lcvtoolbox.vision.encoding.encode\_mask\_batch
==============================================

.. currentmodule:: lcvtoolbox.vision.encoding

.. autofunction:: encode_mask_batch