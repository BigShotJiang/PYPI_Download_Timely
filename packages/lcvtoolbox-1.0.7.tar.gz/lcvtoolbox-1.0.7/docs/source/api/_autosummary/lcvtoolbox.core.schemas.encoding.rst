lcvtoolbox.core.schemas.encoding
================================

.. automodule:: lcvtoolbox.core.schemas.encoding
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree: .
      :nosignatures:
   
      TypedDict
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      CocoRleDict
      CvatMaskAnnotation
   
   

   
   
   



