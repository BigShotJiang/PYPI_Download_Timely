lcvtoolbox.core.schemas.cvat\_pydantic.Field
============================================

.. currentmodule:: lcvtoolbox.core.schemas.cvat_pydantic

.. autofunction:: Field