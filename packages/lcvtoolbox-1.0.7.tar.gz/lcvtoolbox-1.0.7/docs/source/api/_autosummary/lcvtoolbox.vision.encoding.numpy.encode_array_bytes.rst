lcvtoolbox.vision.encoding.numpy.encode\_array\_bytes
=====================================================

.. currentmodule:: lcvtoolbox.vision.encoding.numpy

.. autofunction:: encode_array_bytes