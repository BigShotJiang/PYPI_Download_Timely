lcvtoolbox.vision.encoding.numpy.encode\_array\_uint8\_scaled
=============================================================

.. currentmodule:: lcvtoolbox.vision.encoding.numpy

.. autofunction:: encode_array_uint8_scaled