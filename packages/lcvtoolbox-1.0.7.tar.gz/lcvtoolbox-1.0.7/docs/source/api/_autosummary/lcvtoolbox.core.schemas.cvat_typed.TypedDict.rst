lcvtoolbox.core.schemas.cvat\_typed.TypedDict
=============================================

.. currentmodule:: lcvtoolbox.core.schemas.cvat_typed

.. autofunction:: TypedDict