lcvtoolbox.integrations.cvat.api
================================

.. automodule:: lcvtoolbox.integrations.cvat.api
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      AnnotatedImage
      CvatApi
      CvatJob
      CvatTask
   
   

   
   
   



.. rubric:: Modules

.. autosummary::
   :toctree: .
   :template: custom-module-template.rst
   :recursive:

   api_requests
   compile_annotated_image
   compile_job
   compile_task

