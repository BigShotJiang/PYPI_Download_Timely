lcvtoolbox.vision.geometry.projection.plan\_road.compute\_points3d
==================================================================

.. currentmodule:: lcvtoolbox.vision.geometry.projection.plan_road

.. autofunction:: compute_points3d