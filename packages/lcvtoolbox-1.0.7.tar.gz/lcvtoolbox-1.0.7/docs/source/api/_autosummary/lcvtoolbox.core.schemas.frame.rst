lcvtoolbox.core.schemas.frame
=============================

.. automodule:: lcvtoolbox.core.schemas.frame
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
   :special-members: __init__

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree: .
      :nosignatures:
   
      Field
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree: .
      :nosignatures:
      :template: custom-class-template.rst
   
      BaseModel
      CameraDistortionSchema
      CameraMatrixSchema
      FrameMetadata
      GPSPoint
      ImageMetadata
      PoseRPYSchema
   
   

   
   
   



