lcvtoolbox.vision.encoding.encode\_mask\_efficient
==================================================

.. currentmodule:: lcvtoolbox.vision.encoding

.. autofunction:: encode_mask_efficient