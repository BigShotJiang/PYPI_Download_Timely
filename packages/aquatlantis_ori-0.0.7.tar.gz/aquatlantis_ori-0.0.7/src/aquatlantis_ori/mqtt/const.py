"""MQTT Constants."""

from typing import Final

PORT: Final[int] = 10883
