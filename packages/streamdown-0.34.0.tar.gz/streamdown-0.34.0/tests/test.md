`EndpointHandler` has several abstract functions that must be implemented. Here, we implement two, one
for `/generate`, and one for `/generate_stream`:

```python


"""
AuthData is a dataclass that represents Authentication data sent from Autoscaler to client requesting a route.
}
"""
from aiohttp import web


```
