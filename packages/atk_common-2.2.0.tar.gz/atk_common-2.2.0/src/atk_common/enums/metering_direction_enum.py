from enum import Enum
 
class MeteringDirection(Enum):
    WITH_METERING = 1
    AGAINST_METERING = 2
