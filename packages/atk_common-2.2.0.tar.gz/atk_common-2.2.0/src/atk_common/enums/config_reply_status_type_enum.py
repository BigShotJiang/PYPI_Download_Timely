from enum import Enum
 
class ConfigReplyStatusType(Enum):
    OK = 0
    ERROR = 1
