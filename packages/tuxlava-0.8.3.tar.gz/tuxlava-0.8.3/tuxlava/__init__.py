# -*- coding: utf-8 -*-
#
# vim: set ts=4
#
# Copyright 2024-present Linaro Limited
#
# SPDX-License-Identifier: MIT

"""
Python library and command line tool for generating LAVA jobs
"""
__version__ = "0.8.3"
