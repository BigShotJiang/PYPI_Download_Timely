from .常用 import 报错信息, xk
from .sqlite import db_sql, db_cj, db_dq, db_xg, db_xr

# 定义外部可访问的内容（非必须，但推荐）
__all__ = ["报错信息", "hello", "xk",'db_sql', 'db_cj', 'db_dq', 'db_xg', 'db_xr']
