__title__ = 'Django Wilayah Indonesia'
__version__ = '0.1.1'
__author__ = 'irfanpule'
