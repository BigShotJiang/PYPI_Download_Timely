# HiWorld

Простая библиотека, которая выводит сообщение "Hello from HiWorld!" при вызове `hiworld.pi()`.
