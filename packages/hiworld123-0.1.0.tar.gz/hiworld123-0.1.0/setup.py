from setuptools import setup, find_packages

setup(
    name='hiworld123',
    version='0.1.0',
    description='Simple HiWorld library',
    author='MaksVavrik',
    packages=find_packages(),
    python_requires='>=3.6',
)
