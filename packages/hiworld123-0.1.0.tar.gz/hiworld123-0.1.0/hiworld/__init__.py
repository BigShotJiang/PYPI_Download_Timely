def pi():
    print("Hello from HiWorld!")
