Changelog
=========


v0.0.1
------

*2024-09-27* -- Initial release. Add pipeline for performing Android APK deploy to development analysis.
