# riskmetrics

A Python library to compute various financial risk metrics such as VaR, CVaR, drawdowns, and more.
