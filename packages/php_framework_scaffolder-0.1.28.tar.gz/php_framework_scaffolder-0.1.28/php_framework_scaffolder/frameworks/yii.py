from .base import BaseFrameworkSetup
from php_framework_detector.core.models import FrameworkType
from typing import List, Optional


class YiiSetup(BaseFrameworkSetup):
    def __init__(self):
        super().__init__(FrameworkType.YII)

    def get_setup_commands(self) -> List[List[str]]:
        return [
            [
                "docker",
                "compose",
                "exec",
                "-w",
                "/app",
                "app",
                "php",
                "yii",
                "migrate",
                "--interactive=0",
                "--no-interaction",
                "--no-ansi",
            ]
        ]

    def get_routes_command(self) -> List[str]:
        raise NotImplementedError("Not implemented")
