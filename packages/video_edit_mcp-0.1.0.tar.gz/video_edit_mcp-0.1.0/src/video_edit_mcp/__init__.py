"""Video Edit MCP Server - A powerful MCP server for video editing operations using MoviePy."""

__version__ = "0.1.0"


from .main import mcp

__all__ = ["mcp"] 