## 0.4.0

* Change Define to take pydantic models as base state rather than base classes, to allow customizing state in factories [ Fixes [#13](https://github.com/DeanLight/stringdale/issues/13)]