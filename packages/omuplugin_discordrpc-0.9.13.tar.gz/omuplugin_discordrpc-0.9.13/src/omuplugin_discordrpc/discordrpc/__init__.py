from .client import DiscordRPC

__all__ = ["DiscordRPC"]
