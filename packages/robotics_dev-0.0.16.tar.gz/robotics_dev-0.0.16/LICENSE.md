# PolyForm Noncommercial License 1.0.0

This project is licensed under the PolyForm Noncommercial License 1.0.0.

- **Noncommercial use** is permitted under the license without additional permissions.
- **Commercial use** is strictly prohibited without obtaining a separate paid commercial license.

Please see the full text of the license here:
[https://polyformproject.org/licenses/noncommercial/1.0.0/](https://polyformproject.org/licenses/noncommercial/1.0.0/)

## Commercial Licensing

To inquire about a commercial license, please contact:

- **Email:** sales@robotics.dev
- **Website:** https://robotics.dev
