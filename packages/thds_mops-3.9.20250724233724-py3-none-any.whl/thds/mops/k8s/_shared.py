from thds.core.log import getLogger

logger = getLogger(__name__[: -len("._shared")])
