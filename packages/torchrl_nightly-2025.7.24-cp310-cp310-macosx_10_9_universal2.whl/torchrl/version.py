__version__ = '2025.7.24'
git_version = 'dabdba6fd2f093d3d1bc97fea9933c1ef3adcbe5'
pytorch_version = '2.9.0.dev20250724'
