#!/usr/bin/env python3
"""This is what happens when you do `python -m minisweagent` or `pipx run mini-swe-agent`."""

from minisweagent.run.mini import app

if __name__ == "__main__":
    app()
