class FixtureError(Exception):
    pass


class ParameterisationError(Exception):
    pass


class CollectionError(Exception):
    pass
