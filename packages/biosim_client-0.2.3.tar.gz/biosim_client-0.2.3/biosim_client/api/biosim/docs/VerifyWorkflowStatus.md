# VerifyWorkflowStatus

## Enum

- `PENDING` (value: `'PENDING'`)

- `IN_PROGRESS` (value: `'IN_PROGRESS'`)

- `COMPLETED` (value: `'COMPLETED'`)

- `FAILED` (value: `'FAILED'`)

- `RUN_ID_NOT_FOUND` (value: `'RUN_ID_NOT_FOUND'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
