# BiosimSimulationRunStatus

## Enum

- `CREATED` (value: `'CREATED'`)

- `QUEUED` (value: `'QUEUED'`)

- `RUNNING` (value: `'RUNNING'`)

- `SKIPPED` (value: `'SKIPPED'`)

- `PROCESSING` (value: `'PROCESSING'`)

- `SUCCEEDED` (value: `'SUCCEEDED'`)

- `FAILED` (value: `'FAILED'`)

- `RUN_ID_NOT_FOUND` (value: `'RUN_ID_NOT_FOUND'`)

- `UNKNOWN` (value: `'UNKNOWN'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
