metatensor-operations
=====================

This package contains the Python *operations* to manipulate metatensor data. Most
users will want to use the ``metatensor`` package instead, which re-export all
the functions from this package.
