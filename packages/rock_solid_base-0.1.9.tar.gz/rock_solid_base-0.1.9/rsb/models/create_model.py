from pydantic import create_model as _cm

create_model = _cm
