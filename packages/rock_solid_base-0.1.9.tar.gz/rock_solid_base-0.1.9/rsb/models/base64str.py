from pydantic.types import Base64Str as _Base64Str


class Base64Str(_Base64Str):
    """Alias for pydantic.Base64Str."""

    pass
