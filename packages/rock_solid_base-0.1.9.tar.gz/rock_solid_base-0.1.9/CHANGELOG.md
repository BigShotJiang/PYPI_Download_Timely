# Changelog

## v0.1.9

- feat: more robust `run_sync` implementation to handle nested environments and httpx scenarios.