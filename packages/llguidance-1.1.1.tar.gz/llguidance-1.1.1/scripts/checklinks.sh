#!/bin/sh

python3 scripts/checklinks.py *.md */*.md parser/src/*/*.md