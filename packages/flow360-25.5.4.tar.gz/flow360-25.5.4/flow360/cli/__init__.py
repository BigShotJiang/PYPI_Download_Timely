"""
Flow360 commandline
"""

from .app import flow360

__all__ = ["flow360"]
