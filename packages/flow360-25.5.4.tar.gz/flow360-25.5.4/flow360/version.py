"""
version
"""

__version__ = "25.5.4"
__solver_version__ = "release-25.5"
