def test_load_optimiser_from_json() -> None:

    # TODO: Load optimiser and test it's the same as the original
    #   - Need to do this at different stages
    #       - Before and after training the model

    pass
