def test__refresh_scaling_advanced() -> None:

    # TODO: Make test

    pass
