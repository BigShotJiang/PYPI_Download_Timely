def test_optimise_sequential_distance_punish() -> None:

    # TODO: Implement

    pass
