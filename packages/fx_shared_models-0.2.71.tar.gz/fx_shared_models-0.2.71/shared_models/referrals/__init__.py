"""
Referral System for tracking customer acquisition through referrals.
""" 