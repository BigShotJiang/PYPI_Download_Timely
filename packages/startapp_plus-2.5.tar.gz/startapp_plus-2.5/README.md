#   Étape d'installation du package

# startapp-plus

Générateur de structure d'application Django améliorée.

## Installation

```bash
pip install startapp-plus

#   Utilisation

startapp-plus mon_de_app
