"""
messages.py
"""

messages_dne = 'THIS FILE IS AUTO GENERATED. DO NOT EDIT!!!'
