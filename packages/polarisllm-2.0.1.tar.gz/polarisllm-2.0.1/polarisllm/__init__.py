"""
PolarisLLM Runtime Engine Package
"""

__version__ = "2.0.1"
__author__ = "PolarisLLM Team"
__email__ = "elon@polariscloud.ai"

from .main import sync_main as main

__all__ = ["main"]
