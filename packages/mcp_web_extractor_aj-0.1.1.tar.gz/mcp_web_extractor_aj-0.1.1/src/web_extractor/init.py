# src/web_extractor/__init__.py
from .server import extract_content, mcp