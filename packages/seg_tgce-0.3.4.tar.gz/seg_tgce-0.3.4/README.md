Framework for handling image segmentation in the context of multiple annotators

This repository contains the train, data mocking and usage procedures
for handling the multiple annotators segmentation problem researched by the
GCPDS (2023).

Official documentation available at: https://seg-tgce.readthedocs.io/en/latest/
