from textual.app import App
from textual.screen import Screen
from textual.containers import (
    Horizontal,
    Vertical,
    VerticalScroll,
)
from textual.widgets import Footer, Markdown, Static
from textual.binding import Binding
from textual.reactive import Reactive
from algoflex._data import questions
from algoflex.attempt import AttemptScreen
from algoflex.custom_widgets import Title, Problem
from algoflex.db import get_db
from random import shuffle
from tinydb import Query

KV = Query()


class StatScreen(Vertical):
    DEFAULT_CSS = """
    Horizontal {
        Vertical {
            background: $boost;
            padding: 1;
            margin: 1 0;
        }
        #passed, #attempts, #best, #difficulty {
            padding-top: 1;
        }
    }
    """

    def compose(self):
        with Horizontal():
            with Vertical():
                yield Static("[b]Passed[/]")
                yield Static("0", id="passed")
            with Vertical():
                yield Static("[b]Attempts[/]")
                yield Static("0", id="attempts")
            with Vertical():
                yield Static("[b]Best time[/]")
                yield Static("...", id="best")
            with Vertical():
                yield Static("[b]Difficulty[/]")
                yield Static("[$primary]Easy[/]", id="difficulty")


class HomeScreen(App):
    BINDINGS = [
        Binding("a", "attempt", "attempt", tooltip="Attempt this question"),
        Binding("n", "next", "next", tooltip="Next question"),
        Binding("p", "previous", "previous", tooltip="Previous question"),
    ]
    DEFAULT_CSS = """
    HomeScreen {
        Problem {
            &>*{ max-width: 100; }
            align: center middle;
            margin-top: 1;
        }
        StatScreen {
            height: 7;
            &>* {max-width: 100; }
            align: center middle;
        }
    }
    """
    problem_id = Reactive(0)
    index = Reactive(0, bindings=True)
    PROBLEMS_COUNT = len(questions.keys())
    PROBLEMS = [i for i in range(PROBLEMS_COUNT)]

    def compose(self):
        problem = questions.get(id, {}).get("markdown", "")
        yield Title()
        with VerticalScroll():
            yield Problem(problem)
            yield StatScreen()
        yield Footer()

    def on_mount(self):
        shuffle(self.PROBLEMS)
        self.problem_id = self.PROBLEMS[self.index]

    def watch_problem_id(self, id):
        stats = get_db()
        s = stats.get(KV.problem_id == id) or {}
        p = questions.get(id, {})
        problem, difficulty = p.get("markdown", ""), p.get("difficulty", "Easy")
        passed, attempts, best = (
            s.get("passed", "0"),
            s.get("attempts", "0"),
            s.get("best", "..."),
        )

        if best != "...":
            mins, secs = divmod(best, 60)
            hrs, mins = divmod(mins, 60)
            best = f"{hrs:02,.0f}:{mins:02.0f}:{secs:02.0f}"

        self.query_one(Problem).query_one(Markdown).update(markdown=problem)
        s_widget = self.query_one(StatScreen)
        s_widget.query_one("#difficulty").update(f"[$primary]{difficulty}[/]")
        s_widget.query_one("#passed").update(f"[$primary]{str(passed)}[/]")
        s_widget.query_one("#attempts").update(f"[$primary]{str(attempts)}[/]")
        s_widget.query_one("#best").update(f"[$primary]{best}[/]")

    def action_attempt(self):
        self.push_screen(AttemptScreen(self.problem_id))

    def action_next(self):
        if self.index + 1 < self.PROBLEMS_COUNT:
            self.index += 1
        self.problem_id = self.PROBLEMS[self.index]

    def action_previous(self):
        if self.index > 0:
            self.index -= 1
        self.problem_id = self.PROBLEMS[self.index]

    def check_action(self, action, parameters):
        if not self.screen.id == "_default":
            if action == "attempt" or action == "next" or action == "previous":
                return False
        if self.index == self.PROBLEMS_COUNT - 1 and action == "next":
            return
        if self.index == 0 and action == "previous":
            return
        return True
