# mypackage_anshita

A Python package that provides text generation and vector embedding features using Ollama models and FAISS. Includes PromptRunner and DocumentEmbedder classes.
