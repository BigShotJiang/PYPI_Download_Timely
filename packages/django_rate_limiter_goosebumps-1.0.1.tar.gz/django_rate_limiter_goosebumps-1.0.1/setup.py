#!/usr/bin/env python3
"""Setup script for django-rate-limiter package."""

from setuptools import setup

# Use setuptools with pyproject.toml configuration
if __name__ == "__main__":
    setup()
