from .jingongo import Jingongo 
__version__ = "0.1.2"  # Version of the Jingongo framework