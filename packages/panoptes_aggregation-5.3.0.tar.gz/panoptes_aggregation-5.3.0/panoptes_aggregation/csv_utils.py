import ast
import pandas
from pandas import json_normalize


def flatten_data(data, json_column='data'):
    json_data = data.pop(json_column)
    # this gets at any nested dicts as well
    flat_data = pandas.DataFrame(json_normalize(json_data))
    # rename the columns so they can be un-flattened later
    flat_data.columns = ['{0}.{1}'.format(json_column, i) for i in flat_data.columns.values]
    other_data = pandas.DataFrame(data)
    return pandas.concat([other_data, flat_data], axis=1)


def unflatten_data(data, json_column='data', renest=True):
    data_dict = {}
    for name, value in data.items():
        if ('{0}.'.format(json_column) in name) and (pandas.notnull(value)):
            key = name.split('{0}.'.format(json_column))[1]
            if isinstance(value, str) and (('{' in value) or ('[' in value)):
                try:
                    nan = None  # noqa
                    false = False  # noqa
                    true = True  # noqa
                    null = None  # noqa
                    data_dict[key] = eval(value)
                except:
                    data_dict[key] = value
            else:
                data_dict[key] = value
    if renest:
        return renest_dict(data_dict)
    else:
        return data_dict


def nested_set(dic, keys, value):
    for key in keys[:-1]:
        dic = dic.setdefault(key, {})
    dic[keys[-1]] = value


def renest_dict(data, seporator='.'):
    output = {}
    for key, value in data.items():
        key_expand = key.split(seporator)
        nested_set(output, key_expand, value)
    return output


def json_non_null(value):
    if pandas.notnull(value):
        try:
            return ast.literal_eval(value)
        except:
            return value
    else:
        return value


def unjson_dataframe(data_frame, json_column='data'):
    for column_name in data_frame.columns.values:
        if ('{0}.'.format(json_column) in column_name):
            data_frame[column_name] = data_frame[column_name].apply(json_non_null)


def move_to_front(list_in, value):
    list_copy = list_in[:]
    if value in list_in:
        list_copy.remove(value)
        list_copy = [value] + list_copy
    return list_copy


def order_columns(data_frame, json_column='data', front=['choice']):
    cols = data_frame.columns.tolist()
    d_cols = [c for c in cols if '{0}.'.format(json_column) in c]
    d_cols.sort()
    for f in front[::-1]:
        d_cols = move_to_front(d_cols, '{0}.{1}'.format(json_column, f))
    order_columns = cols[:-len(d_cols)] + d_cols
    return data_frame[order_columns]


def find_non_built_in_data_types(dictionary):
    '''This seraches the dictionary for non-builtin or np.nan data types,
    then stores the dictionary key location when it occurs'''
    found = {}
    directory = ''

    def search_data(d, found, directory):
        if isinstance(d, dict):
            for key, value in d.items():
                if directory == '':
                    directory_temp = key
                else:
                    directory_temp = directory + '/' + key
                search_data(value, found, directory_temp)
        elif isinstance(d, list):
            for value in d:
                search_data(value, found, directory)
        elif d.__class__.__module__ != 'builtins':
            # Note that nan counts as a builtin data type
            found[directory] = 'Contains non built-in data type: ' + d.__class__.__module__
            directory = ''
    search_data(dictionary, found, directory)
    return found
