FEEDBACK_STRATEGIES = {
    'graph2drange': ['x', 'width'],
    'singleAnswerQuestion': ['answer'],
    'surveySimple': ['choiceIds']
}
