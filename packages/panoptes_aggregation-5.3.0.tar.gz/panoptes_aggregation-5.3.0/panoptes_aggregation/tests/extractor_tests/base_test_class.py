import copy
import unittest
import json
import numpy as np
import urllib
from panoptes_aggregation.extractors.utilities import annotation_by_task
from panoptes_aggregation.append_version import append_version
from panoptes_aggregation.csv_utils import find_non_built_in_data_types

try:
    import flask
    OFFLINE = False
except ImportError:
    OFFLINE = True


def round_dict(dictionary, ndigits):
    if isinstance(dictionary, dict):
        return {key: round_dict(value, ndigits) for key, value in dictionary.items()}
    elif isinstance(dictionary, list):
        return [round_dict(value, ndigits) for value in dictionary]
    elif isinstance(dictionary, float):
        return round(dictionary, ndigits)
    return dictionary


def ExtractorTest(
    function,
    classification,
    expected,
    name,
    blank_extract={},
    kwargs={},
    test_type='assertDictEqual',
    test_name=None,
    round=None
):
    class ExtractorTest(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None

        def shortDescription(self):
            return '{0}: {1}'.format(name, self._testMethodDoc)

        def assertTestType(self, result, expected):
            if round is not None:
                result = round_dict(result, round)
                expected = round_dict(expected, round)
            if test_type == 'assertDictEqual':
                self.assertDictEqual(dict(result), expected)
            else:
                self.__getattribute__(test_type)(result, expected)

        def test_extract(self):
            '''Test the offline extract function'''
            result = function(annotation_by_task(classification), **kwargs)
            append_version(expected)
            self.assertTestType(result, expected)

        def test_extract_data_types(self):
            '''Test the dictionary only contains built-in or nan data types'''
            result = function(annotation_by_task(classification), **kwargs)
            non_built_in_locations = find_non_built_in_data_types(result)
            expected = {}
            self.assertDictEqual(non_built_in_locations, expected)

        def test_blank(self):
            '''Test a blank annotation'''
            blank = {'annotations': {'ST': []}}
            kwargs_blank = copy.deepcopy(kwargs)
            kwargs_blank['task'] = 'ST'
            result = function(blank, **kwargs_blank)
            append_version(blank_extract)
            self.assertTestType(result, blank_extract)

        @unittest.skipIf(OFFLINE, 'Installed in offline mode')
        def test_request(self):
            '''Test the online extract function'''
            request_kwargs = {
                'data': json.dumps(annotation_by_task(classification)),
                'content_type': 'application/json'
            }
            app = flask.Flask(__name__)
            append_version(expected)
            if len(kwargs) > 0:
                url_params = '?{0}'.format(urllib.parse.urlencode(kwargs))
            else:
                url_params = ''
            with app.test_request_context(url_params, **request_kwargs):
                result = function(flask.request)
                self.assertTestType(result, expected)

    if test_name is None:
        test_name = '_'.join(name.split())
    ExtractorTest.__name__ = test_name
    ExtractorTest.__qualname__ = test_name
    return ExtractorTest


def TextExtractorTest(
    function,
    classification,
    expected,
    name,
    blank_extract={},
    kwargs={},
    test_name=None
):
    class TextExtractorTest(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None

        def shortDescription(self):
            return '{0}: {1}'.format(name, self._testMethodDoc)

        def assertTextExtractor(self, result, expected):
            for i in expected.keys():
                with self.subTest(i=i):
                    self.assertIn(i, result)
                    if isinstance(expected[i], dict):
                        for j in expected[i].keys():
                            with self.subTest(i=j):
                                self.assertIn(j, result[i])
                                if j == 'slope':
                                    np.testing.assert_allclose(result[i][j], expected[i][j], atol=1e-5)
                                else:
                                    self.assertEqual(result[i][j], expected[i][j])

        def test_extract(self):
            '''Test the offline extract function'''
            result = function(annotation_by_task(classification), **kwargs)
            append_version(expected)
            self.assertTextExtractor(result, expected)

        def test_extract_data_types(self):
            '''Test the dictionary only contains built-in or nan data types'''
            result = function(annotation_by_task(classification), **kwargs)
            non_built_in_locations = find_non_built_in_data_types(result)
            expected = {}
            self.assertDictEqual(non_built_in_locations, expected)

        def test_blank(self):
            '''Test a blank annotation'''
            blank = {'annotations': {'ST': []}}
            kwargs_blank = copy.deepcopy(kwargs)
            kwargs_blank['task'] = 'ST'
            result = function(blank, **kwargs_blank)
            append_version(blank_extract)
            self.assertDictEqual(dict(result), blank_extract)

        @unittest.skipIf(OFFLINE, 'Installed in offline mode')
        def test_request(self):
            '''Test the online extract function'''
            request_kwargs = {
                'data': json.dumps(annotation_by_task(classification)),
                'content_type': 'application/json'
            }
            app = flask.Flask(__name__)
            append_version(expected)
            if len(kwargs) > 0:
                url_params = '?{0}'.format(urllib.parse.urlencode(kwargs))
            else:
                url_params = ''
            with app.test_request_context(url_params, **request_kwargs):
                result = function(flask.request)
                self.assertTextExtractor(result, expected)

    if test_name is None:
        test_name = '_'.join(name.split())
    TextExtractorTest.__name__ = test_name
    TextExtractorTest.__qualname__ = test_name
    return TextExtractorTest


def TextExtractorBadKeywordTest(
    function,
    classification,
    expected,
    name,
    test_name=None
):
    class TextExtractorTestBadKeyword(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None

        def shortDescription(self):
            return '{0}: {1}'.format(name, self._testMethodDoc)

        def test_bad_keyword(self):
            '''Test error is raised if a bad keyword is used for dot_freq'''
            with self.assertRaises(ValueError):
                function(annotation_by_task(classification), dot_freq='bad_keyword')

    if test_name is None:
        test_name = '_'.join(name.split())
    TextExtractorTestBadKeyword.__name__ = test_name
    TextExtractorTestBadKeyword.__qualname__ = test_name
    return TextExtractorTestBadKeyword
