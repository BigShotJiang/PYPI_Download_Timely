import{E as o}from"./index-B3TsnAiv.js";const n=o;export{n as errorComponent};
