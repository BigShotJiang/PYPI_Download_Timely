from django.apps import AppConfig


class DatamigrationConfig(AppConfig):
    name = "datamigration"
