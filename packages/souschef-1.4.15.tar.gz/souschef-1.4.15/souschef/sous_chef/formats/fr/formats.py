# https://docs.djangoproject.com/en/1.10/ref/templates/builtins/#std:templatefilter-date
DATE_FORMAT = "l j F Y"
SHORT_DATE_FORMAT = "j F Y"
