from django.apps import AppConfig


class MealConfig(AppConfig):
    name = "meal"
