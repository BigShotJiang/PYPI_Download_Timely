class BlocksState:
    automations = []

    def __init__(self):
        self.automations = []
