"""
Shared pytest fixtures and configuration.
"""

import pytest

# Add any shared fixtures here that would be needed across multiple test modules