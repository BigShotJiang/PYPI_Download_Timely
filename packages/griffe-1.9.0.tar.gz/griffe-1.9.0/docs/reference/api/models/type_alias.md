# Type Alias

::: griffe.TypeAlias
