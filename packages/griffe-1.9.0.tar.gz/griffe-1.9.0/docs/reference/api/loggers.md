# Loggers

## **Main API**

::: griffe.logger

::: griffe.get_logger

::: griffe.Logger

::: griffe.LogLevel

::: griffe.DEFAULT_LOG_LEVEL
    options:
        annotations_path: full

## **Advanced API**

::: griffe.patch_loggers
