# Finder

## **Advanced API**

::: griffe.ModuleFinder

::: griffe.Package

::: griffe.NamespacePackage

## **Types**

::: griffe.NamePartsType

::: griffe.NamePartsAndPathType
