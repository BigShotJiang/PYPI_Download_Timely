# Exceptions

::: griffe.GriffeError

::: griffe.LoadingError

::: griffe.NameResolutionError

::: griffe.UnhandledEditableModuleError

::: griffe.UnimportableModuleError

::: griffe.AliasResolutionError

::: griffe.CyclicAliasError

::: griffe.LastNodeError

::: griffe.RootNodeError

::: griffe.BuiltinModuleError

::: griffe.ExtensionError

::: griffe.ExtensionNotLoadedError

::: griffe.GitError
