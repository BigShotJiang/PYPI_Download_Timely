# Helpers

::: griffe.TmpPackage

::: griffe.temporary_pyfile

::: griffe.temporary_pypackage

::: griffe.temporary_visited_module

::: griffe.temporary_visited_package

::: griffe.temporary_inspected_module

::: griffe.temporary_inspected_package

::: griffe.vtree

::: griffe.htree

::: griffe.module_vtree
