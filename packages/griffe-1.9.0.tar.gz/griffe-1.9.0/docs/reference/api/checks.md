# API checks

::: griffe.find_breaking_changes

::: griffe.ExplanationStyle

::: griffe.Breakage

::: griffe.BreakageKind

::: griffe.AttributeChangedTypeBreakage

::: griffe.AttributeChangedValueBreakage

::: griffe.ClassRemovedBaseBreakage

::: griffe.ObjectChangedKindBreakage

::: griffe.ObjectRemovedBreakage

::: griffe.ParameterAddedRequiredBreakage

::: griffe.ParameterChangedDefaultBreakage

::: griffe.ParameterChangedKindBreakage

::: griffe.ParameterChangedRequiredBreakage

::: griffe.ParameterMovedBreakage

::: griffe.ParameterRemovedBreakage

::: griffe.ReturnChangedTypeBreakage
