# Extensions

## **Main API**

::: griffe.load_extensions

::: griffe.Extension

## **Advanced API**

::: griffe.Extensions

## **Types**

::: griffe.LoadableExtensionType

## **Builtin extensions**

::: griffe.builtin_extensions

::: griffe.DataclassesExtension
    options:
        inherited_members: false
