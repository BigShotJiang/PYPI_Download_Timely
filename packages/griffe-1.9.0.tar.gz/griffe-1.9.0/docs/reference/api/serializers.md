# Serializers

## **Main API**

See the [`as_json()`][griffe.Object.as_json] and [`from_json()`][griffe.Object.from_json] methods of objects.

## **Advanced API**

::: griffe.JSONEncoder

::: griffe.json_decoder
