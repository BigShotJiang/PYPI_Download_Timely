import unittest
import inspect
import files_sdk
from tests.base import TestBase
from files_sdk.models import Action
from files_sdk import action

class ActionTest(TestBase):
    pass 
    # Instance Methods

    # Static Methods
if __name__ == '__main__':
    unittest.main()