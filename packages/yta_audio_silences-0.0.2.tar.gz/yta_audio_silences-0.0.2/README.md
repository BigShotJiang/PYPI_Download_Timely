# Youtube Autonomous Audio Silences Module

The Audio Silences module.

Please, check the 'pyproject.toml' file to see the dependencies.