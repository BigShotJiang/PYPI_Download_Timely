"""Importing Booksources from booksources in resource directory"""

from downitall.resources.animesources import Animesources
from downitall.resources.booksources import Booksources
from downitall.resources.mangasources import Mangasources
from downitall.resources.musicsources import Musicsources
from downitall.resources.streamsources import Streamsources
from downitall.resources.tvsources import Tvsources
