from .intent_patterns import INTENT_PATTERNS
from .task_patterns import TASK_PATTERNS

__all__ = ["INTENT_PATTERNS", "TASK_PATTERNS"]