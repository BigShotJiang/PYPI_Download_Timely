# src/easyclimate/version.py
__version__ = "2025.8.0"
