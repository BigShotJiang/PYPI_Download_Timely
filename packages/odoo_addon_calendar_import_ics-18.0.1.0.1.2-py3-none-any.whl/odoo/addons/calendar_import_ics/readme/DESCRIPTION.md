This module adds a new wizard that allows you to import .ics files into
odoo calendar, importing events and the following attributes:

- Summary
- Start Date
- End Date
- UID
