To use this module, follow these steps:

1.  Navigate to the Calendar App.
2.  Go to Configuration.
3.  Select Import ICS File.

When importing, you have two options:

- Specify start and end dates to import events occurring within that
  range.
- Leave the date fields empty to import all events from the entire file.
