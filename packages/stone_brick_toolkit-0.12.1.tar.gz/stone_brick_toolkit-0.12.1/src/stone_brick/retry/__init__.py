from stone_brick.retry.utils import stop_after_attempt_may_inf

__all__ = ["stop_after_attempt_may_inf"]
