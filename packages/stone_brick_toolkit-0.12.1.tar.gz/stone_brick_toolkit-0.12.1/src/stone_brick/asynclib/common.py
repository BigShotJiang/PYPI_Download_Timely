class NoResult(Exception):
    pass
