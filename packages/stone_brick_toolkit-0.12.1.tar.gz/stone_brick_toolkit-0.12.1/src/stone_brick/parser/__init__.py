from stone_brick.parser.xml import flat_xml_tags_from_text

__all__ = ["flat_xml_tags_from_text"]
