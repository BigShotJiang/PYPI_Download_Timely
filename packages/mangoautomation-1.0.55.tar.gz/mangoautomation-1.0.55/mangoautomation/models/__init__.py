# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description:# @Time   : 2023-09-09 23:17
# @Author : 毛鹏
import sys

from ..models._ui_model import ElementModel, ElementResultModel


__all__ = [
    'ElementModel',
    'ElementResultModel',
]
