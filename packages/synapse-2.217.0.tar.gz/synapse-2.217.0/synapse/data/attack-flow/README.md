The file `attack-flow-schema-2.0.0.json` in this directory is a heavily modified version of
https://github.com/center-for-threat-informed-defense/attack-flow/blob/main/stix/attack-flow-schema-2.0.0.json.
The open source license for the original is included in this directory as LICENSE.txt.
