"""
ユーティリティ機能
"""

from . import types

__all__ = [
    "types",
]
