"""
エラー情報データベース機能
"""

from .error_database import ErrorDatabase

__all__ = [
    "ErrorDatabase",
]
