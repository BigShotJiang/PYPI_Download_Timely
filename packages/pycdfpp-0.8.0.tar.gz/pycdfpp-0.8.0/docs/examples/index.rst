PyCDFpp examples gallery
========================

Browse example folder on MyBinder:

.. image:: https://mybinder.org/badge_logo.svg
   :target: https://mybinder.org/v2/gh/SciQLop/cdfpp/main?labpath=docs/examples

Browse example folder on Google Colab:

.. image:: https://colab.research.google.com/assets/colab-badge.svg
   :target: https://colab.research.google.com/github/SciQLop/cdfpp

.. nbgallery::
   :glob:

   ./Loading_CDF
   ./Creating_CDF