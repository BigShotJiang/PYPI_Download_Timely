.. include:: ../README.rst

.. toctree::
   :caption: Table of Contents
   :hidden:

   cli-usage
   api-usage
   api-usage-advanced
   api-usage-graphql
   cli-examples
   api-objects
   api/gitlab
   cli-objects
   api-levels
   changelog
   release-notes
   faq


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
