# Features Roadmap

[ ] Add auto-suggestions for colors in color screen
[ ] Add constructor argument for additional art directories
[ ] Create mode for stretching gradients
[X] Add method to add custom directories for art files
[X] Also add some help to color screen
[X] Add built-in pattern picker to Coloromatic class
[X] Add floating text inside Coloromatic for demo
[X] Make custom string screen remember last entry
[X] Prevent randomize button in demo selecting same value
[X] Add help back in about width and height
[X] Add size display back in
[X] Tiling should set width and height to 1fr if they are empty (only for demo)
[X] Add setting for Coloromatic background in demo
