"""
.. include:: ./README.md
"""

from netapp_ontap.error import NetAppRestError
from netapp_ontap.host_connection import HostConnection
from netapp_ontap.response import NetAppResponse

__version__ = "9.17.1.0"
