from .modeling_wav2vec2 import (
    GaudiWav2Vec2SdpaAttention,
    _gaudi_wav2vec2_compute_mask_indices,
    _gaudi_wav2vec2_mask_hidden_states,
    _gaudi_wav2vec2_sample_negative_indices,
    gaudi_wav2vec2_encoder_forward,
    gaudi_wav2vec2_forward,
    gaudi_wav2vec2_tdnnlayer_forward,
    gaudi_wav2vec2forctc_forward,
)
