from .modeling_owlvit import (
    gaudi_owlvitclasspredictionhead_forward,
)
