from .modeling_vision_encoder_decoder import (
    gaudi_VisionEncoderDecoderModel_prepare_inputs_for_generation,
)
