from .configuration_decilm import DeciLMConfig
from .modeling_decilm import (
    DeciLMForCausalLM,
)
