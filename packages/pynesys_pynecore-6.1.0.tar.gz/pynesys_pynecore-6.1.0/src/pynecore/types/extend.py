from .base import IntEnum


class Extend(IntEnum):
    ...