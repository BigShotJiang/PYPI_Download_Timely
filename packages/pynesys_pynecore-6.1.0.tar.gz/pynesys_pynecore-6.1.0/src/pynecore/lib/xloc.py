from ..types.xloc import XLoc

bar_index = XLoc('bar_index')
bar_time = XLoc('bar_time')
