from ..types.extend import Extend

both: Extend = Extend()
left: Extend = Extend()
none: Extend = Extend()
right: Extend = Extend()