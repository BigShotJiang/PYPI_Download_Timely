from ..types.yloc import YLoc

price = YLoc('price')
abovebar = YLoc('abovebar')
belowbar = YLoc('belowbar')
