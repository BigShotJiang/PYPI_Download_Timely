This module allow a user to have Access all OUs' accounting,
without having to add OUs in user setting.

Example use case, a shared accounting team under an OU
but need to work on accounting documents of all OUs.
