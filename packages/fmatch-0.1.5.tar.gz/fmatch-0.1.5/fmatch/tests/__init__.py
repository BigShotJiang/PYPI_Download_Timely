"""
This is __init__.py file for tests of fmatch
"""
