

def myadd(x: int, y: int) -> int:
    return x + y
    
def mysub(x: int, y: int) -> int:
    return x - y