# -*- coding: utf-8 -*-
# __init__.py

"""
Refactored McSAS implementation
"""

__version__ = "1.0.6"
