# 1.0

Initial release

Support for the following Objectscript class components:
- Parameter
- Property
- Method
- ClassMethod
- Query
- Trigger
- Projection
- ForeignKey
- Index
- XData
- Storage
