# Trigger

::: pyobjectscript_gen.cls.Trigger

