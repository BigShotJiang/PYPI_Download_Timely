# MethodArgument

::: pyobjectscript_gen.cls.MethodArgument

