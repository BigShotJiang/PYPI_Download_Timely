# ClassMethod

::: pyobjectscript_gen.cls.ClassMethod

