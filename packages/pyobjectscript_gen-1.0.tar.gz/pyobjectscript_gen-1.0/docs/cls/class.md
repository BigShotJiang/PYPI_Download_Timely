# Class

::: pyobjectscript_gen.cls.Class

