# Parameter

::: pyobjectscript_gen.cls.Parameter

