# ForeignKey

::: pyobjectscript_gen.cls.ForeignKey

