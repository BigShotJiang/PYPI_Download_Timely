# Property

::: pyobjectscript_gen.cls.Property

