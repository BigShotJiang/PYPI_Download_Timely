# Method

::: pyobjectscript_gen.cls.Method

