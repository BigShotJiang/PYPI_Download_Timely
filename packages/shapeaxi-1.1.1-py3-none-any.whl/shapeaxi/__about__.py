# SPDX-FileCopyrightText: 2023-present FlorianDAVAUX <91245912+FlorianDAVAUX@users.noreply.github.com>
#
# SPDX-License-Identifier: MIT
__version__ = "1.1.1"
