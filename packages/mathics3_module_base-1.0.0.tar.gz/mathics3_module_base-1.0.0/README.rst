Base module for the Mathics3 Module system.

The Mathics3 Module system is the mechanism for writing
Mathics3 Packages in Python.
