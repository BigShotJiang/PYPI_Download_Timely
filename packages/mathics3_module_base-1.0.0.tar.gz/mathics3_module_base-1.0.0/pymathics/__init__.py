"""Base module for the Mathic3 Module system.

The Mathics3 Module system is the mechanism Mathics3 uses to get
Package extensions to Mathics3 that are written Python.
"""

from pymathics.version import __version__
