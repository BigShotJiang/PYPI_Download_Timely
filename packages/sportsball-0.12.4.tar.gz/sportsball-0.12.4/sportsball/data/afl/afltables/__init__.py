"""The AFLTables AFL data sportsball module."""
