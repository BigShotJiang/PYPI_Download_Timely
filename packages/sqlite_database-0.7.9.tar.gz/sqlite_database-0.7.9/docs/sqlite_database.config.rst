sqlite\_database.config module
==============================

.. automodule:: sqlite_database.config
   :members:
   :undoc-members:
   :show-inheritance:
