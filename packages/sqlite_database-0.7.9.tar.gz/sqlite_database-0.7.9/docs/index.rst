.. sqlite_database documentation master file, created by
   sphinx-quickstart on Wed Apr 26 14:53:11 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

sqlite-database Documentation
=============================

SQLite Database
---------------

.. toctree::
   :maxdepth: 4
   :caption: SQLite Database

   SimpleGuide
   ModelAPI


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
