sqlite\_database.locals module
==============================

.. automodule:: sqlite_database.locals
   :members:
   :undoc-members:
   :show-inheritance:
