import styled from "styled-components";

export const EditableTextFieldFormContainer = styled.div`
  form > div {
    margin-bottom: 1em;
  }

  button + button {
    margin-left: 1em;
  }
`;
