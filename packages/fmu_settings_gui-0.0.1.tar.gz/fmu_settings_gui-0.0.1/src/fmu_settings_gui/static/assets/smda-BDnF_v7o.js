import{j as o,P as n}from"./index-B17U-SAQ.js";const r=function(){return o.jsx(n,{children:"SMDA"})};export{r as component};
