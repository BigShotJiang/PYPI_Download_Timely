import{j as n,P as o}from"./index-B17U-SAQ.js";const p=function(){return n.jsx(o,{children:"Mappings"})};export{p as component};
