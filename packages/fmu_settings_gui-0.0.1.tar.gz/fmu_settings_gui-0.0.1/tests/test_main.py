"""Tests for the __main__ module."""


def test_main_invocation() -> None:
    """Tests that the main entry point runs."""
