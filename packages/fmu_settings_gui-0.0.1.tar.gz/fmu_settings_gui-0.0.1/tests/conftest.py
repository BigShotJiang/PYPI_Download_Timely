"""Root configuration for pytest."""
