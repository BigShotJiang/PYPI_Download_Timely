"""
Jetson CLI - Command-line interface for NVIDIA Jetson setup and configuration
"""

__version__ = "0.4.0"
__author__ = "Jetson Setup Team"
__email__ = "support@jetson-setup.com"
__description__ = "Command-line interface for NVIDIA Jetson setup and configuration"