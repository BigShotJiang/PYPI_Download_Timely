from bluer_ai.modules.terraform.functions import (
    lxde,
    mac,
    poster,
    rpi,
    signature,
    terraform,
    ubuntu,
)
