from bluer_ai import env


def test_bluer_ai_env():
    assert True
