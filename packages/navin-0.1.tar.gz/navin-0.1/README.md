# navin

A simple Python package to start a local server and serve a styled HTML page.

## Installation

```bash
pip install .
```

## Usage

Start the local server:

```bash
navin runserver
```

Visit [http://localhost:2401](http://localhost:2401) to view the page.

## Version

0.1 