Debemos indicar los proveedores que son no residentes, en la ficha de la
empresa:

1.  Vaya a *Contactos*.
2.  Entrando al correspondiente, en la pestaña "Ventas y compras",
    seleccione en la posición fiscal la "Retención IRPF No residentes"
    que le corresponda.
3.  Al crear facturas para dicho contacto, se mapearán los impuestos
    necesarios siempre que la línea de la factura tenga el producto
    informado con el impuesto nacional adecuado.
