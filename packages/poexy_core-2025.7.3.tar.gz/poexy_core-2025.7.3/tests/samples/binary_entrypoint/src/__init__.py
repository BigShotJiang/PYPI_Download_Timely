def main():
    print(42)


if __name__ == "__main__":
    main()
