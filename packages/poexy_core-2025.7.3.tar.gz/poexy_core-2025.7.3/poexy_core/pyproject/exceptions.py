class PyProjectError(Exception):
    pass
