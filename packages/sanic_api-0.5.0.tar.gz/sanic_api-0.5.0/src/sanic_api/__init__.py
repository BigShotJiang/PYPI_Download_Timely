from sanic_api.logger.extension import LoggerExtend

__version__ = "0.5.0"
