#  Created byMartin.cz
#  Copyright (c) Martin Strohalm. All rights reserved.

from .. drawing import Graphics


class Glyph(Graphics):
    """Abstract base class for simple graphical entities."""
    
    pass
