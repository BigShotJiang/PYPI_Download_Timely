from .cli import main

main.start()
