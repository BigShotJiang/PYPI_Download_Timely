"""
Test package for django-smart-ratelimit.

This package contains all the tests for the rate limiting functionality.
"""
