"""Generated migrations for Django Smart Ratelimit."""
