"""
TODO:
 - cfg naming
 - adapters for dataclasses / namedtuples / user objects (as configured)
 - mro-merge ObjectMetadata
 - key ordering override - like slice, -1 means last
"""
