"""Version information for folder2md4llms."""

__version__ = "0.5.0"
__version_tuple__ = (0, 5, 0)
