﻿flexfloat.ListBoolBitArray
==========================

.. currentmodule:: flexfloat

.. autoclass:: ListBoolBitArray