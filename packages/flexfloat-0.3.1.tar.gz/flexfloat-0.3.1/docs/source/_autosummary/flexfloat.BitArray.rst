﻿flexfloat.BitArray
==================

.. currentmodule:: flexfloat

.. autoclass:: BitArray