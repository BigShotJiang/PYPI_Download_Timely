VERSION = "0.2.0"

# this will be templated during the build
GIT_COMMIT = "dbb3e71028ba0573b07f6a39bee4a4ff7f39c486"
