def test_imports():
    from pytest_jubilant import pack, get_resources

    assert pack and get_resources
