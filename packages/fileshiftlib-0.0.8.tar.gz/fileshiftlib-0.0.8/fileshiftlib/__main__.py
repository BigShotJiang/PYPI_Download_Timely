from .fileshift import SFTP

def main():
    print("SFTP client Python package that uses paramiko library.")

if __name__ == "__main__":
    main()
