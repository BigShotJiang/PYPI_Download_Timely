from edri.dataclass.event import Event, event


@event
class Client(Event):
    pass
