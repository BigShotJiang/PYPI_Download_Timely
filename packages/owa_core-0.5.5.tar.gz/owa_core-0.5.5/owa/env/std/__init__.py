"""
Standard environment components for Open World Agents.

This module provides basic system components like clock functionality
using the entry points-based discovery system.
"""
