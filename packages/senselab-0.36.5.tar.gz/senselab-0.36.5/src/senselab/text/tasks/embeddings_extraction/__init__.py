"""This module provides the API for the senselab text embeddings extraction."""

from .api import extract_embeddings_from_text  # noqa: F401
