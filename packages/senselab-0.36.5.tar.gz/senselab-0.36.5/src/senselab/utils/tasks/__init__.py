"""This module provides the API of the senselab utils data structures."""
