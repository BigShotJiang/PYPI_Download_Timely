""".. include:: ./doc.md"""  # noqa: D415

from .api import synthesize_texts  # noqa: F401
