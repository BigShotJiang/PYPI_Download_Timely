"""Top level file exposing speaker diarization utility functions."""

from .utils import calculate_diarization_error_rate  # noqa: F401
