"""Test suite for point cloud sketching."""
