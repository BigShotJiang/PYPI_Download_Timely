__version__ = "1.7.11"
__release_date__ = "26-Jul-2025"
__author__ = "Agus Makmun (Summon Agus)"
__author_email__ = "summon.agus@gmail.com"
