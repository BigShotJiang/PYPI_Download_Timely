## cdf 

### Added

- [alpha] Support dumping `extraction-pipeline`.

## templates

No changes.