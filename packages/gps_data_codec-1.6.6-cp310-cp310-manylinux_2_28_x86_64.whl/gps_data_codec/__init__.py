from .gps_data_codec import *

__doc__ = gps_data_codec.__doc__
if hasattr(gps_data_codec, "__all__"):
    __all__ = gps_data_codec.__all__