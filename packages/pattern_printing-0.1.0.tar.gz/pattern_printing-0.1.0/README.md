# Pattern
This is simple package to print a pattern 

# Installation 

install it using pip:
pip install Pattern

from file1 import (pyramid,right_angle,left_angle)

# right_angle