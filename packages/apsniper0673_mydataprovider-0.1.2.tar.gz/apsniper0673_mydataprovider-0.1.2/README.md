# mystockdataprovider

모듈 하이라키

Most Independent
  - odi
  - utility에 있는 모든 모듈
    - crawler
    - db 등등

Hierarchy
  - frame > raw > ppd > rdf > rdp > sdp
  - provider > krx / naver > wdp > rdp > sdp

