**2.0.1 - 7/25/2025**

  - Bugfix: fix broken doc stages in Jenkins pipeline

**2.0.0 - 7/24/2025**

  - Clean up and better document Make files

**1.1.2 - 7/16/2025**

  - Bugfix: typo in extra-index-url

**1.1.1 - 7/16/2025**

  - Bugfix: fix broken pip install --dry-run call in get_vbu_version.py

**1.1.0 - 7/15/2025**

  - Allow for pinning in other repos

**1.0.0 - 7/8/2025**

  - Initial major release

**0.1.0 - 7/8/2025**

  - Initial rc release
