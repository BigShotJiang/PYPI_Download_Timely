"""Test modules for ADT system."""
