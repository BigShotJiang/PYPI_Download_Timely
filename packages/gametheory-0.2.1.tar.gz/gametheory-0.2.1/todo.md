# To-Do list

- [ ] Stable Matching: Implement the Gale-Shapley algorithm
- [ ] Voting: Implement the Borda Count method
- [ ] Voting: Implement the Plurality method
- [ ] Voting: Implement the Instant Runoff Voting method
- [ ] Auction: Implement the Vickrey auction