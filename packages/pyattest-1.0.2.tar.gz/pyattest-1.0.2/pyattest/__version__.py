VERSION = (1, 0, 2)

__version__ = ".".join(map(str, VERSION))
