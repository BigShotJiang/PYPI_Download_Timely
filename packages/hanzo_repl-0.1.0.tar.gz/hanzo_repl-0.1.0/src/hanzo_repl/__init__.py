"""Hanzo REPL - Interactive environment for testing MCP tools and AI integration."""

__version__ = "0.1.0"