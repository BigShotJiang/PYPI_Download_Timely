#ifndef EIGEN_SPLINES_MODULE_H
#error "Please include unsupported/Eigen/Splines instead of including headers inside the src directory directly."
#endif
