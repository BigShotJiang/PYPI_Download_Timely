# polsartools/__version__.py
__version__ = "0.8"
