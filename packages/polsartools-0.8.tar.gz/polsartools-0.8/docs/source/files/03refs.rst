References
----------

References of the research works used in this package. 

.. :cite:`mandal2020dual`

.. .. bibliography:: ref.bib
..    :cited:

.. bibliography:: ref.bib
   :all:
   :style: plain