Full-pol H-alpha plot (``halpha_plot_fp``)
===========================================

.. autofunction:: polsartools.halpha_plot_fp
   :noindex:
