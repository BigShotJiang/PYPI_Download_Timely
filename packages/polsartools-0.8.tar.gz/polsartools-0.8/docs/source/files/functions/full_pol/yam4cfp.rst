Yamaguchi 4-Component decomposition (``yam4cfp``)
=================================================

.. autofunction:: polsartools.yam4cfp
   :noindex: