Non-negative Eigen Value decomposition (``nnedfp``)
===================================================

.. autofunction:: polsartools.nnedfp
   :noindex:
