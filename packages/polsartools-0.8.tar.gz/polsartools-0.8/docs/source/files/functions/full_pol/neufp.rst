Neumann decomposition (``neufp``)
==================================

.. autofunction:: polsartools.neufp
   :noindex:
