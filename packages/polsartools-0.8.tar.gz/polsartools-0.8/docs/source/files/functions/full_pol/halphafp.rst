H/A/α Decomposition (``halphafp``)
==================================

.. autofunction:: polsartools.halphafp
   :noindex:
