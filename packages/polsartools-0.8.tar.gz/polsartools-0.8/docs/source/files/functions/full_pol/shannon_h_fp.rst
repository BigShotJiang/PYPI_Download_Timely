Shannon entropy (``shannon_h_fp``)
==================================

.. autofunction:: polsartools.shannon_h_fp
   :noindex: