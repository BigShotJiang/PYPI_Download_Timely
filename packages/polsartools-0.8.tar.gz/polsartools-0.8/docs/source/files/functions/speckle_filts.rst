.. Polarimetric speckle filters
.. =============================

Refined-Lee filter (``rlee``)
------------------------------
.. autofunction:: polsartools.rlee
   :noindex:


Boxcar filter (``boxcar``)
--------------------------
.. autofunction:: polsartools.boxcar
   :noindex:

