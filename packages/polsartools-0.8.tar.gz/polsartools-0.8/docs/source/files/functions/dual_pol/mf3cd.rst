Model Free 3-Component decomposition for dual-co-pol (``mf3cd``)
================================================================

.. autofunction:: polsartools.mf3cd
   :noindex:
