Dual-pol H-alpha plot (``halpha_plot_dp``)
===========================================

.. autofunction:: polsartools.halpha_plot_dp
   :noindex:
