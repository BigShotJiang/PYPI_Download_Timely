🔸RADARSAT-2
=============


Full-pol (``rs2_fp``)
---------------------

The `rs2_fp` function extracts matrix elements (S2, C3 or T3) from the given RADARSAT-2 folder and saves them into respective directories (S2, C3 or T3).



.. autofunction:: polsartools.rs2_fp
   :noindex:
