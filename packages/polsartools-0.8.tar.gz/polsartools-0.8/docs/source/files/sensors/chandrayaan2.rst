🔸Chandrayaan-II (DFSAR)
========================



Full-pol (``chyaan2_fp``)
-------------------------

The `chyaan2_fp` function extracts matrix elements (S2, C3 or T3) from the given Chandrayaan-II folder and saves them into respective directories (S2, C3 or T3).

.. autofunction:: polsartools.chyaan2_fp
   :noindex:

