🔸RISAT-1A
============


Level 1.1 (``risat_l11``)
--------------------------
The `risat_l11` function extracts Sxy/C2 matrix elements from the given RISAT product folder and saves them into a directory.

.. autofunction:: polsartools.risat_l11
   :noindex:

