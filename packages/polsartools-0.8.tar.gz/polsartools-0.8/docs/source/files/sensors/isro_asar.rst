🔸ISRO ASAR
============


RSLC (``isro_asar``)
---------------------
The `isro_asar` function extracts S2/C3/C4/T3 matrix elements from the given ASAR RSLC `.h5` file and saves them into a directory.

.. autofunction:: polsartools.isro_asar
   :noindex:

