============
Changelog
============

.. changelog::
    :changelog-url: https://github.com/bj00rn/pysaleryd/releases/
    :github: https://github.com/bj00rn/pysaleryd/releases/
    :pypi: https://pypi.org/project/pysaleryd/
