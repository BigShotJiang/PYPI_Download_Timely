from typedlogic.integrations.solvers.clingo.clingo_solver import ClingoSolver

__all__ = [
    "ClingoSolver",
]
