from typedlogic.integrations.solvers.souffle.souffle_solver import SouffleSolver

__all__ = ["SouffleSolver"]
