from .rdf import Triple

__all__ = ["Triple"]
