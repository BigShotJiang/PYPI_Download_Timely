from typedlogic.integrations.frameworks.pydantic.pydantic_bridge import FactBaseModel

__all__ = [
    "FactBaseModel",
]
