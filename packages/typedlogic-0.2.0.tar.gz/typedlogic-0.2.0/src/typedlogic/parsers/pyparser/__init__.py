from typedlogic.parsers.pyparser.python_parser import PythonParser

__all__ = [
    "PythonParser",
]
