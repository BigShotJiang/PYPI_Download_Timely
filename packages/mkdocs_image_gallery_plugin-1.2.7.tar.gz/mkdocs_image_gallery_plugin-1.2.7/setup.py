import sys
import warnings

from setuptools import setup

# Forward to setuptools for backward compatibility
if __name__ == "__main__":
    setup()