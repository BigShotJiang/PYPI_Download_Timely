from .xwarning import warn, warning, configure  # optional shortcut exports
