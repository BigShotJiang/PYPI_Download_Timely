"""
Tokenlay SDK - Python client library for Tokenlay API.
This is a placeholder package to reserve the name.
"""

__version__ = "0.0.1"
__author__ = "Tokenlay"
__description__ = "Python SDK for Tokenlay API (placeholder)"