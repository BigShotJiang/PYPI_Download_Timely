# this is a clone of the userinfo.py data for compatibility across testing
# it should be removed in a future release
from .userinfo import RESPONSES

__all__ = ("RESPONSES",)
