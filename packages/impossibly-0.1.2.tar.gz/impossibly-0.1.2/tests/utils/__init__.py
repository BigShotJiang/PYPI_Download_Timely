"""
Utility functions and classes for testing.
""" 