"""
Feature tests for verifying core functionality of the Imagination Engine.

These tests focus on the key features of the framework rather than specific examples.
""" 