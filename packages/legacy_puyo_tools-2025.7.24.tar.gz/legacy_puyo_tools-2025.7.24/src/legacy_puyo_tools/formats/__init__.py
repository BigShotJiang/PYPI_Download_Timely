"""Formats that older Puyo Puyo games uses.

SPDX-FileCopyrightText: 2025 Samuel Wu
SPDX-License-Identifier: MIT
"""
