"""Testing infrastructure for legacy_puyo_tools.

SPDX-FileCopyrightText: 2025 Samuel Wu
SPDX-License-Identifier: MIT
"""
