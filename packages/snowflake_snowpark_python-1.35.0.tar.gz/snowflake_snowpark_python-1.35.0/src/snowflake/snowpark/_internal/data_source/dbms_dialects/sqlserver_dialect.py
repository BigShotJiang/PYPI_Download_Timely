#
# Copyright (c) 2012-2025 Snowflake Computing Inc. All rights reserved.
#
from snowflake.snowpark._internal.data_source.dbms_dialects import BaseDialect


class SqlServerDialect(BaseDialect):
    pass
