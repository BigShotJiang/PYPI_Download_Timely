Add resampling tools, for example to downsample 62.5 sps to 1 sps.
Add improved decimation filters?  (SAC only reduces by 50 dB, is this
enough for the noise notch w.r.t. microseisms?)