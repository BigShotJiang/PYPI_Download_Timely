VERSION = "0.1.0"
__version__ = VERSION
APP_NAME = "Magentic-UI"
