from .settings import IndexSettings

__all__ = ['IndexSettings']
