import os

PACKAGE_DIR = os.path.abspath(os.path.dirname(__file__))
SCIPTS_DIR = os.path.join(PACKAGE_DIR, "scripts", "CNS.anno.R")


