# hlo123/__init__.py
def hello():
    return "Hello from hlo123!"

# Optional: define __version__
__version__ = "0.1.0"
