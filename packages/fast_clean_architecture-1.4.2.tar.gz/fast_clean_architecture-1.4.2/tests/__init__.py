"""Test suite for fast-clean-architecture package."""
