"""Jinja2 templates for Fast Clean Architecture."""

from pathlib import Path

TEMPLATES_DIR = Path(__file__).parent

__all__ = ["TEMPLATES_DIR"]
