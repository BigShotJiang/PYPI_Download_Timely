"""Inialize the duet_simplyprint_connector package."""

from . import _version

__version__ = _version.get_versions()['version']
