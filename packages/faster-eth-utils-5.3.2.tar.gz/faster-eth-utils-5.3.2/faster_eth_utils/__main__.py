from .debug import (
    get_environment_summary,
)

print(get_environment_summary())
