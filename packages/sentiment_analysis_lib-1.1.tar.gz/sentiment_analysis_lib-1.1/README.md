This is a simple Python package for analysing sentiment of text data.
