import pathlib

CONFIG = pathlib.Path(__file__).parent / "config.toml"
TEMPLATES = pathlib.Path(__file__).parent / "templates"
ASSETS = pathlib.Path(__file__).parent / "assets"
