COL_FOR_FUND_PRICE = '수정기준가'
KEYS_TO_PROJECT_FOR_FUND_PRICE = ['일자', '수정기준가']
DEFAULT_COLS_FOR_BM_PRICE = ['KOSPI Index', 'KOSDAQ Index', 'KOSPI2 Index', 'SPX Index']
COLS_FOR_CONSISE_INFO = ['펀드명', '매니저', '자본금', 'NAV', '설정일', '결산일', '펀드구분', '펀드분류', '공모/사모', '보수율: Total', '보관은행', '사무수탁사', 'BM1: 기준', '종류형구분', '재투자여부', '판매펀드']
