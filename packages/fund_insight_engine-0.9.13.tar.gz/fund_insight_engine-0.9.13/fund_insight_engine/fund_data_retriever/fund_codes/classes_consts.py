KEY_FOR_CLASS = '클래스구분'
VALUES_FOR_CLASS = ['운용펀드', '일반', '클래스펀드', '-']