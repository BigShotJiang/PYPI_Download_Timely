# coding=utf-8
from .._impl import (
    api_rids_AttachmentRid as AttachmentRid,
    api_rids_AutomaticCheckEvaluationRid as AutomaticCheckEvaluationRid,
    api_rids_ChunkRid as ChunkRid,
    api_rids_DataSourceRid as DataSourceRid,
    api_rids_DatasetRid as DatasetRid,
    api_rids_EventRid as EventRid,
    api_rids_NominalDataSourceOrDatasetRid as NominalDataSourceOrDatasetRid,
    api_rids_NominalDataSourceRid as NominalDataSourceRid,
    api_rids_ProcedureExecutionRid as ProcedureExecutionRid,
    api_rids_ProcedureRid as ProcedureRid,
    api_rids_SegmentRid as SegmentRid,
    api_rids_StreamingConnectionRid as StreamingConnectionRid,
    api_rids_VideoFileRid as VideoFileRid,
    api_rids_VideoRid as VideoRid,
    api_rids_WorkspaceRid as WorkspaceRid,
)

__all__ = [
    'AttachmentRid',
    'AutomaticCheckEvaluationRid',
    'ChunkRid',
    'DataSourceRid',
    'DatasetRid',
    'EventRid',
    'NominalDataSourceOrDatasetRid',
    'NominalDataSourceRid',
    'ProcedureExecutionRid',
    'ProcedureRid',
    'SegmentRid',
    'StreamingConnectionRid',
    'VideoFileRid',
    'VideoRid',
    'WorkspaceRid',
]

