from setuptools import setup, find_packages

setup(
    name="ckbnum2txt",
    version="1.0.0",
    description="Kurdish number to text and normalization tools",
    author="Your Name",
    author_email="your.email@example.com",
    url="https://github.com/yourusername/ckbnum2txt",  # if hosted on GitHub or similar
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        # Add dependencies here if you have any
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    include_package_data=True,
)
