# Pyarmor 8.4.7 (basic), 004363, 2025-07-24T19:12:09.518519
from .pyarmor_runtime import __pyarmor__
