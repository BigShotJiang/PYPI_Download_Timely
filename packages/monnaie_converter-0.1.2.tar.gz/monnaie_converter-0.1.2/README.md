# monnaie-converter

Un package Django simple pour convertir des monnaies via un formulaire.

## Installation

```bash
pip install monnaie-converter
