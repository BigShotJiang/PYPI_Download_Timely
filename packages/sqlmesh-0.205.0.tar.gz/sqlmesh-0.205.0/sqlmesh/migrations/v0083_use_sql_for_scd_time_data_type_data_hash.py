"""Use sql(...) instead of gen when computing the data hash of the time data type."""


def migrate(state_sync, **kwargs):  # type: ignore
    pass
