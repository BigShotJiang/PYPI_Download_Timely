# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

"""Module for the startup phase of the AWS Deadline Cloud Worker Agent"""
