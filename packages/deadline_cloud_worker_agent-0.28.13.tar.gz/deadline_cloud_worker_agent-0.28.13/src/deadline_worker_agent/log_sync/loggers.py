# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

from logging import getLogger as _getLogger

logger = _getLogger(__name__.rsplit(".", maxsplit=1)[0])

ROOT_LOGGER = _getLogger("root")
