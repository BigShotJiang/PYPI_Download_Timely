# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

from logging import getLogger

logger = getLogger(__name__.rsplit(".", maxsplit=1)[0])
