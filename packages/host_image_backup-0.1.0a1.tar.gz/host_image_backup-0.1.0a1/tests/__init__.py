"""Test initialization module"""
