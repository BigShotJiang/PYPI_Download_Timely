"""Host Image Backup"""

__version__ = "0.1.0.a1"
__author__ = "Wenjie Xu"
__email__ = "wenjie.xu.cn@outlook.com"
