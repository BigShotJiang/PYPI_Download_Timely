_RESOURCE = 'http://apli.bizkaia.net/'
_RESOURCE += 'APPS/DANOK/TQWS/TQ.ASMX/'

TIMETABLE_SERVICE = 'GetPasoParadaMobile_JSON'
LINES_PER_TOWN_SERVICE = 'GetLineasPrincipalesSecundariasMunicipio_JSON'
LINES_ITINERARY_SERVICE = 'GetItinerarioLinea_JSON'
STOP_INFO_SERVICE = 'GetParadas_JSON'