# Screenshots

## Music player (June 2024)

![screenshot](https://downloads.rkslot.nl/music-player-screenshots/player4.png)

## Activity (June 2024)

![screenshot](https://downloads.rkslot.nl/music-player-screenshots/history3.png)

## Lyrics (November 2024)

![screenshot](https://downloads.rkslot.nl/music-player-screenshots/lyrics3.png)

## Statistics (December 2023)

![screenshot](https://downloads.rkslot.nl/music-player-screenshots/stats2.png)

## Search (June 2024)

![screenshot](https://downloads.rkslot.nl/music-player-screenshots/search.png)

## Metadata editor (January 2023)

![screenshot](https://downloads.rkslot.nl/music-player-screenshots/metadata-editor.png)

## Home (November 2024)

![screenshot](https://downloads.rkslot.nl/music-player-screenshots/home3.png)

## Album view (January 2023)

![screenshot](https://downloads.rkslot.nl/music-player-screenshots/album-view.png)

## Album cover meme mode (April 2023)

![screenshot](https://downloads.rkslot.nl/music-player-screenshots/meme.png)

## Account settings (November 2024)

![screenshot](https://downloads.rkslot.nl/music-player-screenshots/account2.png)
