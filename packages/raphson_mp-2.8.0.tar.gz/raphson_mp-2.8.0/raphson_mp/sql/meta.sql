CREATE TABLE db_version (
    version INTEGER NOT NULL
) STRICT;
