CREATE INDEX idx_history_track ON history(track);
