-- Add privacy column

ALTER TABLE user ADD COLUMN privacy TEXT NULL;
