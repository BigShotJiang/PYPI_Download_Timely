DROP TABLE now_playing;
