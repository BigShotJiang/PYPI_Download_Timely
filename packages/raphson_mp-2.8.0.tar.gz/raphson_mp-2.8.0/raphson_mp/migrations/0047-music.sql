CREATE INDEX idx_history_user ON history(user);
