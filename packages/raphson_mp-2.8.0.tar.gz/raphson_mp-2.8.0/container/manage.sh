#!/bin/bash
exec python3 -m raphson_mp $@
