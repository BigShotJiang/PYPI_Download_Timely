"""
Python-based GUI for viewing and analyzing recordings of animal
vocalizations.
"""

from .version import __version__
from .audian import main

