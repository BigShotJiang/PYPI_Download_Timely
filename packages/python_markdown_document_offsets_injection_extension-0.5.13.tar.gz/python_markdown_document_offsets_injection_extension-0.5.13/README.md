# python_markdown_document_offsets_injection_extension

A Python-Markdown extension to count and calculate offset between rendered html and origin markdown document,
inject them into the html elements.
