"""The trigger module of AWEL."""
