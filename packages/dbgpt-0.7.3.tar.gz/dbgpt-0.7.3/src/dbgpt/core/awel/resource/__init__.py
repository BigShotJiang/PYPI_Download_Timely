"""The module of AWEL resource.

Not implemented yet.
"""
