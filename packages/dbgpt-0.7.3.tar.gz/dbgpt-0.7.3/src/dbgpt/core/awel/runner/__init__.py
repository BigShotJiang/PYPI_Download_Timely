"""The module to run AWEL operators.

You can implement your own runner by inheriting the `WorkflowRunner` class.
"""
