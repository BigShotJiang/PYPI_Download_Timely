"""The core interface of DB-GPT.

Just include the core interface to keep our dependencies clean.
"""
