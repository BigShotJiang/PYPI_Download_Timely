"""
a tool to discovery sensitive data
"""
