"""
data masking, transform private sensitive data into mask data, based on the tool
sensitive data recognition.
"""
