"""
mask the sensitive data before upload LLM inference service
"""
