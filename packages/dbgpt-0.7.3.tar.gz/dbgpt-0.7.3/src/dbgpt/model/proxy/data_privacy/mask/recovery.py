"""
recovery the data after LLM inference
"""
