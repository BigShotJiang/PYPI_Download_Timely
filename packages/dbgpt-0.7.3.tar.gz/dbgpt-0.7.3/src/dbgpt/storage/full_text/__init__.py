"""Full Text Store Module."""
