from .console import CliLogger  # noqa: F401

__ALL__ = ["CliLogger"]
