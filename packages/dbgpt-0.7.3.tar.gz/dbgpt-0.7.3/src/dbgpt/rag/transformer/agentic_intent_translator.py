"""Agentic IntentTranslator class."""

import logging

from dbgpt.rag.transformer.base import TranslatorBase

logger = logging.getLogger(__name__)


class AgenticIntentTranslator(TranslatorBase):
    """Agentic IntentTranslator class."""
