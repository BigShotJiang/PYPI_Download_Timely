"""AwelIntentTranslator class."""

import logging

from dbgpt.rag.transformer.base import TranslatorBase

logger = logging.getLogger(__name__)


class AwelIntentTranslator(TranslatorBase):
    """AwelIntentTranslator class."""
