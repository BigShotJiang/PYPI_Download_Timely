"""Expand resources for the agent module."""
