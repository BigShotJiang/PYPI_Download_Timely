"""External planner.

Use AWEL as the external planner.
"""
