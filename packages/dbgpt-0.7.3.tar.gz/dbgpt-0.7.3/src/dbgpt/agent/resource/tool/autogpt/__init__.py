"""Some compatible tools for autogpt."""
