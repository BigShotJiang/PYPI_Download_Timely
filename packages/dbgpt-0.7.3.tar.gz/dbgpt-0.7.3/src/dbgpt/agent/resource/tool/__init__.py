"""Tool resources.

Tool is a special type of resource that is used to execute a function or a command.
"""
