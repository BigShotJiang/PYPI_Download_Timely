"""Vis Api Response."""

from ..base import Vis


class VisApiResponse(Vis):
    """Vis Api Response."""

    @classmethod
    def vis_tag(cls):
        """Vis Api Response."""
        return "vis-api-response"
