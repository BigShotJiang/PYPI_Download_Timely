"""Vis Plugin."""

from ..base import Vis


class VisPlugin(Vis):
    """Vis Plugin."""

    @classmethod
    def vis_tag(cls):
        """Vis Plugin."""
        return "vis-plugin"
