"""VisDbgptsFlow."""

from ..base import Vis


class VisDbgptsFlow(Vis):
    """VisDbgptsFlow."""

    @classmethod
    def vis_tag(cls):
        """VIS Flow."""
        return "dbgpts-flow"
