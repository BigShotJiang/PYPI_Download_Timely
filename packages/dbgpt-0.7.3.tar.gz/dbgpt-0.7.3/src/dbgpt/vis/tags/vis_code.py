"""Vis Code."""

from ..base import Vis


class VisCode(Vis):
    """Vis Code."""

    @classmethod
    def vis_tag(cls):
        """Vis Code."""
        return "vis-code"
