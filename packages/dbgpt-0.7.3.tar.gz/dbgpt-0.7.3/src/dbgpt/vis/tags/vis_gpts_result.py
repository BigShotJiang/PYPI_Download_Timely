"""VisDbgptsFlowResult."""

from ..base import Vis


class VisDbgptsFlowResult(Vis):
    """VisDbgptsFlowResult."""

    @classmethod
    def vis_tag(cls) -> str:
        """VisDbgptsFlowResult."""
        return "dbgpts-result"
