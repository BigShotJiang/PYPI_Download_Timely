"""Vis App Link."""

from ..base import Vis


class VisAppLink(Vis):
    """Vis App Link."""

    @classmethod
    def vis_tag(cls):
        """Vis App Link."""
        return "vis-app-link"
