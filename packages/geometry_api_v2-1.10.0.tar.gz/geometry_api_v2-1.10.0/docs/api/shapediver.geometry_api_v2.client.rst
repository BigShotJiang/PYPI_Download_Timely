shapediver.geometry\_api\_v2.client package
===========================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   shapediver.geometry_api_v2.client.api
   shapediver.geometry_api_v2.client.models

Submodules
----------

shapediver.geometry\_api\_v2.client.api\_client module
------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.api_client
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.api\_response module
--------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.api_response
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.configuration module
--------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.configuration
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.exceptions module
-----------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.exceptions
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.rest module
-----------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.rest
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: shapediver.geometry_api_v2.client
   :members:
   :show-inheritance:
   :undoc-members:
