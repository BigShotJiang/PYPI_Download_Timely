shapediver.geometry\_api\_v2 package
====================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   shapediver.geometry_api_v2.client

Submodules
----------

shapediver.geometry\_api\_v2.sd\_client module
----------------------------------------------

.. automodule:: shapediver.geometry_api_v2.sd_client
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.sd\_utils module
---------------------------------------------

.. automodule:: shapediver.geometry_api_v2.sd_utils
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: shapediver.geometry_api_v2
   :members:
   :show-inheritance:
   :undoc-members:
