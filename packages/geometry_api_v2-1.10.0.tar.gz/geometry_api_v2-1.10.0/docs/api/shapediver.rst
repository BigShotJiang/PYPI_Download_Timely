shapediver namespace
====================

.. py:module:: shapediver

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   shapediver.geometry_api_v2
