shapediver.geometry\_api\_v2.client.models package
==================================================

Submodules
----------

shapediver.geometry\_api\_v2.client.models.commmons\_parameter\_asset module
----------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.commmons_parameter_asset
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.commons\_basic\_parameter module
---------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.commons_basic_parameter
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.commons\_computation\_status module
------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.commons_computation_status
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.commons\_group module
----------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.commons_group
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.commons\_model\_blocking\_reasons module
-----------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.commons_model_blocking_reasons
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.commons\_model\_status module
------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.commons_model_status
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.commons\_parameter\_chunk module
---------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.commons_parameter_chunk
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.commons\_stype\_parameter module
---------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.commons_stype_parameter
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.commons\_ticket module
-----------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.commons_ticket
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.commons\_ticket\_type module
-----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.commons_ticket_type
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.null\_obj module
-----------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.null_obj
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.query\_computation\_statistics\_status module
----------------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.query_computation_statistics_status
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.query\_computation\_status module
----------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.query_computation_status
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.query\_computation\_type module
--------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.query_computation_type
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.query\_gltf\_conversion module
-------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.query_gltf_conversion
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.query\_model\_status module
----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.query_model_status
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.query\_order module
--------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.query_order
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_any\_credit\_metric\_id module
------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_any_credit_metric_id
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_authorization\_group module
---------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_authorization_group
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_basic\_parameter module
-----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_basic_parameter
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_cache module
------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_cache
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_configure module
----------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_configure
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_credit\_metric module
---------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_credit_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_credit\_metrics module
----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_credit_metrics
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_customization module
--------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_customization
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_customization\_or\_cache module
-------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_customization_or_cache
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_customization\_or\_export module
--------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_customization_or_export
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_export module
-------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_export
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_export\_definition module
-------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_export_definition
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_export\_definition\_group module
--------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_export_definition_group
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_export\_definitions module
--------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_export_definitions
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_export\_or\_cache module
------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_export_or_cache
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_file\_definition module
-----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_file_definition
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_file\_upload module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_file_upload
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_group module
------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_group
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_log\_level module
-----------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_log_level
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_log\_message module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_log_message
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_model module
------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_model
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_model\_blocking\_reasons module
-------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_model_blocking_reasons
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_model\_credit\_metric\_id module
--------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_model_credit_metric_id
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_model\_file\_type module
------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_model_file_type
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_model\_organization\_credit\_metric\_id module
----------------------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_model_organization_credit_metric_id
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_model\_state module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_model_state
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_model\_statistic module
-----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_model_statistic
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_model\_statistics module
------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_model_statistics
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_model\_user\_credit\_metric\_id module
--------------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_model_user_credit_metric_id
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_organization\_credit\_metric\_id module
---------------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_organization_credit_metric_id
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_output\_definition module
-------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_output_definition
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_output\_definition\_chunk module
--------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_output_definition_chunk
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_output\_definition\_group module
--------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_output_definition_group
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_output\_definitions module
--------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_output_definitions
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_parameter\_definition module
----------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_parameter_definition
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_parameter\_definition\_group module
-----------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_parameter_definition_group
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_parameter\_definitions module
-----------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_parameter_definitions
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_parameter\_value module
-----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_parameter_value
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_sdtf\_definition module
-----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_sdtf_definition
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_sdtf\_type module
-----------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_sdtf_type
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_stype\_parameter module
-----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_stype_parameter
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_system\_credit\_metric\_id module
---------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_system_credit_metric_id
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_ticket module
-------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_ticket
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_ticket\_type module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_ticket_type
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_trust\_level module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_trust_level
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.req\_user\_credit\_metric\_id module
-------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.req_user_credit_metric_id
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_action module
-------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_action
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_allowed\_worker\_plugin module
------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_allowed_worker_plugin
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_analytics module
----------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_analytics
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_any\_credit\_metric module
--------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_any_credit_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_ar\_credit\_metric module
-------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_ar_credit_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_asset module
------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_asset
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_asset\_definition module
------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_asset_definition
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_asset\_upload\_headers module
-----------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_asset_upload_headers
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_authorization\_settings module
------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_authorization_settings
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_base module
-----------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_base
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_base\_asset module
------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_base_asset
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_base\_credit\_metric module
---------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_base_credit_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_base\_list module
-----------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_base_list
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_base\_model\_state module
-------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_base_model_state
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_base\_system module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_base_system
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_basic\_parameter module
-----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_basic_parameter
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_cleanup\_exports module
-----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_cleanup_exports
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_cleanup\_outputs module
-----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_cleanup_outputs
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_cleanup\_textures module
------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_cleanup_textures
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_close\_session module
---------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_close_session
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_computation\_component module
-----------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_computation_component
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_computation\_components module
------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_computation_components
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_computation\_limits module
--------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_computation_limits
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_computation\_status module
--------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_computation_status
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_compute\_exports module
-----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_compute_exports
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_compute\_outputs module
-----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_compute_outputs
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_compute\_settings module
------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_compute_settings
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_computed\_component module
--------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_computed_component
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_computing\_component module
---------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_computing_component
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_create\_authorization\_group module
-----------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_create_authorization_group
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_create\_model module
--------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_create_model
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_create\_model\_config module
----------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_create_model_config
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_create\_model\_state module
---------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_create_model_state
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_create\_session\_by\_model module
---------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_create_session_by_model
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_create\_session\_by\_ticket module
----------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_create_session_by_ticket
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_create\_ticket module
---------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_create_ticket
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_decrypt\_ticket module
----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_decrypt_ticket
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_default\_combined\_metric module
--------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_default_combined_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_default\_computation\_metric module
-----------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_default_computation_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_default\_credit\_metric module
------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_default_credit_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_default\_export\_metric module
------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_default_export_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_default\_output\_metric module
------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_default_output_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_default\_session\_metric module
-------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_default_session_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_delete\_file module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_delete_file
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_delete\_model module
--------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_delete_model
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_delete\_model\_state module
---------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_delete_model_state
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_delete\_sdtf module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_delete_sdtf
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_error module
------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_error
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_error\_component module
-----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_error_component
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_error\_type module
------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_error_type
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_export module
-------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_export
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_export\_content module
----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_export_content
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_export\_definition module
-------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_export_definition
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_export\_definition\_group module
--------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_export_definition_group
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_export\_definition\_type module
-------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_export_definition_type
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_export\_list module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_export_list
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_export\_or\_definition module
-----------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_export_or_definition
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_export\_result module
---------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_export_result
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_file module
-----------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_file
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_file\_asset module
------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_file_asset
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_file\_info module
-----------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_file_info
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_file\_list module
-----------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_file_list
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_get\_cached\_exports module
---------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_get_cached_exports
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_get\_cached\_outputs module
---------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_get_cached_outputs
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_get\_cleanup\_status module
---------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_get_cleanup_status
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_get\_credit\_metrics module
---------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_get_credit_metrics
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_get\_minions\_info module
-------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_get_minions_info
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_get\_model module
-----------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_get_model
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_get\_model\_computations module
-------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_get_model_computations
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_get\_model\_config module
-------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_get_model_config
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_get\_model\_organization\_credit\_metrics module
------------------------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_get_model_organization_credit_metrics
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_get\_model\_state module
------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_get_model_state
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_get\_model\_state\_data module
------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_get_model_state_data
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_get\_model\_statistics module
-----------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_get_model_statistics
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_get\_model\_user\_credit\_metrics module
----------------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_get_model_user_credit_metrics
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_get\_organization\_credit\_metrics module
-----------------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_get_organization_credit_metrics
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_get\_session\_defaults module
-----------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_get_session_defaults
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_get\_user\_credit\_metrics module
---------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_get_user_credit_metrics
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_get\_workers\_info module
-------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_get_workers_info
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_gltf\_upload module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_gltf_upload
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_installed\_worker\_plugin module
--------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_installed_worker_plugin
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_limited\_credit\_metric module
------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_limited_credit_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_list module
-----------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_list
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_list\_export\_versions module
-----------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_list_export_versions
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_list\_files module
------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_list_files
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_list\_model\_states module
--------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_list_model_states
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_list\_models module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_list_models
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_list\_output\_versions module
-----------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_list_output_versions
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_list\_sdtfs module
------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_list_sdtfs
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_list\_textures module
---------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_list_textures
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_loading\_credit\_metric module
------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_loading_credit_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_log\_message module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_log_message
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_minion\_info module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_minion_info
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_minion\_process module
----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_minion_process
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_minion\_system module
---------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_minion_system
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_minion\_task module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_minion_task
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_model module
------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_model
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_model\_blocking\_reasons module
-------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_model_blocking_reasons
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_model\_cleanup\_process module
------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_model_cleanup_process
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_model\_cleanup\_process\_type module
------------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_model_cleanup_process_type
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_model\_computation module
-------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_model_computation
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_model\_computation\_stats module
--------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_model_computation_stats
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_model\_credit\_metric module
----------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_model_credit_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_model\_list module
------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_model_list
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_model\_organization\_credit\_metric module
------------------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_model_organization_credit_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_model\_settings module
----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_model_settings
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_model\_state module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_model_state
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_model\_state\_asset module
--------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_model_state_asset
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_model\_state\_data module
-------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_model_state_data
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_model\_state\_info module
-------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_model_state_info
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_model\_state\_list module
-------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_model_state_list
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_model\_state\_or\_data module
-----------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_model_state_or_data
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_model\_statistic module
-----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_model_statistic
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_model\_status module
--------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_model_status
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_model\_user\_credit\_metric module
----------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_model_user_credit_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_on\_action\_statistic module
----------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_on_action_statistic
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_on\_duration\_statistic module
------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_on_duration_statistic
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_organization\_credit\_metric module
-----------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_organization_credit_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_output module
-------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_output
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_output\_chunk module
--------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_output_chunk
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_output\_content module
----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_output_content
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_output\_definition module
-------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_output_definition
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_output\_definition\_group module
--------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_output_definition_group
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_output\_list module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_output_list
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_output\_or\_definition module
-----------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_output_or_definition
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_pagination module
-----------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_pagination
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_parameter module
----------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_parameter
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_parameter\_group module
-----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_parameter_group
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_parameter\_type module
----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_parameter_type
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_parameter\_value module
-----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_parameter_value
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_actions module
--------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_actions
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_analytics module
----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_analytics
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_authorization\_group module
---------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_authorization_group
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_cleanup module
--------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_cleanup
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_decrypted\_ticket module
------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_decrypted_ticket
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_exports module
--------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_exports
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_file module
-----------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_file
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_gltf\_upload module
-------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_gltf_upload
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_message module
--------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_message
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_model module
------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_model
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_model\_computation module
-------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_model_computation
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_model\_state module
-------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_model_state
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_model\_state\_data module
-------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_model_state_data
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_outputs module
--------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_outputs
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_pagination module
-----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_pagination
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_parameters module
-----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_parameters
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_plugins module
--------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_plugins
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_session\_id module
------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_session_id
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_setting module
--------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_setting
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_statistic module
----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_statistic
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_templates module
----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_templates
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_ticket module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_ticket
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_version module
--------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_version
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_viewer module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_viewer
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_viewer\_settings\_version module
--------------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_viewer_settings_version
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_part\_warnings module
---------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_part_warnings
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_plugins module
--------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_plugins
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_plugins\_library module
-----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_plugins_library
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_rate\_limited\_combined\_metric module
--------------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_rate_limited_combined_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_rate\_limited\_computation\_metric module
-----------------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_rate_limited_computation_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_rate\_limited\_export\_metric module
------------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_rate_limited_export_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_rate\_limited\_output\_metric module
------------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_rate_limited_output_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_rate\_limited\_session\_metric module
-------------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_rate_limited_session_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_sdtf\_asset module
------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_sdtf_asset
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_sdtf\_info module
-----------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_sdtf_info
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_sdtf\_list module
-----------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_sdtf_list
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_settings module
---------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_settings
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_statistic module
----------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_statistic
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_structure\_type module
----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_structure_type
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_stype\_parameter module
-----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_stype_parameter
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_system module
-------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_system
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_system\_credit\_metric module
-----------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_system_credit_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_template module
---------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_template
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_texture module
--------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_texture
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_texture\_list module
--------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_texture_list
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_ticket module
-------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_ticket
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_ticket\_authorization module
----------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_ticket_authorization
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_ticket\_type module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_ticket_type
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_token\_authorization module
---------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_token_authorization
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_update\_export\_definitions module
----------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_update_export_definitions
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_update\_model module
--------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_update_model
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_update\_model\_config module
----------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_update_model_config
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_update\_output\_definitions module
----------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_update_output_definitions
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_update\_parameter\_default\_values module
-----------------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_update_parameter_default_values
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_update\_parameter\_definitions module
-------------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_update_parameter_definitions
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_upload\_file module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_upload_file
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_upload\_gltf module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_upload_gltf
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_upload\_sdtf module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_upload_sdtf
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_user\_credit\_metric module
---------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_user_credit_metric
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_viewer module
-------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_viewer
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_visualization\_type module
--------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_visualization_type
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_warning\_component module
-------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_warning_component
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_worker\_info module
-------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_worker_info
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_worker\_plugin\_component module
--------------------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_worker_plugin_component
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_worker\_plugins module
----------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_worker_plugins
   :members:
   :show-inheritance:
   :undoc-members:

shapediver.geometry\_api\_v2.client.models.res\_worker\_system module
---------------------------------------------------------------------

.. automodule:: shapediver.geometry_api_v2.client.models.res_worker_system
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: shapediver.geometry_api_v2.client.models
   :members:
   :show-inheritance:
   :undoc-members:
