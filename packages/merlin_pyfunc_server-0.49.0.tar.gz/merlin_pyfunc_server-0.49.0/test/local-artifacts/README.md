This folder contains model artifacts used by `build-pyfunc-server-base-image` GitHub Actions job.
