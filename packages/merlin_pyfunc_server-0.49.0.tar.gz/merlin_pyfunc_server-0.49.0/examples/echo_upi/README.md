# Echo UPI Model Examples

Run the server locally:

```
python upi_server.py
```

In different terminal session, run the client:

```
python upi_client.py
```
