#  create_django

`create_Newapp` est un package Python qui vous permet de générer automatiquement une application Django complète prête à l'emploi, en une seule commande.

---

##  Fonctionnalités

- Génère un dossier d'application Django avec une structure complète

---

## Usage

```bash
 create_django nom_de_lappli
