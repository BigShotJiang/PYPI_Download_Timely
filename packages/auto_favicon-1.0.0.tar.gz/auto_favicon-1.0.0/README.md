# Auto Favicon MCP Server

An MCP (Model Context Protocol) server that automatically generates complete favicon sets from PNG images or URLs. This server creates a comprehensive set of favicon files including various sizes, Apple touch icons, and a manifest.json file.

## Features

- **PNG to Favicon**: Generate favicon sets from local PNG files
- **URL to Favicon**: Download images from URLs and generate favicon sets
- **Complete Icon Set**: Creates multiple sizes (16x16, 32x32, 48x48, 64x64, 128x128, 256x256)
- **ICO Format**: Generates traditional favicon.ico files
- **Apple Touch Icons**: Creates Apple-specific touch icons for iOS devices
- **Web App Manifest**: Generates manifest.json for Progressive Web Apps

## Installation & Usage

### Using uvx (Recommended)

The package can be run directly using `uvx` without installation:

```bash
# Run the MCP server
uvx auto-favicon

# Or with custom output directory
uvx auto-favicon --output-dir ./my-favicons
```

### Local Development

1. Clone this repository:
```bash
git clone <repository-url>
cd auto-favicon-mcp
```

2. Install dependencies:
```bash
uv sync
```

3. Run the server:
```bash
# Using the module
python -m auto_favicon

# Or using the console script (if installed)
auto-favicon
```

### MCP Client Configuration

Add to your MCP client configuration:

```json
{
  "mcpServers": {
    "favicon-generator": {
      "command": "uvx",
      "args": ["auto-favicon"],
      "env": {}
    }
  }
}
```

## Package Structure

The project follows standard Python packaging conventions:

```
auto-favicon-mcp/
├── src/
│   └── auto_favicon/
│       ├── __init__.py      # Package initialization
│       ├── __main__.py      # Module entry point
│       └── server.py        # Main server implementation
├── pyproject.toml           # Project configuration
├── uv.lock                  # Dependency lock file
└── dist/                    # Built distribution files
    ├── auto_favicon-0.1.0.tar.gz
    └── auto_favicon-0.1.0-py3-none-any.whl
```

## Available Tools

- `generate_favicon_from_png`: Generate favicon set from a local PNG file
- `generate_favicon_from_url`: Download image from URL and generate favicon set

## Building the Package

To build the distribution files:

```bash
uv build
```

This creates both a source distribution (`.tar.gz`) and a wheel (`.whl`) in the `dist/` directory.

## Requirements

- Python 3.12+
- uv package manager
