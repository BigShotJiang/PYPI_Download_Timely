# command-generator

## Installation
`pip install redis_command_generator` - for latest version (or `make install_latest`)
`pip install -e .` - to install from local sources (or `make dev`)

## Usage
See examples/
Or run `python -m redis_command_generator.<Generator Type> -h`
(for e.g. `GenRunner`. see src/ for list of available generators)