__version__ = "0.0.1"
from .widget import CopickPlugin

__all__ = ("CopickPlugin",)
