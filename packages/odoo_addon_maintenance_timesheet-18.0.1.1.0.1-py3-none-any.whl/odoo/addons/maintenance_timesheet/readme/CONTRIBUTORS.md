- David Alonso \<<david.alonso@solvos.es>\>
- Luisa Miguéns \<<luisa.miguens@solvos.es>\>
- Christian Ramos \<<c.ramos@binhex.es>\>
- [Heliconia Solutions Pvt. Ltd.](https://www.heliconia.io)
  - Bhavesh Heliconia

