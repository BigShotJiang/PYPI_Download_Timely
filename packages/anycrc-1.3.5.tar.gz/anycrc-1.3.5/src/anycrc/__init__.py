from .crc import CRC, Model
from .models import models, aliases
from .utils import get_hex, str_model