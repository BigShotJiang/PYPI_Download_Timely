"""Top-level package for workforce."""

__author__ = """Theo Portlock"""
__email__ = 'zn.tportlock@gmail.com'
__version__ = 'master'
