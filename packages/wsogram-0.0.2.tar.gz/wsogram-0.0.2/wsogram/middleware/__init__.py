"""
Middleware system for wsogram
""" 