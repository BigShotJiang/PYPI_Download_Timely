"""
Filters for WebSocket message processing
""" 