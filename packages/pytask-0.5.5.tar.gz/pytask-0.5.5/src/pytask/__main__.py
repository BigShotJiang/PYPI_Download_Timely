"""The pytask entry-point."""

from __future__ import annotations

import sys

import pytask

if __name__ == "__main__":
    sys.exit(pytask.cli())
