from enum import Enum


class TaskExecutionStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
