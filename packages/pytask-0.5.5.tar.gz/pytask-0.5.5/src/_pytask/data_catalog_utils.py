"""Contains utilities for the data catalog."""

__all__ = ["DATA_CATALOG_NAME_FIELD"]


DATA_CATALOG_NAME_FIELD = "catalog_name"
