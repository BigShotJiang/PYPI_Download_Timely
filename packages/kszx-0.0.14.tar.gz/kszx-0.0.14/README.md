For installation instructions and documentation, see: https://kszx.readthedocs.io/en/

This github repo contains source code for the ``kszx`` package, but does not contain jupyter notebooks.
Notebooks are located in the parallel repo: https://github.com/kmsmith137/kszx_notebooks.

(This two-repo split is because jupyter notebooks tend to result in large github repos, and I wanted
to keep the "core" kszx repo small.)
