"""This submodule is a place for old code to retire peacefully."""

from .RichardsonLucyDeconvolver import RichardsonLucyDeconvolver
