###############
Source of Files
###############

SMSIM Files
===========
   SMSIM was downloaded from [1]_ (last accessed on 2/4/2014) and was used to
   create all of the ``*.sum``, ``*.col``, and ``*.ofr`` files. The Fourier
   amplitude spectra (``*_fs.col``) were calculated with ``fas_drvr.exe``,
   and the response spectra (``*_rs.rv.col``) were calculated with
   ``gm_rv_drvr.exe``.

    On 1/15/18 with SMSIM v6.0 was used to create new tests for BT15.

References
==========
 .. _[1] http://daveboore.com/software_online.html
