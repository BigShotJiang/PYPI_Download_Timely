# Changelog

## 0.8.1 (2025-07-25)

- Fixed: Issue with naming in CLI tools.

## 0.8.0 (2025-07-25)

- Added Stafford et al. (2022) ground motion model.
- Added Seifried et al. (2025) peak factor model.
- Fix: Moved non-stationarity correction from Vanmarck to ToroMcGuire.
- Changed to use uv for package versioning.

## 0.7.0

- Added Boore & Thompson (2015)
- Added Wang & Rathje (2018)
- Re-factored peak factor calculators

## 0.6.3 (2017-10-10)

- Add scripts for profiling

## 0.6.2 (2017-05-07)

- Fixed PEP8 issues in docstrings.

## 0.6.0 (2017-05-05)

- Removed pyprind require and progress bars.

## 0.6.0 (2017-05-05)

- Improved performance with multiprocessing and numba.
- Changed CLI name from `rvt_operator` to `pyrvt`

## 0.5.8 (2016-11-16)

- Fixed: osc_freqs typo in tools.py
- Added: test cases for tools.py

## 0.5.7 (2016-07-14)

- Fixed version numbering.

## 0.5.6 (2016-07-14)

- Fixed manifest to include data directory.

## 0.5.5 (2016-07-11)

- Updated Travis build scripts.

## 0.5.4 (2016-07-09)

- Fixed building the documentation on RTFD

## 0.5.1 (2016-07-06)

- Fixed Travis deployment

## 0.5.0 (2016-07-06)

- Added ability to pass transfer function to PSA calculation.
- Removed extraneous files.
- Cleaned up documentation to use NumPy style.
- Fixed PEP8 issues.

## 0.1.0 (2016-03-04)

- First release on PyPI.
