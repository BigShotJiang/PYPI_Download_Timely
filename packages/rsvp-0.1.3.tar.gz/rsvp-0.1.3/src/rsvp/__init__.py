"""RSVP is a asynchronous Python framework."""

from .__about__ import __version__ as __version__


__all__ = ['__version__']
