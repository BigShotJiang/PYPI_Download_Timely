"""__init__.py."""

DEFAULT_PROFILE_NAME = "default"
