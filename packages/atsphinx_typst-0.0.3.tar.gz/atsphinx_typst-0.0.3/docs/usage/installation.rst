Installation
============

Install from PyPI
-----------------

It is published on PyPI.
You can install it by pip or other package management tools.

.. note:: Currently, it is not published yet.

.. code-block:: console

    pip install atsphinx-typst

If you want to generate PDF too, you should set ``pdf`` extra.

.. code-block:: console

    pip install 'atsphinx-typst[pdf]'
