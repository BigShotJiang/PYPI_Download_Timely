# noqa: D100

extensions = []

typst_documents = [
    {
        "entrypoint": "index",
        "filename": "index",
        "theme": "manual",
        "title": "Test documentation",
        "toctree_only": True,
    }
]
