import{r,g as s}from"./ansi-regex-DJPe--rM.js";var t,e;const n=s(function(){if(e)return t;e=1;const s=r();return t=r=>"string"==typeof r?r.replace(s(),""):r}());export{n as s};
