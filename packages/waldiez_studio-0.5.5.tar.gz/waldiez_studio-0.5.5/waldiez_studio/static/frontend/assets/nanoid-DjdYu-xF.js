let e=(e=21)=>{let r="",t=crypto.getRandomValues(new Uint8Array(e|=0));for(;e--;)r+="useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict"[63&t[e]];return r};export{e as n};
