# Connection Imports #


# Global Main Connection #
main_conn = None


# Method retrieves database connection according to selected environment #
def get_main_connection_session():

    # Assigning global variable #
    global main_conn

    return None
