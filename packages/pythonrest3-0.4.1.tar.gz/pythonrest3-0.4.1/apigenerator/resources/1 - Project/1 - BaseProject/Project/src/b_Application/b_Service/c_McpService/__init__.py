# This file makes 'c_McpService' a Python package.
# You can expose elements from ApiQueryService.py here if needed, e.g.:
# from .ApiQueryService import ApiQueryService
