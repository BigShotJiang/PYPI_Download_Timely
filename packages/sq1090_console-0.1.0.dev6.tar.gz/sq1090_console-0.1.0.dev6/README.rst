Sq1090 Console is Sq1090 project application to show aircraft information.

Sq1090 is a web application, which can be deployed on a server, or used
locally on a user workstation.

The application is tested on Firefox.

.. image:: doc/screenshot.png
   :alt: Sq1090 Console screenshot
   :width: 800px
