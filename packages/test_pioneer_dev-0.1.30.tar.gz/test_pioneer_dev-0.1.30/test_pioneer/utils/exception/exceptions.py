class ExecutorException(Exception):
    pass


class YamlException(Exception):
    pass


class WrongInputException(Exception):
    pass


class ProjectException(Exception):
    pass
