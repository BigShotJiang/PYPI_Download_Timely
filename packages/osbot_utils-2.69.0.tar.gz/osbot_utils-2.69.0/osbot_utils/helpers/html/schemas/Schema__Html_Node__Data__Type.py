from enum import Enum

class Schema__Html_Node__Data__Type(Enum):
    TEXT : str = 'text'
