from osbot_utils.type_safe.Type_Safe import Type_Safe

# todo: refactor all of Kwargs_To_Self to use Type_Safe
Kwargs_To_Self = Type_Safe
