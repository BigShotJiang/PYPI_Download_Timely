```{include} ../README.md

```

```{toctree}
:maxdepth: 1
:hidden:

reference
changelog
```
