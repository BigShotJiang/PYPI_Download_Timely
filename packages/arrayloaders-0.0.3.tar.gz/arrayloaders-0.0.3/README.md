# `arrayloaders`

This package still is in an early version. To use it, see:

- [Training example](https://lamin.ai/laminlabs/arrayloader-benchmarks/transform/UMQFXo0vs0Z6)
- [Benchmark](https://lamin.ai/laminlabs/arrayloader-benchmarks/transform/2C0ghWpz0auc)

## Contributing

Please run `pre-commit install` and `gitmoji -i` on the CLI before starting to work on this repository!
