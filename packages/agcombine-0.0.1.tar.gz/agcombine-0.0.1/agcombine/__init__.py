"""Top-level package for agcombine."""

__author__ = """Mailson Freire de Oliveira"""
__email__ = "mailson.oliveira@unesp.br"
__version__ = "0.0.1"
