# Welcome to agcombine


[![image](https://img.shields.io/pypi/v/agcombine.svg)](https://pypi.python.org/pypi/agcombine)


**A python package for yield data filtering**


-   Free software: MIT License
-   Documentation: <https://oliveiralab.github.io/agcombine>
    

## Features

-   TODO
