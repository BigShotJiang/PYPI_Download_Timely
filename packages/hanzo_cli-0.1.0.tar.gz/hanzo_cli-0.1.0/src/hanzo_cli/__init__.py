"""Hanzo CLI - Unified command-line interface for Hanzo AI."""

__version__ = "0.1.0"
__all__ = ["main", "cli"]

from hanzo_cli.cli import main, cli