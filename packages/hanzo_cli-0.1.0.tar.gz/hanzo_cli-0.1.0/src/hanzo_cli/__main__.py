"""Entry point for python -m hanzo_cli."""

from hanzo_cli.cli import main

if __name__ == "__main__":
    main()