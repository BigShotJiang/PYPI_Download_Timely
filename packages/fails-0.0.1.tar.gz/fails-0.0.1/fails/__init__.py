# Safe dummy package: fails
