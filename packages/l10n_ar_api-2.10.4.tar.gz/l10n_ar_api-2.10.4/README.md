# API para localizacion Argentina

# V2.6.0
- Se añade integración WS de ARBA para obtener COT.

# V2.3.2
- Se corrige redondeo en casos de bonificación.

# V2.3.0
- Se agrega Percepciones y Retenciones para misiones.

# V2.2.1
- Se corrige cambio de longitud y se agrega caso de importes mayores al permitido

# V2.2.0
- Percepciones SIRCAR

# V2.1.14
- Se actualiza longitud de base e importe en percepciones AGIP

# V2.1.13
- Se corrige encoding de response de login AFIP

# V2.1.12
- Tributo SUSS

# V2.1.11
- Gestión de errores de número de documento

# V2.1.10
- Percepciones y Retenciones AGIP

# V2.1.9
- Padron Tucuman

# V2.1.6
- Se agrega PeriodoAsoc a WSFE

# V2.1.5
- Percepciones ARBA 1.2

# V2.1.4
- Posibilidad de obtener CAE

# V2.1.3
- Correcion de colores invertidos en el codigo QR

# V2.0.25
- Corrección de redondeo en total de factura de WSFEX

# V2.0.24
- Corrección de redondeo en total de ítem de WSFEX

# V2.0.23
- Agregado impuesto minimo a iibb

# V2.0.22
- No se tomaban en cuenta bonificaciones en total de líneas de factura

# V2.0.21
- Corrección en redondeo de totales al validar montos de factura de exportación

# V2.0.19
- Correccion de total de lineas de bono fiscal. No restaba la bonificacion

# V2.0.18
- Correccion de total de factura de bono fiscal

# V2.0.17
- Correccion de total de items de exportacion

# V2.0.16
- Libro IVA Digital
