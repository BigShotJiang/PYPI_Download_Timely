service_urls = dict(
    ws_anmat_homologation='https://servicios.pami.org.ar/trazaenprodmed.WebService?wsdl',
    ws_anmat_production='https://servicios.pami.org.ar/trazaprodmed.WebService?wsdl',
)
