# Safe dummy package: libopus
