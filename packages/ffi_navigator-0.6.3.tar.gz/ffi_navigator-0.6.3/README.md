# FFI Navigator

Python package and language server to support ffi navigation.
