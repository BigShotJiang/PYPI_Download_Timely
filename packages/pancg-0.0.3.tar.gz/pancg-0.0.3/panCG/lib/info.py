# -*- coding: utf-8 -*-

__version__ = '0.0.3'
__author__ = "Lei Tan"
__email__ = "lei.tan.bio@outlook.com"
__doc__ = """
    an integrative pipeline for family-level super-pangenome analysis across coding and noncoding sequences. 
"""