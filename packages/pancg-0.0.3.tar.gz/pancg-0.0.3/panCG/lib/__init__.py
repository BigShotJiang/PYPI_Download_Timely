#!/usr/bin/env python
# !/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Date    : 2025/7/28 12:12
@File    : __init__.py
@IDE     : PyCharm 
@Author  : lei tan
@Mail    : lei.tan.bio@outlook.com
@Desc    : None
"""


def main():
    pass


if __name__ == '__main__':
    main()
