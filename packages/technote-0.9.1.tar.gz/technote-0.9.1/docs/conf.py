from documenteer.conf.guide import *

autodoc_pydantic_model_show_json = True
autodoc_pydantic_model_show_config = False
