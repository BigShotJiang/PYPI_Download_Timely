:og:description: Learn how to use technote.

##########
User guide
##########

.. toctree::
   :name: toc-config
   :maxdepth: 2
   :caption: Configuration

   configuration-overview
   configure-authors
   configure-status
   configure-sphinx
   technote-toml

.. toctree::
   :name: toc-curation
   :maxdepth: 2
   :caption: Curation

   metadata

.. toctree::
   :name: toc-theming
   :maxdepth: 2
   :caption: Theming

   theming-overview
