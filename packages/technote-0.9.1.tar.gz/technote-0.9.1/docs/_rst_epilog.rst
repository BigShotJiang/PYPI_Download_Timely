
.. Links

.. _mypy: http://www.mypy-lang.org
.. _pre-commit: https://pre-commit.com
.. _pytest: https://docs.pytest.org/en/latest/
.. _tox: https://tox.wiki/en/latest/
.. _Click: https://click.palletsprojects.com/
.. _Intersphinx: https://www.sphinx-doc.org/en/master/usage/extensions/intersphinx.html
.. _Sphinx: https://www.sphinx-doc.org/
.. _TOML: https://toml.io/en/
.. _Documenteer: https://documenteer.lsst.io/

.. Badges

.. |required| replace:: :bdg-primary-line:`Required`
.. |optional| replace:: :bdg-secondary-line:`Optional`
