"""Tests for the technote.ext module of Sphinx extensions."""
