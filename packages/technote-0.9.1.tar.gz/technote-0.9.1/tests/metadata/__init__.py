"""Tests for the technote.metadata subpackage."""
