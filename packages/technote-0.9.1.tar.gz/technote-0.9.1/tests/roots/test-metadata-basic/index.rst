######################
Metadata demonstration
######################

.. abstract::

   First paragraph of abstract.

   Second paragraph of abstract.

Section one
===========

Lorem ipsum.
