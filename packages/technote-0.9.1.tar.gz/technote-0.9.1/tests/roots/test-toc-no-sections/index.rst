###############
TOC No Sections
###############

This document doesn't have any subsections.
We're testing that the TOC can cope with this.

.. abstract::

   First paragraph of abstract.

   Second paragraph of abstract.
