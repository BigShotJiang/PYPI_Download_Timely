from technote.sphinxconf import *  # noqa: F403
