"""Bibliographic metadata interfaces."""
