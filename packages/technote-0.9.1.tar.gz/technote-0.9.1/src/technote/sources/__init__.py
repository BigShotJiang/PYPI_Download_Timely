"""Settings and metadata sources external to Sphinx."""
