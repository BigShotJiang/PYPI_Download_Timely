"""Classes for the Jinja templating context."""
