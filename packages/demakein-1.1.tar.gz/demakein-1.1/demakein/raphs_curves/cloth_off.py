# Fancy new algorithms for computing the offset of a clothoid.

