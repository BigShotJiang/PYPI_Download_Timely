
"""
Raph Levien's cornu spiral utilities
GPL
http://www.levien.com/spiro/
"""
