# waterrocketpy.legacy.Core

::: waterrocketpy.legacy.Core
