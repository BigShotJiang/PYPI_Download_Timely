# waterrocketpy.analysis.energy_breakdown_plot

::: waterrocketpy.analysis.energy_breakdown_plot
