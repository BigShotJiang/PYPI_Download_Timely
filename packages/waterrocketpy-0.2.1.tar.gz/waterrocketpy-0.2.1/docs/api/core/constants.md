# waterrocketpy.core.constants

::: waterrocketpy.core.constants
