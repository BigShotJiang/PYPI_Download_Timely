

# AirThrust:
https://www.youtube.com/watch?v=p8e8A3sdVOg&ab_channel=JoshTheEngineer
### AirThrust for water rockets:
https://www.et.byu.edu/~wheeler/benchtop/pix/thrust_eqns.pdf

# Drag:
http://ftp.demec.ufpr.br/foguete/bibliografia/TR-11%20AERODYNAMIC%20DRAG%20OF%20MODEL%20ROCKET.pdf