# Welcome to waterrocketpy


[![image](https://img.shields.io/pypi/v/waterrocketpy.svg)](https://pypi.python.org/pypi/waterrocketpy)


**A modular Python package for simulating water rockets.**


-   Free software: MIT License
-   Documentation: <https://Cube002.github.io/waterrocketpy>
    

## Features

-   TODO
