# Usage

To use waterrocketpy in a project:

```
import waterrocketpy
```
