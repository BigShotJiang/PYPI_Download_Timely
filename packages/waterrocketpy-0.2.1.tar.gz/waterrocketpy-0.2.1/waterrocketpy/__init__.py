"""Top-level package for waterrocketpy."""

__author__ = """Pablo M"""
__email__ = "pablo.marg8@gmail.com"
__version__ = "0.2.1"
