"""utils"""

__author__ = """Pablo M"""
__email__ = "pablo.marg8@gmail.com"
__version__ = "0.0.1"
