__app_name__ = "scimon"
__version__ = "0.1.1"