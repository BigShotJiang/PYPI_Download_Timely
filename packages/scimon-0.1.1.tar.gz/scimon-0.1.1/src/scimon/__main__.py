from scimon import cli


def main():
    cli.app()

if __name__ == "__main__":
    main()
