# Named Entity Recognition Task

::: openaivec.task.nlp.named_entity_recognition
    options:
      show_source: true
      show_root_heading: true
      show_root_toc_entry: true
      heading_level: 2
      members_order: source
      show_signature_annotations: true
      separate_signature: true
      show_bases: true
      show_docstring_parameters: true
      show_docstring_returns: true
      show_docstring_examples: true