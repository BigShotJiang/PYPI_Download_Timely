"""Claude Notes - Transform Claude Code transcripts to readable formats."""

__version__ = "0.1.0"
