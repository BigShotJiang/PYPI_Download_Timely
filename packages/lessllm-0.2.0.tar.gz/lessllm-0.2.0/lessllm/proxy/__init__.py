"""
Network proxy module for HTTP/SOCKS proxy support
"""

from .manager import ProxyManager

__all__ = ["ProxyManager"]