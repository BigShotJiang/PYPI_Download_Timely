"""
GUI package for LessLLM analytics visualization
"""