from camoufox.async_api import AsyncCamoufox


class Captchafox(AsyncCamoufox): ...
