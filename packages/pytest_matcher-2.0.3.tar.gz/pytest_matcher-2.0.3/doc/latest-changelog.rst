.. SPDX-FileCopyrightText: 2017-now, See ``CONTRIBUTORS.lst``
.. SPDX-License-Identifier: CC0-1.0

=============
Release Notes
=============

.. toctree::
    :maxdepth: 1

.. include:: ../ChangeLog.rst
    :start-line: 8
