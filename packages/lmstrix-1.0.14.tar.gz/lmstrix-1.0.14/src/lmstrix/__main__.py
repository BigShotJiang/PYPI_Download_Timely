"""Entry point for executing lmstrix as a module."""

from lmstrix.cli.main import main

if __name__ == "__main__":
    main()