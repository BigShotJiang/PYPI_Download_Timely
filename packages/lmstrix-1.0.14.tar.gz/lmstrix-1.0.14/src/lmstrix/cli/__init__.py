# this_file: src/lmstrix/cli/__init__.py
"""Command-line interface for LMStrix."""

__all__ = []
