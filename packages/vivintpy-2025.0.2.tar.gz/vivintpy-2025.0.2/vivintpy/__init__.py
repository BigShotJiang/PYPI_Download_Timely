"""Provide a package for vivintpy."""

__version__ = "2025.0.2"
