"""
Taskinator - A Python CLI task management tool for software development projects.
"""

__version__ = "0.2.0"
