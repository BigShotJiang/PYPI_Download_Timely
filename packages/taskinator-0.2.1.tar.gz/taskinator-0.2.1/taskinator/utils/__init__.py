"""
Utility functions for Taskinator.
"""
