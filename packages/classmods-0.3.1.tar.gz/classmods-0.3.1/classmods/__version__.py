__version__ = '0.3.1'


def get_version() -> str:
    return __version__


__all__ = [
    '__all__',
]