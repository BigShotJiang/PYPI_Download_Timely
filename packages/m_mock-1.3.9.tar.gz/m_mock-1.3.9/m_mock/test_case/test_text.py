from m_mock.m_random import m_text


def test_text():
    print(m_text.mix_sentence())