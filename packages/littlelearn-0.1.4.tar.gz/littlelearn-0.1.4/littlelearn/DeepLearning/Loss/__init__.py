from .Loss import MeanSquareError 
from .Loss import MeanAbsoluteError 
from .Loss import CaterigocallCrossentropy
from .Loss import BinaryCrossentropy 
from .Loss import HuberLoss
from .Loss import SparseCategoricallCrossentropy