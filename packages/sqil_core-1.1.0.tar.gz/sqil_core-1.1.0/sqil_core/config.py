_EXCLUDED_PACKAGES = [
    "os",
    "sys",
    "inspect",
    "np",
    "spopt",
    "lmfit",
    "h5py",
    "json",
    "tabulate",
    "matplotlib",
    "plt",
]
