# -*- coding: utf-8 -*-
from .apiresource import SingletonAPIResource


class User(SingletonAPIResource):
    pass
