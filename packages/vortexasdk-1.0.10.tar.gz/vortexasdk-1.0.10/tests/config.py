import os

SKIP_TAGS = os.getenv("SKIP_TAGS", "").split()
