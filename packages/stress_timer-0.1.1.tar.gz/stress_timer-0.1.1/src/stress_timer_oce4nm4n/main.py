# stress-timer_oce4nm4n/main.py

from .timer import main as timer_main

def main():
    timer_main()
