"""
Module to run the Tic-Tac-Toe game.
"""
from tic_tac_toe_pygame.game import TicTacToe


if __name__ == '__main__':
    game = TicTacToe()
    game.run()
