"""
A Tic-Tac-Toe game implementation using Pygame.
"""
