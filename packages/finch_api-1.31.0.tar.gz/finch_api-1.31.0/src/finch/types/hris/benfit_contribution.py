# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .benefit_contribution import BenefitContribution

__all__ = ["BenfitContribution"]

BenfitContribution = BenefitContribution
"""use `BenefitContribution` instead"""
