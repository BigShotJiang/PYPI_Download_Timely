__author__ = {
    "jackzzs": "jackzzs@outlook.com",
}
__version__ = "7.4.11"
__url__ = "https://emby-keeper.github.io"
