from . import BotCheckin

__ignore__ = True


class JohnSGKCheckin(BotCheckin):
    name = "约翰社工库"
    bot_username = "yuehanbot"
    bot_checkin_cmd = "/sign"
