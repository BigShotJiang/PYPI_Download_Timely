from . import BotCheckin

__ignore__ = True


class TestCheckin(BotCheckin):
    name = "签到测试"
    bot_username = "embykeeper_test_bot"
