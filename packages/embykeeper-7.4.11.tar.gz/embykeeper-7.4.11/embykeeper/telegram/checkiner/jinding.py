from . import BotCheckin

__ignore__ = True


class JinDingCheckin(BotCheckin):
    name = "金鼎轰炸"
    bot_username = "jdHappybot"
    bot_checkin_cmd = "/qd"
