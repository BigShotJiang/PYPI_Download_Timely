from ._templ_a import TemplateACheckin

__ignore__ = True


class HeisiCheckin(TemplateACheckin):
    name = "Heisi"
    bot_username = "HeisiheiBot"
