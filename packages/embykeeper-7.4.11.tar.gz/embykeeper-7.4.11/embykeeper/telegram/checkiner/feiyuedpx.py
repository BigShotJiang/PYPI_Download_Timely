from ._templ_a import TemplateACheckin


class FeiyueDPXCheckin(TemplateACheckin):
    name = "飞跃地平线"
    bot_username = "feiyueDPX_bot"
