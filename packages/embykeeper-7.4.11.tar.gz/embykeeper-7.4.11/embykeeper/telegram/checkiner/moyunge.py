from ._templ_a import TemplateACheckin


class MoyungeCheckin(TemplateACheckin):
    name = "墨云阁"
    bot_username = "MoYunGeBoss_bot"
