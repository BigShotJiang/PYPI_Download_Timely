from ._templ_a import TemplateACheckin

__ignore__ = True


class TheEndCheckin(TemplateACheckin):
    name = "阿甘正传"
    bot_username = "theendemby_bot"
