from ._templ_a import TemplateACheckin


class JSQCheckin(TemplateACheckin):
    name = "见手青"
    bot_username = "jsq_gy_bot"
    bot_use_captcha = False
