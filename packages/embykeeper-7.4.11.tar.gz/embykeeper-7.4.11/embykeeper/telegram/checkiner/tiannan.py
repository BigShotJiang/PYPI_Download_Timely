from ._templ_a import TemplateACheckin

__ignore__ = True


class TiannanCheckin(TemplateACheckin):
    name = "天南小筑"
    bot_username = "Nanflix_bot"
