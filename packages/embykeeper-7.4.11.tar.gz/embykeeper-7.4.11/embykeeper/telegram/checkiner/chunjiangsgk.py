from . import BotCheckin

__ignore__ = True


class ChunjiangSGKCheckin(BotCheckin):
    name = "春江社工库"
    bot_username = "ChunJiang_SGK_Bot"
    bot_checkin_cmd = "/qd"
