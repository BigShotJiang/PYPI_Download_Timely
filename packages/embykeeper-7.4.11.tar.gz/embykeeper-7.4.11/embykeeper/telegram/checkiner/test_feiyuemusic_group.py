from .feiyuemusic_group_old import FeiyueMusicGroupCheckin

__ignore__ = True


class TestFeiyueGroupCheckin(FeiyueMusicGroupCheckin):
    name = "飞跃星空群组签到测试"
    chat_name = "api_group"
