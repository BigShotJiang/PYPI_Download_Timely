from ._templ_a import TemplateACheckin


class LyrebirdCheckin(TemplateACheckin):
    name = "Lyrebird"
    bot_username = "Lyrebird_bot"
