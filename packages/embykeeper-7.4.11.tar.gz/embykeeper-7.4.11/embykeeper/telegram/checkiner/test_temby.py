from .temby import TembyCheckin

__ignore__ = True


class TestTembyCheckin(TembyCheckin):
    name = "Temby 签到测试"
    bot_username = "embykeeper_test_bot"
