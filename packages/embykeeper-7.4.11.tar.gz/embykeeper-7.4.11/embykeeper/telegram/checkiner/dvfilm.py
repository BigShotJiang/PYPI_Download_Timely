from ._templ_a import TemplateACheckin


class DVFilmCheckin(TemplateACheckin):
    name = "DVfilm"
    bot_username = "DVfilm_user_bot"
