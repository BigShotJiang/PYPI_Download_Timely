from ._templ_a import TemplateACheckin

__ignore__ = True


class HappyCheckin(TemplateACheckin):
    name = "开心服"
    bot_username = "happy_sign_bot"
