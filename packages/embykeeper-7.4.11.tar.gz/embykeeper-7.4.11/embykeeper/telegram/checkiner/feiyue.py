from ._templ_a import TemplateACheckin


class FeiyueCheckin(TemplateACheckin):
    name = "飞跃彩虹"
    bot_username = "FeiyueEmby_bot"
