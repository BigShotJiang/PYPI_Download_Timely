from ._templ_a import TemplateACheckin


class LembyCheckin(TemplateACheckin):
    name = "Lemby"
    bot_username = "LembyPremium_BOT"
