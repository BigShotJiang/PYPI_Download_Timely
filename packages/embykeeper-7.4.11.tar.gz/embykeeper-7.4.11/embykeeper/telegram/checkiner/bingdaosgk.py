from . import BotCheckin

__ignore__ = True


class BingdaoSGKCheckin(BotCheckin):
    name = "冰岛社工库"
    bot_username = "BingDaoSGKBot"
    bot_checkin_cmd = "/qd"
