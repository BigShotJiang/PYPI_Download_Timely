from ._templ_a import TemplateACheckin

__ignore__ = True


class AlphaCheckin(TemplateACheckin):
    name = "Alpha 海外服"
    bot_username = "AlphaTVOverseaBoss_bot"
