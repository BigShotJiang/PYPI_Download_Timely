from ._templ_a import TemplateACheckin


class SaturdayCheckin(TemplateACheckin):
    name = "SaturDay.Lite"
    bot_username = "saturday_lite_bot"
