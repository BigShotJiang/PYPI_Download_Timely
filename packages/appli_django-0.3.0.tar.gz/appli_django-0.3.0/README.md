# appli-django

🚀 Génère rapidement une structure complète d'application Django avec :

- `models/`, `views/`, `migrations/`
- `urls.py`, `admin.py`, `apps.py`, `tests.py`

## ✅ Installation

```bash
pip install appli-django
appli-django <nom du app>
