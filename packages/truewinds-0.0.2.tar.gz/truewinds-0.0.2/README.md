# truewinds

True winds is still in beta and requires updated docstrings, examples, and tests.

## Installation

`pip install truewinds`


## Documentation
The code truewinds is based on can be found here: https://samos.coaps.fsu.edu/html/tools_truewinds.php

The original manuscript for true winds computation can be found here: https://doi.org/10.1175/1520-0426(1999)016<0939:EMTITW>2.0.CO;2