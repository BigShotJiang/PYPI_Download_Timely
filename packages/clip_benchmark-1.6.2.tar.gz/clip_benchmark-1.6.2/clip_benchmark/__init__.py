"""Top-level package for CLIP Benchmark."""

__author__ = """Mehdi Cherti"""
__email__ = 'mehdicherti@gmail.com'
__version__ = '0.1.0'
