class NotAnAccessTokenError(Exception):
    """Exception raised when the provided token is not an access token."""

    pass
