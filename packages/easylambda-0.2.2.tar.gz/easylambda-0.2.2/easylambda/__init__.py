from .main import delete, easylambda, get, options, patch, post, put

__all__ = ["delete", "get", "easylambda", "options", "patch", "post", "put"]
