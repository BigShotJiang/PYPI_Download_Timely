# ------------------------------------------------------------------------------
# Copyright (c) Acoular Development Team.
# ------------------------------------------------------------------------------

"""Dedicated file to determine the package version without importing acoular."""

__author__ = 'Acoular Development Team'
__date__ = '24 July 2025'
__version__ = '25.07'
