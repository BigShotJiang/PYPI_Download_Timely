.. AUTHORS.rst

History
=======

This project was started in 2006 by Ennes Sarradj as non-published software and evolved over the years as it was used in several research and consultancy projects. In 2015 it was published under an open source license (BSD).

People
======

* Ennes Sarradj
* Gert Herold
* Adam Kujawski
* Tom Gensch
* Simon Jekosch
* Mikolaj Czuchaj
* Art Pelling

