====================================
opendialog
====================================

.. automodule:: mdaviz.opendialog
    :members:
    :private-members:
