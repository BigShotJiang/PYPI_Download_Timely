====================================
Main Window
====================================

.. automodule:: mdaviz.mainwindow
    :members:
    :private-members:
