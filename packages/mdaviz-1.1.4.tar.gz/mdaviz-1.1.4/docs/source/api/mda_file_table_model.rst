====================================
mda_file_table_model
====================================

.. automodule:: mdaviz.mda_file_table_model
    :members:
    :private-members:
