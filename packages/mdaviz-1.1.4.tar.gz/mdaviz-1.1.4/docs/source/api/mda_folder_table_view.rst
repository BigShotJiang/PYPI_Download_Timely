====================================
mda_folder_table_view
====================================

.. automodule:: mdaviz.mda_folder_table_view
    :members:
    :private-members:
