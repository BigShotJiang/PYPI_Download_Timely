====================================
licensedialog
====================================

.. automodule:: mdaviz.licensedialog
    :members:
    :private-members:
