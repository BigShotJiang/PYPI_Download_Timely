====================================
MDA File
====================================

.. automodule:: mdaviz.mda_file
    :members:
    :private-members:
