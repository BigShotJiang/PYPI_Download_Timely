from elrahapi.middleware import models
class LogReadModel(models.LogReadModel):
    class setting:
        from_attributes=True



