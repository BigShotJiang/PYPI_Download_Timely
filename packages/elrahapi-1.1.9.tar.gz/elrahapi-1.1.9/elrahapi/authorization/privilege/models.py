
from elrahapi.authorization.base_meta_model import MetaAuthorization


class PrivilegeModel(MetaAuthorization):
    pass








