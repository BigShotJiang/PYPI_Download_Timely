# sage_setup: distribution = sagemath-categories
from sage.data_structures.bitset import Bitset, FrozenBitset
