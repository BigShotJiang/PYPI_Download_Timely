# sage_setup: distribution = sagemath-categories
# code exports

from sage.schemes.generic.spec import Spec
from sage.schemes.generic.hypersurface import ProjectiveHypersurface, AffineHypersurface
