# sage_setup: distribution = sagemath-categories
from sage.misc.lazy_import import lazy_import

lazy_import('sage.schemes.product_projective.space', 'ProductProjectiveSpaces')
lazy_import('sage.schemes.product_projective.space', 'is_ProductProjectiveSpaces')
del lazy_import
