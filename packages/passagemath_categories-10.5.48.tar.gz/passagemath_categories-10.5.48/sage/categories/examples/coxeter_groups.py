# sage_setup: distribution = sagemath-categories
"""
Examples of Coxeter groups
"""
# temporary until someone implements an appropriate example

from . import finite_weyl_groups
Example = finite_weyl_groups.Example
