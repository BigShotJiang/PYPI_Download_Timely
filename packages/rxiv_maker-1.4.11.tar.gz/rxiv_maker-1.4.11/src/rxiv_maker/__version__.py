"""Version information for rxiv-maker."""

__version__ = "1.4.11"
__version_tuple__ = (1, 4, 11)

# Note: Docker images v1.8+ use Cairo-only processing (no browser dependencies)
# This improves cross-platform compatibility and performance
