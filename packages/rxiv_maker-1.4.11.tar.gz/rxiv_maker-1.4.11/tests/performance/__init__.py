"""Performance benchmark tests for rxiv-maker."""
