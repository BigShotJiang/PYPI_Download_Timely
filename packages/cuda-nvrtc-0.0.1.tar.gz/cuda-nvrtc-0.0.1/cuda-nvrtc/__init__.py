# Safe dummy package: cuda-nvrtc
