// This template file is filled in upon start up of the application
const importers = $$importers$$;

import daraCore from '@darajs/core';

daraCore(importers);
