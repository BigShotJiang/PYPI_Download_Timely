"""
TaskExecutor implementation for handling task parsing and execution.

This module provides the TaskExecutor class which manages the execution of
individual implementation tasks from the tasks.md file. It parses task hierarchies,
tracks completion status, and provides execution context.
"""

import re
from typing import Dict, List, Optional, Tuple

from .models import Spec, Task, TaskStatus
from .task_parser import TaskParser


class TaskExecutionContext:
    """Context information for task execution."""

    def __init__(
        self,
        spec: Spec,
        task: Task,
        requirements_content: Optional[str] = None,
        design_content: Optional[str] = None,
        tasks_content: Optional[str] = None,
    ):
        """
        Initialize task execution context.

        Args:
            spec: The specification containing the task
            task: The task to execute
            requirements_content: Content of requirements.md
            design_content: Content of design.md
            tasks_content: Content of tasks.md
        """
        self.spec = spec
        self.task = task
        self.requirements_content = requirements_content
        self.design_content = design_content
        self.tasks_content = tasks_content

    def get_referenced_requirements(self) -> List[str]:
        """Get the content of requirements referenced by this task."""
        if not self.requirements_content or not self.task.requirements_refs:
            return []

        referenced_content = []
        for ref in self.task.requirements_refs:
            # Extract requirement content based on reference
            # This is a simplified implementation - could be enhanced
            # to parse specific requirement sections
            referenced_content.append(f"Requirement {ref}")

        return referenced_content


class TaskExecutor:
    """
    Manages the execution of individual implementation tasks.

    Parses task hierarchies, tracks completion status, and provides execution
    context by combining information from all three spec documents.
    """

    # Regex patterns for parsing markdown checkbox tasks
    TASK_PATTERN = re.compile(r"^(\s*)-\s*\[([x\s-])\]\s*(\d+(?:\.\d+)*\.?)\s+(.+)$", re.MULTILINE)
    REQUIREMENTS_REF_PATTERN = re.compile(r"_Requirements:\s*([^_]+)_")
    SUB_BULLET_PATTERN = re.compile(r"^(\s+)-\s+(.+)$", re.MULTILINE)

    def __init__(self) -> None:
        """Initialize the TaskExecutor."""
        self.task_parser = TaskParser()

    def parse_tasks(self, tasks_content: str) -> List[Task]:
        """
        Parse tasks from tasks.md content using the standardized TaskParser.

        Args:
            tasks_content: Content of the tasks.md file

        Returns:
            List of parsed Task objects with hierarchy relationships
        """
        # Use the standardized TaskParser to parse TaskItem objects
        task_items = self.task_parser.parse_tasks(tasks_content)

        # Convert TaskItem objects to Task objects for backward compatibility
        tasks = []
        for task_item in task_items:
            # Convert string status to enum - handle both string and enum values
            if isinstance(task_item.status, str):
                # Map string values to enum
                status_mapping = {
                    "not_started": TaskStatus.NOT_STARTED,
                    "in_progress": TaskStatus.IN_PROGRESS,
                    "completed": TaskStatus.COMPLETED,
                }
                status = status_mapping.get(task_item.status, TaskStatus.NOT_STARTED)
            else:
                status = task_item.status

            task = Task(
                identifier=task_item.identifier,
                description=task_item.description,
                requirements_refs=task_item.requirements_refs,
                status=status,
                parent_task=task_item.parent_task,
                sub_tasks=task_item.sub_tasks[:],  # Copy the list
            )
            tasks.append(task)

        return tasks

    def _extract_requirements_refs(self, content: str, start_pos: int) -> List[str]:
        """
        Extract requirements references from the task details.

        Args:
            content: Full tasks.md content
            start_pos: Position after the task line

        Returns:
            List of requirement references
        """
        # Look for requirements reference in the next few lines after the task
        lines_to_check = content[start_pos:].split("\n")[:5]  # Check next 5 lines

        for line in lines_to_check:
            match = self.REQUIREMENTS_REF_PATTERN.search(line)
            if match:
                refs_text = match.group(1).strip()
                # Split by comma and clean up
                refs = [ref.strip() for ref in refs_text.split(",")]
                return [ref for ref in refs if ref]

        return []

    def _determine_parent_task(self, identifier: str) -> Optional[str]:
        """
        Determine parent task identifier based on task identifier.

        Args:
            identifier: Task identifier like "1.2.3"

        Returns:
            Parent task identifier or None if top-level task
        """
        # Remove trailing dot if present
        clean_id = identifier.rstrip(".")
        parts = clean_id.split(".")
        if len(parts) <= 1:
            return None

        # Parent is the identifier with the last part removed
        return ".".join(parts[:-1])

    def _build_task_hierarchy(self, tasks: List[Task], task_hierarchy: Dict[str, Task]) -> None:
        """
        Build parent-child relationships between tasks.

        Args:
            tasks: List of all tasks
            task_hierarchy: Dictionary mapping identifiers to tasks
        """
        for task in tasks:
            if task.parent_task and task.parent_task in task_hierarchy:
                parent = task_hierarchy[task.parent_task]
                parent.sub_tasks.append(task.identifier)

    def get_next_task(self, tasks: List[Task]) -> Optional[Task]:
        """
        Get the next task that should be executed.

        Args:
            tasks: List of all tasks

        Returns:
            Next task to execute or None if all tasks are complete
        """
        # First, find tasks that are not started and have no incomplete sub-tasks
        for task in tasks:
            if task.status == TaskStatus.NOT_STARTED.value:
                # Check if this task has sub-tasks
                if task.sub_tasks:
                    # Check if all sub-tasks are completed
                    sub_tasks = [t for t in tasks if t.identifier in task.sub_tasks]
                    if all(st.status == TaskStatus.COMPLETED.value for st in sub_tasks):
                        return task
                    # If sub-tasks are not all complete, skip this parent task
                    continue
                else:
                    # No sub-tasks, this task can be executed
                    return task

        # If no not-started tasks, look for in-progress tasks
        for task in tasks:
            if task.status == TaskStatus.IN_PROGRESS.value:
                return task

        return None

    def update_task_status(self, spec: Spec, task_identifier: str, status: TaskStatus) -> Dict[str, str]:
        """
        Update task status in the tasks.md content using the standardized format.

        Args:
            spec: The specification containing the task
            task_identifier: Identifier of task to update
            status: New status for the task

        Returns:
            Dictionary with updated task information

        Raises:
            ValueError: If task identifier is not found
        """
        # Read current tasks content
        tasks_path = spec.get_tasks_path()
        if not tasks_path.exists():
            raise ValueError("Tasks file does not exist")

        tasks_content = tasks_path.read_text(encoding="utf-8")

        # Parse tasks using the standardized parser
        task_items = self.task_parser.parse_tasks(tasks_content)

        # Find and update the target task
        target_task = None
        for task_item in task_items:
            if task_item.identifier == task_identifier:
                target_task = task_item
                # Update the status (convert enum to string)
                task_item.status = status.value
                break

        if not target_task:
            raise ValueError(f"Task identifier '{task_identifier}' not found")

        # Re-render the tasks using the TaskRenderer
        from .task_renderer import TaskRenderer

        renderer = TaskRenderer()
        updated_content = renderer.render_tasks(task_items)

        # Write back to file
        tasks_path.write_text(updated_content, encoding="utf-8")

        # Return task information
        return {
            "identifier": target_task.identifier,
            "description": target_task.description,
            "status": status.value,
            "requirements_refs": target_task.requirements_refs,
            "parent_task": target_task.parent_task,
            "sub_tasks": target_task.sub_tasks,
        }

    def execute_task_context(self, spec: Spec, task: Task) -> TaskExecutionContext:
        """
        Create execution context for a task by loading all spec documents.

        Args:
            spec: The specification containing the task
            task: The task to execute

        Returns:
            TaskExecutionContext with all relevant information
        """
        # Load document contents
        requirements_content = None
        design_content = None
        tasks_content = None

        try:
            if spec.get_requirements_path().exists():
                requirements_content = spec.get_requirements_path().read_text(encoding="utf-8")
        except IOError:
            pass

        try:
            if spec.get_design_path().exists():
                design_content = spec.get_design_path().read_text(encoding="utf-8")
        except IOError:
            pass

        try:
            if spec.get_tasks_path().exists():
                tasks_content = spec.get_tasks_path().read_text(encoding="utf-8")
        except IOError:
            pass

        return TaskExecutionContext(
            spec=spec,
            task=task,
            requirements_content=requirements_content,
            design_content=design_content,
            tasks_content=tasks_content,
        )

    def get_task_by_identifier(self, spec: Spec, identifier: str) -> Optional[Dict[str, str]]:
        """
        Find a task by its identifier using the standardized format.

        Args:
            spec: The specification containing the tasks
            identifier: Task identifier to find

        Returns:
            Dictionary with task information or None if not found
        """
        # Read current tasks content
        tasks_path = spec.get_tasks_path()
        if not tasks_path.exists():
            return None

        tasks_content = tasks_path.read_text(encoding="utf-8")

        # Parse tasks using the standardized parser
        task_items = self.task_parser.parse_tasks(tasks_content)

        # Find the target task
        for task_item in task_items:
            if task_item.identifier == identifier:
                return {
                    "identifier": task_item.identifier,
                    "description": task_item.description,
                    "status": task_item.status,
                    "requirements_refs": task_item.requirements_refs,
                    "parent_task": task_item.parent_task,
                    "sub_tasks": task_item.sub_tasks,
                }

        return None

    def get_task_object_by_identifier(self, spec: Spec, identifier: str) -> Optional[Task]:
        """
        Find a task by its identifier and return as Task object for backward compatibility.

        Args:
            spec: The specification containing the tasks
            identifier: Task identifier to find

        Returns:
            Task object or None if not found
        """
        # Read current tasks content
        tasks_path = spec.get_tasks_path()
        if not tasks_path.exists():
            return None

        tasks_content = tasks_path.read_text(encoding="utf-8")

        # Parse tasks using the standardized parser and convert to Task objects
        tasks = self.parse_tasks(tasks_content)

        # Find the target task
        for task in tasks:
            if task.identifier == identifier:
                return task

        return None

    def get_task_by_identifier_from_list(self, tasks: List[Task], identifier: str) -> Optional[Task]:
        """
        Find a task by its identifier from a list (backward compatibility).

        Args:
            tasks: List of tasks to search
            identifier: Task identifier to find

        Returns:
            Task with matching identifier or None if not found
        """
        for task in tasks:
            if task.identifier == identifier:
                return task
        return None

    def get_task_progress(self, tasks: List[Task]) -> Tuple[int, int]:
        """
        Calculate task progress statistics.

        Args:
            tasks: List of tasks

        Returns:
            Tuple of (completed_count, total_count)
        """
        completed = sum(1 for task in tasks if task.status == TaskStatus.COMPLETED.value)
        total = len(tasks)
        return completed, total

    def validate_task_hierarchy(self, tasks: List[Task]) -> List[str]:
        """
        Validate task hierarchy for consistency.

        Args:
            tasks: List of tasks to validate

        Returns:
            List of validation error messages
        """
        errors = []
        task_ids = {task.identifier for task in tasks}

        for task in tasks:
            # Check if parent task exists
            if task.parent_task and task.parent_task not in task_ids:
                errors.append(f"Task {task.identifier} references non-existent parent {task.parent_task}")

            # Check if sub-tasks exist
            for sub_task_id in task.sub_tasks:
                if sub_task_id not in task_ids:
                    errors.append(f"Task {task.identifier} references non-existent sub-task {sub_task_id}")

        return errors

    def get_task_dependencies(self, task: Task, all_tasks: List[Task]) -> List[Task]:
        """
        Get all tasks that must be completed before this task can be executed.

        Args:
            task: The task to check dependencies for
            all_tasks: List of all tasks

        Returns:
            List of tasks that are dependencies
        """
        dependencies = []

        # If this task has sub-tasks, they are dependencies
        for sub_task_id in task.sub_tasks:
            sub_task = self.get_task_by_identifier_from_list(all_tasks, sub_task_id)
            if sub_task:
                dependencies.append(sub_task)

        return dependencies

    def can_execute_task(self, task: Task, all_tasks: List[Task]) -> bool:
        """
        Check if a task can be executed (all dependencies are complete).

        Args:
            task: The task to check
            all_tasks: List of all tasks

        Returns:
            True if task can be executed, False otherwise
        """
        if task.status == TaskStatus.COMPLETED.value:
            return False

        dependencies = self.get_task_dependencies(task, all_tasks)
        return all(dep.status == TaskStatus.COMPLETED.value for dep in dependencies)
