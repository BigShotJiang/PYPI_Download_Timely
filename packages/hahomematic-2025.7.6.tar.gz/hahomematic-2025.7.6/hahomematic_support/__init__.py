"""Module to support hahomematic testing with a local client."""
