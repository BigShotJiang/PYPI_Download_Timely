from . import WebBrowseToolSet
from ...utils.remote import toolset_cli


toolset_cli(WebBrowseToolSet, "web-browse")
