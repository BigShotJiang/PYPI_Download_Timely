# BIDS Study Design Spreadsheet

The BIDS Study Design spreadsheet was moved to
<https://docs.google.com/spreadsheets/d/1Yd74ewWAk4roA-IBfrQuOSMNR4DPxhB9/edit#gid=1495259008>
