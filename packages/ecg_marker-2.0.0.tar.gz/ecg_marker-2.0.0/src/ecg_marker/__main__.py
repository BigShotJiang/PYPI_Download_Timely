from .ecg_marker import ecg_marker

if __name__ == "__main__":
    ecg_marker()