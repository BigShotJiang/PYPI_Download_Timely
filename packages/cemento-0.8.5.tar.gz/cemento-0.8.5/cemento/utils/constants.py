class NullTermError(ValueError):
    pass