class NoDokumentsFoundError(Exception):
    """Exception raised when Dokuments is not found."""

    pass
