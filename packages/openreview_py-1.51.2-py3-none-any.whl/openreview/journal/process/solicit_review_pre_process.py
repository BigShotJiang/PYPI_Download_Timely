def process(client, edit, invitation):
    note=edit.note