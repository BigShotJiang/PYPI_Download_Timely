"""
CLI commands package for Karma healthcare model evaluation.

This package contains all the command implementations for the CLI interface.
"""