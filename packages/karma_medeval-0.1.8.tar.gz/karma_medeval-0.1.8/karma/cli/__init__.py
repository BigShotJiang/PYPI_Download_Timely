"""
Karma CLI package for healthcare model evaluation.

This package provides a command-line interface for evaluating healthcare AI models
across multiple datasets with a user-friendly interface.
"""

__version__ = "0.1.0"