from django.apps import AppConfig

class DjangoBasicAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_basic_app'
