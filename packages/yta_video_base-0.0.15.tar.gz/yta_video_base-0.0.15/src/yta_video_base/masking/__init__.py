"""
TODO: This module has been created to
include, temporary, the functionality
related to alphascreens and greenscreens
instead of creating a new library, but
in a near future we should handle it in
a specific 'yta_video_base_masking' 
library or similar, I think.
"""