SANDBOX_BASE_URL = "https://api-m.sandbox.paypal.com"
LIVE_BASE_URL = "https://api-m.paypal.com"
ENV_SANDBOX = "sandbox"
ENV_LIVE = "live"