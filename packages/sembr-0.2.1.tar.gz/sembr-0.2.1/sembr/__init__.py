__toolname__ = __name__
__version__ = "0.2.1"
__author__ = "admk"
__license__ = "MIT"
__url__ = f"https://github.com/admk/{__name__}"
