import slack_emoji_attached.mod as mod

def main() -> None:
    mod.run()
