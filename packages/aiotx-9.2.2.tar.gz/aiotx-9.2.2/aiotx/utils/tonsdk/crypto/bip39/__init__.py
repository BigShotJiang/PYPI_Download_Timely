from ._english import words as english

__all__ = ["english"]
