"""Data types for NI Python APIs."""

from importlib.metadata import version


__version__ = version(__name__)
"""nitypes version string."""
