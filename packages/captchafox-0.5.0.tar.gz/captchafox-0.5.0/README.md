PyPI package based on camoufox with native captcha passing functions and the ability to switch to selenium_driverless (for the browser GUI) for development.

TODO:
1. Add UI for selenium_driverless
2. Add statistic data for full random browser fingerprints generating
3. Add UI for integrations capsola, 2captcha and others for passing captchas