dftlib - Python library for dynamic fault tree analysis
=======================================================

[![Build Status](https://github.com/volkm/dftlib/workflows/Build%20Test/badge.svg)](https://github.com/volkm/dftlib/actions)

### Main author:
- Matthias Volk

The development of dftlib received significant contributions from:
- Dustin Jungen
