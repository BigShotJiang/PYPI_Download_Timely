collect_ignore_glob = []
pytest_plugins = []
