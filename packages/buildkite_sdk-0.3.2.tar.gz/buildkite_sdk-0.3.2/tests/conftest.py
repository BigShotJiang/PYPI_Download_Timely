"""Unit tests configuration module."""

pytest_plugins = []
