GRAPHQL_ENDPOINT = "http://0.0.0.0:8092/graphql"
