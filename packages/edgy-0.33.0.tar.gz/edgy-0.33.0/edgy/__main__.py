from edgy.cli.cli import edgy_cli


def run_cli() -> None:
    edgy_cli()


if __name__ == "__main__":  # pragma: no cover
    run_cli()
