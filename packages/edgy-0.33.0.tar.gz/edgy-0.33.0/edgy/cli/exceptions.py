from edgy.exceptions import EdgyException


class MissingParameterException(EdgyException): ...
