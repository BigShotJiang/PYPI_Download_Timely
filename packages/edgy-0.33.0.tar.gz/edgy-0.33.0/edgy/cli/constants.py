DEFAULT_TEMPLATE_NAME = "default"
APP_PARAMETER = "--app"
DISCOVERY_PRELOADS = ["application", "app", "main", "asgi"]
COMMANDS_WITHOUT_APP = ["list-templates", "inspectdb", "init"]
