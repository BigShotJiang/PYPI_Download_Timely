The module allows to add advance payments on sales and then use them on
invoices.
