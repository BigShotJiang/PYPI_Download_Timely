from .Plate_Design import Beulnachweise_Platten
from .Ritz_Optimiert import PlateBucklingRitz