"""Version information for the Order History plugin."""

PLUGIN_VERSION = "0.5.3"
