# Auto-generated __init__.py
from . import v1

__all__ = ["v1"]
