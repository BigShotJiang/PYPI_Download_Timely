To use this module, you need to:

1. Go to the configured product web page.
2. You'll se the matrix where you can add units to the cart.

