With this module we'll be able to use the product matrix in the eCommerce so our customers can easily add products to their carts.
