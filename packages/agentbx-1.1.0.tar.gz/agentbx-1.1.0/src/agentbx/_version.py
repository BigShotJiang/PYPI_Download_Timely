"""Version information for agentbx."""

__version__ = "1.1.0"
