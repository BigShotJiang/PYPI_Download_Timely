"""System prompts for KubeMindNexus."""
