type_of_prec = dict(single="float", double="double", extended='long double')
