# Pattern 
This is the simple package to print the pattern 

## Installation 

Instal it using pip:

pip install Patterns_SIDDV26

from Pattern import (pyramid , right_angle  , left_angle)