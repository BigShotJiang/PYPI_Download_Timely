# Experimental typed finders

This generates helper classes to query data using a logical model and mapping