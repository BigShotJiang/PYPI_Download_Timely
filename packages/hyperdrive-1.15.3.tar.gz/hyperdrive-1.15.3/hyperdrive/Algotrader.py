class HyperDrive:
    # HyperDrive should have attrs Broker, Backtester, Strategy

    def __init__(self):
        pass


# HyperDrive(load=True).save_symbols()
