"""Update command for deepctl."""

from .command import UpdateCommand

__all__ = ["UpdateCommand"]
