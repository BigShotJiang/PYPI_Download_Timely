"""E2B runtime implementation.

This runtime reads configuration directly from environment variables:
- E2B_API_KEY: API key for E2B authentication
"""