#!/usr/bin/env python
"""Build script for VSCode extension."""

import sys

# This is a placeholder build script
# The actual VSCode extension build would happen here
print("Skipping VSCode extension build...")
sys.exit(0)