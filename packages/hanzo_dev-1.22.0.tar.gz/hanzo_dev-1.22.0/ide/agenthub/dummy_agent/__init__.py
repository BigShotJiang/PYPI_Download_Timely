from ide.agenthub.dummy_agent.agent import DummyAgent
from ide.controller.agent import Agent

Agent.register('DummyAgent', DummyAgent)
