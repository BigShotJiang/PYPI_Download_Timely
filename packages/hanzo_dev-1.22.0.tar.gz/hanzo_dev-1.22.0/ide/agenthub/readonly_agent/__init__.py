from ide.agenthub.readonly_agent.readonly_agent import ReadOnlyAgent
from ide.controller.agent import Agent

Agent.register('ReadOnlyAgent', ReadOnlyAgent)
