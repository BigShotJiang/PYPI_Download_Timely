from ide.agenthub.loc_agent.loc_agent import LocAgent
from ide.controller.agent import Agent

Agent.register('LocAgent', LocAgent)
