from ide.agenthub.browsing_agent.browsing_agent import BrowsingAgent
from ide.controller.agent import Agent

Agent.register('BrowsingAgent', BrowsingAgent)
