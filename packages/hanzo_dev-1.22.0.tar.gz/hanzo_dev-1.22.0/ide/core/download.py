# Run this file to trigger a model download
import ide.agenthub  # noqa F401 (we import this to get the agents registered)
