"""
MCP Proxy module for IDE.
"""

from ide.runtime.mcp.proxy.manager import MCPProxyManager

__all__ = ['MCPProxyManager']
