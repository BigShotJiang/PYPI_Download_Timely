"""
CLI Runtime implementation for IDE.
"""

from ide.runtime.impl.cli.cli_runtime import CLIRuntime

__all__ = ['CLIRuntime']
