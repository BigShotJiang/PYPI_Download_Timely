from ide.runtime.browser.utils import browse

__all__ = ['browse']
