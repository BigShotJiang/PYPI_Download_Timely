class TraffyAPIError(Exception):
    """Base exception for TraffyAPI errors."""
    pass
