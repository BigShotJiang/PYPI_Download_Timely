## Fixes

- Fixed pydantic validation error for post description field
- Fixed python versions in GitHub CI
