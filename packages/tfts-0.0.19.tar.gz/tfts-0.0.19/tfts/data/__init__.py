"""tfts data"""

from .get_data import get_air_passengers, get_data, get_sine
from .timeseries import TimeSeriesSequence
