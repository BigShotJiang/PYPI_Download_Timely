from abc import ABC, abstractmethod


class BaseTask(ABC):
    """Base task for tfts task."""
