"""
`ForecastPFN: Synthetically-Trained Zero-Shot Forecasting
<https://arxiv.org/abs/2311.01933>`_
"""
