"""Two stage features, like ratio, diff"""

import logging

from .registry import FeatureRegistry, registry

logger = logging.getLogger(__name__)


def add_2order_feature():
    return
