from agentica.model.nvidia.chat import NvidiaChat
