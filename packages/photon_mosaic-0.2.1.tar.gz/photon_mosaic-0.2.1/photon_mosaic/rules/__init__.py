"""
Rules module for photon-mosaic.

This module contains the rules for running preprocessing and Suite2P.
"""
