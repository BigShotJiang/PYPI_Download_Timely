"""Init lib to call/import module directly."""

from .choice_base import Choice

__all__ = ["Choice"]
