// This file will export middleware as the application grows
module.exports = {
  // Add your middleware here
};
