# Bootcamp module

These are the initial configs and python functions used for the bootcamp.
[Docs](https://docs.cdf-bootcamp.cogniteapp.com/)
[Repo](https://github.com/cognitedata/cognite-data-fusion-bootcamp)
