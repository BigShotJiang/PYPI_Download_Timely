## cdf 

### Added

- [alpha] All profile commands, `cdf profile` now has an
`--output-spreadsheet` option for writing the profiling table to a
spreadsheet.

## templates

No changes.