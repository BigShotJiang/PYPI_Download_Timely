#!/usr/bin/env python3

# Copyright 2025 Broadcom.
# SPDX-License-Identifier: Apache-2.0

from setuptools import setup

if __name__ == "__main__":
    setup(include_package_data=True)
