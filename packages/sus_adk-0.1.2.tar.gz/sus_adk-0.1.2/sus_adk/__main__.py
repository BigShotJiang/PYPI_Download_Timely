def main():
    print("sus-adk CLI")
    print("This is a modular sus-adk for LLM interaction via cookies.")
    print("See documentation for usage examples.")

if __name__ == "__main__":
    main() 