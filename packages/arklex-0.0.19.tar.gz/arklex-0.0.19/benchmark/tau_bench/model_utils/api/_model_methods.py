MODEL_METHODS: list[str] = [
    "classify",
    "binary_classify",
    "parse",
    "generate",
    "parse_force",
    "score",
]
