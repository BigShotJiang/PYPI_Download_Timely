.. Libinsdb documentation master file, created by
   sphinx-quickstart on Wed Aug  9 12:55:46 2023.

Welcome to Libinsdb's documentation!
====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   introduction
   installation
   tutorial
   reference

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
