---
name: Documentation Issue
about: 'An issue pertaining to the documentation. '
title: ''
labels: documentation
assignees: ''

---

**Describe the issue**
<!--- Is it a typo, or something that is missing from the documentation, etc. -->

**Link to the page and section containing the issue, if applicable**
<!--- URL to the page and section with the issue -->

**Suggested content or correction, if applicable**
<!--- What would you suggest needs to be there, if anything. -->
