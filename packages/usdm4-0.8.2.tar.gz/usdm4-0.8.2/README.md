# USDM4

Library for USDM Version 4

# Build Package

Build steps for deployment to pypi.org

- Build with `python3 -m build --sdist --wheel`
- Upload to pypi.org using `twine upload dist/*`
