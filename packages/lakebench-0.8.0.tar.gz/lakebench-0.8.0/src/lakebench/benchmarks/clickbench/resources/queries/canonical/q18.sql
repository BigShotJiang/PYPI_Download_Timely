SELECT
    UserID,
    SearchPhrase,
    COUNT(*)
FROM
    hits
GROUP BY
    UserID,
    SearchPhrase
LIMIT
    10;