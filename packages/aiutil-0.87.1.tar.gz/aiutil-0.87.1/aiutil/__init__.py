"""A utils Python package for data scientists."""

__version__ = "0.87.1"
