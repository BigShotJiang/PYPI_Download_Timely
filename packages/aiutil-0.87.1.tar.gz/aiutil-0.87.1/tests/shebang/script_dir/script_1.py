#!/usr/bin/env python3


def f():
    pass
