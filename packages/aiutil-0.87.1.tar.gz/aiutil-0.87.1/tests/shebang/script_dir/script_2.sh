#!/bin/bash

if [[ -f ~/.bashrc ]]; then
    echo exist
fi
