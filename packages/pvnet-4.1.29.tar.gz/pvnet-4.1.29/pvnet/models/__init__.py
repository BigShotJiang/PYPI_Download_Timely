"""Models for PVNet"""
