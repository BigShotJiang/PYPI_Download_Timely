from pydantic.networks import UrlConstraints as _UC


class UrlConstraints(_UC):
    """Alias for pydantic.UrlConstraints."""

    pass
