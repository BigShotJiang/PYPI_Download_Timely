from pydantic import PrivateAttr as _PrivateAttr

PrivateAttr = _PrivateAttr