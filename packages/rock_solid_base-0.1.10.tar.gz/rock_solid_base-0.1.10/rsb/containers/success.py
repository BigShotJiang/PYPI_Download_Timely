from rsb.containers.result import Result


class Success[T_Success](Result[T_Success, Exception]): ...
