from enum import Enum

NODES_REQUEST_LIMIT         = 20



