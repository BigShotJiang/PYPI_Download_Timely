# BeamLogger package
from .beamlogger import BeamLogger

__version__ = '0.1.2'  # Updated version
__author__ = 'Bhaskar'

# Crafted With <3 By Bhaskar 