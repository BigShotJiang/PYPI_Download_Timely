# PraisonAI Package

This is the PraisonAI package, which serves as a wrapper for PraisonAIAgents.

It provides a simple and intuitive interface for working with AI agents and their capabilities.

## Directory Structure

The main package code is located in the `praisonai` subdirectory.
