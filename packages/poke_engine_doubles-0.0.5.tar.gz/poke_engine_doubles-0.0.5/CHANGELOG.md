# Changelog

## [v0.0.5](https://github.com/pmariglia/poke-engine-doubles/releases/tag/v0.0.5) - 2025-07-27

### Performance

- Until 50x visits per option are done, choose iteratively - ([8d0f85c](https://github.com/pmariglia/poke-engine-doubles/commit/8d0f85cbe85bd538a773fe92d62a51b127103fbb))

## [v0.0.3](https://github.com/pmariglia/poke-engine-doubles/releases/tag/v0.0.3) - 2025-07-27

### Features
- Python bindings refactor

## [v0.0.0](https://github.com/pmariglia/poke-engine-doubles/releases/tag/v0.0.0) - 2025-04-21

### Features

- Doubles lol