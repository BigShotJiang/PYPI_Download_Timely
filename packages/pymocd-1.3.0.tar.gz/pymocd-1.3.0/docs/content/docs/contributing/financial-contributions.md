---
weight: 1910
title: "Financial Contributions"
icon: paid
description: "Help support the pymocd development team by becoming a financial contributor."
lead: "Help support the pymocd development team by becoming a financial contributor."
date: 2022-10-19T07:07:38+01:00
lastmod: 2022-10-19T07:07:38+01:00
draft: false
images: []
toc: true
---

## Make a Donation!

Have I helped you with a project, or have any tools I've developed helped you in any way? Consider **buying me a coffee** and supporting monetary decentralization! :)

#### Monero (XMR)

XMR is a privacy-focused cryptocurrency that keeps transactions confidential. Donations are received in XMR, so if you use the wallet address below, you’ll be sending Monero directly.


```text
45Fm24G4wdzRvfzMBJeEav4A2euBUDRSE2UhGaeRXzSoBktc5bvmQsua8fAuxZqN4Eb1dXRcaJRt95b4Kma77QrELPkhtXV
```

## Thanks :green_heart:

Thanks for your contribution!
