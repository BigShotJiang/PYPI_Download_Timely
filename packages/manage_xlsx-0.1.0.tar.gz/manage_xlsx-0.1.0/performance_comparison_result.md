## Performance Comparison: openpyxl vs manage-xlsx

| Operation | openpyxl (seconds) | manage-xlsx (seconds) |
|---|---|---|
| create | 0.002868 | 0.000868 |
| write | 0.033283 | 0.653821 |
| save | 0.115038 | 0.056196 |
| load | 0.158525 | 0.051237 |
| read | 0.006609 | 0.957591 |
