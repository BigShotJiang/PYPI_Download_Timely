"""
Geometric Constants
"""

import numpy as np

DEFAULT_MARGIN_ANGLE_ERROR = np.pi / 50
