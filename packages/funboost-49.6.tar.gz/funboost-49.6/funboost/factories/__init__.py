# -*- coding: utf-8 -*-
# @Author  : ydf
# @Time    : 2022/8/8 0008 13:17

"""
工厂模式，通过broker_kind来生成不同中间件类型的消费者和发布者。
"""