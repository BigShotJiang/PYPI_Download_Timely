# arXiv Alert Bot

Get Telegram alerts for new high-impact papers on your research topic.

## Setup
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
