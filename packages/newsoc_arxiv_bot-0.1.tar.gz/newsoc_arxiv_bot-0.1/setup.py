from setuptools import setup

setup(
    name="newsoc-arxiv-bot",
    version="0.1",
    scripts=["arxiv_alert.py"],
)
