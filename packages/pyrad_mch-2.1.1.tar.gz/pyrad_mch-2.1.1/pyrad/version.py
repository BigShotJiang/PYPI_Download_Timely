
# THIS FILE IS GENERATED FROM PYRAD_PROC SETUP.PY
short_version = '2.1.1'
version = '2.1.1'
full_version = '2.1.1'
git_revision = '8ef3e1d8393abf1ed183261ef91febe7795c1a6b'
compile_date_time = '2025-07-24 08:40'
username = 'runner'
release = True

if not release:
    version = full_version
