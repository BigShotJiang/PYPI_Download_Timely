# Auto-generated __init__.py
from . import vector_db_pb2, vector_db_pb2_grpc

__all__ = ["vector_db_pb2", "vector_db_pb2_grpc"]
