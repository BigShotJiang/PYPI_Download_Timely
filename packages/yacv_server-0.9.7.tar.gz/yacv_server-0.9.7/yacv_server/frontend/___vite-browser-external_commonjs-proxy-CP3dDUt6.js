import{bR as e}from"./index-DOwMiaD3.js";const t={},r=Object.freeze(Object.defineProperty({__proto__:null,default:t},Symbol.toStringTag,{value:"Module"})),a=e(r);export{a as r};
//# sourceMappingURL=___vite-browser-external_commonjs-proxy-CP3dDUt6.js.map
