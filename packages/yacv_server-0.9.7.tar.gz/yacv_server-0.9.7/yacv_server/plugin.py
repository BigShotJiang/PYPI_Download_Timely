# TODO(if there is interest): Plugins that can freely modify the GLTF file as it is being built
