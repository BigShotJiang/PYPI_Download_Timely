from uvy.cli.cli import cli


def main():
    """Entry point for the uvy CLI."""
    cli()
