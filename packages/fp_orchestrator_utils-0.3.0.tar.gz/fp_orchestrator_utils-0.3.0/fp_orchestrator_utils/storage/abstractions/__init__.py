from .base import BaseStorage

__all__ = [
    'BaseStorage',
]