"""Voice-specific features and detection"""

from voxstream.voice.vad import VADetector, VoiceState

__all__ = ["VADetector", "VoiceState"]