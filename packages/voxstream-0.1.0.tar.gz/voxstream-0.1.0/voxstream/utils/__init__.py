"""Utility functions and helpers"""

__all__ = []