# Example: Spatial Population Dynamics

*FIXME migrate code to pydiffsol*
