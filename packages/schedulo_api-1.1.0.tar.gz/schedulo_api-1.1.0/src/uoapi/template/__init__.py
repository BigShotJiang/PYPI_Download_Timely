
from uoapi.template import code
from uoapi.template.cli import (parser, cli, main as py_cli, 
    help as cli_help, description as cli_description, epilog as cli_epilog
)
