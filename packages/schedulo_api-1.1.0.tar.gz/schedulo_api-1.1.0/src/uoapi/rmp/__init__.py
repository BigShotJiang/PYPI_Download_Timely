
from uoapi.rmp.rate_my_prof import get_teachers_ratings_by_school
from uoapi.rmp.cli import (parser, cli, main as py_cli, 
    help as cli_help, description as cli_description, epilog as cli_epilog
)
