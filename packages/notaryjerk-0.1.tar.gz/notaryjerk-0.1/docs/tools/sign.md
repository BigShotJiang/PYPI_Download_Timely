sign
====

!!! Error
    Code signing is not yet implemented in `notaryjerk` yet!


For now, you have to manually use the `codesign` cmdline tool, that comes with *XCode* ¯\\_(ツ)_/¯.
