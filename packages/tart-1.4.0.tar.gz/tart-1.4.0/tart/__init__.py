# Top level file for the TART radio-telescope utilities module
# Tim Molteno 2013. tim@elec.ac.nz
#
#
VERSION = "1.3.1"
# import operation
# import simulation
# import imaging
