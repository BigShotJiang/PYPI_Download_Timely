
import enum

class AxisScale(enum.Enum):
    LINEAR = enum.auto()
    LOG = enum.auto()
