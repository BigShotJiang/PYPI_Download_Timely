import importlib.metadata


__version__ = importlib.metadata.version("ezmsg-panel")
