# -*- coding: utf-8 -*-


from test_holado.steps.public_steps import *

# Note: following lines are commented since, with this example files architecture, these steps are automatically found and imported by behave
# from steps.config_steps import *



