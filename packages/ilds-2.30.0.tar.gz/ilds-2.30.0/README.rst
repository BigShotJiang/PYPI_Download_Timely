====================
ilds
====================

**ilds** 是一个常用模块的集合，为了多平台，多电脑调用方便

功能模块包含:

* 获取文件md5
* 处理文件内容

安装：
-------------
pip install -U ilds


简单的例子:
-------------

.. code-block:: python

   import ilds

   from lds.file import is_file



查看 `更改日志 <https://github.com/ldsxp/ilds/blob/master/CHANGELOG.md>`__

