from collections import UserDict


class Macros(UserDict):
    pass
