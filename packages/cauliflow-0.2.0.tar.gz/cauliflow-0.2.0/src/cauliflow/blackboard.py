from collections import UserDict


class BlackBoard(UserDict):
    pass
