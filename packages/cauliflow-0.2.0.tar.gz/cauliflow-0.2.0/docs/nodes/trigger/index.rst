Trigger Nodes
=======================

.. toctree::
   :maxdepth: 1

   camonitor
   scheduler
   interval
