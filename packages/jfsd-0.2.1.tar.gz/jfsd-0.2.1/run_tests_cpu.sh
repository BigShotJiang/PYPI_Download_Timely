#!/bin/bash

# Run pytest on the jfsd package
JAX_PLATFORMS=cpu pytest tests/test_class_cpu.py
