"""Utilities for the API to MCP Generator library."""
