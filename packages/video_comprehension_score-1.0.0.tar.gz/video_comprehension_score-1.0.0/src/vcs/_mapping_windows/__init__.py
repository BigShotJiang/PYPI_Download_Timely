from ._mapping_windows import _get_mapping_windows

__all__ = [
    "_get_mapping_windows"
]