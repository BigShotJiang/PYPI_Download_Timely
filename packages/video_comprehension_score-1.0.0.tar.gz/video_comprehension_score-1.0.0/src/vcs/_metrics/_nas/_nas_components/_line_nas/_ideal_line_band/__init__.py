from ._ideal_line_band import _compute_ideal_narrative_line_band

__all__ = ["_compute_ideal_narrative_line_band"]