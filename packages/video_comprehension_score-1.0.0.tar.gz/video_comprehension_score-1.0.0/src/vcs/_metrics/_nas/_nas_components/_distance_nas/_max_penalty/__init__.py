from ._max_penalty import calculate_max_penalty

__all__ = ["calculate_max_penalty"]