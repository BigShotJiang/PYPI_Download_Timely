Read more about the protobuf definitions [here](https://github.com/abc8747/fr24/blob/master/src/fr24/proto/README.md).

::: fr24.proto
    options:
        show_if_no_docstring: true
        filters:
            - "!_*_pb2"
::: fr24.proto.v1_pb2
    options:
        show_if_no_docstring: true
        filters:
            - "!DESCRIPTOR"
            - "!_FIELD_NUMBER$"
            - "!_sym_db"
            - "!_globals"