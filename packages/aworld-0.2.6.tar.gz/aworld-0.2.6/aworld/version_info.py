# auto generated
class VersionInfo:
    BUILD_DATE = "2025-07-24 12:15:11"
    BUILD_VERSION = "0.2.6"
    BUILD_USER = "ganrunsheng" 
    SCENARIO = "AWORLD_SDIST"
