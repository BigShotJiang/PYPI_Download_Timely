
# auto generated
class VersionInfo(object):
    @property
    def build_date(self):
      return "2025-07-24 12:15:11"

    @property
    def version(self):
      return "0.2.6"

    @property
    def build_user(self):
      return "gain"
