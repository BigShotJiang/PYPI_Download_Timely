# Safe dummy package: lcms2
