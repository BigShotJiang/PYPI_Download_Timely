# Changelog

## 0.1.0-beta.3 (2025-07-25)

Full Changelog: [v0.1.0-beta.2...v0.1.0-beta.3](https://github.com/digitalocean/gradientai-python/compare/v0.1.0-beta.2...v0.1.0-beta.3)

### Bug Fixes

* **parsing:** parse extra field types ([93bea71](https://github.com/digitalocean/gradientai-python/commit/93bea71735195fa3f32de6b64bbc0aaac60a6d6c))


### Chores

* **project:** add settings file for vscode ([3b597aa](https://github.com/digitalocean/gradientai-python/commit/3b597aa96e1f588506de47d782444992383f5522))
* update README with new gradient name ([03157fb](https://github.com/digitalocean/gradientai-python/commit/03157fb38616c68568024ab7e426b45d414bf432))

## 0.1.0-beta.2 (2025-07-22)

Full Changelog: [v0.1.0-beta.1...v0.1.0-beta.2](https://github.com/digitalocean/gradientai-python/compare/v0.1.0-beta.1...v0.1.0-beta.2)

### Bug Fixes

* **parsing:** ignore empty metadata ([cee9728](https://github.com/digitalocean/gradientai-python/commit/cee9728fd727cd600d2ac47ead9206ca937f7757))


### Chores

* **internal:** version bump ([e13ccb0](https://github.com/digitalocean/gradientai-python/commit/e13ccb069743fc6ebc56e0bb0463ff11864ad944))
* **internal:** version bump ([00ee94d](https://github.com/digitalocean/gradientai-python/commit/00ee94d848ae5c5fc4604160c822e4757c4e6de8))
* **types:** rebuild Pydantic models after all types are defined ([db7d61c](https://github.com/digitalocean/gradientai-python/commit/db7d61c02df9f86af9170d38539257e9cbf3eff9))

## 0.1.0-beta.1 (2025-07-21)

Full Changelog: [v0.1.0-alpha.19...v0.1.0-beta.1](https://github.com/digitalocean/gradientai-python/compare/v0.1.0-alpha.19...v0.1.0-beta.1)

### Features

* **api:** manual updates ([fda6270](https://github.com/digitalocean/gradientai-python/commit/fda62708a8f4d4fd66187edd54b39336b88a7e1c))
* **api:** manual updates ([7548648](https://github.com/digitalocean/gradientai-python/commit/75486489df49297376fe0bcff70f1e527764b64d))


### Chores

* **internal:** version bump ([be22c3d](https://github.com/digitalocean/gradientai-python/commit/be22c3d8c9835b45643d5e91db093108cb03f893))
* **internal:** version bump ([2774d54](https://github.com/digitalocean/gradientai-python/commit/2774d540184f8ca7d401c77eaa69a52f62e8514b))
* **internal:** version bump ([44abb37](https://github.com/digitalocean/gradientai-python/commit/44abb37d897dc77c1fda511b195cc9297fd324ac))
* **internal:** version bump ([981ba17](https://github.com/digitalocean/gradientai-python/commit/981ba17925e46a9f87a141a481645711fbb6bb6e))

## 0.1.0-alpha.19 (2025-07-19)

Full Changelog: [v0.1.0-alpha.18...v0.1.0-alpha.19](https://github.com/digitalocean/gradientai-python/compare/v0.1.0-alpha.18...v0.1.0-alpha.19)

### Features

* **api:** manual updates ([2c36a8b](https://github.com/digitalocean/gradientai-python/commit/2c36a8be83bb24025adf921c24acba3d666bf25d))


### Chores

* **internal:** version bump ([2864090](https://github.com/digitalocean/gradientai-python/commit/2864090c0af4858e4bee35aef2113e6983cfdca4))

## 0.1.0-alpha.18 (2025-07-19)

Full Changelog: [v0.1.0-alpha.17...v0.1.0-alpha.18](https://github.com/digitalocean/gradientai-python/compare/v0.1.0-alpha.17...v0.1.0-alpha.18)

### Features

* **api:** manual updates ([92d54ed](https://github.com/digitalocean/gradientai-python/commit/92d54edfff94931f10fb8dac822764edf6fca6bd))
* **api:** manual updates ([688982c](https://github.com/digitalocean/gradientai-python/commit/688982c143e0ebca62f6ac39c1e074a2fd4083fc))


### Chores

* **internal:** version bump ([ecb4bae](https://github.com/digitalocean/gradientai-python/commit/ecb4baedce933efc4ae99e0ef47100a02a68c9cd))
* **internal:** version bump ([feb32ce](https://github.com/digitalocean/gradientai-python/commit/feb32ce78b107e9414be87e8c34d8c3274105cb4))
* update pypi package name ([656dfe0](https://github.com/digitalocean/gradientai-python/commit/656dfe01d8e301dd1f93b3fa447434e6a5b41270))

## 0.1.0-alpha.17 (2025-07-19)

Full Changelog: [v0.1.0-alpha.16...v0.1.0-alpha.17](https://github.com/digitalocean/gradientai-python/compare/v0.1.0-alpha.16...v0.1.0-alpha.17)

### Chores

* **internal:** version bump ([bc0b77b](https://github.com/digitalocean/gradientai-python/commit/bc0b77b663dc5837a2e341b70b1cda31224a6d9d))
* **internal:** version bump ([503666f](https://github.com/digitalocean/gradientai-python/commit/503666fa61c23e584a22273371850f520100984a))
* **internal:** version bump ([394991e](https://github.com/digitalocean/gradientai-python/commit/394991e1f436ac2fa3581a3e1bab02e8a95f94b9))
* **internal:** version bump ([7ae18a1](https://github.com/digitalocean/gradientai-python/commit/7ae18a15cc889c8b0ffe5879824745e964cdd637))

## 0.1.0-alpha.16 (2025-07-18)

Full Changelog: [v0.1.0-alpha.15...v0.1.0-alpha.16](https://github.com/digitalocean/gradientai-python/compare/v0.1.0-alpha.15...v0.1.0-alpha.16)

### Chores

* **internal:** version bump ([02f1f68](https://github.com/digitalocean/gradientai-python/commit/02f1f686505028155ee2a4cf670794117ce7981a))

## 0.1.0-alpha.15 (2025-07-18)

Full Changelog: [v0.1.0-alpha.14...v0.1.0-alpha.15](https://github.com/digitalocean/gradientai-python/compare/v0.1.0-alpha.14...v0.1.0-alpha.15)

### Features

* **api:** add gpu droplets ([b207e9a](https://github.com/digitalocean/gradientai-python/commit/b207e9a69ddf821522f5d9e9f10502850220585f))
* **api:** add gpu droplets ([b9e317b](https://github.com/digitalocean/gradientai-python/commit/b9e317bac2c541a7eafcfb59a4b19c81e1145075))


### Chores

* format ([d940e66](https://github.com/digitalocean/gradientai-python/commit/d940e66107e00f351853c0bc667ca6ed3cf98605))
* **internal:** version bump ([1a66126](https://github.com/digitalocean/gradientai-python/commit/1a661264f68580dff74c3f7d4891ab2661fde190))
* **internal:** version bump ([9c546a1](https://github.com/digitalocean/gradientai-python/commit/9c546a1f97241bb448430e1e43f4e20589e243c1))
* **internal:** version bump ([8814098](https://github.com/digitalocean/gradientai-python/commit/881409847161671b798baf2c89f37ae29e195f29))
* **internal:** version bump ([bb3ad60](https://github.com/digitalocean/gradientai-python/commit/bb3ad60d02fe01b937eaced64682fd66d95a9aec))
* **internal:** version bump ([2022024](https://github.com/digitalocean/gradientai-python/commit/20220246634accf95c4a53df200db5ace7107c55))
* **internal:** version bump ([52e2c23](https://github.com/digitalocean/gradientai-python/commit/52e2c23c23d4dc27c176ebf4783c8fbd86a4c07b))
* **internal:** version bump ([8ac0f2a](https://github.com/digitalocean/gradientai-python/commit/8ac0f2a6d4862907243ba78b132373289e2c3543))
* **internal:** version bump ([d83fe97](https://github.com/digitalocean/gradientai-python/commit/d83fe97aa2f77c84c3c7f4bf40b9fb94c5c28aca))
* **internal:** version bump ([9d20399](https://github.com/digitalocean/gradientai-python/commit/9d2039919e1d9c9e6d153edfb03bccff18b56686))
* **internal:** version bump ([44a045a](https://github.com/digitalocean/gradientai-python/commit/44a045a9c0ce0f0769cce66bc7421a9d81cbc645))
* **internal:** version bump ([95d1dd2](https://github.com/digitalocean/gradientai-python/commit/95d1dd24d290d7d5f23328e4c45c439dca5df748))
* **internal:** version bump ([7416147](https://github.com/digitalocean/gradientai-python/commit/74161477f98e3a76b7227b07d942e1f26a4612b3))
* **internal:** version bump ([06d7f19](https://github.com/digitalocean/gradientai-python/commit/06d7f19cd42a6bc578b39709fe6efed8741a24bc))

## 0.1.0-alpha.14 (2025-07-17)

Full Changelog: [v0.1.0-alpha.13...v0.1.0-alpha.14](https://github.com/digitalocean/gradientai-python/compare/v0.1.0-alpha.13...v0.1.0-alpha.14)

### Features

* **api:** update via SDK Studio ([6cdcc6a](https://github.com/digitalocean/gradientai-python/commit/6cdcc6a36b9dde2117295ee7bcb9a3bc15571779))
* **api:** update via SDK Studio ([5475a94](https://github.com/digitalocean/gradientai-python/commit/5475a9460676d1c48e99e0d1e75e50de7caecf3a))
* dynamically build domain for agents.chat.completions.create() ([dee4ef0](https://github.com/digitalocean/gradientai-python/commit/dee4ef07ebb3367abc7f05c15271d43ab57e2081))
* dynamically build domain for agents.chat.completions.create() ([3dbd194](https://github.com/digitalocean/gradientai-python/commit/3dbd194643e31907a78ab7e222e95e7508378ada))


### Bug Fixes

* add /api prefix for agent routes ([00c62b3](https://github.com/digitalocean/gradientai-python/commit/00c62b35f3a29ea8b6e7c96b2e755e6b5199ae55))
* add /api prefix for agent routes ([72a59db](https://github.com/digitalocean/gradientai-python/commit/72a59db98ebeccdf0c4498f6cce37ffe1cb198dd))
* fix validation for inference_key and agent_key auth ([d27046d](https://github.com/digitalocean/gradientai-python/commit/d27046d0c1e8214dd09ab5508e4fcb11fa549dfe))


### Chores

* **internal:** version bump ([f3629f1](https://github.com/digitalocean/gradientai-python/commit/f3629f169267f240aeb2c4d400606761a649dff7))

## 0.1.0-alpha.13 (2025-07-15)

Full Changelog: [v0.1.0-alpha.12...v0.1.0-alpha.13](https://github.com/digitalocean/gradientai-python/compare/v0.1.0-alpha.12...v0.1.0-alpha.13)

### Features

* **api:** manual updates ([bd6fecc](https://github.com/digitalocean/gradientai-python/commit/bd6feccf97fa5877085783419f11dad04c57d700))
* **api:** manual updates ([c2b96ce](https://github.com/digitalocean/gradientai-python/commit/c2b96ce3d95cc9b74bffd8d6a499927eefd23b14))
* **api:** share chat completion chunk model between chat and agent.chat ([d67371f](https://github.com/digitalocean/gradientai-python/commit/d67371f9f4d0761ea03097820bc3e77654b4d2bf))
* clean up environment call outs ([64ee5b4](https://github.com/digitalocean/gradientai-python/commit/64ee5b449c0195288d0a1dc55d2725e8cdd6afcf))


### Bug Fixes

* **client:** don't send Content-Type header on GET requests ([507a342](https://github.com/digitalocean/gradientai-python/commit/507a342fbcc7c801ba36708e56ea2d2a28a1a392))
* **parsing:** correctly handle nested discriminated unions ([569e473](https://github.com/digitalocean/gradientai-python/commit/569e473d422928597ccf762133d5e52ac9a8665a))


### Chores

* **internal:** bump pinned h11 dep ([6f4e960](https://github.com/digitalocean/gradientai-python/commit/6f4e960b6cb838cbf5e50301375fcb4b60a2cfb3))
* **internal:** codegen related update ([1df657d](https://github.com/digitalocean/gradientai-python/commit/1df657d9b384cb85d27fe839c0dab212a7773f8f))
* **package:** mark python 3.13 as supported ([1a899b6](https://github.com/digitalocean/gradientai-python/commit/1a899b66a484986672a380e405f09b1ae94b6310))
* **readme:** fix version rendering on pypi ([6fbe83b](https://github.com/digitalocean/gradientai-python/commit/6fbe83b11a9e3dbb40cf7f9f627abbbd086ee24a))

## 0.1.0-alpha.12 (2025-07-02)

Full Changelog: [v0.1.0-alpha.11...v0.1.0-alpha.12](https://github.com/digitalocean/gradientai-python/compare/v0.1.0-alpha.11...v0.1.0-alpha.12)

### Bug Fixes

* **ci:** correct conditional ([646b4c6](https://github.com/digitalocean/gradientai-python/commit/646b4c62044c9bb5211c50e008ef30c777715acb))


### Chores

* **ci:** change upload type ([7449413](https://github.com/digitalocean/gradientai-python/commit/7449413efc16c58bc484f5f5793aa9cd36c3f405))
* **internal:** codegen related update ([434929c](https://github.com/digitalocean/gradientai-python/commit/434929ce29b314182dec1542a3093c98ca0bb24a))

## 0.1.0-alpha.11 (2025-06-28)

Full Changelog: [v0.1.0-alpha.10...v0.1.0-alpha.11](https://github.com/digitalocean/gradientai-python/compare/v0.1.0-alpha.10...v0.1.0-alpha.11)

### Features

* **api:** manual updates ([8d918dc](https://github.com/digitalocean/gradientai-python/commit/8d918dcc45f03d799b3aed4e94276086e2d7ea9b))


### Chores

* **ci:** only run for pushes and fork pull requests ([adfb5b5](https://github.com/digitalocean/gradientai-python/commit/adfb5b51149f667bf9a0b4b4c4c6418e91f843d8))
* Move model providers ([8d918dc](https://github.com/digitalocean/gradientai-python/commit/8d918dcc45f03d799b3aed4e94276086e2d7ea9b))

## 0.1.0-alpha.10 (2025-06-28)

Full Changelog: [v0.1.0-alpha.9...v0.1.0-alpha.10](https://github.com/digitalocean/gradientai-python/compare/v0.1.0-alpha.9...v0.1.0-alpha.10)

### Features

* **api:** manual updates ([0e5effc](https://github.com/digitalocean/gradientai-python/commit/0e5effc727cebe88ea38f0ec4c3fcb45ffeb4924))
* **api:** manual updates ([d510ae0](https://github.com/digitalocean/gradientai-python/commit/d510ae03f13669af7f47093af06a00609e9b7c07))
* **api:** manual updates ([c5bc3ca](https://github.com/digitalocean/gradientai-python/commit/c5bc3caa477945dc19bbf90661ffeea86370189d))

## 0.1.0-alpha.9 (2025-06-28)

Full Changelog: [v0.1.0-alpha.8...v0.1.0-alpha.9](https://github.com/digitalocean/gradientai-python/compare/v0.1.0-alpha.8...v0.1.0-alpha.9)

### Features

* **api:** manual updates ([e0c210a](https://github.com/digitalocean/gradientai-python/commit/e0c210a0ffde24bd2c5877689f8ab222288cc597))

## 0.1.0-alpha.8 (2025-06-27)

Full Changelog: [v0.1.0-alpha.7...v0.1.0-alpha.8](https://github.com/digitalocean/gradientai-python/compare/v0.1.0-alpha.7...v0.1.0-alpha.8)

### Features

* **client:** setup streaming ([3fd6e57](https://github.com/digitalocean/gradientai-python/commit/3fd6e575f6f5952860e42d8c1fa22ccb0b10c623))

## 0.1.0-alpha.7 (2025-06-27)

Full Changelog: [v0.1.0-alpha.6...v0.1.0-alpha.7](https://github.com/digitalocean/gradientai-python/compare/v0.1.0-alpha.6...v0.1.0-alpha.7)

### Features

* **api:** manual updates ([63b9ec0](https://github.com/digitalocean/gradientai-python/commit/63b9ec02a646dad258afbd048db8db1af8d4401b))
* **api:** manual updates ([5247aee](https://github.com/digitalocean/gradientai-python/commit/5247aee6d6052f6380fbe892d7c2bd9a8d0a32c0))
* **api:** manual updates ([aa9e2c7](https://github.com/digitalocean/gradientai-python/commit/aa9e2c78956162f6195fdbaa1c95754ee4af207e))
* **client:** add agent_domain option ([b4b6260](https://github.com/digitalocean/gradientai-python/commit/b4b62609a12a1dfa0b505e9ec54334b776fb0515))

## 0.1.0-alpha.6 (2025-06-27)

Full Changelog: [v0.1.0-alpha.5...v0.1.0-alpha.6](https://github.com/digitalocean/gradientai-python/compare/v0.1.0-alpha.5...v0.1.0-alpha.6)

### Features

* **api:** manual updates ([04eb1be](https://github.com/digitalocean/gradientai-python/commit/04eb1be35de7db04e1f0d4e1da8719b54a353bb5))

## 0.1.0-alpha.5 (2025-06-27)

Full Changelog: [v0.1.0-alpha.4...v0.1.0-alpha.5](https://github.com/digitalocean/gradientai-python/compare/v0.1.0-alpha.4...v0.1.0-alpha.5)

### Features

* **api:** define api links and meta as shared models ([8d87001](https://github.com/digitalocean/gradientai-python/commit/8d87001b51de17dd1a36419c0e926cef119f20b8))
* **api:** update OpenAI spec and add endpoint/smodels ([e92c54b](https://github.com/digitalocean/gradientai-python/commit/e92c54b05f1025b6173945524724143fdafc7728))
* **api:** update via SDK Studio ([1ae76f7](https://github.com/digitalocean/gradientai-python/commit/1ae76f78ce9e74f8fd555e3497299127e9aa6889))
* **api:** update via SDK Studio ([98424f4](https://github.com/digitalocean/gradientai-python/commit/98424f4a2c7e00138fb5eecf94ca72e2ffcc1212))
* **api:** update via SDK Studio ([299fd1b](https://github.com/digitalocean/gradientai-python/commit/299fd1b29b42f6f2581150e52dcf65fc73270862))
* **api:** update via SDK Studio ([9a45427](https://github.com/digitalocean/gradientai-python/commit/9a45427678644c34afe9792a2561f394718e64ff))
* **api:** update via SDK Studio ([abe573f](https://github.com/digitalocean/gradientai-python/commit/abe573fcc2233c7d71f0a925eea8fa9dd4d0fb91))
* **api:** update via SDK Studio ([e5ce590](https://github.com/digitalocean/gradientai-python/commit/e5ce59057792968892317215078ac2c11e811812))
* **api:** update via SDK Studio ([1daa3f5](https://github.com/digitalocean/gradientai-python/commit/1daa3f55a49b5411d1b378fce30aea3ccbccb6d7))
* **api:** update via SDK Studio ([1c702b3](https://github.com/digitalocean/gradientai-python/commit/1c702b340e4fd723393c0f02df2a87d03ca8c9bb))
* **api:** update via SDK Studio ([891d6b3](https://github.com/digitalocean/gradientai-python/commit/891d6b32e5bdb07d23abf898cec17a60ee64f99d))
* **api:** update via SDK Studio ([dcbe442](https://github.com/digitalocean/gradientai-python/commit/dcbe442efc67554e60b3b28360a4d9f7dcbb313a))
* use inference key for chat.completions.create() ([5d38e2e](https://github.com/digitalocean/gradientai-python/commit/5d38e2eb8604a0a4065d146ba71aa4a5a0e93d85))


### Bug Fixes

* **ci:** release-doctor — report correct token name ([4d2b3dc](https://github.com/digitalocean/gradientai-python/commit/4d2b3dcefdefc3830d631c5ac27b58778a299983))


### Chores

* clean up pyproject ([78637e9](https://github.com/digitalocean/gradientai-python/commit/78637e99816d459c27b4f2fd2f6d79c8d32ecfbe))
* **internal:** codegen related update ([58d7319](https://github.com/digitalocean/gradientai-python/commit/58d7319ce68c639c2151a3e96a5d522ec06ff96f))

## 0.1.0-alpha.4 (2025-06-25)

Full Changelog: [v0.1.0-alpha.3...v0.1.0-alpha.4](https://github.com/digitalocean/gradientai-python/compare/v0.1.0-alpha.3...v0.1.0-alpha.4)

### Features

* **api:** update via SDK Studio ([d1ea884](https://github.com/digitalocean/gradientai-python/commit/d1ea884c9be72b3f8804c5ba91bf4f77a3284a6c))
* **api:** update via SDK Studio ([584f9f1](https://github.com/digitalocean/gradientai-python/commit/584f9f1304b3612eb25f1438041d287592463438))
* **api:** update via SDK Studio ([7aee6e5](https://github.com/digitalocean/gradientai-python/commit/7aee6e55a0574fc1b6ab73a1777c92e4f3a940ea))
* **api:** update via SDK Studio ([4212f62](https://github.com/digitalocean/gradientai-python/commit/4212f62b19c44bcb12c02fe396e8c51dd89d3868))
* **api:** update via SDK Studio ([b16cceb](https://github.com/digitalocean/gradientai-python/commit/b16cceb63edb4253084036b693834bde5da10943))
* **api:** update via SDK Studio ([34382c0](https://github.com/digitalocean/gradientai-python/commit/34382c06c5d61ac97572cb4977d020e1ede9d4ff))
* **api:** update via SDK Studio ([c33920a](https://github.com/digitalocean/gradientai-python/commit/c33920aba0dc1f3b8f4f890ce706c86fd452dd6b))
* **api:** update via SDK Studio ([359c8d8](https://github.com/digitalocean/gradientai-python/commit/359c8d88cec1d60f0beb810b5a0139443d0a3348))
* **api:** update via SDK Studio ([f27643e](https://github.com/digitalocean/gradientai-python/commit/f27643e1e00f606029be919a7117801facc6e5b7))
* **api:** update via SDK Studio ([e59144c](https://github.com/digitalocean/gradientai-python/commit/e59144c2d474a4003fd28b8eded08814ffa8d2f3))
* **api:** update via SDK Studio ([97e1768](https://github.com/digitalocean/gradientai-python/commit/97e17687a348b8ef218c23a06729b6edb1ac5ea9))
* **api:** update via SDK Studio ([eac41f1](https://github.com/digitalocean/gradientai-python/commit/eac41f12912b8d32ffa23d225f4ca56fa5c72505))
* **api:** update via SDK Studio ([1fa7ebb](https://github.com/digitalocean/gradientai-python/commit/1fa7ebb0080db9087b82d29e7197e44dfbb1ebed))
* **api:** update via SDK Studio ([aa2610a](https://github.com/digitalocean/gradientai-python/commit/aa2610afe7da79429e05bff64b4796de7f525681))
* **api:** update via SDK Studio ([e5c8d76](https://github.com/digitalocean/gradientai-python/commit/e5c8d768388b16c06fcc2abee71a53dcc8b3e8c5))
* **api:** update via SDK Studio ([5f700dc](https://github.com/digitalocean/gradientai-python/commit/5f700dc7a4e757015d3bd6f2e82a311114b82d77))
* **api:** update via SDK Studio ([c042496](https://github.com/digitalocean/gradientai-python/commit/c04249614917198b1eb2324438605d99b719a1cf))
* **api:** update via SDK Studio ([5ebec81](https://github.com/digitalocean/gradientai-python/commit/5ebec81604a206eba5e75a7e8990bd7711ba8f47))
* **api:** update via SDK Studio ([cac54a8](https://github.com/digitalocean/gradientai-python/commit/cac54a81a3f22d34b2de0ebfac3c68a982178cad))
* **api:** update via SDK Studio ([6d62ab0](https://github.com/digitalocean/gradientai-python/commit/6d62ab00594d70df0458a0a401f866af15a9298e))
* **api:** update via SDK Studio ([0ccc62c](https://github.com/digitalocean/gradientai-python/commit/0ccc62cb8ef387e0aaf6784db25d5f99a587e5da))
* **api:** update via SDK Studio ([e75adfb](https://github.com/digitalocean/gradientai-python/commit/e75adfbd2d035e57ae110a1d78ea40fb116975e5))
* **api:** update via SDK Studio ([8bd264b](https://github.com/digitalocean/gradientai-python/commit/8bd264b4b4686ca078bf4eb4b5462f058406df3e))
* **api:** update via SDK Studio ([6254ccf](https://github.com/digitalocean/gradientai-python/commit/6254ccf45cbe50ca8191c7149824964f5d00d82f))
* **api:** update via SDK Studio ([8f5761b](https://github.com/digitalocean/gradientai-python/commit/8f5761b1d18fb48ad7488e6f0ad771c077eb7961))
* **api:** update via SDK Studio ([f853616](https://github.com/digitalocean/gradientai-python/commit/f8536166320d1d5bacf1d10a5edb2f71691dde8b))
* **client:** add support for aiohttp ([494afde](https://github.com/digitalocean/gradientai-python/commit/494afde754f735d1ba95011fc83d23d2410fcfdd))


### Bug Fixes

* **client:** correctly parse binary response | stream ([abba5be](https://github.com/digitalocean/gradientai-python/commit/abba5be958d03a7e5ce7d1cbf8069c0bcf52ee20))
* **tests:** fix: tests which call HTTP endpoints directly with the example parameters ([e649dcb](https://github.com/digitalocean/gradientai-python/commit/e649dcb0f9416e9bf568cc9f3480d7e222052391))


### Chores

* **ci:** enable for pull requests ([b6b3f9e](https://github.com/digitalocean/gradientai-python/commit/b6b3f9ea85918cfc6fc7304b2d21c340d82a0083))
* **internal:** codegen related update ([4126872](https://github.com/digitalocean/gradientai-python/commit/41268721eafd33fcca5688ca5dff7401f25bdeb2))
* **internal:** codegen related update ([10b79fb](https://github.com/digitalocean/gradientai-python/commit/10b79fb1d51bcff6ed0d18e5ccd18fd1cd75af9f))
* **internal:** update conftest.py ([12e2103](https://github.com/digitalocean/gradientai-python/commit/12e210389204ff74f504e1ec3aa5ba99f1b4971c))
* **readme:** update badges ([6e40dc3](https://github.com/digitalocean/gradientai-python/commit/6e40dc3fa4e33082be7b0bbf65d07e9ae9ac6370))
* **tests:** add tests for httpx client instantiation & proxies ([7ecf66c](https://github.com/digitalocean/gradientai-python/commit/7ecf66c58a124c153a32055967beacbd1a3bbcf3))
* **tests:** run tests in parallel ([861dd6b](https://github.com/digitalocean/gradientai-python/commit/861dd6b75956f2c12814ad32b05624d8d8537d52))
* **tests:** skip some failing tests on the latest python versions ([75b4539](https://github.com/digitalocean/gradientai-python/commit/75b45398c18e75be3389be20479f54521c2e474a))
* update SDK settings ([ed595b0](https://github.com/digitalocean/gradientai-python/commit/ed595b0a23df125ffba733d7339e771997c3f149))


### Documentation

* **client:** fix httpx.Timeout documentation reference ([5d452d7](https://github.com/digitalocean/gradientai-python/commit/5d452d7245af6c80f47f8395f1c03493dfb53a52))

## 0.1.0-alpha.3 (2025-06-12)

Full Changelog: [v0.1.0-alpha.2...v0.1.0-alpha.3](https://github.com/digitalocean/genai-python/compare/v0.1.0-alpha.2...v0.1.0-alpha.3)

### Chores

* update SDK settings ([502bb34](https://github.com/digitalocean/genai-python/commit/502bb34e1693603cd572c756e8ce6aeba63d1283))

## 0.1.0-alpha.2 (2025-06-12)

Full Changelog: [v0.1.0-alpha.1...v0.1.0-alpha.2](https://github.com/digitalocean/genai-python/compare/v0.1.0-alpha.1...v0.1.0-alpha.2)

### Chores

* update SDK settings ([5b3b94b](https://github.com/digitalocean/genai-python/commit/5b3b94b57a4ba7837093617aafc2ce2d21ac87f1))

## 0.1.0-alpha.1 (2025-06-12)

Full Changelog: [v0.0.1-alpha.0...v0.1.0-alpha.1](https://github.com/digitalocean/genai-python/compare/v0.0.1-alpha.0...v0.1.0-alpha.1)

### Features

* **api:** update via SDK Studio ([1e202d0](https://github.com/digitalocean/genai-python/commit/1e202d01e3582ef5284380417d9f7e195bbc8a39))
* **api:** update via SDK Studio ([e6103ad](https://github.com/digitalocean/genai-python/commit/e6103ad8134752e632cf1dae9cb09edf10fd7739))
* **api:** update via SDK Studio ([bf61629](https://github.com/digitalocean/genai-python/commit/bf61629f25376f1cc32b910fbaea9feccfef9884))
* **api:** update via SDK Studio ([c680ef3](https://github.com/digitalocean/genai-python/commit/c680ef3bac9874ef595edde2bd8f0ce5948ac6c4))
* **api:** update via SDK Studio ([a4bb08b](https://github.com/digitalocean/genai-python/commit/a4bb08ba4829b5780511b78538e5cbbc276f1965))
* **api:** update via SDK Studio ([691923d](https://github.com/digitalocean/genai-python/commit/691923d9f60b5ebe5dc34c8227273d06448945e8))
* **client:** add follow_redirects request option ([5a6d480](https://github.com/digitalocean/genai-python/commit/5a6d480aef6d4c5084f484d1b69e6f49568a8caf))


### Chores

* **docs:** remove reference to rye shell ([29febe9](https://github.com/digitalocean/genai-python/commit/29febe9affcb0ae41ec69f8aea3ae6ef53967537))
* **docs:** remove unnecessary param examples ([35ec489](https://github.com/digitalocean/genai-python/commit/35ec48915a8bd750060634208e91bd98c905b53c))
* update SDK settings ([a095281](https://github.com/digitalocean/genai-python/commit/a095281b52c7ac5f096147e67b7b2e5bf342f95e))
* update SDK settings ([d2c39ec](https://github.com/digitalocean/genai-python/commit/d2c39eceea1aaeaf0e6c2707af10c3998d222bda))
* update SDK settings ([f032621](https://github.com/digitalocean/genai-python/commit/f03262136aa46e9325ac2fae785bf48a56f0127b))
* update SDK settings ([b2cf700](https://github.com/digitalocean/genai-python/commit/b2cf700a0419f7d6e3f23ee02747fe7766a05f98))
