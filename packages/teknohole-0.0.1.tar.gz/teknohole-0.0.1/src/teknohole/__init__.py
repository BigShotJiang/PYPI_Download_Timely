def hello():
    print("Selamat datang di Teknohole")