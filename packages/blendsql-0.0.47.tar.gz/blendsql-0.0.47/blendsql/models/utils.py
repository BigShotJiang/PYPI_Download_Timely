system = lambda x: {"role": "system", "content": x}
assistant = lambda x: {"role": "assistant", "content": x}
user = lambda x: {"role": "user", "content": x}
