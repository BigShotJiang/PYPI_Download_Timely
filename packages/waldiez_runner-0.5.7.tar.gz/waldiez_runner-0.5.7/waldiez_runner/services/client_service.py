# SPDX-License-Identifier: Apache-2.0.
# Copyright (c) 2024 - 2025 Waldiez and contributors.
"""Client service."""

# noinspection PyPep8Naming
from . import _client_service as ClientService

__all__ = ["ClientService"]
