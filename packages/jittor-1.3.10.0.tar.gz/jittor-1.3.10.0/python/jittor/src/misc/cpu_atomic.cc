// ***************************************************************
// Copyright (c) 2023 Jittor. All Rights Reserved. 
// Maintainers: Dun Liang <randonlang@gmail.com>. 
// This file is subject to the terms and conditions defined in
// file 'LICENSE.txt', which is part of this source code package.
// ***************************************************************
#include "misc/cpu_atomic.h"

namespace jittor {

std::atomic_flag lock = ATOMIC_FLAG_INIT;;

} // jittor
