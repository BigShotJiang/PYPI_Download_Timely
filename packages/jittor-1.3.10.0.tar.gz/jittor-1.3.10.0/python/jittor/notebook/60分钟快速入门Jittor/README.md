# 计图零基础入门教程（60分钟）

```
git clone https://github.com/Jittor/LearnJittorBasicIn60Min.git
cd LearnJittorBasicIn60Min
jupyter notebook
```

在线浏览地址：<https://nbviewer.jupyter.org/github/Jittor/LearnJittorBasicIn60Min/tree/master/>

特别感谢教程作者：llt
