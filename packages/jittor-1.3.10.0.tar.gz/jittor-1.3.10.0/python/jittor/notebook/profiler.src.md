# Profiler: Profiling your model

# 性能分析器：分析您的模型

> NOTE: This tutorial is still working in progress

In this tutorial, we will show:
1. how to profiling your model and check the elapsed time of each operation
2. profiling the cache hit rate

> 注意：本教程仍在持续更新中

在本教程中，我们将展示：

1. 如何分析模型并检查每个运算的耗时
2. 分析缓存命中率

```python
import jittor as jt
```