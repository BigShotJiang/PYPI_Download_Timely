import typing as t


class T:
    Item = t.Any
