import streamlit as st

AnyComponent = st.delta_generator.DeltaGenerator
AnyContainer = st.delta_generator.DeltaGenerator
