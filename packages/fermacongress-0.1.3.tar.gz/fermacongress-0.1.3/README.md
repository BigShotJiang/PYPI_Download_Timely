# Ferma Congress
This is a Python package built for Internal Purposes of ZoomRx - Ferma Congress which does some operation related in planning.

## 🔐 Authentication Setup

To access the Ferma API, you need a `.env` file with your Authorized Ferma  credentials.

### ✅ Option 1: Non-Encoded Credentials (default)

```env
FERMA_USERNAME=your_email@domain.com
FERMA_PASSWORD=your_password
```

### ✅ Option 2: Base64-Encoded Credentials (for `format="ENCODED"`)

```env
FERMA_USERNAME_ENC=encoded_username
FERMA_PASSWORD_ENC=encoded_password
```

Then use:

```python
from FermaCongress.ExtractFerma import *

login("path/to/.env") # Default: In Case of Non-Encoded Credentials

login("path/to/.env", format="ENCODED") # Encoded: In Case of Encoded Credentials
```

---

# ExtractFerma

To use the `ExtractFerma` functionality, you must first authenticate using the `login()` function. Once authenticated, you can call various data extraction functions to retrieve Ferma Congress data. Each function returns a `pandas.DataFrame` for easy analysis or export.

```python
from FermaCongress.ExtractFerma import *

get_all_sessions(congress_id)                         # Fetches Session-Level Metadata
get_skg(congress_id)                                  # Fetches Session Entities Data
get_tweets(congress_id)                               # Fetches tweet-level data linked to sessions
get_priority(congress_id, include=None, exclude=None) # Fetches session priorities across planners
get_summary(congress_id)                              # Fetches Sessions generated v1 summary
get_fullabstracts(congress_id)                        # Fetches Session Full Abstracts
```

```python
# Usage Examples
from FermaCongress.ExtractFerma import *

get_all_sessions("217")

get_skg("217")

get_tweets("217")

get_summary("217)

get_fullabstracts("217") 

get_priority("217")
get_priority("217", include=["ClientA", "ClientB"])   # Include only specific clients
get_priority("217", exclude=["ClientX"])              # Exclude specific clients
```

---

# FormatExcel

The `FormatExcel` utility is used to apply styling and export your Ferma data (from a DataFrame or input file) into a clean, Ferma-styled Excel format.

```python
from FermaCongress.FormatExcel import format

format(dataframe=df, output_path="priority_report.xlsx")  # Format from a DataFrame

format(input_path="raw_sessions.xlsx", output_path="formatted_sessions.xlsx")  # Format from Excel file

format(input_path="raw_data.csv", output_path="formatted_output.xlsx")  # Format from CSV file
```


| Parameter      | Type                         | Description                                                                                |
| -------------- | ---------------------------- | ------------------------------------------------------------------------------------------ |
| `input_path`   | `str`                        | Path to an input Excel or CSV file.                                                        |
| `dataframe`    | `pandas.DataFrame`           | DataFrame to format.                                                                       |
| `output_path`  | `str`                        | File path to save the formatted Excel output.                                              |
| `headers`      | `bool`                       | True to convert headers to proper casing (e.g., buzz_score → Buzz Score).                  |
| `input_sheet`  | `str`                        | Name of the sheet to read from (Excel only). Optional if only one sheet.                   |
| `output_sheet` | `str`                        | Name of the sheet to write into in the output Excel file.                                  |

---

# Annotate

The `Annotate` module enables annotation of CSV files via the Ferma Support Portal using defined needle types and optional entity filters. The annotated output is returned as a `pandas.DataFrame` and can be exported to Excel/CSV.

### ✅ Setup & Usage

```python
from FermaCongress.Annotate import login, annotate

# First login using your .env credentials: Required before using annotate()
login("path/to/.env")

# Basic annotation
df = annotate(input_path="path/to/input.csv")

# With custom needles and pivot format
df = annotate(input_path="path/to/input.csv",custom_needles_path="path/to/custom_needles.csv",long_table=False)

# With entity-level filters (e.g., Agency-only annotations)
df = annotate(input_path="path/to/input.csv",entities={"institution": ["Agency"], "author": []})
```

### Parameters (in `annotate()`)

| Parameter             | Type                  | Description                                                              |
| --------------------- | --------------------- | ------------------------------------------------------------------------ |
| `input_path`          | `str`                 | Path to the CSV file to be annotated.                                    |
| `custom_needles_path` | `str or None`         | Optional path to a custom needle CSV file.                               |
| `needles`             | `list[int, int]`      | Indicates whether to include `kb` and/or `nct` needles (e.g., `[1, 0]`). |
| `entities`            | `dict or None`        | Entity filters (e.g., `{"institution": ["Agency"], "author": []}`).      |
| `long_table`          | `bool`                | Format type. `True` = long table, `False` = pivot table.                 |

---

# Changelog

All notable changes to this project will be documented here.

## [0.1.2] - 2025-07-27
### Added
- Annotation module to upload CSVs and download long/pivot table format results via Ferma AaaS portal.

## [0.1.1] - 2025-07-24
### Added
- Congress-level extraction logic for full abstracts and V1 summaries.

## [0.1.0] - 2025-07-17
### Added
- Ferma-style Excel formatting utilities for highlighting and column styling.
- Initial version of congress data extraction from Ferma Admin portal.