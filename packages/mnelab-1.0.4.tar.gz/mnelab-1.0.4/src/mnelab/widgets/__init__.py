# © MNELAB developers
#
# License: BSD (3-clause)

from mnelab.widgets.infowidget import EmptyWidget, InfoWidget
from mnelab.widgets.sidebar import SidebarTableWidget
