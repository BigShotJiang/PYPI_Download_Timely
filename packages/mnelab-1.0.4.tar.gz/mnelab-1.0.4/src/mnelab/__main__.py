# © MNELAB developers
#
# License: BSD (3-clause)

from mnelab import main

if __name__ == "__main__":
    main()
