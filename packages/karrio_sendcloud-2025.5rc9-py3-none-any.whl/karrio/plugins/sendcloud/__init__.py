# Import metadata from mappers module to avoid circular imports
from karrio.mappers.sendcloud import METADATA