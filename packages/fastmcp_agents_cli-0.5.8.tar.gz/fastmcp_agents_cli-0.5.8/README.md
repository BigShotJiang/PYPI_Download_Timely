

`uvx fastmcp-agents-cli call tool --config config.yml --tool=get_structure --args '{"depth": 3}'`
`uvx fastmcp-agents-cli list tools --config config.json`

Will auto pick up mcp.json, config.json, mcp.yml, config.yml

`uvx fastmcp-agents-cli call tool get_structure '{"depth": 3}'`
`uvx fastmcp-agents-cli list tools`