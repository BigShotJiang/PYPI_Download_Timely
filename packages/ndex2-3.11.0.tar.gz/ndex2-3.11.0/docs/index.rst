.. include:: ../README.rst

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   quicktutorial
   advancedtutorial
   modules
   license
   history

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


