License
=======

.. include:: ../LICENSE.txt

