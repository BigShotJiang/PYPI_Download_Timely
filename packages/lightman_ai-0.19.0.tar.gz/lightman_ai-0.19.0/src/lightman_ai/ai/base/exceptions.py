from lightman_ai.core.exceptions import BaseHackermanError


class BaseAgentError(BaseHackermanError): ...
