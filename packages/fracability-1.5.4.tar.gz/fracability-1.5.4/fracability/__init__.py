from os.path import dirname, join as joinpath

__version__ = "1.5.4"
__author__ = 'Gabriele Benedetti'
