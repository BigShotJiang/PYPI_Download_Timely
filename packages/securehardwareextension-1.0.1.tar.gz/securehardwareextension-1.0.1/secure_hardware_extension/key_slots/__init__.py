"""
Package for key slot identification.

"""
__all__ = ["autosar", "base"]
