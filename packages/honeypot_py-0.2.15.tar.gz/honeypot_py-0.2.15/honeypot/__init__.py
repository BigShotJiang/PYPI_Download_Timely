# honeypot/__init__.py
from .client import Honeypot as honeypot, __version__

__all__ = ["honeypot"]