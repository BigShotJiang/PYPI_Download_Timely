Once the survey is configured, the users can fill them up as usual. The
answers in the next survey will be prefilled according to the linked
questions.

If the user changes any response in the next question, we can tell the
difference in the backend: go to the participation and in the answers
tree let the column *Diff with origin* show.
