You can configure either a new or an existing survey.

1.  Go to *Surveys* and choose an existing one or create it.
2.  In the *Options* tab, *Questions* group, choose the *Next Survey*.

Now you'll have to configure the destination questions linked to this
survey's questions.

1.  Go to the *Answers* tab choose the linked question.
2.  For simple/multiple choice qustions you'll have to link the answers
    as well.
