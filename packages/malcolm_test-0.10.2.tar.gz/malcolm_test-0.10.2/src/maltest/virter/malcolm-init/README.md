This directory is for distribution-agnostic [virter provisioning](https://github.com/LINBIT/virter/blob/master/doc/provisioning.md) TOML files used to set up Malcolm prior to starting it.
