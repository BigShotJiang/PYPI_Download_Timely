# bill-flow-plugin

A package to create plugins for [bill-flow](https://github.com/raulodev/bill-flow) system
