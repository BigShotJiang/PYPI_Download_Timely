

class InvalidToken(BaseException):
    ...