
class MaxConnection(BaseException):
    ...
    
    
class MaxUploadFileFailed(BaseException):
    ...
    

class MaxIconParamsException(BaseException):
    ...