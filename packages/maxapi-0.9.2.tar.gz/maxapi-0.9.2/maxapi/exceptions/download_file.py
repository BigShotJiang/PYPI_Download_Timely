

class NotAvailableForDownload(BaseException):
    ...