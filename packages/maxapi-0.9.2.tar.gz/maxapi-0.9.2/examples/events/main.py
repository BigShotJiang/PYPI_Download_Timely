import asyncio
import logging

from maxapi import Bot, Dispatcher
from maxapi.types import (
    BotStarted, 
    Command, 
    MessageCreated, 
    CallbackButton, 
    MessageCallback, 
    BotAdded, 
    ChatTitleChanged, 
    MessageEdited, 
    MessageRemoved, 
    UserAdded, 
    UserRemoved,
    BotStopped,
    DialogCleared,
    DialogMuted,
    DialogUnmuted,
    ChatButton,
    MessageChatCreated
)
from maxapi.utils.inline_keyboard import InlineKeyboardBuilder

logging.basicConfig(level=logging.INFO)

bot = Bot('тут_ваш_токен')
dp = Dispatcher()


@dp.message_created(Command('start'))
async def hello(event: MessageCreated):
    builder = InlineKeyboardBuilder()

    builder.row(
        CallbackButton(
            text='Кнопка 1',
            payload='btn_1'
        ),
        CallbackButton(
            text='Кнопка 2',
            payload='btn_2',
        )
    )
    builder.add(
        ChatButton(
            text='Создать чат',
            chat_title='Тест чат'
        )
    )

    await event.message.answer(
        text='Привет!', 
        attachments=[
            builder.as_markup(),
        ]                               # Для MAX клавиатура это вложение, 
    )                                       # поэтому она в списке вложений


@dp.bot_added()
async def bot_added(event: BotAdded):
    await event.bot.send_message(
        chat_id=event.chat.id,
        text=f'Привет чат {event.chat.title}!'
    )
    
    
@dp.message_removed()
async def message_removed(event: MessageRemoved):
    await event.bot.send_message(
        chat_id=event.chat_id,
        text='Я всё видел!'
    )
    
    
@dp.bot_started()
async def bot_started(event: BotStarted):
    await event.bot.send_message(
        chat_id=event.chat_id,
        text='Привет! Отправь мне /start'
    )
    
    
@dp.chat_title_changed()
async def chat_title_changed(event: ChatTitleChanged):
    await event.bot.send_message(
        chat_id=event.chat_id,
        text=f'Крутое новое название "{event.chat.title}"!'
    )
    
    
@dp.message_callback()
async def message_callback(event: MessageCallback):
    await event.answer(
        new_text=f'Вы нажали на кнопку {event.callback.payload}!'
    )
    

@dp.message_edited()
async def message_edited(event: MessageEdited):
    await event.message.answer(
        text='Вы отредактировали сообщение!'
    )
    
    
@dp.user_removed()
async def user_removed(event: UserRemoved):
    await event.bot.send_message(
        chat_id=event.chat_id,
        text=f'{event.from_user.first_name} кикнул {event.user.first_name} 😢'
    )
    
    
@dp.user_added()
async def user_added(event: UserAdded):
    await event.bot.send_message(
        chat_id=event.chat_id,
        text=f'Чат "{event.chat.title}" приветствует вас, {event.user.first_name}!'
    )
    

@dp.bot_stopped()
async def bot_stopped(event: BotStopped):
    print(event.from_user.full_name, 'остановил бота') # type: ignore
    
    
@dp.dialog_cleared()
async def dialog_cleared(event: DialogCleared):
    print(event.from_user.full_name, 'очистил историю чата с ботом') # type: ignore
    
    
@dp.dialog_muted()
async def dialog_muted(event: DialogMuted):
    print(event.from_user.full_name, 'отключил оповещения от чата бота до ', event.muted_until_datetime) # type: ignore
    
    
@dp.dialog_unmuted()
async def dialog_unmuted(event: DialogUnmuted):
    print(event.from_user.full_name, 'включил оповещения от чата бота') # type: ignore
    

@dp.message_chat_created()
async def message_chat_created(event: MessageChatCreated):
    await event.bot.send_message(
        chat_id=event.chat.chat_id,
        text=f'Чат создан! Ссылка: {event.chat.link}'
    )


async def main():
    await dp.start_polling(bot)


if __name__ == '__main__':
    asyncio.run(main())