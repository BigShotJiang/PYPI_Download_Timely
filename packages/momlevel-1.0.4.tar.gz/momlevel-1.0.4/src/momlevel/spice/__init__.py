""" momlevel - spiciness module """

from . import flament
