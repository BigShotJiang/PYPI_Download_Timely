DESCRIPTION structure_ara

`structure_aram` est un package Python qui inclut une commande en ligne `generate-app` pour faciliter la génération d’applications .

---

 INSTALLATION

- Créez un environnement virtuel (optionnel mais recommandé) :

```bash
python3 -m venv venv
source venv/bin/activate

- installe le package avec pip install structure-aram
- genere ton application avec < generate-app "nom_app">  
