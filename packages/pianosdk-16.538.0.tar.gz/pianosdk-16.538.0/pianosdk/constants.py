__version__ = '16.538.0'
__license__ = 'Apache License, Version 2.0'
__copyright__ = 'Copyright 2020 Piano Software, Inc'

USER_AGENT = 'Piano-Python-SDK/' + __version__
