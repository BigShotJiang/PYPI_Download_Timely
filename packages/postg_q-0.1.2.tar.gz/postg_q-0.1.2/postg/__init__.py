from .postg import DB

__all__ = ['DB']
