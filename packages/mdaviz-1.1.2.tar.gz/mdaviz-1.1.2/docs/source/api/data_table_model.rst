====================================
data_table_model
====================================

.. automodule:: mdaviz.data_table_model
    :members:
    :private-members:
