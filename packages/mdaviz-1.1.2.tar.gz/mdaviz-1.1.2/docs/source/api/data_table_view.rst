====================================
data_table_view
====================================

.. automodule:: mdaviz.data_table_view
    :members:
    :private-members:
