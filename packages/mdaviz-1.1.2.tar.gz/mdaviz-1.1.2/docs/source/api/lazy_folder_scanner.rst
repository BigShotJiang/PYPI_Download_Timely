====================================
Lazy Folder Scanner
====================================

.. automodule:: mdaviz.lazy_folder_scanner
    :members:
    :private-members:
