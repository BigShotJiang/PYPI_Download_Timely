====================================
empty_table_model
====================================

.. automodule:: mdaviz.empty_table_model
    :members:
    :private-members:
