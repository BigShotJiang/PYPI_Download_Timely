====================================
mda_file_table_view
====================================

.. automodule:: mdaviz.mda_file_table_view
    :members:
    :private-members:
