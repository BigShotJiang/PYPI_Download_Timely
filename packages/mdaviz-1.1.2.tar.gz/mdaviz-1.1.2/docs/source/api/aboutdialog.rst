====================================
About Dialog
====================================

.. automodule:: mdaviz.aboutdialog
    :members:
    :private-members:
