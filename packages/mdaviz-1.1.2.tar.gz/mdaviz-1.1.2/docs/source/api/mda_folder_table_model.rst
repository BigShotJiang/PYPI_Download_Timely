====================================
mda_folder_table_model
====================================

.. automodule:: mdaviz.mda_folder_table_model
    :members:
    :private-members:
