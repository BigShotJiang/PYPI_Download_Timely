.. _license:

License
=======

.. literalinclude:: ../../LICENSE.txt
   :language: text
