from .legacy.tree import OrthoXMLTree

__version__ = "1.1.0"
