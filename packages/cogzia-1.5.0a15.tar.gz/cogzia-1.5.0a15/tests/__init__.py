"""
Test suite for Cogzia Alpha v1.5.

This module contains unit, integration, and UI tests for the AI app creator.
All tests use real services (no mocking) following TDD best practices.
"""