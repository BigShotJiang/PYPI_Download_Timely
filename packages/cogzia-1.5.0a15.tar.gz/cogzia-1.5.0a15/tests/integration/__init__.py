"""
Integration tests for Cogzia Alpha v1.5.

This module contains integration tests that verify multi-component interactions
including conversation flows, tool streaming, and end-to-end workflows.
"""