"""
Unit tests for Cogzia Alpha v1.5.

This module contains unit tests for individual components and functions.
Tests use real services and follow TDD best practices.
"""