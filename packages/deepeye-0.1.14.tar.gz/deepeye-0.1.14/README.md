
# DeepEye
Utility tools for image enhancement


### Install pytorch (support GPU)

- pip3 install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121

- pip install -r requirements.txt