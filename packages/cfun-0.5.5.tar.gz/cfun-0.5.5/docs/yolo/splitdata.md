## 划分yolo数据集



::: cfun.yolo.splitdata