## 检测模块
::: cfun.yolo.detect





## 分类模块
::: cfun.yolo.classify

    
## 识别模块(一步到位 onnx 模型)

::: cfun.yolo.detclsonnx
            

## 识别模块(一步到位 pt 模型) YOLOv11

::: cfun.yolo.detclspt
