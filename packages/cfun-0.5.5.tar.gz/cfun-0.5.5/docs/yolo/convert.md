
## json标注文件转yolo格式

主要提供一些函数,将xlabeling生成的json标注文件转换为yolo格式的txt标注文件。


::: cfun.yolo.convert


