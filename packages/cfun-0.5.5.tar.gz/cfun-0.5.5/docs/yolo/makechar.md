## makechar

::: cfun.yolo.makechar
