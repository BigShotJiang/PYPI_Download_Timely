## 通过坐标生成x-anylabeling格式的json文件



::: cfun.yolo.xlabel