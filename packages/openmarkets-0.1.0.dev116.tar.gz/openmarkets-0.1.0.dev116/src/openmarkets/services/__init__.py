# Abstractions for external services/APIs
