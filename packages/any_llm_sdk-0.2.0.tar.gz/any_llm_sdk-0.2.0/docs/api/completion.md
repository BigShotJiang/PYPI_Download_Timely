## Completion

::: any_llm.completion
::: any_llm.acompletion
