## Exceptions

::: any_llm.exceptions
