# Authors of Bigraph Schema

The maintainers of the Bigraph-Schema project are:

* Ryan Spangler (@prismofeverything)
* Eran Agmon  (@eagmon)
