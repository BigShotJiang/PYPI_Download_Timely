from torrra.core.config import Config

# shared instance of Config
config = Config()
