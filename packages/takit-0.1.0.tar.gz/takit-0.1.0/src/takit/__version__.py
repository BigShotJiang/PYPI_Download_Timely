__title__ = "takit"
__description__ = "Technical analysis library for financial data."
__version__ = "0.1.0"
