# Copyright 2025 Q-CTRL. All rights reserved.
#
# Licensed under the Q-CTRL Terms of service (the "License"). Unauthorized
# copying or use of this file, via any medium, is strictly prohibited.
# Proprietary and confidential. You may not use this file except in compliance
# with the License. You may obtain a copy of the License at
#
#    https://q-ctrl.com/terms
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS. See the
# License for the specific language.

from pydantic import PrivateAttr

from boulderopalscaleupsdk.experiments.common import (
    CWSIterable,
    Experiment,
    HypIterable,
    LinspaceIterable,
    RangeIterable,
)

DEFAULT_RECYCLE_DELAY_NS = 10_000
DEFAULT_SHOT_COUNT = 100


class Chi01Scan(Experiment):
    """
    Parameters for running an experiment to find the dispersive shift for a transmon
    resonator pair.

    Attributes
    ----------
    transmon : str
        The reference for the transmon to target in the experiment.
    frequencies : list[int] or LinspaceIterable or RangeIterable or CWSIterable
                  or HypIterable or None, optional
        The frequencies at which to scan.
        If None, frequencies around the readout frequency will be used.
    recycle_delay_ns : int, optional
        The delay time between consecutive shots of the experiment, in nanoseconds.
        Defaults to 10000 ns.
    shot_count : int, optional
        The number of shots to be taken in the experiment.
        Defaults to 100.
    """

    _experiment_name: str = PrivateAttr("chi01_scan")

    transmon: str
    frequencies: list[int] | LinspaceIterable | RangeIterable | CWSIterable | HypIterable | None = (
        None
    )
    recycle_delay_ns: int = DEFAULT_RECYCLE_DELAY_NS
    shot_count: int = DEFAULT_SHOT_COUNT
