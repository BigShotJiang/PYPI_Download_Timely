## 1、若没听说过Navicat，你就不用继续看了

#### 最新版的Navicat有了ai功能，还不赶紧来了解下

![img.png](imgs/Navicat1.png)

## 2、api地址一定要写该项目的地址：http://127.0.0.1:8000,模型服务提供商选择openai
![img.png](imgs/Navicat2.png)

## 3、可以附加数据库，然后就可以愉快的聊天了
![img.png](imgs/Navicat3.png)

