## 1、配置模型，选择ollama(也可以选择openai，请自行探索)
![img.png](imgs/CherryStudio1.png)
## 2、api地址一定要写该项目的地址：http://127.0.0.1:8000
## 3、选择一个模型，进行聊天
![img.png](imgs/CherryStudio2.png)
## 4、请仔细观察上图，右边是日志页面，聊天过程中，日志会实时更新