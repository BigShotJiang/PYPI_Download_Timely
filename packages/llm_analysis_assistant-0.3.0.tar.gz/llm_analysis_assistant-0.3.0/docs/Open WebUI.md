## 1、配置模型,管理OpenAI API连接，一定要写：http://127.0.0.1:8000
![img.png](imgs/OpenWebUI1.png)
## 2、选择一个模型，进行聊天
![img.png](imgs/OpenWebUI2.png)

## 3、请仔细观察下图，右边是日志页面，聊天过程中，日志会实时更新

![img.png](imgs/OpenWebUI3.png)