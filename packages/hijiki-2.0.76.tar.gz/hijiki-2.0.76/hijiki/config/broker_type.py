from enum import Enum

class BrokerType(Enum):
    RABBITMQ = "RabbitMQ"
    SQSSNS = "SQSSNS" 