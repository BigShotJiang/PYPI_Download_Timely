from spade.template import Template as SpadeTemplate


class Template(SpadeTemplate):
    """PEAK's template for matching messages."""
