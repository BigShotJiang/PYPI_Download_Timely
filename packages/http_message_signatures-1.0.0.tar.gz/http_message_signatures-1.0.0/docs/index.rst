.. include:: ../README.rst

API documentation
=================

.. automodule:: http_message_signatures
   :members:

Release Notes
=============
.. include:: ../Changes.rst


Table of Contents
=================

.. toctree::
   :maxdepth: 5

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
