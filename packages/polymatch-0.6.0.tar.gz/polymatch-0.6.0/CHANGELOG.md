## v0.6.0 (2025-07-25)

### Feat

- Add renovate.json

### Fix

- **devcontainer**: update zsh-plugins feature source URL
- remove non-default codeql config

### Refactor

- update linter rules

## v0.5.2 (2024-05-24)

## v0.5.1 (2024-05-24)

### Fix

- bump workflow action version

## v0.5.0 (2024-05-24)

## v0.4.2 (2024-05-24)

### Refactor

- apply nitpick settings

## v0.4.1 (2024-04-18)

### Fix

- correct the version reference

### Refactor

- add ssort to sort module members

## v0.4.0 (2024-04-16)

## v0.3.0 (2024-04-04)

## v0.2.1 (2024-04-03)

## v0.2.0 (2024-04-03)

## v0.1.7 (2018-08-16)

## v0.1.6 (2018-04-18)

## v0.1.5 (2018-02-18)

## v0.1.4 (2018-02-18)

## v0.1.3 (2018-02-14)

## v0.1.2 (2018-02-14)

## v0.1.1 (2018-02-14)

## v0.1.0 (2018-02-13)
