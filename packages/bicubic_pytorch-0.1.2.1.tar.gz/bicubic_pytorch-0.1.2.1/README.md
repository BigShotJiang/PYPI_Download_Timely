# bicubic_pytorch

Maintained fork of [bicubic_pytorch]([https://github.com/SkafteNicki/libcpab](https://github.com/sanghyun-son/bicubic_pytorch)).

Install with `pip`: `pip install bicubic_pytorch`

Changes:

- Remove `cv2` dependency
- Packaging