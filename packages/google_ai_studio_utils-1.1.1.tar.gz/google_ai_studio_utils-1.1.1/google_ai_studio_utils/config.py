from pathlib import Path

parent_dir = Path(__file__).parent
templates_dir = parent_dir / "templates"
google_ai_studio_html_template = templates_dir / "google-ai-studio-conversation.html"
