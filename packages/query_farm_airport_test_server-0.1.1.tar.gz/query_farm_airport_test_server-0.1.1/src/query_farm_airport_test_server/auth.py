import query_farm_flight_server.auth as base_auth


class AccountToken(base_auth.AccountToken):
    pass


class Account(base_auth.Account):
    pass
