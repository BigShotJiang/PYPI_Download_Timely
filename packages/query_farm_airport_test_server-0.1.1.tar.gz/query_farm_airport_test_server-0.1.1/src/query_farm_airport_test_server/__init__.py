from . import server


def do_server() -> int:
    return server.run()

