from freeact.model.prompt.feedback import (
    EXECUTION_ERROR_TEMPLATE,
    EXECUTION_OUTPUT_TEMPLATE,
)
from freeact.model.prompt.system_tag import (
    CODE_TAG_SYSTEM_TEMPLATE,
)
from freeact.model.prompt.system_tool import (
    TOOL_USE_SYSTEM_TEMPLATE,
)
