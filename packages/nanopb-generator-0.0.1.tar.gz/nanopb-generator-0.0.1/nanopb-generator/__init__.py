# Safe dummy package: nanopb-generator
