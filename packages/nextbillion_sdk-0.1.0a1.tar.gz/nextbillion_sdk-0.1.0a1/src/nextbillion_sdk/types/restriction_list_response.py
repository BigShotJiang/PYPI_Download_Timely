# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from typing_extensions import TypeAlias

from .rich_group_dto_response import RichGroupDtoResponse

__all__ = ["RestrictionListResponse"]

RestrictionListResponse: TypeAlias = List[RichGroupDtoResponse]
