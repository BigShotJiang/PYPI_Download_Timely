jaqpotpy.api.openapi.models package
===================================

Submodules
----------

jaqpotpy.api.openapi.models.api\_key module
-------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.api_key
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.binary\_classification\_scores module
-----------------------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.binary_classification_scores
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.bounding\_box\_doa module
-----------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.bounding_box_doa
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.city\_block\_doa module
---------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.city_block_doa
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.create\_api\_key201\_response module
----------------------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.create_api_key201_response
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.create\_invitations\_request module
---------------------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.create_invitations_request
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.dataset module
------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.dataset
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.dataset\_csv module
-----------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.dataset_csv
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.dataset\_type module
------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.dataset_type
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.doa module
--------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.doa
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.doa\_method module
----------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.doa_method
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.error\_code module
----------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.error_code
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.error\_response module
--------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.error_response
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.feature module
------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.feature
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.feature\_possible\_value module
-----------------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.feature_possible_value
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.feature\_type module
------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.feature_type
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.get\_all\_api\_keys\_for\_user200\_response\_inner module
-------------------------------------------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.get_all_api_keys_for_user200_response_inner
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.get\_datasets200\_response module
-------------------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.get_datasets200_response
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.get\_models200\_response module
-----------------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.get_models200_response
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.kernel\_based\_doa module
-----------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.kernel_based_doa
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.lead module
---------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.lead
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.leverage\_doa module
------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.leverage_doa
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.library module
------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.library
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.mahalanobis\_doa module
---------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.mahalanobis_doa
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.mean\_var\_doa module
-------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.mean_var_doa
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.model module
----------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.model
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.model\_scores module
------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.model_scores
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.model\_summary module
-------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.model_summary
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.model\_task module
----------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.model_task
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.model\_type module
----------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.model_type
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.model\_visibility module
----------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.model_visibility
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.multiclass\_classification\_scores module
---------------------------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.multiclass_classification_scores
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.organization module
-----------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.organization
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.organization\_invitation module
-----------------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.organization_invitation
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.organization\_summary module
--------------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.organization_summary
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.organization\_user module
-----------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.organization_user
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.organization\_user\_association\_type module
------------------------------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.organization_user_association_type
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.organization\_visibility module
-----------------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.organization_visibility
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.partial\_update\_organization\_request module
-------------------------------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.partial_update_organization_request
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.partially\_update\_model\_feature\_request module
-----------------------------------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.partially_update_model_feature_request
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.partially\_update\_model\_request module
--------------------------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.partially_update_model_request
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.prediction\_doa module
--------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.prediction_doa
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.prediction\_model module
----------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.prediction_model
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.prediction\_request module
------------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.prediction_request
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.prediction\_response module
-------------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.prediction_response
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.regression\_scores module
-----------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.regression_scores
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.scores module
-----------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.scores
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.transformer module
----------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.transformer
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.update\_api\_key200\_response module
----------------------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.update_api_key200_response
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.update\_api\_key\_request module
------------------------------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.update_api_key_request
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.api.openapi.models.user module
---------------------------------------

.. automodule:: jaqpotpy.api.openapi.models.user
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: jaqpotpy.api.openapi.models
   :members:
   :undoc-members:
   :show-inheritance:
