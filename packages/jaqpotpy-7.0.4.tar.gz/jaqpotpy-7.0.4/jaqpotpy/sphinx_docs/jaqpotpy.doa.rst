jaqpotpy.doa package
====================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   jaqpotpy.doa.tests

Submodules
----------

jaqpotpy.doa.doa module
-----------------------

.. automodule:: jaqpotpy.doa.doa
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: jaqpotpy.doa
   :members:
   :undoc-members:
   :show-inheritance:
