jaqpotpy.models.tests package
=============================

Submodules
----------

jaqpotpy.models.tests.one\_hot\_tests module
--------------------------------------------

.. automodule:: jaqpotpy.models.tests.one_hot_tests
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.models.tests.test\_sklearn module
------------------------------------------

.. automodule:: jaqpotpy.models.tests.test_sklearn
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: jaqpotpy.models.tests
   :members:
   :undoc-members:
   :show-inheritance:
