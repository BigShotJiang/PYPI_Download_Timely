jaqpotpy.models package
=======================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   jaqpotpy.models.tests
   jaqpotpy.models.torch_geometric_models
   jaqpotpy.models.torch_models
   jaqpotpy.models.trainers

Submodules
----------

jaqpotpy.models.base\_classes module
------------------------------------

.. automodule:: jaqpotpy.models.base_classes
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.models.sklearn module
------------------------------

.. automodule:: jaqpotpy.models.sklearn
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.models.xgboost module
------------------------------

.. automodule:: jaqpotpy.models.xgboost
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: jaqpotpy.models
   :members:
   :undoc-members:
   :show-inheritance:
