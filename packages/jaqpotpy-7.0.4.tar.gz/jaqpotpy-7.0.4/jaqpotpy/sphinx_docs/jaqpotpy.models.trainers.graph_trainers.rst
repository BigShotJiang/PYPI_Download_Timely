jaqpotpy.models.trainers.graph\_trainers package
================================================

Submodules
----------

jaqpotpy.models.trainers.graph\_trainers.binary\_trainer module
---------------------------------------------------------------

.. automodule:: jaqpotpy.models.trainers.graph_trainers.binary_trainer
   :members:
   :undoc-members:
   :show-inheritance:

jaqpotpy.models.trainers.graph\_trainers.regression\_trainer module
-------------------------------------------------------------------

.. automodule:: jaqpotpy.models.trainers.graph_trainers.regression_trainer
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: jaqpotpy.models.trainers.graph_trainers
   :members:
   :undoc-members:
   :show-inheritance:
