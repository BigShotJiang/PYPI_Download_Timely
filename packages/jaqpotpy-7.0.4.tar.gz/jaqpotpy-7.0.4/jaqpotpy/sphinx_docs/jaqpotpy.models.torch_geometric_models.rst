jaqpotpy.models.torch\_geometric\_models package
================================================

Submodules
----------

jaqpotpy.models.torch\_geometric\_models.graph\_neural\_network module
----------------------------------------------------------------------

.. automodule:: jaqpotpy.models.torch_geometric_models.graph_neural_network
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: jaqpotpy.models.torch_geometric_models
   :members:
   :undoc-members:
   :show-inheritance:
