from jaqpotpy.models.trainers.graph_trainers.binary_trainer import (
    BinaryGraphModelTrainer,
)
from jaqpotpy.models.trainers.graph_trainers.regression_trainer import (
    RegressionGraphModelTrainer,
)
