from jaqpotpy.models.trainers.base_trainer import TorchModelTrainer
