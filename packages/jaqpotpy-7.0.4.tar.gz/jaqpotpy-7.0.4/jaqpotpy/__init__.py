from .jaqpot import Jaqpot

__version__ = "7.0.4"
