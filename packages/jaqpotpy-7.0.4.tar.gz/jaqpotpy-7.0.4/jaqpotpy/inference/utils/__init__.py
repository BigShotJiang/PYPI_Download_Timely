"""
Utility functions for prediction processing.

Includes image processing, tensor operations, and other helper functions
used by prediction handlers.
"""
