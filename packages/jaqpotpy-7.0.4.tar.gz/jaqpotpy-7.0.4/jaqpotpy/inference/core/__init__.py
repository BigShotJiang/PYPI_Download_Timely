"""
Core prediction algorithms and data processing utilities.

This module contains the fundamental prediction logic shared between
local development and production inference.
"""
