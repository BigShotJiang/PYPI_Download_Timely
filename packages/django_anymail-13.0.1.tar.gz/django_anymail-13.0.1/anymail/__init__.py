from ._version import VERSION, __version__

__all__ = [
    "VERSION",
    "__version__",
]
