# Don't import this file directly (unless you are a build system).
# Instead, load version info from the package root.

#: major.minor or major.minor.patch (optionally with .devN suffix)
__version__ = "13.0.1"

VERSION = __version__.split(",")
