# Tests for enhanced tool functionality
