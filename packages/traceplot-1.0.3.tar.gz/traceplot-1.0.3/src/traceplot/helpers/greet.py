def greetme() -> str:
    text = "greeted"
    print(text)
    return text
