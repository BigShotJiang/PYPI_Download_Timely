# @dataclass
# class UserMessage(Exception):
#     """To be raised each time a user message is found."""
#     msg: dict

# @dataclass
# class AssistantMessage(Exception):
#     """To be raised each time an assistant message is found."""
#     msg: dict

# class AppendContentHandler:
