from invariant.analyzer.stdlib.invariant.parsers.html import *
from invariant.analyzer.stdlib.invariant.parsers.ocr import *
