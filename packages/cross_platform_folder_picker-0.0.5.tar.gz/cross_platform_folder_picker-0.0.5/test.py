from src.cross_platform_folder_picker import open_folder_picker

res = open_folder_picker()

print(res)
