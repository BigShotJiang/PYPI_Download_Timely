#!/usr/bin/env python
"""Setup script for the 'xdis' distribution."""

from setuptools import setup

setup(packages=["xdis"])
