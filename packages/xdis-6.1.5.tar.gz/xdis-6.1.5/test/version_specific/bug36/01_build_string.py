# Generates wordcode with Python 3.6 "BUILD_STRING" op
x = 'abcd'
y = 'def'
print(f"{x}{y}")
