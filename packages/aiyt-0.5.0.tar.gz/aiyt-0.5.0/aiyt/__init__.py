metadata = {
    "name": "aiyt",
    "version": "0.5.0",
    "description": "Transcribe, Chat and Summarize Youtube Video with AI",
}
