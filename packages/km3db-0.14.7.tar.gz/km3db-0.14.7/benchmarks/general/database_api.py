#!/usr/bin/env python3

import km3db

db = km3db.DBManager()
