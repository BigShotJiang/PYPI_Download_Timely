#!/usr/bin/env bash
# set -euo pipefail

runinfo -h

runinfo 44 5446
