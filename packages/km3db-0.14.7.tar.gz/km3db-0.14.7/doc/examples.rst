========
Examples
========

.. include:: auto_examples/index.rst
