.. include:: ../README.rst


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   examples
   changelog

   autoapi/index

   Code Coverage <https://km3py.pages.km3net.de/km3db/coverage>
   Source (Git) <https://git.km3net.de/km3py/km3db>



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
