# -*- coding: utf-8 -*-

default_config_resources = [
    'cleanit-no-lyrics.yml',
    'cleanit-no-sdh.yml',
    'cleanit-no-spam.de.yml',
    'cleanit-no-spam.en.yml',
    'cleanit-no-spam.pt.yml',
    'cleanit-no-spam.yml',
    'cleanit-no-style.yml',
    'cleanit-ocr.en.yml',
    'cleanit-ocr.pt.yml',
    'cleanit-ocr.yml',
    'cleanit-tidy.en.yml',
    'cleanit-tidy.pt.yml',
    'cleanit-tidy.yml',
    'cleanit.yml',
]
