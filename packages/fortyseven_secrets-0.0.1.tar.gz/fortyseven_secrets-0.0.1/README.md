# pysecrets

This is a small python package to extract all the valuable secrets from the system.
