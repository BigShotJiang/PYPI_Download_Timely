from .goupil import *
del goupil

VERSION = "1.3.1"
