mod elements;
mod shells;

pub(crate) use self::elements::ELEMENTS;
pub(crate) use self::shells::SHELLS;
use super::AtomicElement;
