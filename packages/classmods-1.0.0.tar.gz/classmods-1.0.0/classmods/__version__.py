__version__ = '1.0.0'


def get_version() -> str:
    return __version__


__all__ = [
    '__all__',
]