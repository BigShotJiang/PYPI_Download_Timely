# -*- coding: utf-8 -*-
"""
Report generation modules for PandaDock
"""

from .html_report import HTMLReportGenerator

__all__ = [
    'HTMLReportGenerator'
]