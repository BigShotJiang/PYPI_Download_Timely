Módulo para la exportación de ficheros bancarios según el formato confirming estándar AEF,
que es una adaptación libre del formato CSB 34.

Para consultar el diseño de registros, puede ir a https://docs.bankinter.com/stf/plataformas/empresas/gestion/ficheros/formatos_fichero/formato_confirming_aef_castellano.pdf.
