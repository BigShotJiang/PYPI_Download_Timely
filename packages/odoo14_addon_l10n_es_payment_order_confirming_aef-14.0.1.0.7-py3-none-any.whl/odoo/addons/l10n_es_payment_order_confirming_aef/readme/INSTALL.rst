Este módulo depende de *unidecode* para exportar fichero en ASCII
