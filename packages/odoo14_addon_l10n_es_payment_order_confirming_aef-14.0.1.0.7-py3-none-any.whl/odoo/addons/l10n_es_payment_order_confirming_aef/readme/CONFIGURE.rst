Para poder generar el archivo de exportación confirming AEF, hay que definir un modo de
pago que use el tipo de pago "Confirming AEF". Para ello, vaya a Facturación / Contabilidad >
Configuración > Modos de pago, y escoja el tipo de pago a realizar
(Transferencia o cheque).

El nº de contrato de Confirming será el valor asignado en el campo `Contrato AEF Confirming`
dentro del modo de pago creado anteriormente
