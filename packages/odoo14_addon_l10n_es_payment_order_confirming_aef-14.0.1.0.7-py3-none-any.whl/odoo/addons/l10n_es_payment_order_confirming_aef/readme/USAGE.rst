Cree una orden de cobro en Contabilidad > Pago > Órdenes de pago, y escoja
el modo de pago creado antes.

Confirme la orden de pago, y pulse en el botón "Realizar pagos". Pulse en
"Generar" en la pantalla resultante, y obtendra el archivo exportado.
