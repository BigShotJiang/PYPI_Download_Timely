__version__ = "0.51.9"


if __name__ == "__main__":
    print(__version__)
