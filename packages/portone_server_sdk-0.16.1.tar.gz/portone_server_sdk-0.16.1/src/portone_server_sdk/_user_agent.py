USER_AGENT = "v0.16.1-dirty"

__all__ = ["USER_AGENT"]
