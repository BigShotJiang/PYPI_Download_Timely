"""
Bleu tests module.

This module contains test suites for Bleu.js.
"""

__version__ = "1.1.7"
