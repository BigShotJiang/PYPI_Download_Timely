"""
Quantum tests module.

This module contains quantum computing tests for Bleu.js.
"""

__version__ = "1.1.7"
