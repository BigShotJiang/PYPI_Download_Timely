"""
Bleu AI module.

This module provides AI capabilities for Bleu.js.
"""

__version__ = "1.1.7"
