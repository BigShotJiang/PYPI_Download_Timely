"""
Configuration tests module.

This module contains configuration tests for Bleu.js.
"""

__version__ = "1.1.7"
