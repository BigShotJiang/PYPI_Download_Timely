"""
Configuration module.

This module provides configuration management for Bleu.js.
"""

__version__ = "1.1.7"
