from src.models.declarative_base import Base

__all__ = ["Base"]
