"""
Quantum machine learning module.

This module provides quantum-enhanced machine learning capabilities.
"""

__version__ = "1.1.7"
