"""
Quantum hybrid computing module.

This module provides hybrid quantum-classical computing capabilities.
"""

__version__ = "1.1.7"
