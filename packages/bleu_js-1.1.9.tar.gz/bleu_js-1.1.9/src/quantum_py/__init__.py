"""
Quantum Python module for Bleu.js.

This module provides quantum computing capabilities and utilities.
"""

__version__ = "1.1.7"
__author__ = "Bleu.js Team"
