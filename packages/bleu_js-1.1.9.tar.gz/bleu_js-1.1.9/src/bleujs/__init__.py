"""
Bleujs core module.

This module provides core functionality for Bleujs.
"""

__version__ = "1.1.7"
