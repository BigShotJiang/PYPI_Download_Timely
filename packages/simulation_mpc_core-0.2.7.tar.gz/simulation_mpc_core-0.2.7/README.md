# My Library

This is a simple Python library that does something cool!

## Installation

```bash
pip install simulation-mpc-core