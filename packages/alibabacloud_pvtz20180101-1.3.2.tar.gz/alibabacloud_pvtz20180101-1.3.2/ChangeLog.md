2025-06-30 Version: 1.3.1
- Update API AddResolverRule: add request parameters EdgeDnsClusters.
- Update API AddResolverRule: add request parameters Vpcs.
- Update API DescribeResolverRule: add response parameters Body.BindEdgeDnsClusters.
- Update API DescribeResolverRules: add response parameters Body.Rules.$.BindEdgeDnsClusters.
- Update API DescribeZoneInfo: add response parameters Body.BindEdgeDnsClusters.
- Update API DescribeZones: add response parameters Body.Zones.$.SlaveDnsStatus.


2024-11-25 Version: 1.3.0
- Support API DescribeUserServiceStatus.
- Update API BindResolverRuleVpc: update param Vpc.
- Update API BindZoneVpc: update param Vpcs.
- Update API DescribeChangeLogs: update response param.


2024-08-08 Version: 1.2.0
- Support API DescribeUserServiceStatus.


2024-08-01 Version: 1.1.0
- Support API AddCustomLine.
- Support API ChangeZoneDnsGroup.
- Support API DeleteCustomLine.
- Support API DescribeCustomLineInfo.
- Support API DescribeCustomLines.
- Support API DescribeZoneRecord.
- Support API SearchCustomLines.
- Support API UpdateCustomLine.


2024-07-09 Version: 1.0.5
- Update API AddZone: add param DnsGroup.
- Update API DescribeResolverEndpoints: add param VpcRegionId.
- Update API UpdateResolverRule: add param EndpointId.


2024-07-09 Version: 1.0.5
- Update API AddZone: add param DnsGroup.
- Update API DescribeResolverEndpoints: add param VpcRegionId.
- Update API UpdateResolverRule: add param EndpointId.


2024-02-19 Version: 1.0.4
- Update API AddZone: add param DnsGroup.


2023-10-23 Version: 1.0.3
- Generated python 2018-01-01 for pvtz.

2023-05-12 Version: 1.0.2
- Update python sdk.

2021-03-30 Version: 1.0.1
- Generated python 2018-01-01 for pvtz.

2020-12-30 Version: 1.0.0
- AMP Version Change.

