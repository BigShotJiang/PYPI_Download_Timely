# dataflow-conda-plugin
Conda plugin which install dataflow dependencies in every newly created conda environment.
