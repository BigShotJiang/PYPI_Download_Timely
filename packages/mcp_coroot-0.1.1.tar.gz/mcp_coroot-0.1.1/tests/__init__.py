"""Test package for mcp-coroot."""
