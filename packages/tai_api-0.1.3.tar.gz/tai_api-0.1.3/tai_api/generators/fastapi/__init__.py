from .endpoints import EndpointsGenerator

__all__ = ["EndpointsGenerator"]