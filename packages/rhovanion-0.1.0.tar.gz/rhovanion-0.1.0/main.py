def main():
    print("Hello from rhovanion!")


if __name__ == "__main__":
    main()
