from cg.constants.constants import FileExtensions


QUALITY_REPORT_FILE_NAME: str = f"QC_done{FileExtensions.JSON}"
