# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "premai"
__version__ = "0.9.3"  # x-release-please-version
