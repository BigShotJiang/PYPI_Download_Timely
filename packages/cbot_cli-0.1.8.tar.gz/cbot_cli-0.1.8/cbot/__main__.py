import sys
from .cbot_cli import run_cbot


def main():
    run_cbot(sys.argv)


if __name__ == "__main__":
    main()
