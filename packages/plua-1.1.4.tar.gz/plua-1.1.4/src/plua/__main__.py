"""
Entry point for plua module when run with python -m plua
"""

from .main import main

if __name__ == "__main__":
    main()
