
from .clselove import (
    auto,
    get_phone,
    get_sms,
    scr,
    totel_temp,
    geetest,
    se,
    na_em,
    cap_se,
    web,
    se_chr
)

__version__ = "0.6"
__author__ = "CodeMaster"
