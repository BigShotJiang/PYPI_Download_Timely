from . import ScraperToolSet
from ...utils.remote import toolset_cli


toolset_cli(ScraperToolSet, "scraper") 