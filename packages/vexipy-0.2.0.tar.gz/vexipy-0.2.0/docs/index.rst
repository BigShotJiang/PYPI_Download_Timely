Welcome to Vexipy documentation!
===================================


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   quickstart
   apidocs



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`