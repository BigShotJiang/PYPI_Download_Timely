API Documentation
=================

.. automodule:: vexipy
   :members: Product, Subcomponent, Document, StatusJustification, StatusLabel, Vulnerability, Statement
   :exclude-members: model_config