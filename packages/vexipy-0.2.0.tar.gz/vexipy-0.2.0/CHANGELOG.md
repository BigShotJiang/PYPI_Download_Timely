# Changelog

## [v0.2.0] - TBD

### New features 

- Added last updated fields

### Bug fixes

### Breaking changes

- Removed timestamp normalizaiton
- Renamed Component to Product

### Security fixes

## [v0.1.0] - 2025-07-16

- Initial Release