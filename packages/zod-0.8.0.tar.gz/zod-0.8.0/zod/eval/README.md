# Evaluation

TODO: describe the evaluation process for each task