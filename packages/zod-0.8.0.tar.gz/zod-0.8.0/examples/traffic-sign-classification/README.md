# Minimalistic Traffic Sign Recognition classifier

This is a placeholder