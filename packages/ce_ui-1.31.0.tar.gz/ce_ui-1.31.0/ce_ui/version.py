from DiscoverVersion import get_version

__version__ = get_version('ce_ui', __file__)
