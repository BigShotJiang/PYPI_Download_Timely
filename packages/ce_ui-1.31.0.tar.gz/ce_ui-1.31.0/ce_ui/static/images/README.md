Logo
====

contact.engineering logo (ce_logo.svg and favicon) by Michal Rössler.
The logo is licensed under CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/).
