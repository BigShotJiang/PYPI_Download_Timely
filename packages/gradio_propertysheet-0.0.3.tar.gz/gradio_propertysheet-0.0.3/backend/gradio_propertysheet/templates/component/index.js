var Ml = Object.defineProperty;
var Si = (i) => {
  throw TypeError(i);
};
var Pl = (i, e, t) => e in i ? Ml(i, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : i[e] = t;
var Q = (i, e, t) => Pl(i, typeof e != "symbol" ? e + "" : e, t), Ul = (i, e, t) => e.has(i) || Si("Cannot " + t);
var Ti = (i, e, t) => e.has(i) ? Si("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(i) : e.set(i, t);
var cn = (i, e, t) => (Ul(i, e, "access private method"), t);
const {
  SvelteComponent: Hl,
  append_hydration: Yn,
  assign: Gl,
  attr: De,
  binding_callbacks: jl,
  children: Xt,
  claim_element: Ha,
  claim_space: Ga,
  claim_svg_element: qn,
  create_slot: Vl,
  detach: et,
  element: ja,
  empty: Bi,
  get_all_dirty_from_scope: Wl,
  get_slot_changes: Zl,
  get_spread_update: Yl,
  init: Xl,
  insert_hydration: tn,
  listen: Kl,
  noop: Ql,
  safe_not_equal: Jl,
  set_dynamic_element_data: Ri,
  set_style: V,
  space: Va,
  svg_element: Nn,
  toggle_class: fe,
  transition_in: Wa,
  transition_out: Za,
  update_slot_base: eo
} = window.__gradio__svelte__internal;
function Ii(i) {
  let e, t, n, a, o;
  return {
    c() {
      e = Nn("svg"), t = Nn("line"), n = Nn("line"), this.h();
    },
    l(l) {
      e = qn(l, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var r = Xt(e);
      t = qn(r, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Xt(t).forEach(et), n = qn(r, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Xt(n).forEach(et), r.forEach(et), this.h();
    },
    h() {
      De(t, "x1", "1"), De(t, "y1", "9"), De(t, "x2", "9"), De(t, "y2", "1"), De(t, "stroke", "gray"), De(t, "stroke-width", "0.5"), De(n, "x1", "5"), De(n, "y1", "9"), De(n, "x2", "9"), De(n, "y2", "5"), De(n, "stroke", "gray"), De(n, "stroke-width", "0.5"), De(e, "class", "resize-handle svelte-239wnu"), De(e, "xmlns", "http://www.w3.org/2000/svg"), De(e, "viewBox", "0 0 10 10");
    },
    m(l, r) {
      tn(l, e, r), Yn(e, t), Yn(e, n), a || (o = Kl(
        e,
        "mousedown",
        /*resize*/
        i[27]
      ), a = !0);
    },
    p: Ql,
    d(l) {
      l && et(e), a = !1, o();
    }
  };
}
function to(i) {
  var h;
  let e, t, n, a, o;
  const l = (
    /*#slots*/
    i[31].default
  ), r = Vl(
    l,
    i,
    /*$$scope*/
    i[30],
    null
  );
  let s = (
    /*resizable*/
    i[19] && Ii(i)
  ), u = [
    { "data-testid": (
      /*test_id*/
      i[11]
    ) },
    { id: (
      /*elem_id*/
      i[6]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      (((h = i[7]) == null ? void 0 : h.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: a = /*rtl*/
      i[20] ? "rtl" : "ltr"
    }
  ], c = {};
  for (let d = 0; d < u.length; d += 1)
    c = Gl(c, u[d]);
  return {
    c() {
      e = ja(
        /*tag*/
        i[25]
      ), r && r.c(), t = Va(), s && s.c(), this.h();
    },
    l(d) {
      e = Ha(
        d,
        /*tag*/
        (i[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var f = Xt(e);
      r && r.l(f), t = Ga(f), s && s.l(f), f.forEach(et), this.h();
    },
    h() {
      Ri(
        /*tag*/
        i[25]
      )(e, c), fe(
        e,
        "hidden",
        /*visible*/
        i[14] === !1
      ), fe(
        e,
        "padded",
        /*padding*/
        i[10]
      ), fe(
        e,
        "flex",
        /*flex*/
        i[1]
      ), fe(
        e,
        "border_focus",
        /*border_mode*/
        i[9] === "focus"
      ), fe(
        e,
        "border_contrast",
        /*border_mode*/
        i[9] === "contrast"
      ), fe(e, "hide-container", !/*explicit_call*/
      i[12] && !/*container*/
      i[13]), fe(
        e,
        "fullscreen",
        /*fullscreen*/
        i[0]
      ), fe(
        e,
        "animating",
        /*fullscreen*/
        i[0] && /*preexpansionBoundingRect*/
        i[24] !== null
      ), fe(
        e,
        "auto-margin",
        /*scale*/
        i[17] === null
      ), V(
        e,
        "height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*height*/
            i[2]
          )
        )
      ), V(
        e,
        "min-height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*min_height*/
            i[3]
          )
        )
      ), V(
        e,
        "max-height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*max_height*/
            i[4]
          )
        )
      ), V(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].top}px` : "0px"
      ), V(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].left}px` : "0px"
      ), V(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].width}px` : "0px"
      ), V(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].height}px` : "0px"
      ), V(
        e,
        "width",
        /*fullscreen*/
        i[0] ? void 0 : typeof /*width*/
        i[5] == "number" ? `calc(min(${/*width*/
        i[5]}px, 100%))` : (
          /*get_dimension*/
          i[26](
            /*width*/
            i[5]
          )
        )
      ), V(
        e,
        "border-style",
        /*variant*/
        i[8]
      ), V(
        e,
        "overflow",
        /*allow_overflow*/
        i[15] ? (
          /*overflow_behavior*/
          i[16]
        ) : "hidden"
      ), V(
        e,
        "flex-grow",
        /*scale*/
        i[17]
      ), V(e, "min-width", `calc(min(${/*min_width*/
      i[18]}px, 100%))`), V(e, "border-width", "var(--block-border-width)");
    },
    m(d, f) {
      tn(d, e, f), r && r.m(e, null), Yn(e, t), s && s.m(e, null), i[32](e), o = !0;
    },
    p(d, f) {
      var v;
      r && r.p && (!o || f[0] & /*$$scope*/
      1073741824) && eo(
        r,
        l,
        d,
        /*$$scope*/
        d[30],
        o ? Zl(
          l,
          /*$$scope*/
          d[30],
          f,
          null
        ) : Wl(
          /*$$scope*/
          d[30]
        ),
        null
      ), /*resizable*/
      d[19] ? s ? s.p(d, f) : (s = Ii(d), s.c(), s.m(e, null)) : s && (s.d(1), s = null), Ri(
        /*tag*/
        d[25]
      )(e, c = Yl(u, [
        (!o || f[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          d[11]
        ) },
        (!o || f[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          d[6]
        ) },
        (!o || f[0] & /*elem_classes*/
        128 && n !== (n = "block " + /*elem_classes*/
        (((v = d[7]) == null ? void 0 : v.join(" ")) || "") + " svelte-239wnu")) && { class: n },
        (!o || f[0] & /*rtl*/
        1048576 && a !== (a = /*rtl*/
        d[20] ? "rtl" : "ltr")) && { dir: a }
      ])), fe(
        e,
        "hidden",
        /*visible*/
        d[14] === !1
      ), fe(
        e,
        "padded",
        /*padding*/
        d[10]
      ), fe(
        e,
        "flex",
        /*flex*/
        d[1]
      ), fe(
        e,
        "border_focus",
        /*border_mode*/
        d[9] === "focus"
      ), fe(
        e,
        "border_contrast",
        /*border_mode*/
        d[9] === "contrast"
      ), fe(e, "hide-container", !/*explicit_call*/
      d[12] && !/*container*/
      d[13]), fe(
        e,
        "fullscreen",
        /*fullscreen*/
        d[0]
      ), fe(
        e,
        "animating",
        /*fullscreen*/
        d[0] && /*preexpansionBoundingRect*/
        d[24] !== null
      ), fe(
        e,
        "auto-margin",
        /*scale*/
        d[17] === null
      ), f[0] & /*fullscreen, height*/
      5 && V(
        e,
        "height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*height*/
            d[2]
          )
        )
      ), f[0] & /*fullscreen, min_height*/
      9 && V(
        e,
        "min-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*min_height*/
            d[3]
          )
        )
      ), f[0] & /*fullscreen, max_height*/
      17 && V(
        e,
        "max-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*max_height*/
            d[4]
          )
        )
      ), f[0] & /*preexpansionBoundingRect*/
      16777216 && V(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].top}px` : "0px"
      ), f[0] & /*preexpansionBoundingRect*/
      16777216 && V(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].left}px` : "0px"
      ), f[0] & /*preexpansionBoundingRect*/
      16777216 && V(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].width}px` : "0px"
      ), f[0] & /*preexpansionBoundingRect*/
      16777216 && V(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].height}px` : "0px"
      ), f[0] & /*fullscreen, width*/
      33 && V(
        e,
        "width",
        /*fullscreen*/
        d[0] ? void 0 : typeof /*width*/
        d[5] == "number" ? `calc(min(${/*width*/
        d[5]}px, 100%))` : (
          /*get_dimension*/
          d[26](
            /*width*/
            d[5]
          )
        )
      ), f[0] & /*variant*/
      256 && V(
        e,
        "border-style",
        /*variant*/
        d[8]
      ), f[0] & /*allow_overflow, overflow_behavior*/
      98304 && V(
        e,
        "overflow",
        /*allow_overflow*/
        d[15] ? (
          /*overflow_behavior*/
          d[16]
        ) : "hidden"
      ), f[0] & /*scale*/
      131072 && V(
        e,
        "flex-grow",
        /*scale*/
        d[17]
      ), f[0] & /*min_width*/
      262144 && V(e, "min-width", `calc(min(${/*min_width*/
      d[18]}px, 100%))`);
    },
    i(d) {
      o || (Wa(r, d), o = !0);
    },
    o(d) {
      Za(r, d), o = !1;
    },
    d(d) {
      d && et(e), r && r.d(d), s && s.d(), i[32](null);
    }
  };
}
function Li(i) {
  let e;
  return {
    c() {
      e = ja("div"), this.h();
    },
    l(t) {
      e = Ha(t, "DIV", { class: !0 }), Xt(e).forEach(et), this.h();
    },
    h() {
      De(e, "class", "placeholder svelte-239wnu"), V(
        e,
        "height",
        /*placeholder_height*/
        i[22] + "px"
      ), V(
        e,
        "width",
        /*placeholder_width*/
        i[23] + "px"
      );
    },
    m(t, n) {
      tn(t, e, n);
    },
    p(t, n) {
      n[0] & /*placeholder_height*/
      4194304 && V(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), n[0] & /*placeholder_width*/
      8388608 && V(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && et(e);
    }
  };
}
function no(i) {
  let e, t, n, a = (
    /*tag*/
    i[25] && to(i)
  ), o = (
    /*fullscreen*/
    i[0] && Li(i)
  );
  return {
    c() {
      a && a.c(), e = Va(), o && o.c(), t = Bi();
    },
    l(l) {
      a && a.l(l), e = Ga(l), o && o.l(l), t = Bi();
    },
    m(l, r) {
      a && a.m(l, r), tn(l, e, r), o && o.m(l, r), tn(l, t, r), n = !0;
    },
    p(l, r) {
      /*tag*/
      l[25] && a.p(l, r), /*fullscreen*/
      l[0] ? o ? o.p(l, r) : (o = Li(l), o.c(), o.m(t.parentNode, t)) : o && (o.d(1), o = null);
    },
    i(l) {
      n || (Wa(a, l), n = !0);
    },
    o(l) {
      Za(a, l), n = !1;
    },
    d(l) {
      l && (et(e), et(t)), a && a.d(l), o && o.d(l);
    }
  };
}
function io(i, e, t) {
  let { $$slots: n = {}, $$scope: a } = e, { height: o = void 0 } = e, { min_height: l = void 0 } = e, { max_height: r = void 0 } = e, { width: s = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: c = [] } = e, { variant: h = "solid" } = e, { border_mode: d = "base" } = e, { padding: f = !0 } = e, { type: v = "normal" } = e, { test_id: D = void 0 } = e, { explicit_call: b = !1 } = e, { container: E = !0 } = e, { visible: m = !0 } = e, { allow_overflow: _ = !0 } = e, { overflow_behavior: g = "auto" } = e, { scale: F = null } = e, { min_width: w = 0 } = e, { flex: C = !1 } = e, { resizable: I = !1 } = e, { rtl: S = !1 } = e, { fullscreen: O = !1 } = e, q = O, H, ke = v === "fieldset" ? "fieldset" : "div", re = 0, ae = 0, se = null;
  function Se($) {
    O && $.key === "Escape" && t(0, O = !1);
  }
  const K = ($) => {
    if ($ !== void 0) {
      if (typeof $ == "number")
        return $ + "px";
      if (typeof $ == "string")
        return $;
    }
  }, ue = ($) => {
    let le = $.clientY;
    const X = (A) => {
      const Ee = A.clientY - le;
      le = A.clientY, t(21, H.style.height = `${H.offsetHeight + Ee}px`, H);
    }, _e = () => {
      window.removeEventListener("mousemove", X), window.removeEventListener("mouseup", _e);
    };
    window.addEventListener("mousemove", X), window.addEventListener("mouseup", _e);
  };
  function he($) {
    jl[$ ? "unshift" : "push"](() => {
      H = $, t(21, H);
    });
  }
  return i.$$set = ($) => {
    "height" in $ && t(2, o = $.height), "min_height" in $ && t(3, l = $.min_height), "max_height" in $ && t(4, r = $.max_height), "width" in $ && t(5, s = $.width), "elem_id" in $ && t(6, u = $.elem_id), "elem_classes" in $ && t(7, c = $.elem_classes), "variant" in $ && t(8, h = $.variant), "border_mode" in $ && t(9, d = $.border_mode), "padding" in $ && t(10, f = $.padding), "type" in $ && t(28, v = $.type), "test_id" in $ && t(11, D = $.test_id), "explicit_call" in $ && t(12, b = $.explicit_call), "container" in $ && t(13, E = $.container), "visible" in $ && t(14, m = $.visible), "allow_overflow" in $ && t(15, _ = $.allow_overflow), "overflow_behavior" in $ && t(16, g = $.overflow_behavior), "scale" in $ && t(17, F = $.scale), "min_width" in $ && t(18, w = $.min_width), "flex" in $ && t(1, C = $.flex), "resizable" in $ && t(19, I = $.resizable), "rtl" in $ && t(20, S = $.rtl), "fullscreen" in $ && t(0, O = $.fullscreen), "$$scope" in $ && t(30, a = $.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && O !== q && (t(29, q = O), O ? (t(24, se = H.getBoundingClientRect()), t(22, re = H.offsetHeight), t(23, ae = H.offsetWidth), window.addEventListener("keydown", Se)) : (t(24, se = null), window.removeEventListener("keydown", Se))), i.$$.dirty[0] & /*visible*/
    16384 && (m || t(1, C = !1));
  }, [
    O,
    C,
    o,
    l,
    r,
    s,
    u,
    c,
    h,
    d,
    f,
    D,
    b,
    E,
    m,
    _,
    g,
    F,
    w,
    I,
    S,
    H,
    re,
    ae,
    se,
    ke,
    K,
    ue,
    v,
    q,
    a,
    n,
    he
  ];
}
class ao extends Hl {
  constructor(e) {
    super(), Xl(
      this,
      e,
      io,
      no,
      Jl,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function si() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let Tt = si();
function Ya(i) {
  Tt = i;
}
const Xa = /[&<>"']/, lo = new RegExp(Xa.source, "g"), Ka = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, oo = new RegExp(Ka.source, "g"), ro = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, xi = (i) => ro[i];
function Be(i, e) {
  if (e) {
    if (Xa.test(i))
      return i.replace(lo, xi);
  } else if (Ka.test(i))
    return i.replace(oo, xi);
  return i;
}
const so = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function uo(i) {
  return i.replace(so, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const co = /(^|[^\[])\^/g;
function Y(i, e) {
  let t = typeof i == "string" ? i : i.source;
  e = e || "";
  const n = {
    replace: (a, o) => {
      let l = typeof o == "string" ? o : o.source;
      return l = l.replace(co, "$1"), t = t.replace(a, l), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
function Oi(i) {
  try {
    i = encodeURI(i).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return i;
}
const Kt = { exec: () => null };
function qi(i, e) {
  const t = i.replace(/\|/g, (o, l, r) => {
    let s = !1, u = l;
    for (; --u >= 0 && r[u] === "\\"; )
      s = !s;
    return s ? "|" : " |";
  }), n = t.split(/ \|/);
  let a = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; )
        n.push("");
  for (; a < n.length; a++)
    n[a] = n[a].trim().replace(/\\\|/g, "|");
  return n;
}
function _n(i, e, t) {
  const n = i.length;
  if (n === 0)
    return "";
  let a = 0;
  for (; a < n && i.charAt(n - a - 1) === e; )
    a++;
  return i.slice(0, n - a);
}
function _o(i, e) {
  if (i.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < i.length; n++)
    if (i[n] === "\\")
      n++;
    else if (i[n] === e[0])
      t++;
    else if (i[n] === e[1] && (t--, t < 0))
      return n;
  return -1;
}
function Ni(i, e, t, n) {
  const a = e.href, o = e.title ? Be(e.title) : null, l = i[1].replace(/\\([\[\]])/g, "$1");
  if (i[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const r = {
      type: "link",
      raw: t,
      href: a,
      title: o,
      text: l,
      tokens: n.inlineTokens(l)
    };
    return n.state.inLink = !1, r;
  }
  return {
    type: "image",
    raw: t,
    href: a,
    title: o,
    text: Be(l)
  };
}
function fo(i, e) {
  const t = i.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const n = t[1];
  return e.split(`
`).map((a) => {
    const o = a.match(/^\s+/);
    if (o === null)
      return a;
    const [l] = o;
    return l.length >= n.length ? a.slice(n.length) : a;
  }).join(`
`);
}
class $n {
  // set by the lexer
  constructor(e) {
    Q(this, "options");
    Q(this, "rules");
    // set by the lexer
    Q(this, "lexer");
    this.options = e || Tt;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const n = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : _n(n, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const n = t[0], a = fo(n, t[3] || "");
      return {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: a
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (/#$/.test(n)) {
        const a = _n(n, "#");
        (this.options.pedantic || !a || / $/.test(a)) && (n = a.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = _n(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const a = this.lexer.state.top;
      this.lexer.state.top = !0;
      const o = this.lexer.blockTokens(n);
      return this.lexer.state.top = a, {
        type: "blockquote",
        raw: t[0],
        tokens: o,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim();
      const a = n.length > 1, o = {
        type: "list",
        raw: "",
        ordered: a,
        start: a ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = a ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = a ? n : "[*+-]");
      const l = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let r = "", s = "", u = !1;
      for (; e; ) {
        let c = !1;
        if (!(t = l.exec(e)) || this.rules.block.hr.test(e))
          break;
        r = t[0], e = e.substring(r.length);
        let h = t[2].split(`
`, 1)[0].replace(/^\t+/, (E) => " ".repeat(3 * E.length)), d = e.split(`
`, 1)[0], f = 0;
        this.options.pedantic ? (f = 2, s = h.trimStart()) : (f = t[2].search(/[^ ]/), f = f > 4 ? 1 : f, s = h.slice(f), f += t[1].length);
        let v = !1;
        if (!h && /^ *$/.test(d) && (r += d + `
`, e = e.substring(d.length + 1), c = !0), !c) {
          const E = new RegExp(`^ {0,${Math.min(3, f - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), m = new RegExp(`^ {0,${Math.min(3, f - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), _ = new RegExp(`^ {0,${Math.min(3, f - 1)}}(?:\`\`\`|~~~)`), g = new RegExp(`^ {0,${Math.min(3, f - 1)}}#`);
          for (; e; ) {
            const F = e.split(`
`, 1)[0];
            if (d = F, this.options.pedantic && (d = d.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), _.test(d) || g.test(d) || E.test(d) || m.test(e))
              break;
            if (d.search(/[^ ]/) >= f || !d.trim())
              s += `
` + d.slice(f);
            else {
              if (v || h.search(/[^ ]/) >= 4 || _.test(h) || g.test(h) || m.test(h))
                break;
              s += `
` + d;
            }
            !v && !d.trim() && (v = !0), r += F + `
`, e = e.substring(F.length + 1), h = d.slice(f);
          }
        }
        o.loose || (u ? o.loose = !0 : /\n *\n *$/.test(r) && (u = !0));
        let D = null, b;
        this.options.gfm && (D = /^\[[ xX]\] /.exec(s), D && (b = D[0] !== "[ ] ", s = s.replace(/^\[[ xX]\] +/, ""))), o.items.push({
          type: "list_item",
          raw: r,
          task: !!D,
          checked: b,
          loose: !1,
          text: s,
          tokens: []
        }), o.raw += r;
      }
      o.items[o.items.length - 1].raw = r.trimEnd(), o.items[o.items.length - 1].text = s.trimEnd(), o.raw = o.raw.trimEnd();
      for (let c = 0; c < o.items.length; c++)
        if (this.lexer.state.top = !1, o.items[c].tokens = this.lexer.blockTokens(o.items[c].text, []), !o.loose) {
          const h = o.items[c].tokens.filter((f) => f.type === "space"), d = h.length > 0 && h.some((f) => /\n.*\n/.test(f.raw));
          o.loose = d;
        }
      if (o.loose)
        for (let c = 0; c < o.items.length; c++)
          o.items[c].loose = !0;
      return o;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const n = t[1].toLowerCase().replace(/\s+/g, " "), a = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", o = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: t[0],
        href: a,
        title: o
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const n = qi(t[1]), a = t[2].replace(/^\||\| *$/g, "").split("|"), o = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], l = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === a.length) {
      for (const r of a)
        /^ *-+: *$/.test(r) ? l.align.push("right") : /^ *:-+: *$/.test(r) ? l.align.push("center") : /^ *:-+ *$/.test(r) ? l.align.push("left") : l.align.push(null);
      for (const r of n)
        l.header.push({
          text: r,
          tokens: this.lexer.inline(r)
        });
      for (const r of o)
        l.rows.push(qi(r, l.header.length).map((s) => ({
          text: s,
          tokens: this.lexer.inline(s)
        })));
      return l;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: Be(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const n = t[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const l = _n(n.slice(0, -1), "\\");
        if ((n.length - l.length) % 2 === 0)
          return;
      } else {
        const l = _o(t[2], "()");
        if (l > -1) {
          const s = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + l;
          t[2] = t[2].substring(0, l), t[0] = t[0].substring(0, s).trim(), t[3] = "";
        }
      }
      let a = t[2], o = "";
      if (this.options.pedantic) {
        const l = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(a);
        l && (a = l[1], o = l[3]);
      } else
        o = t[3] ? t[3].slice(1, -1) : "";
      return a = a.trim(), /^</.test(a) && (this.options.pedantic && !/>$/.test(n) ? a = a.slice(1) : a = a.slice(1, -1)), Ni(t, {
        href: a && a.replace(this.rules.inline.anyPunctuation, "$1"),
        title: o && o.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      const a = (n[2] || n[1]).replace(/\s+/g, " "), o = t[a.toLowerCase()];
      if (!o) {
        const l = n[0].charAt(0);
        return {
          type: "text",
          raw: l,
          text: l
        };
      }
      return Ni(n, o, n[0], this.lexer);
    }
  }
  emStrong(e, t, n = "") {
    let a = this.rules.inline.emStrongLDelim.exec(e);
    if (!a || a[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(a[1] || a[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const l = [...a[0]].length - 1;
      let r, s, u = l, c = 0;
      const h = a[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (h.lastIndex = 0, t = t.slice(-1 * e.length + l); (a = h.exec(t)) != null; ) {
        if (r = a[1] || a[2] || a[3] || a[4] || a[5] || a[6], !r)
          continue;
        if (s = [...r].length, a[3] || a[4]) {
          u += s;
          continue;
        } else if ((a[5] || a[6]) && l % 3 && !((l + s) % 3)) {
          c += s;
          continue;
        }
        if (u -= s, u > 0)
          continue;
        s = Math.min(s, s + u + c);
        const d = [...a[0]][0].length, f = e.slice(0, l + a.index + d + s);
        if (Math.min(l, s) % 2) {
          const D = f.slice(1, -1);
          return {
            type: "em",
            raw: f,
            text: D,
            tokens: this.lexer.inlineTokens(D)
          };
        }
        const v = f.slice(2, -2);
        return {
          type: "strong",
          raw: f,
          text: v,
          tokens: this.lexer.inlineTokens(v)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(/\n/g, " ");
      const a = /[^ ]/.test(n), o = /^ /.test(n) && / $/.test(n);
      return a && o && (n = n.substring(1, n.length - 1)), n = Be(n, !0), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, a;
      return t[2] === "@" ? (n = Be(t[1]), a = "mailto:" + n) : (n = Be(t[1]), a = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: a,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(e) {
    var n;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let a, o;
      if (t[2] === "@")
        a = Be(t[0]), o = "mailto:" + a;
      else {
        let l;
        do
          l = t[0], t[0] = ((n = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : n[0]) ?? "";
        while (l !== t[0]);
        a = Be(t[0]), t[1] === "www." ? o = "http://" + t[0] : o = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: a,
        href: o,
        tokens: [
          {
            type: "text",
            raw: a,
            text: a
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let n;
      return this.lexer.state.inRawBlock ? n = t[0] : n = Be(t[0]), {
        type: "text",
        raw: t[0],
        text: n
      };
    }
  }
}
const po = /^(?: *(?:\n|$))+/, ho = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, mo = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, nn = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, go = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, Qa = /(?:[*+-]|\d{1,9}[.)])/, Ja = Y(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, Qa).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), ui = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, vo = /^[^\n]+/, ci = /(?!\s*\])(?:\\.|[^\[\]\\])+/, Do = Y(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", ci).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), bo = Y(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, Qa).getRegex(), Tn = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", _i = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, yo = Y("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", _i).replace("tag", Tn).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), el = Y(ui).replace("hr", nn).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Tn).getRegex(), Fo = Y(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", el).getRegex(), di = {
  blockquote: Fo,
  code: ho,
  def: Do,
  fences: mo,
  heading: go,
  hr: nn,
  html: yo,
  lheading: Ja,
  list: bo,
  newline: po,
  paragraph: el,
  table: Kt,
  text: vo
}, zi = Y("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", nn).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Tn).getRegex(), wo = {
  ...di,
  table: zi,
  paragraph: Y(ui).replace("hr", nn).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", zi).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Tn).getRegex()
}, $o = {
  ...di,
  html: Y(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", _i).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: Kt,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: Y(ui).replace("hr", nn).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", Ja).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, tl = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, ko = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, nl = /^( {2,}|\\)\n(?!\s*$)/, Eo = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, an = "\\p{P}\\p{S}", Ao = Y(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, an).getRegex(), Co = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, So = Y(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, an).getRegex(), To = Y("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, an).getRegex(), Bo = Y("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, an).getRegex(), Ro = Y(/\\([punct])/, "gu").replace(/punct/g, an).getRegex(), Io = Y(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), Lo = Y(_i).replace("(?:-->|$)", "-->").getRegex(), xo = Y("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", Lo).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), kn = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, Oo = Y(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", kn).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), il = Y(/^!?\[(label)\]\[(ref)\]/).replace("label", kn).replace("ref", ci).getRegex(), al = Y(/^!?\[(ref)\](?:\[\])?/).replace("ref", ci).getRegex(), qo = Y("reflink|nolink(?!\\()", "g").replace("reflink", il).replace("nolink", al).getRegex(), fi = {
  _backpedal: Kt,
  // only used for GFM url
  anyPunctuation: Ro,
  autolink: Io,
  blockSkip: Co,
  br: nl,
  code: ko,
  del: Kt,
  emStrongLDelim: So,
  emStrongRDelimAst: To,
  emStrongRDelimUnd: Bo,
  escape: tl,
  link: Oo,
  nolink: al,
  punctuation: Ao,
  reflink: il,
  reflinkSearch: qo,
  tag: xo,
  text: Eo,
  url: Kt
}, No = {
  ...fi,
  link: Y(/^!?\[(label)\]\((.*?)\)/).replace("label", kn).getRegex(),
  reflink: Y(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", kn).getRegex()
}, Xn = {
  ...fi,
  escape: Y(tl).replace("])", "~|])").getRegex(),
  url: Y(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, zo = {
  ...Xn,
  br: Y(nl).replace("{2,}", "*").getRegex(),
  text: Y(Xn.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, dn = {
  normal: di,
  gfm: wo,
  pedantic: $o
}, Ht = {
  normal: fi,
  gfm: Xn,
  breaks: zo,
  pedantic: No
};
class tt {
  constructor(e) {
    Q(this, "tokens");
    Q(this, "options");
    Q(this, "state");
    Q(this, "tokenizer");
    Q(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || Tt, this.options.tokenizer = this.options.tokenizer || new $n(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: dn.normal,
      inline: Ht.normal
    };
    this.options.pedantic ? (t.block = dn.pedantic, t.inline = Ht.pedantic) : this.options.gfm && (t.block = dn.gfm, this.options.breaks ? t.inline = Ht.breaks : t.inline = Ht.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: dn,
      inline: Ht
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new tt(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new tt(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (r, s, u) => s + "    ".repeat(u.length));
    let n, a, o, l;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((r) => (n = r.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(e)) {
          e = e.substring(n.raw.length), n.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(n);
          continue;
        }
        if (n = this.tokenizer.code(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.list(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.html(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.def(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + n.raw, a.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (o = e, this.options.extensions && this.options.extensions.startBlock) {
          let r = 1 / 0;
          const s = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((c) => {
            u = c.call({ lexer: this }, s), typeof u == "number" && u >= 0 && (r = Math.min(r, u));
          }), r < 1 / 0 && r >= 0 && (o = e.substring(0, r + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(o))) {
          a = t[t.length - 1], l && a.type === "paragraph" ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n), l = o.length !== e.length, e = e.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && a.type === "text" ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n);
          continue;
        }
        if (e) {
          const r = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(r);
            break;
          } else
            throw new Error(r);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let n, a, o, l = e, r, s, u;
    if (this.tokens.links) {
      const c = Object.keys(this.tokens.links);
      if (c.length > 0)
        for (; (r = this.tokenizer.rules.inline.reflinkSearch.exec(l)) != null; )
          c.includes(r[0].slice(r[0].lastIndexOf("[") + 1, -1)) && (l = l.slice(0, r.index) + "[" + "a".repeat(r[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (r = this.tokenizer.rules.inline.blockSkip.exec(l)) != null; )
      l = l.slice(0, r.index) + "[" + "a".repeat(r[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (r = this.tokenizer.rules.inline.anyPunctuation.exec(l)) != null; )
      l = l.slice(0, r.index) + "++" + l.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (s || (u = ""), s = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((c) => (n = c.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && n.type === "text" && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.link(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && n.type === "text" && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(e, l, u)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.br(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.del(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(e))) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (o = e, this.options.extensions && this.options.extensions.startInline) {
          let c = 1 / 0;
          const h = e.slice(1);
          let d;
          this.options.extensions.startInline.forEach((f) => {
            d = f.call({ lexer: this }, h), typeof d == "number" && d >= 0 && (c = Math.min(c, d));
          }), c < 1 / 0 && c >= 0 && (o = e.substring(0, c + 1));
        }
        if (n = this.tokenizer.inlineText(o)) {
          e = e.substring(n.raw.length), n.raw.slice(-1) !== "_" && (u = n.raw.slice(-1)), s = !0, a = t[t.length - 1], a && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (e) {
          const c = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(c);
            break;
          } else
            throw new Error(c);
        }
      }
    return t;
  }
}
class En {
  constructor(e) {
    Q(this, "options");
    this.options = e || Tt;
  }
  code(e, t, n) {
    var o;
    const a = (o = (t || "").match(/^\S*/)) == null ? void 0 : o[0];
    return e = e.replace(/\n$/, "") + `
`, a ? '<pre><code class="language-' + Be(a) + '">' + (n ? e : Be(e, !0)) + `</code></pre>
` : "<pre><code>" + (n ? e : Be(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, n) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, n) {
    const a = t ? "ol" : "ul", o = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + a + o + `>
` + e + "</" + a + `>
`;
  }
  listitem(e, t, n) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const n = t.header ? "th" : "td";
    return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, n) {
    const a = Oi(e);
    if (a === null)
      return n;
    e = a;
    let o = '<a href="' + e + '"';
    return t && (o += ' title="' + t + '"'), o += ">" + n + "</a>", o;
  }
  image(e, t, n) {
    const a = Oi(e);
    if (a === null)
      return n;
    e = a;
    let o = `<img src="${e}" alt="${n}"`;
    return t && (o += ` title="${t}"`), o += ">", o;
  }
  text(e) {
    return e;
  }
}
class pi {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, n) {
    return "" + n;
  }
  image(e, t, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class nt {
  constructor(e) {
    Q(this, "options");
    Q(this, "renderer");
    Q(this, "textRenderer");
    this.options = e || Tt, this.options.renderer = this.options.renderer || new En(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new pi();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new nt(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new nt(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let n = "";
    for (let a = 0; a < e.length; a++) {
      const o = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[o.type]) {
        const l = o, r = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (r !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(l.type)) {
          n += r || "";
          continue;
        }
      }
      switch (o.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const l = o;
          n += this.renderer.heading(this.parseInline(l.tokens), l.depth, uo(this.parseInline(l.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const l = o;
          n += this.renderer.code(l.text, l.lang, !!l.escaped);
          continue;
        }
        case "table": {
          const l = o;
          let r = "", s = "";
          for (let c = 0; c < l.header.length; c++)
            s += this.renderer.tablecell(this.parseInline(l.header[c].tokens), { header: !0, align: l.align[c] });
          r += this.renderer.tablerow(s);
          let u = "";
          for (let c = 0; c < l.rows.length; c++) {
            const h = l.rows[c];
            s = "";
            for (let d = 0; d < h.length; d++)
              s += this.renderer.tablecell(this.parseInline(h[d].tokens), { header: !1, align: l.align[d] });
            u += this.renderer.tablerow(s);
          }
          n += this.renderer.table(r, u);
          continue;
        }
        case "blockquote": {
          const l = o, r = this.parse(l.tokens);
          n += this.renderer.blockquote(r);
          continue;
        }
        case "list": {
          const l = o, r = l.ordered, s = l.start, u = l.loose;
          let c = "";
          for (let h = 0; h < l.items.length; h++) {
            const d = l.items[h], f = d.checked, v = d.task;
            let D = "";
            if (d.task) {
              const b = this.renderer.checkbox(!!f);
              u ? d.tokens.length > 0 && d.tokens[0].type === "paragraph" ? (d.tokens[0].text = b + " " + d.tokens[0].text, d.tokens[0].tokens && d.tokens[0].tokens.length > 0 && d.tokens[0].tokens[0].type === "text" && (d.tokens[0].tokens[0].text = b + " " + d.tokens[0].tokens[0].text)) : d.tokens.unshift({
                type: "text",
                text: b + " "
              }) : D += b + " ";
            }
            D += this.parse(d.tokens, u), c += this.renderer.listitem(D, v, !!f);
          }
          n += this.renderer.list(c, r, s);
          continue;
        }
        case "html": {
          const l = o;
          n += this.renderer.html(l.text, l.block);
          continue;
        }
        case "paragraph": {
          const l = o;
          n += this.renderer.paragraph(this.parseInline(l.tokens));
          continue;
        }
        case "text": {
          let l = o, r = l.tokens ? this.parseInline(l.tokens) : l.text;
          for (; a + 1 < e.length && e[a + 1].type === "text"; )
            l = e[++a], r += `
` + (l.tokens ? this.parseInline(l.tokens) : l.text);
          n += t ? this.renderer.paragraph(r) : r;
          continue;
        }
        default: {
          const l = 'Token with "' + o.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let n = "";
    for (let a = 0; a < e.length; a++) {
      const o = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[o.type]) {
        const l = this.options.extensions.renderers[o.type].call({ parser: this }, o);
        if (l !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(o.type)) {
          n += l || "";
          continue;
        }
      }
      switch (o.type) {
        case "escape": {
          const l = o;
          n += t.text(l.text);
          break;
        }
        case "html": {
          const l = o;
          n += t.html(l.text);
          break;
        }
        case "link": {
          const l = o;
          n += t.link(l.href, l.title, this.parseInline(l.tokens, t));
          break;
        }
        case "image": {
          const l = o;
          n += t.image(l.href, l.title, l.text);
          break;
        }
        case "strong": {
          const l = o;
          n += t.strong(this.parseInline(l.tokens, t));
          break;
        }
        case "em": {
          const l = o;
          n += t.em(this.parseInline(l.tokens, t));
          break;
        }
        case "codespan": {
          const l = o;
          n += t.codespan(l.text);
          break;
        }
        case "br": {
          n += t.br();
          break;
        }
        case "del": {
          const l = o;
          n += t.del(this.parseInline(l.tokens, t));
          break;
        }
        case "text": {
          const l = o;
          n += t.text(l.text);
          break;
        }
        default: {
          const l = 'Token with "' + o.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
}
class Qt {
  constructor(e) {
    Q(this, "options");
    this.options = e || Tt;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
Q(Qt, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var St, Kn, ll;
class Mo {
  constructor(...e) {
    Ti(this, St);
    Q(this, "defaults", si());
    Q(this, "options", this.setOptions);
    Q(this, "parse", cn(this, St, Kn).call(this, tt.lex, nt.parse));
    Q(this, "parseInline", cn(this, St, Kn).call(this, tt.lexInline, nt.parseInline));
    Q(this, "Parser", nt);
    Q(this, "Renderer", En);
    Q(this, "TextRenderer", pi);
    Q(this, "Lexer", tt);
    Q(this, "Tokenizer", $n);
    Q(this, "Hooks", Qt);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var a, o;
    let n = [];
    for (const l of e)
      switch (n = n.concat(t.call(this, l)), l.type) {
        case "table": {
          const r = l;
          for (const s of r.header)
            n = n.concat(this.walkTokens(s.tokens, t));
          for (const s of r.rows)
            for (const u of s)
              n = n.concat(this.walkTokens(u.tokens, t));
          break;
        }
        case "list": {
          const r = l;
          n = n.concat(this.walkTokens(r.items, t));
          break;
        }
        default: {
          const r = l;
          (o = (a = this.defaults.extensions) == null ? void 0 : a.childTokens) != null && o[r.type] ? this.defaults.extensions.childTokens[r.type].forEach((s) => {
            const u = r[s].flat(1 / 0);
            n = n.concat(this.walkTokens(u, t));
          }) : r.tokens && (n = n.concat(this.walkTokens(r.tokens, t)));
        }
      }
    return n;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      const a = { ...n };
      if (a.async = this.defaults.async || a.async || !1, n.extensions && (n.extensions.forEach((o) => {
        if (!o.name)
          throw new Error("extension name required");
        if ("renderer" in o) {
          const l = t.renderers[o.name];
          l ? t.renderers[o.name] = function(...r) {
            let s = o.renderer.apply(this, r);
            return s === !1 && (s = l.apply(this, r)), s;
          } : t.renderers[o.name] = o.renderer;
        }
        if ("tokenizer" in o) {
          if (!o.level || o.level !== "block" && o.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const l = t[o.level];
          l ? l.unshift(o.tokenizer) : t[o.level] = [o.tokenizer], o.start && (o.level === "block" ? t.startBlock ? t.startBlock.push(o.start) : t.startBlock = [o.start] : o.level === "inline" && (t.startInline ? t.startInline.push(o.start) : t.startInline = [o.start]));
        }
        "childTokens" in o && o.childTokens && (t.childTokens[o.name] = o.childTokens);
      }), a.extensions = t), n.renderer) {
        const o = this.defaults.renderer || new En(this.defaults);
        for (const l in n.renderer) {
          if (!(l in o))
            throw new Error(`renderer '${l}' does not exist`);
          if (l === "options")
            continue;
          const r = l, s = n.renderer[r], u = o[r];
          o[r] = (...c) => {
            let h = s.apply(o, c);
            return h === !1 && (h = u.apply(o, c)), h || "";
          };
        }
        a.renderer = o;
      }
      if (n.tokenizer) {
        const o = this.defaults.tokenizer || new $n(this.defaults);
        for (const l in n.tokenizer) {
          if (!(l in o))
            throw new Error(`tokenizer '${l}' does not exist`);
          if (["options", "rules", "lexer"].includes(l))
            continue;
          const r = l, s = n.tokenizer[r], u = o[r];
          o[r] = (...c) => {
            let h = s.apply(o, c);
            return h === !1 && (h = u.apply(o, c)), h;
          };
        }
        a.tokenizer = o;
      }
      if (n.hooks) {
        const o = this.defaults.hooks || new Qt();
        for (const l in n.hooks) {
          if (!(l in o))
            throw new Error(`hook '${l}' does not exist`);
          if (l === "options")
            continue;
          const r = l, s = n.hooks[r], u = o[r];
          Qt.passThroughHooks.has(l) ? o[r] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(o, c)).then((d) => u.call(o, d));
            const h = s.call(o, c);
            return u.call(o, h);
          } : o[r] = (...c) => {
            let h = s.apply(o, c);
            return h === !1 && (h = u.apply(o, c)), h;
          };
        }
        a.hooks = o;
      }
      if (n.walkTokens) {
        const o = this.defaults.walkTokens, l = n.walkTokens;
        a.walkTokens = function(r) {
          let s = [];
          return s.push(l.call(this, r)), o && (s = s.concat(o.call(this, r))), s;
        };
      }
      this.defaults = { ...this.defaults, ...a };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return tt.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return nt.parse(e, t ?? this.defaults);
  }
}
St = new WeakSet(), Kn = function(e, t) {
  return (n, a) => {
    const o = { ...a }, l = { ...this.defaults, ...o };
    this.defaults.async === !0 && o.async === !1 && (l.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), l.async = !0);
    const r = cn(this, St, ll).call(this, !!l.silent, !!l.async);
    if (typeof n > "u" || n === null)
      return r(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return r(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (l.hooks && (l.hooks.options = l), l.async)
      return Promise.resolve(l.hooks ? l.hooks.preprocess(n) : n).then((s) => e(s, l)).then((s) => l.hooks ? l.hooks.processAllTokens(s) : s).then((s) => l.walkTokens ? Promise.all(this.walkTokens(s, l.walkTokens)).then(() => s) : s).then((s) => t(s, l)).then((s) => l.hooks ? l.hooks.postprocess(s) : s).catch(r);
    try {
      l.hooks && (n = l.hooks.preprocess(n));
      let s = e(n, l);
      l.hooks && (s = l.hooks.processAllTokens(s)), l.walkTokens && this.walkTokens(s, l.walkTokens);
      let u = t(s, l);
      return l.hooks && (u = l.hooks.postprocess(u)), u;
    } catch (s) {
      return r(s);
    }
  };
}, ll = function(e, t) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const a = "<p>An error occurred:</p><pre>" + Be(n.message + "", !0) + "</pre>";
      return t ? Promise.resolve(a) : a;
    }
    if (t)
      return Promise.reject(n);
    throw n;
  };
};
const Ct = new Mo();
function Z(i, e) {
  return Ct.parse(i, e);
}
Z.options = Z.setOptions = function(i) {
  return Ct.setOptions(i), Z.defaults = Ct.defaults, Ya(Z.defaults), Z;
};
Z.getDefaults = si;
Z.defaults = Tt;
Z.use = function(...i) {
  return Ct.use(...i), Z.defaults = Ct.defaults, Ya(Z.defaults), Z;
};
Z.walkTokens = function(i, e) {
  return Ct.walkTokens(i, e);
};
Z.parseInline = Ct.parseInline;
Z.Parser = nt;
Z.parser = nt.parse;
Z.Renderer = En;
Z.TextRenderer = pi;
Z.Lexer = tt;
Z.lexer = tt.lex;
Z.Tokenizer = $n;
Z.Hooks = Qt;
Z.parse = Z;
Z.options;
Z.setOptions;
Z.use;
Z.walkTokens;
Z.parseInline;
nt.parse;
tt.lex;
const Po = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, Uo = Object.hasOwnProperty;
class ol {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const n = this;
    let a = Ho(e, t === !0);
    const o = a;
    for (; Uo.call(n.occurrences, a); )
      n.occurrences[o]++, a = o + "-" + n.occurrences[o];
    return n.occurrences[a] = 0, a;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function Ho(i, e) {
  return typeof i != "string" ? "" : (e || (i = i.toLowerCase()), i.replace(Po, "").replace(/ /g, "-"));
}
new ol();
var Mi = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, Go = { exports: {} };
(function(i) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(n) {
    var a = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, o = 0, l = {}, r = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function m(_) {
          return _ instanceof s ? new s(_.type, m(_.content), _.alias) : Array.isArray(_) ? _.map(m) : _.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(m) {
          return Object.prototype.toString.call(m).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(m) {
          return m.__id || Object.defineProperty(m, "__id", { value: ++o }), m.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function m(_, g) {
          g = g || {};
          var F, w;
          switch (r.util.type(_)) {
            case "Object":
              if (w = r.util.objId(_), g[w])
                return g[w];
              F = /** @type {Record<string, any>} */
              {}, g[w] = F;
              for (var C in _)
                _.hasOwnProperty(C) && (F[C] = m(_[C], g));
              return (
                /** @type {any} */
                F
              );
            case "Array":
              return w = r.util.objId(_), g[w] ? g[w] : (F = [], g[w] = F, /** @type {Array} */
              /** @type {any} */
              _.forEach(function(I, S) {
                F[S] = m(I, g);
              }), /** @type {any} */
              F);
            default:
              return _;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(m) {
          for (; m; ) {
            var _ = a.exec(m.className);
            if (_)
              return _[1].toLowerCase();
            m = m.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(m, _) {
          m.className = m.className.replace(RegExp(a, "gi"), ""), m.classList.add("language-" + _);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (F) {
            var m = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(F.stack) || [])[1];
            if (m) {
              var _ = document.getElementsByTagName("script");
              for (var g in _)
                if (_[g].src == m)
                  return _[g];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(m, _, g) {
          for (var F = "no-" + _; m; ) {
            var w = m.classList;
            if (w.contains(_))
              return !0;
            if (w.contains(F))
              return !1;
            m = m.parentElement;
          }
          return !!g;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: l,
        plaintext: l,
        text: l,
        txt: l,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(m, _) {
          var g = r.util.clone(r.languages[m]);
          for (var F in _)
            g[F] = _[F];
          return g;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(m, _, g, F) {
          F = F || /** @type {any} */
          r.languages;
          var w = F[m], C = {};
          for (var I in w)
            if (w.hasOwnProperty(I)) {
              if (I == _)
                for (var S in g)
                  g.hasOwnProperty(S) && (C[S] = g[S]);
              g.hasOwnProperty(I) || (C[I] = w[I]);
            }
          var O = F[m];
          return F[m] = C, r.languages.DFS(r.languages, function(q, H) {
            H === O && q != m && (this[q] = C);
          }), C;
        },
        // Traverse a language definition with Depth First Search
        DFS: function m(_, g, F, w) {
          w = w || {};
          var C = r.util.objId;
          for (var I in _)
            if (_.hasOwnProperty(I)) {
              g.call(_, I, _[I], F || I);
              var S = _[I], O = r.util.type(S);
              O === "Object" && !w[C(S)] ? (w[C(S)] = !0, m(S, g, null, w)) : O === "Array" && !w[C(S)] && (w[C(S)] = !0, m(S, g, I, w));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(m, _) {
        r.highlightAllUnder(document, m, _);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(m, _, g) {
        var F = {
          callback: g,
          container: m,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        r.hooks.run("before-highlightall", F), F.elements = Array.prototype.slice.apply(F.container.querySelectorAll(F.selector)), r.hooks.run("before-all-elements-highlight", F);
        for (var w = 0, C; C = F.elements[w++]; )
          r.highlightElement(C, _ === !0, F.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(m, _, g) {
        var F = r.util.getLanguage(m), w = r.languages[F];
        r.util.setLanguage(m, F);
        var C = m.parentElement;
        C && C.nodeName.toLowerCase() === "pre" && r.util.setLanguage(C, F);
        var I = m.textContent, S = {
          element: m,
          language: F,
          grammar: w,
          code: I
        };
        function O(H) {
          S.highlightedCode = H, r.hooks.run("before-insert", S), S.element.innerHTML = S.highlightedCode, r.hooks.run("after-highlight", S), r.hooks.run("complete", S), g && g.call(S.element);
        }
        if (r.hooks.run("before-sanity-check", S), C = S.element.parentElement, C && C.nodeName.toLowerCase() === "pre" && !C.hasAttribute("tabindex") && C.setAttribute("tabindex", "0"), !S.code) {
          r.hooks.run("complete", S), g && g.call(S.element);
          return;
        }
        if (r.hooks.run("before-highlight", S), !S.grammar) {
          O(r.util.encode(S.code));
          return;
        }
        if (_ && n.Worker) {
          var q = new Worker(r.filename);
          q.onmessage = function(H) {
            O(H.data);
          }, q.postMessage(JSON.stringify({
            language: S.language,
            code: S.code,
            immediateClose: !0
          }));
        } else
          O(r.highlight(S.code, S.grammar, S.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(m, _, g) {
        var F = {
          code: m,
          grammar: _,
          language: g
        };
        if (r.hooks.run("before-tokenize", F), !F.grammar)
          throw new Error('The language "' + F.language + '" has no grammar.');
        return F.tokens = r.tokenize(F.code, F.grammar), r.hooks.run("after-tokenize", F), s.stringify(r.util.encode(F.tokens), F.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(m, _) {
        var g = _.rest;
        if (g) {
          for (var F in g)
            _[F] = g[F];
          delete _.rest;
        }
        var w = new h();
        return d(w, w.head, m), c(m, w, _, w.head, 0), v(w);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(m, _) {
          var g = r.hooks.all;
          g[m] = g[m] || [], g[m].push(_);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(m, _) {
          var g = r.hooks.all[m];
          if (!(!g || !g.length))
            for (var F = 0, w; w = g[F++]; )
              w(_);
        }
      },
      Token: s
    };
    n.Prism = r;
    function s(m, _, g, F) {
      this.type = m, this.content = _, this.alias = g, this.length = (F || "").length | 0;
    }
    s.stringify = function m(_, g) {
      if (typeof _ == "string")
        return _;
      if (Array.isArray(_)) {
        var F = "";
        return _.forEach(function(O) {
          F += m(O, g);
        }), F;
      }
      var w = {
        type: _.type,
        content: m(_.content, g),
        tag: "span",
        classes: ["token", _.type],
        attributes: {},
        language: g
      }, C = _.alias;
      C && (Array.isArray(C) ? Array.prototype.push.apply(w.classes, C) : w.classes.push(C)), r.hooks.run("wrap", w);
      var I = "";
      for (var S in w.attributes)
        I += " " + S + '="' + (w.attributes[S] || "").replace(/"/g, "&quot;") + '"';
      return "<" + w.tag + ' class="' + w.classes.join(" ") + '"' + I + ">" + w.content + "</" + w.tag + ">";
    };
    function u(m, _, g, F) {
      m.lastIndex = _;
      var w = m.exec(g);
      if (w && F && w[1]) {
        var C = w[1].length;
        w.index += C, w[0] = w[0].slice(C);
      }
      return w;
    }
    function c(m, _, g, F, w, C) {
      for (var I in g)
        if (!(!g.hasOwnProperty(I) || !g[I])) {
          var S = g[I];
          S = Array.isArray(S) ? S : [S];
          for (var O = 0; O < S.length; ++O) {
            if (C && C.cause == I + "," + O)
              return;
            var q = S[O], H = q.inside, ke = !!q.lookbehind, re = !!q.greedy, ae = q.alias;
            if (re && !q.pattern.global) {
              var se = q.pattern.toString().match(/[imsuy]*$/)[0];
              q.pattern = RegExp(q.pattern.source, se + "g");
            }
            for (var Se = q.pattern || q, K = F.next, ue = w; K !== _.tail && !(C && ue >= C.reach); ue += K.value.length, K = K.next) {
              var he = K.value;
              if (_.length > m.length)
                return;
              if (!(he instanceof s)) {
                var $ = 1, le;
                if (re) {
                  if (le = u(Se, ue, m, ke), !le || le.index >= m.length)
                    break;
                  var Ee = le.index, X = le.index + le[0].length, _e = ue;
                  for (_e += K.value.length; Ee >= _e; )
                    K = K.next, _e += K.value.length;
                  if (_e -= K.value.length, ue = _e, K.value instanceof s)
                    continue;
                  for (var A = K; A !== _.tail && (_e < X || typeof A.value == "string"); A = A.next)
                    $++, _e += A.value.length;
                  $--, he = m.slice(ue, _e), le.index -= ue;
                } else if (le = u(Se, 0, he, ke), !le)
                  continue;
                var Ee = le.index, We = le[0], gt = he.slice(0, Ee), vt = he.slice(Ee + We.length), Dt = ue + he.length;
                C && Dt > C.reach && (C.reach = Dt);
                var st = K.prev;
                gt && (st = d(_, st, gt), ue += gt.length), f(_, st, $);
                var Ze = new s(I, H ? r.tokenize(We, H) : We, ae, We);
                if (K = d(_, st, Ze), vt && d(_, K, vt), $ > 1) {
                  var Ye = {
                    cause: I + "," + O,
                    reach: Dt
                  };
                  c(m, _, g, K.prev, ue, Ye), C && Ye.reach > C.reach && (C.reach = Ye.reach);
                }
              }
            }
          }
        }
    }
    function h() {
      var m = { value: null, prev: null, next: null }, _ = { value: null, prev: m, next: null };
      m.next = _, this.head = m, this.tail = _, this.length = 0;
    }
    function d(m, _, g) {
      var F = _.next, w = { value: g, prev: _, next: F };
      return _.next = w, F.prev = w, m.length++, w;
    }
    function f(m, _, g) {
      for (var F = _.next, w = 0; w < g && F !== m.tail; w++)
        F = F.next;
      _.next = F, F.prev = _, m.length -= w;
    }
    function v(m) {
      for (var _ = [], g = m.head.next; g !== m.tail; )
        _.push(g.value), g = g.next;
      return _;
    }
    if (!n.document)
      return n.addEventListener && (r.disableWorkerMessageHandler || n.addEventListener("message", function(m) {
        var _ = JSON.parse(m.data), g = _.language, F = _.code, w = _.immediateClose;
        n.postMessage(r.highlight(F, r.languages[g], g)), w && n.close();
      }, !1)), r;
    var D = r.util.currentScript();
    D && (r.filename = D.src, D.hasAttribute("data-manual") && (r.manual = !0));
    function b() {
      r.manual || r.highlightAll();
    }
    if (!r.manual) {
      var E = document.readyState;
      E === "loading" || E === "interactive" && D && D.defer ? document.addEventListener("DOMContentLoaded", b) : window.requestAnimationFrame ? window.requestAnimationFrame(b) : window.setTimeout(b, 16);
    }
    return r;
  }(e);
  i.exports && (i.exports = t), typeof Mi < "u" && (Mi.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(a, o) {
      var l = {};
      l["language-" + o] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[o]
      }, l.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var r = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: l
        }
      };
      r["language-" + o] = {
        pattern: /[\s\S]+/,
        inside: t.languages[o]
      };
      var s = {};
      s[a] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return a;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: r
      }, t.languages.insertBefore("markup", "cdata", s);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, a) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [a, "language-" + a],
                inside: t.languages[a]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(n) {
    var a = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + a.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + a.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + a.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + a.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: a,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var o = n.languages.markup;
    o && (o.tag.addInlined("style", "css"), o.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", a = function(D, b) {
      return "✖ Error " + D + " while fetching file: " + b;
    }, o = "✖ Error: File does not exist or is empty", l = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, r = "data-src-status", s = "loading", u = "loaded", c = "failed", h = "pre[data-src]:not([" + r + '="' + u + '"]):not([' + r + '="' + s + '"])';
    function d(D, b, E) {
      var m = new XMLHttpRequest();
      m.open("GET", D, !0), m.onreadystatechange = function() {
        m.readyState == 4 && (m.status < 400 && m.responseText ? b(m.responseText) : m.status >= 400 ? E(a(m.status, m.statusText)) : E(o));
      }, m.send(null);
    }
    function f(D) {
      var b = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(D || "");
      if (b) {
        var E = Number(b[1]), m = b[2], _ = b[3];
        return m ? _ ? [E, Number(_)] : [E, void 0] : [E, E];
      }
    }
    t.hooks.add("before-highlightall", function(D) {
      D.selector += ", " + h;
    }), t.hooks.add("before-sanity-check", function(D) {
      var b = (
        /** @type {HTMLPreElement} */
        D.element
      );
      if (b.matches(h)) {
        D.code = "", b.setAttribute(r, s);
        var E = b.appendChild(document.createElement("CODE"));
        E.textContent = n;
        var m = b.getAttribute("data-src"), _ = D.language;
        if (_ === "none") {
          var g = (/\.(\w+)$/.exec(m) || [, "none"])[1];
          _ = l[g] || g;
        }
        t.util.setLanguage(E, _), t.util.setLanguage(b, _);
        var F = t.plugins.autoloader;
        F && F.loadLanguages(_), d(
          m,
          function(w) {
            b.setAttribute(r, u);
            var C = f(b.getAttribute("data-range"));
            if (C) {
              var I = w.split(/\r\n?|\n/g), S = C[0], O = C[1] == null ? I.length : C[1];
              S < 0 && (S += I.length), S = Math.max(0, Math.min(S - 1, I.length)), O < 0 && (O += I.length), O = Math.max(0, Math.min(O, I.length)), w = I.slice(S, O).join(`
`), b.hasAttribute("data-start") || b.setAttribute("data-start", String(S + 1));
            }
            E.textContent = w, t.highlightElement(E);
          },
          function(w) {
            b.setAttribute(r, c), E.textContent = w;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(b) {
        for (var E = (b || document).querySelectorAll(h), m = 0, _; _ = E[m++]; )
          t.highlightElement(_);
      }
    };
    var v = !1;
    t.fileHighlight = function() {
      v || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), v = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(Go);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(i) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  i.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, i.languages.tex = i.languages.latex, i.languages.context = i.languages.latex;
})(Prism);
(function(i) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  i.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = i.languages.bash;
  for (var a = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], o = n.variable[1].inside, l = 0; l < a.length; l++)
    o[a[l]] = i.languages.bash[a[l]];
  i.languages.sh = i.languages.bash, i.languages.shell = i.languages.bash;
})(Prism);
new ol();
const jo = (i) => {
  const e = {};
  for (let t = 0, n = i.length; t < n; t++) {
    const a = i[t];
    for (const o in a)
      e[o] ? e[o] = e[o].concat(a[o]) : e[o] = a[o];
  }
  return e;
}, Vo = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], Wo = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], Zo = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
jo([
  Object.fromEntries(Vo.map((i) => [i, ["*"]])),
  Object.fromEntries(Wo.map((i) => [i, ["svg:*"]])),
  Object.fromEntries(Zo.map((i) => [i, ["math:*"]]))
]);
const {
  HtmlTagHydration: Vs,
  SvelteComponent: Ws,
  attr: Zs,
  binding_callbacks: Ys,
  children: Xs,
  claim_element: Ks,
  claim_html_tag: Qs,
  detach: Js,
  element: eu,
  init: tu,
  insert_hydration: nu,
  noop: iu,
  safe_not_equal: au,
  toggle_class: lu
} = window.__gradio__svelte__internal, { afterUpdate: ou, tick: ru, onMount: su } = window.__gradio__svelte__internal, {
  SvelteComponent: uu,
  attr: cu,
  children: _u,
  claim_component: du,
  claim_element: fu,
  create_component: pu,
  destroy_component: hu,
  detach: mu,
  element: gu,
  init: vu,
  insert_hydration: Du,
  mount_component: bu,
  safe_not_equal: yu,
  transition_in: Fu,
  transition_out: wu
} = window.__gradio__svelte__internal, {
  SvelteComponent: $u,
  attr: ku,
  check_outros: Eu,
  children: Au,
  claim_component: Cu,
  claim_element: Su,
  claim_space: Tu,
  create_component: Bu,
  create_slot: Ru,
  destroy_component: Iu,
  detach: Lu,
  element: xu,
  empty: Ou,
  get_all_dirty_from_scope: qu,
  get_slot_changes: Nu,
  group_outros: zu,
  init: Mu,
  insert_hydration: Pu,
  mount_component: Uu,
  safe_not_equal: Hu,
  space: Gu,
  toggle_class: ju,
  transition_in: Vu,
  transition_out: Wu,
  update_slot_base: Zu
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yu,
  append_hydration: Xu,
  attr: Ku,
  children: Qu,
  claim_component: Ju,
  claim_element: ec,
  claim_space: tc,
  claim_text: nc,
  create_component: ic,
  destroy_component: ac,
  detach: lc,
  element: oc,
  init: rc,
  insert_hydration: sc,
  mount_component: uc,
  safe_not_equal: cc,
  set_data: _c,
  space: dc,
  text: fc,
  toggle_class: pc,
  transition_in: hc,
  transition_out: mc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yo,
  append_hydration: yn,
  attr: ft,
  bubble: Xo,
  check_outros: Ko,
  children: Qn,
  claim_component: Qo,
  claim_element: Jn,
  claim_space: Pi,
  claim_text: Jo,
  construct_svelte_component: Ui,
  create_component: Hi,
  create_slot: er,
  destroy_component: Gi,
  detach: Jt,
  element: ei,
  get_all_dirty_from_scope: tr,
  get_slot_changes: nr,
  group_outros: ir,
  init: ar,
  insert_hydration: rl,
  listen: lr,
  mount_component: ji,
  safe_not_equal: or,
  set_data: rr,
  set_style: fn,
  space: Vi,
  text: sr,
  toggle_class: ve,
  transition_in: zn,
  transition_out: Mn,
  update_slot_base: ur
} = window.__gradio__svelte__internal;
function Wi(i) {
  let e, t;
  return {
    c() {
      e = ei("span"), t = sr(
        /*label*/
        i[1]
      ), this.h();
    },
    l(n) {
      e = Jn(n, "SPAN", { class: !0 });
      var a = Qn(e);
      t = Jo(
        a,
        /*label*/
        i[1]
      ), a.forEach(Jt), this.h();
    },
    h() {
      ft(e, "class", "svelte-qgco6m");
    },
    m(n, a) {
      rl(n, e, a), yn(e, t);
    },
    p(n, a) {
      a & /*label*/
      2 && rr(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && Jt(e);
    }
  };
}
function cr(i) {
  let e, t, n, a, o, l, r, s, u = (
    /*show_label*/
    i[2] && Wi(i)
  );
  var c = (
    /*Icon*/
    i[0]
  );
  function h(v, D) {
    return {};
  }
  c && (a = Ui(c, h()));
  const d = (
    /*#slots*/
    i[14].default
  ), f = er(
    d,
    i,
    /*$$scope*/
    i[13],
    null
  );
  return {
    c() {
      e = ei("button"), u && u.c(), t = Vi(), n = ei("div"), a && Hi(a.$$.fragment), o = Vi(), f && f.c(), this.h();
    },
    l(v) {
      e = Jn(v, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var D = Qn(e);
      u && u.l(D), t = Pi(D), n = Jn(D, "DIV", { class: !0 });
      var b = Qn(n);
      a && Qo(a.$$.fragment, b), o = Pi(b), f && f.l(b), b.forEach(Jt), D.forEach(Jt), this.h();
    },
    h() {
      ft(n, "class", "svelte-qgco6m"), ve(
        n,
        "x-small",
        /*size*/
        i[4] === "x-small"
      ), ve(
        n,
        "small",
        /*size*/
        i[4] === "small"
      ), ve(
        n,
        "large",
        /*size*/
        i[4] === "large"
      ), ve(
        n,
        "medium",
        /*size*/
        i[4] === "medium"
      ), e.disabled = /*disabled*/
      i[7], ft(
        e,
        "aria-label",
        /*label*/
        i[1]
      ), ft(
        e,
        "aria-haspopup",
        /*hasPopup*/
        i[8]
      ), ft(
        e,
        "title",
        /*label*/
        i[1]
      ), ft(e, "class", "svelte-qgco6m"), ve(
        e,
        "pending",
        /*pending*/
        i[3]
      ), ve(
        e,
        "padded",
        /*padded*/
        i[5]
      ), ve(
        e,
        "highlight",
        /*highlight*/
        i[6]
      ), ve(
        e,
        "transparent",
        /*transparent*/
        i[9]
      ), fn(e, "color", !/*disabled*/
      i[7] && /*_color*/
      i[11] ? (
        /*_color*/
        i[11]
      ) : "var(--block-label-text-color)"), fn(e, "--bg-color", /*disabled*/
      i[7] ? "auto" : (
        /*background*/
        i[10]
      ));
    },
    m(v, D) {
      rl(v, e, D), u && u.m(e, null), yn(e, t), yn(e, n), a && ji(a, n, null), yn(n, o), f && f.m(n, null), l = !0, r || (s = lr(
        e,
        "click",
        /*click_handler*/
        i[15]
      ), r = !0);
    },
    p(v, [D]) {
      if (/*show_label*/
      v[2] ? u ? u.p(v, D) : (u = Wi(v), u.c(), u.m(e, t)) : u && (u.d(1), u = null), D & /*Icon*/
      1 && c !== (c = /*Icon*/
      v[0])) {
        if (a) {
          ir();
          const b = a;
          Mn(b.$$.fragment, 1, 0, () => {
            Gi(b, 1);
          }), Ko();
        }
        c ? (a = Ui(c, h()), Hi(a.$$.fragment), zn(a.$$.fragment, 1), ji(a, n, o)) : a = null;
      }
      f && f.p && (!l || D & /*$$scope*/
      8192) && ur(
        f,
        d,
        v,
        /*$$scope*/
        v[13],
        l ? nr(
          d,
          /*$$scope*/
          v[13],
          D,
          null
        ) : tr(
          /*$$scope*/
          v[13]
        ),
        null
      ), (!l || D & /*size*/
      16) && ve(
        n,
        "x-small",
        /*size*/
        v[4] === "x-small"
      ), (!l || D & /*size*/
      16) && ve(
        n,
        "small",
        /*size*/
        v[4] === "small"
      ), (!l || D & /*size*/
      16) && ve(
        n,
        "large",
        /*size*/
        v[4] === "large"
      ), (!l || D & /*size*/
      16) && ve(
        n,
        "medium",
        /*size*/
        v[4] === "medium"
      ), (!l || D & /*disabled*/
      128) && (e.disabled = /*disabled*/
      v[7]), (!l || D & /*label*/
      2) && ft(
        e,
        "aria-label",
        /*label*/
        v[1]
      ), (!l || D & /*hasPopup*/
      256) && ft(
        e,
        "aria-haspopup",
        /*hasPopup*/
        v[8]
      ), (!l || D & /*label*/
      2) && ft(
        e,
        "title",
        /*label*/
        v[1]
      ), (!l || D & /*pending*/
      8) && ve(
        e,
        "pending",
        /*pending*/
        v[3]
      ), (!l || D & /*padded*/
      32) && ve(
        e,
        "padded",
        /*padded*/
        v[5]
      ), (!l || D & /*highlight*/
      64) && ve(
        e,
        "highlight",
        /*highlight*/
        v[6]
      ), (!l || D & /*transparent*/
      512) && ve(
        e,
        "transparent",
        /*transparent*/
        v[9]
      ), D & /*disabled, _color*/
      2176 && fn(e, "color", !/*disabled*/
      v[7] && /*_color*/
      v[11] ? (
        /*_color*/
        v[11]
      ) : "var(--block-label-text-color)"), D & /*disabled, background*/
      1152 && fn(e, "--bg-color", /*disabled*/
      v[7] ? "auto" : (
        /*background*/
        v[10]
      ));
    },
    i(v) {
      l || (a && zn(a.$$.fragment, v), zn(f, v), l = !0);
    },
    o(v) {
      a && Mn(a.$$.fragment, v), Mn(f, v), l = !1;
    },
    d(v) {
      v && Jt(e), u && u.d(), a && Gi(a), f && f.d(v), r = !1, s();
    }
  };
}
function _r(i, e, t) {
  let n, { $$slots: a = {}, $$scope: o } = e, { Icon: l } = e, { label: r = "" } = e, { show_label: s = !1 } = e, { pending: u = !1 } = e, { size: c = "small" } = e, { padded: h = !0 } = e, { highlight: d = !1 } = e, { disabled: f = !1 } = e, { hasPopup: v = !1 } = e, { color: D = "var(--block-label-text-color)" } = e, { transparent: b = !1 } = e, { background: E = "var(--block-background-fill)" } = e;
  function m(_) {
    Xo.call(this, i, _);
  }
  return i.$$set = (_) => {
    "Icon" in _ && t(0, l = _.Icon), "label" in _ && t(1, r = _.label), "show_label" in _ && t(2, s = _.show_label), "pending" in _ && t(3, u = _.pending), "size" in _ && t(4, c = _.size), "padded" in _ && t(5, h = _.padded), "highlight" in _ && t(6, d = _.highlight), "disabled" in _ && t(7, f = _.disabled), "hasPopup" in _ && t(8, v = _.hasPopup), "color" in _ && t(12, D = _.color), "transparent" in _ && t(9, b = _.transparent), "background" in _ && t(10, E = _.background), "$$scope" in _ && t(13, o = _.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty & /*highlight, color*/
    4160 && t(11, n = d ? "var(--color-accent)" : D);
  }, [
    l,
    r,
    s,
    u,
    c,
    h,
    d,
    f,
    v,
    b,
    E,
    n,
    D,
    o,
    a,
    m
  ];
}
class dr extends Yo {
  constructor(e) {
    super(), ar(this, e, _r, cr, or, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: gc,
  append_hydration: vc,
  attr: Dc,
  binding_callbacks: bc,
  children: yc,
  claim_element: Fc,
  create_slot: wc,
  detach: $c,
  element: kc,
  get_all_dirty_from_scope: Ec,
  get_slot_changes: Ac,
  init: Cc,
  insert_hydration: Sc,
  safe_not_equal: Tc,
  toggle_class: Bc,
  transition_in: Rc,
  transition_out: Ic,
  update_slot_base: Lc
} = window.__gradio__svelte__internal, {
  SvelteComponent: xc,
  append_hydration: Oc,
  attr: qc,
  children: Nc,
  claim_svg_element: zc,
  detach: Mc,
  init: Pc,
  insert_hydration: Uc,
  noop: Hc,
  safe_not_equal: Gc,
  svg_element: jc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vc,
  append_hydration: Wc,
  attr: Zc,
  children: Yc,
  claim_svg_element: Xc,
  detach: Kc,
  init: Qc,
  insert_hydration: Jc,
  noop: e_,
  safe_not_equal: t_,
  svg_element: n_
} = window.__gradio__svelte__internal, {
  SvelteComponent: i_,
  append_hydration: a_,
  attr: l_,
  children: o_,
  claim_svg_element: r_,
  detach: s_,
  init: u_,
  insert_hydration: c_,
  noop: __,
  safe_not_equal: d_,
  svg_element: f_
} = window.__gradio__svelte__internal, {
  SvelteComponent: p_,
  append_hydration: h_,
  attr: m_,
  children: g_,
  claim_svg_element: v_,
  detach: D_,
  init: b_,
  insert_hydration: y_,
  noop: F_,
  safe_not_equal: w_,
  svg_element: $_
} = window.__gradio__svelte__internal, {
  SvelteComponent: k_,
  append_hydration: E_,
  attr: A_,
  children: C_,
  claim_svg_element: S_,
  detach: T_,
  init: B_,
  insert_hydration: R_,
  noop: I_,
  safe_not_equal: L_,
  svg_element: x_
} = window.__gradio__svelte__internal, {
  SvelteComponent: O_,
  append_hydration: q_,
  attr: N_,
  children: z_,
  claim_svg_element: M_,
  detach: P_,
  init: U_,
  insert_hydration: H_,
  noop: G_,
  safe_not_equal: j_,
  svg_element: V_
} = window.__gradio__svelte__internal, {
  SvelteComponent: W_,
  append_hydration: Z_,
  attr: Y_,
  children: X_,
  claim_svg_element: K_,
  detach: Q_,
  init: J_,
  insert_hydration: ed,
  noop: td,
  safe_not_equal: nd,
  svg_element: id
} = window.__gradio__svelte__internal, {
  SvelteComponent: ad,
  append_hydration: ld,
  attr: od,
  children: rd,
  claim_svg_element: sd,
  detach: ud,
  init: cd,
  insert_hydration: _d,
  noop: dd,
  safe_not_equal: fd,
  svg_element: pd
} = window.__gradio__svelte__internal, {
  SvelteComponent: hd,
  append_hydration: md,
  attr: gd,
  children: vd,
  claim_svg_element: Dd,
  detach: bd,
  init: yd,
  insert_hydration: Fd,
  noop: wd,
  safe_not_equal: $d,
  svg_element: kd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ed,
  append_hydration: Ad,
  attr: Cd,
  children: Sd,
  claim_svg_element: Td,
  detach: Bd,
  init: Rd,
  insert_hydration: Id,
  noop: Ld,
  safe_not_equal: xd,
  svg_element: Od
} = window.__gradio__svelte__internal, {
  SvelteComponent: qd,
  append_hydration: Nd,
  attr: zd,
  children: Md,
  claim_svg_element: Pd,
  detach: Ud,
  init: Hd,
  insert_hydration: Gd,
  noop: jd,
  safe_not_equal: Vd,
  svg_element: Wd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zd,
  append_hydration: Yd,
  attr: Xd,
  children: Kd,
  claim_svg_element: Qd,
  detach: Jd,
  init: ef,
  insert_hydration: tf,
  noop: nf,
  safe_not_equal: af,
  svg_element: lf
} = window.__gradio__svelte__internal, {
  SvelteComponent: fr,
  append_hydration: Pn,
  attr: Me,
  children: pn,
  claim_svg_element: hn,
  detach: Gt,
  init: pr,
  insert_hydration: hr,
  noop: Un,
  safe_not_equal: mr,
  set_style: Je,
  svg_element: mn
} = window.__gradio__svelte__internal;
function gr(i) {
  let e, t, n, a;
  return {
    c() {
      e = mn("svg"), t = mn("g"), n = mn("path"), a = mn("path"), this.h();
    },
    l(o) {
      e = hn(o, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var l = pn(e);
      t = hn(l, "g", { transform: !0 });
      var r = pn(t);
      n = hn(r, "path", { d: !0, style: !0 }), pn(n).forEach(Gt), r.forEach(Gt), a = hn(l, "path", { d: !0, style: !0 }), pn(a).forEach(Gt), l.forEach(Gt), this.h();
    },
    h() {
      Me(n, "d", "M18,6L6.087,17.913"), Je(n, "fill", "none"), Je(n, "fill-rule", "nonzero"), Je(n, "stroke-width", "2px"), Me(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), Me(a, "d", "M4.364,4.364L19.636,19.636"), Je(a, "fill", "none"), Je(a, "fill-rule", "nonzero"), Je(a, "stroke-width", "2px"), Me(e, "width", "100%"), Me(e, "height", "100%"), Me(e, "viewBox", "0 0 24 24"), Me(e, "version", "1.1"), Me(e, "xmlns", "http://www.w3.org/2000/svg"), Me(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Me(e, "xml:space", "preserve"), Me(e, "stroke", "currentColor"), Je(e, "fill-rule", "evenodd"), Je(e, "clip-rule", "evenodd"), Je(e, "stroke-linecap", "round"), Je(e, "stroke-linejoin", "round");
    },
    m(o, l) {
      hr(o, e, l), Pn(e, t), Pn(t, n), Pn(e, a);
    },
    p: Un,
    i: Un,
    o: Un,
    d(o) {
      o && Gt(e);
    }
  };
}
class vr extends fr {
  constructor(e) {
    super(), pr(this, e, null, gr, mr, {});
  }
}
const {
  SvelteComponent: of,
  append_hydration: rf,
  attr: sf,
  children: uf,
  claim_svg_element: cf,
  detach: _f,
  init: df,
  insert_hydration: ff,
  noop: pf,
  safe_not_equal: hf,
  svg_element: mf
} = window.__gradio__svelte__internal, {
  SvelteComponent: gf,
  append_hydration: vf,
  attr: Df,
  children: bf,
  claim_svg_element: yf,
  detach: Ff,
  init: wf,
  insert_hydration: $f,
  noop: kf,
  safe_not_equal: Ef,
  svg_element: Af
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cf,
  append_hydration: Sf,
  attr: Tf,
  children: Bf,
  claim_svg_element: Rf,
  detach: If,
  init: Lf,
  insert_hydration: xf,
  noop: Of,
  safe_not_equal: qf,
  svg_element: Nf
} = window.__gradio__svelte__internal, {
  SvelteComponent: zf,
  append_hydration: Mf,
  attr: Pf,
  children: Uf,
  claim_svg_element: Hf,
  detach: Gf,
  init: jf,
  insert_hydration: Vf,
  noop: Wf,
  safe_not_equal: Zf,
  svg_element: Yf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xf,
  append_hydration: Kf,
  attr: Qf,
  children: Jf,
  claim_svg_element: ep,
  detach: tp,
  init: np,
  insert_hydration: ip,
  noop: ap,
  safe_not_equal: lp,
  svg_element: op
} = window.__gradio__svelte__internal, {
  SvelteComponent: rp,
  append_hydration: sp,
  attr: up,
  children: cp,
  claim_svg_element: _p,
  detach: dp,
  init: fp,
  insert_hydration: pp,
  noop: hp,
  safe_not_equal: mp,
  svg_element: gp
} = window.__gradio__svelte__internal, {
  SvelteComponent: vp,
  append_hydration: Dp,
  attr: bp,
  children: yp,
  claim_svg_element: Fp,
  detach: wp,
  init: $p,
  insert_hydration: kp,
  noop: Ep,
  safe_not_equal: Ap,
  svg_element: Cp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sp,
  append_hydration: Tp,
  attr: Bp,
  children: Rp,
  claim_svg_element: Ip,
  detach: Lp,
  init: xp,
  insert_hydration: Op,
  noop: qp,
  safe_not_equal: Np,
  svg_element: zp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mp,
  append_hydration: Pp,
  attr: Up,
  children: Hp,
  claim_svg_element: Gp,
  detach: jp,
  init: Vp,
  insert_hydration: Wp,
  noop: Zp,
  safe_not_equal: Yp,
  svg_element: Xp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kp,
  append_hydration: Qp,
  attr: Jp,
  children: eh,
  claim_svg_element: th,
  detach: nh,
  init: ih,
  insert_hydration: ah,
  noop: lh,
  safe_not_equal: oh,
  svg_element: rh
} = window.__gradio__svelte__internal, {
  SvelteComponent: sh,
  append_hydration: uh,
  attr: ch,
  children: _h,
  claim_svg_element: dh,
  detach: fh,
  init: ph,
  insert_hydration: hh,
  noop: mh,
  safe_not_equal: gh,
  svg_element: vh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dh,
  append_hydration: bh,
  attr: yh,
  children: Fh,
  claim_svg_element: wh,
  detach: $h,
  init: kh,
  insert_hydration: Eh,
  noop: Ah,
  safe_not_equal: Ch,
  svg_element: Sh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Th,
  append_hydration: Bh,
  attr: Rh,
  children: Ih,
  claim_svg_element: Lh,
  detach: xh,
  init: Oh,
  insert_hydration: qh,
  noop: Nh,
  safe_not_equal: zh,
  svg_element: Mh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ph,
  append_hydration: Uh,
  attr: Hh,
  children: Gh,
  claim_svg_element: jh,
  detach: Vh,
  init: Wh,
  insert_hydration: Zh,
  noop: Yh,
  safe_not_equal: Xh,
  svg_element: Kh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qh,
  append_hydration: Jh,
  attr: em,
  children: tm,
  claim_svg_element: nm,
  detach: im,
  init: am,
  insert_hydration: lm,
  noop: om,
  safe_not_equal: rm,
  svg_element: sm
} = window.__gradio__svelte__internal, {
  SvelteComponent: um,
  append_hydration: cm,
  attr: _m,
  children: dm,
  claim_svg_element: fm,
  detach: pm,
  init: hm,
  insert_hydration: mm,
  noop: gm,
  safe_not_equal: vm,
  svg_element: Dm
} = window.__gradio__svelte__internal, {
  SvelteComponent: bm,
  append_hydration: ym,
  attr: Fm,
  children: wm,
  claim_svg_element: $m,
  detach: km,
  init: Em,
  insert_hydration: Am,
  noop: Cm,
  safe_not_equal: Sm,
  svg_element: Tm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bm,
  append_hydration: Rm,
  attr: Im,
  children: Lm,
  claim_svg_element: xm,
  detach: Om,
  init: qm,
  insert_hydration: Nm,
  noop: zm,
  safe_not_equal: Mm,
  svg_element: Pm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Um,
  append_hydration: Hm,
  attr: Gm,
  children: jm,
  claim_svg_element: Vm,
  detach: Wm,
  init: Zm,
  insert_hydration: Ym,
  noop: Xm,
  safe_not_equal: Km,
  svg_element: Qm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jm,
  append_hydration: eg,
  attr: tg,
  children: ng,
  claim_svg_element: ig,
  detach: ag,
  init: lg,
  insert_hydration: og,
  noop: rg,
  safe_not_equal: sg,
  svg_element: ug
} = window.__gradio__svelte__internal, {
  SvelteComponent: cg,
  append_hydration: _g,
  attr: dg,
  children: fg,
  claim_svg_element: pg,
  detach: hg,
  init: mg,
  insert_hydration: gg,
  noop: vg,
  safe_not_equal: Dg,
  svg_element: bg
} = window.__gradio__svelte__internal, {
  SvelteComponent: yg,
  append_hydration: Fg,
  attr: wg,
  children: $g,
  claim_svg_element: kg,
  detach: Eg,
  init: Ag,
  insert_hydration: Cg,
  noop: Sg,
  safe_not_equal: Tg,
  svg_element: Bg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rg,
  append_hydration: Ig,
  attr: Lg,
  children: xg,
  claim_svg_element: Og,
  detach: qg,
  init: Ng,
  insert_hydration: zg,
  noop: Mg,
  safe_not_equal: Pg,
  svg_element: Ug
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hg,
  append_hydration: Gg,
  attr: jg,
  children: Vg,
  claim_svg_element: Wg,
  detach: Zg,
  init: Yg,
  insert_hydration: Xg,
  noop: Kg,
  safe_not_equal: Qg,
  svg_element: Jg
} = window.__gradio__svelte__internal, {
  SvelteComponent: e0,
  append_hydration: t0,
  attr: n0,
  children: i0,
  claim_svg_element: a0,
  detach: l0,
  init: o0,
  insert_hydration: r0,
  noop: s0,
  safe_not_equal: u0,
  svg_element: c0
} = window.__gradio__svelte__internal, {
  SvelteComponent: _0,
  append_hydration: d0,
  attr: f0,
  children: p0,
  claim_svg_element: h0,
  detach: m0,
  init: g0,
  insert_hydration: v0,
  noop: D0,
  safe_not_equal: b0,
  svg_element: y0
} = window.__gradio__svelte__internal, {
  SvelteComponent: F0,
  append_hydration: w0,
  attr: $0,
  children: k0,
  claim_svg_element: E0,
  detach: A0,
  init: C0,
  insert_hydration: S0,
  noop: T0,
  safe_not_equal: B0,
  svg_element: R0
} = window.__gradio__svelte__internal, {
  SvelteComponent: I0,
  append_hydration: L0,
  attr: x0,
  children: O0,
  claim_svg_element: q0,
  detach: N0,
  init: z0,
  insert_hydration: M0,
  noop: P0,
  safe_not_equal: U0,
  svg_element: H0
} = window.__gradio__svelte__internal, {
  SvelteComponent: G0,
  append_hydration: j0,
  attr: V0,
  children: W0,
  claim_svg_element: Z0,
  detach: Y0,
  init: X0,
  insert_hydration: K0,
  noop: Q0,
  safe_not_equal: J0,
  svg_element: e1
} = window.__gradio__svelte__internal, {
  SvelteComponent: t1,
  append_hydration: n1,
  attr: i1,
  children: a1,
  claim_svg_element: l1,
  detach: o1,
  init: r1,
  insert_hydration: s1,
  noop: u1,
  safe_not_equal: c1,
  svg_element: _1
} = window.__gradio__svelte__internal, {
  SvelteComponent: d1,
  append_hydration: f1,
  attr: p1,
  children: h1,
  claim_svg_element: m1,
  detach: g1,
  init: v1,
  insert_hydration: D1,
  noop: b1,
  safe_not_equal: y1,
  svg_element: F1
} = window.__gradio__svelte__internal, {
  SvelteComponent: w1,
  append_hydration: $1,
  attr: k1,
  children: E1,
  claim_svg_element: A1,
  detach: C1,
  init: S1,
  insert_hydration: T1,
  noop: B1,
  safe_not_equal: R1,
  svg_element: I1
} = window.__gradio__svelte__internal, {
  SvelteComponent: L1,
  append_hydration: x1,
  attr: O1,
  children: q1,
  claim_svg_element: N1,
  detach: z1,
  init: M1,
  insert_hydration: P1,
  noop: U1,
  safe_not_equal: H1,
  svg_element: G1
} = window.__gradio__svelte__internal, {
  SvelteComponent: j1,
  append_hydration: V1,
  attr: W1,
  children: Z1,
  claim_svg_element: Y1,
  detach: X1,
  init: K1,
  insert_hydration: Q1,
  noop: J1,
  safe_not_equal: ev,
  svg_element: tv
} = window.__gradio__svelte__internal, {
  SvelteComponent: nv,
  append_hydration: iv,
  attr: av,
  children: lv,
  claim_svg_element: ov,
  detach: rv,
  init: sv,
  insert_hydration: uv,
  noop: cv,
  safe_not_equal: _v,
  set_style: dv,
  svg_element: fv
} = window.__gradio__svelte__internal, {
  SvelteComponent: pv,
  append_hydration: hv,
  attr: mv,
  children: gv,
  claim_svg_element: vv,
  detach: Dv,
  init: bv,
  insert_hydration: yv,
  noop: Fv,
  safe_not_equal: wv,
  svg_element: $v
} = window.__gradio__svelte__internal, {
  SvelteComponent: kv,
  append_hydration: Ev,
  attr: Av,
  children: Cv,
  claim_svg_element: Sv,
  detach: Tv,
  init: Bv,
  insert_hydration: Rv,
  noop: Iv,
  safe_not_equal: Lv,
  svg_element: xv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ov,
  append_hydration: qv,
  attr: Nv,
  children: zv,
  claim_svg_element: Mv,
  detach: Pv,
  init: Uv,
  insert_hydration: Hv,
  noop: Gv,
  safe_not_equal: jv,
  svg_element: Vv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wv,
  append_hydration: Zv,
  attr: Yv,
  children: Xv,
  claim_svg_element: Kv,
  detach: Qv,
  init: Jv,
  insert_hydration: eD,
  noop: tD,
  safe_not_equal: nD,
  svg_element: iD
} = window.__gradio__svelte__internal, {
  SvelteComponent: aD,
  append_hydration: lD,
  attr: oD,
  children: rD,
  claim_svg_element: sD,
  detach: uD,
  init: cD,
  insert_hydration: _D,
  noop: dD,
  safe_not_equal: fD,
  svg_element: pD
} = window.__gradio__svelte__internal, {
  SvelteComponent: hD,
  append_hydration: mD,
  attr: gD,
  children: vD,
  claim_svg_element: DD,
  detach: bD,
  init: yD,
  insert_hydration: FD,
  noop: wD,
  safe_not_equal: $D,
  svg_element: kD
} = window.__gradio__svelte__internal, {
  SvelteComponent: ED,
  append_hydration: AD,
  attr: CD,
  children: SD,
  claim_svg_element: TD,
  detach: BD,
  init: RD,
  insert_hydration: ID,
  noop: LD,
  safe_not_equal: xD,
  svg_element: OD
} = window.__gradio__svelte__internal, {
  SvelteComponent: qD,
  append_hydration: ND,
  attr: zD,
  children: MD,
  claim_svg_element: PD,
  detach: UD,
  init: HD,
  insert_hydration: GD,
  noop: jD,
  safe_not_equal: VD,
  svg_element: WD
} = window.__gradio__svelte__internal, {
  SvelteComponent: ZD,
  append_hydration: YD,
  attr: XD,
  children: KD,
  claim_svg_element: QD,
  claim_text: JD,
  detach: eb,
  init: tb,
  insert_hydration: nb,
  noop: ib,
  safe_not_equal: ab,
  svg_element: lb,
  text: ob
} = window.__gradio__svelte__internal, {
  SvelteComponent: rb,
  append_hydration: sb,
  attr: ub,
  children: cb,
  claim_svg_element: _b,
  detach: db,
  init: fb,
  insert_hydration: pb,
  noop: hb,
  safe_not_equal: mb,
  svg_element: gb
} = window.__gradio__svelte__internal, {
  SvelteComponent: vb,
  append_hydration: Db,
  attr: bb,
  children: yb,
  claim_svg_element: Fb,
  detach: wb,
  init: $b,
  insert_hydration: kb,
  noop: Eb,
  safe_not_equal: Ab,
  svg_element: Cb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sb,
  append_hydration: Tb,
  attr: Bb,
  children: Rb,
  claim_svg_element: Ib,
  detach: Lb,
  init: xb,
  insert_hydration: Ob,
  noop: qb,
  safe_not_equal: Nb,
  svg_element: zb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mb,
  append_hydration: Pb,
  attr: Ub,
  children: Hb,
  claim_svg_element: Gb,
  detach: jb,
  init: Vb,
  insert_hydration: Wb,
  noop: Zb,
  safe_not_equal: Yb,
  svg_element: Xb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kb,
  append_hydration: Qb,
  attr: Jb,
  children: ey,
  claim_svg_element: ty,
  detach: ny,
  init: iy,
  insert_hydration: ay,
  noop: ly,
  safe_not_equal: oy,
  svg_element: ry
} = window.__gradio__svelte__internal, {
  SvelteComponent: sy,
  append_hydration: uy,
  attr: cy,
  children: _y,
  claim_svg_element: dy,
  detach: fy,
  init: py,
  insert_hydration: hy,
  noop: my,
  safe_not_equal: gy,
  svg_element: vy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dy,
  append_hydration: by,
  attr: yy,
  children: Fy,
  claim_svg_element: wy,
  detach: $y,
  init: ky,
  insert_hydration: Ey,
  noop: Ay,
  safe_not_equal: Cy,
  svg_element: Sy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ty,
  append_hydration: By,
  attr: Ry,
  children: Iy,
  claim_svg_element: Ly,
  claim_text: xy,
  detach: Oy,
  init: qy,
  insert_hydration: Ny,
  noop: zy,
  safe_not_equal: My,
  svg_element: Py,
  text: Uy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hy,
  append_hydration: Gy,
  attr: jy,
  children: Vy,
  claim_svg_element: Wy,
  claim_text: Zy,
  detach: Yy,
  init: Xy,
  insert_hydration: Ky,
  noop: Qy,
  safe_not_equal: Jy,
  svg_element: eF,
  text: tF
} = window.__gradio__svelte__internal, {
  SvelteComponent: nF,
  append_hydration: iF,
  attr: aF,
  children: lF,
  claim_svg_element: oF,
  claim_text: rF,
  detach: sF,
  init: uF,
  insert_hydration: cF,
  noop: _F,
  safe_not_equal: dF,
  svg_element: fF,
  text: pF
} = window.__gradio__svelte__internal, {
  SvelteComponent: hF,
  append_hydration: mF,
  attr: gF,
  children: vF,
  claim_svg_element: DF,
  detach: bF,
  init: yF,
  insert_hydration: FF,
  noop: wF,
  safe_not_equal: $F,
  svg_element: kF
} = window.__gradio__svelte__internal, {
  SvelteComponent: EF,
  append_hydration: AF,
  attr: CF,
  children: SF,
  claim_svg_element: TF,
  detach: BF,
  init: RF,
  insert_hydration: IF,
  noop: LF,
  safe_not_equal: xF,
  svg_element: OF
} = window.__gradio__svelte__internal, {
  SvelteComponent: qF,
  append_hydration: NF,
  attr: zF,
  children: MF,
  claim_svg_element: PF,
  detach: UF,
  init: HF,
  insert_hydration: GF,
  noop: jF,
  safe_not_equal: VF,
  svg_element: WF
} = window.__gradio__svelte__internal, {
  SvelteComponent: ZF,
  append_hydration: YF,
  attr: XF,
  children: KF,
  claim_svg_element: QF,
  detach: JF,
  init: ew,
  insert_hydration: tw,
  noop: nw,
  safe_not_equal: iw,
  svg_element: aw
} = window.__gradio__svelte__internal, {
  SvelteComponent: lw,
  append_hydration: ow,
  attr: rw,
  children: sw,
  claim_svg_element: uw,
  detach: cw,
  init: _w,
  insert_hydration: dw,
  noop: fw,
  safe_not_equal: pw,
  svg_element: hw
} = window.__gradio__svelte__internal, {
  SvelteComponent: mw,
  append_hydration: gw,
  attr: vw,
  children: Dw,
  claim_svg_element: bw,
  detach: yw,
  init: Fw,
  insert_hydration: ww,
  noop: $w,
  safe_not_equal: kw,
  svg_element: Ew
} = window.__gradio__svelte__internal, {
  SvelteComponent: Aw,
  append_hydration: Cw,
  attr: Sw,
  children: Tw,
  claim_svg_element: Bw,
  detach: Rw,
  init: Iw,
  insert_hydration: Lw,
  noop: xw,
  safe_not_equal: Ow,
  svg_element: qw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nw,
  append_hydration: zw,
  attr: Mw,
  children: Pw,
  claim_svg_element: Uw,
  detach: Hw,
  init: Gw,
  insert_hydration: jw,
  noop: Vw,
  safe_not_equal: Ww,
  svg_element: Zw
} = window.__gradio__svelte__internal, Dr = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Zi = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Dr.reduce(
  (i, { color: e, primary: t, secondary: n }) => ({
    ...i,
    [e]: {
      primary: Zi[e][t],
      secondary: Zi[e][n]
    }
  }),
  {}
);
const {
  SvelteComponent: Yw,
  claim_component: Xw,
  create_component: Kw,
  destroy_component: Qw,
  init: Jw,
  mount_component: e$,
  safe_not_equal: t$,
  transition_in: n$,
  transition_out: i$
} = window.__gradio__svelte__internal, { createEventDispatcher: a$ } = window.__gradio__svelte__internal, {
  SvelteComponent: l$,
  append_hydration: o$,
  attr: r$,
  check_outros: s$,
  children: u$,
  claim_component: c$,
  claim_element: _$,
  claim_space: d$,
  claim_text: f$,
  create_component: p$,
  destroy_component: h$,
  detach: m$,
  element: g$,
  empty: v$,
  group_outros: D$,
  init: b$,
  insert_hydration: y$,
  mount_component: F$,
  safe_not_equal: w$,
  set_data: $$,
  space: k$,
  text: E$,
  toggle_class: A$,
  transition_in: C$,
  transition_out: S$
} = window.__gradio__svelte__internal, {
  SvelteComponent: T$,
  attr: B$,
  children: R$,
  claim_element: I$,
  create_slot: L$,
  detach: x$,
  element: O$,
  get_all_dirty_from_scope: q$,
  get_slot_changes: N$,
  init: z$,
  insert_hydration: M$,
  safe_not_equal: P$,
  toggle_class: U$,
  transition_in: H$,
  transition_out: G$,
  update_slot_base: j$
} = window.__gradio__svelte__internal, {
  SvelteComponent: V$,
  append_hydration: W$,
  attr: Z$,
  check_outros: Y$,
  children: X$,
  claim_component: K$,
  claim_element: Q$,
  claim_space: J$,
  create_component: ek,
  destroy_component: tk,
  detach: nk,
  element: ik,
  empty: ak,
  group_outros: lk,
  init: ok,
  insert_hydration: rk,
  listen: sk,
  mount_component: uk,
  safe_not_equal: ck,
  space: _k,
  toggle_class: dk,
  transition_in: fk,
  transition_out: pk
} = window.__gradio__svelte__internal, {
  SvelteComponent: hk,
  attr: mk,
  children: gk,
  claim_element: vk,
  create_slot: Dk,
  detach: bk,
  element: yk,
  get_all_dirty_from_scope: Fk,
  get_slot_changes: wk,
  init: $k,
  insert_hydration: kk,
  null_to_empty: Ek,
  safe_not_equal: Ak,
  transition_in: Ck,
  transition_out: Sk,
  update_slot_base: Tk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bk,
  check_outros: Rk,
  claim_component: Ik,
  create_component: Lk,
  destroy_component: xk,
  detach: Ok,
  empty: qk,
  group_outros: Nk,
  init: zk,
  insert_hydration: Mk,
  mount_component: Pk,
  noop: Uk,
  safe_not_equal: Hk,
  transition_in: Gk,
  transition_out: jk
} = window.__gradio__svelte__internal, { createEventDispatcher: Vk } = window.__gradio__svelte__internal;
function Ot(i) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; i > 1e3 && t < e.length - 1; )
    i /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(i) ? i : i.toFixed(1)) + n;
}
function Fn() {
}
const sl = typeof window < "u";
let Yi = sl ? () => window.performance.now() : () => Date.now(), ul = sl ? (i) => requestAnimationFrame(i) : Fn;
const qt = /* @__PURE__ */ new Set();
function cl(i) {
  qt.forEach((e) => {
    e.c(i) || (qt.delete(e), e.f());
  }), qt.size !== 0 && ul(cl);
}
function br(i) {
  let e;
  return qt.size === 0 && ul(cl), { promise: new Promise((t) => {
    qt.add(e = { c: i, f: t });
  }), abort() {
    qt.delete(e);
  } };
}
const xt = [];
function yr(i, e = Fn) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function a(l) {
    if (s = l, ((r = i) != r ? s == s : r !== s || r && typeof r == "object" || typeof r == "function") && (i = l, t)) {
      const u = !xt.length;
      for (const c of n) c[1](), xt.push(c, i);
      if (u) {
        for (let c = 0; c < xt.length; c += 2) xt[c][0](xt[c + 1]);
        xt.length = 0;
      }
    }
    var r, s;
  }
  function o(l) {
    a(l(i));
  }
  return { set: a, update: o, subscribe: function(l, r = Fn) {
    const s = [l, r];
    return n.add(s), n.size === 1 && (t = e(a, o) || Fn), l(i), () => {
      n.delete(s), n.size === 0 && t && (t(), t = null);
    };
  } };
}
function Xi(i) {
  return Object.prototype.toString.call(i) === "[object Date]";
}
function ti(i, e, t, n) {
  if (typeof t == "number" || Xi(t)) {
    const a = n - t, o = (t - e) / (i.dt || 1 / 60), l = (o + (i.opts.stiffness * a - i.opts.damping * o) * i.inv_mass) * i.dt;
    return Math.abs(l) < i.opts.precision && Math.abs(a) < i.opts.precision ? n : (i.settled = !1, Xi(t) ? new Date(t.getTime() + l) : t + l);
  }
  if (Array.isArray(t)) return t.map((a, o) => ti(i, e[o], t[o], n[o]));
  if (typeof t == "object") {
    const a = {};
    for (const o in t) a[o] = ti(i, e[o], t[o], n[o]);
    return a;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function Ki(i, e = {}) {
  const t = yr(i), { stiffness: n = 0.15, damping: a = 0.8, precision: o = 0.01 } = e;
  let l, r, s, u = i, c = i, h = 1, d = 0, f = !1;
  function v(b, E = {}) {
    c = b;
    const m = s = {};
    return i == null || E.hard || D.stiffness >= 1 && D.damping >= 1 ? (f = !0, l = Yi(), u = b, t.set(i = c), Promise.resolve()) : (E.soft && (d = 1 / (60 * (E.soft === !0 ? 0.5 : +E.soft)), h = 0), r || (l = Yi(), f = !1, r = br((_) => {
      if (f) return f = !1, r = null, !1;
      h = Math.min(h + d, 1);
      const g = { inv_mass: h, opts: D, settled: !0, dt: 60 * (_ - l) / 1e3 }, F = ti(g, u, i, c);
      return l = _, u = i, t.set(i = F), g.settled && (r = null), !g.settled;
    })), new Promise((_) => {
      r.promise.then(() => {
        m === s && _();
      });
    }));
  }
  const D = { set: v, update: (b, E) => v(b(c, i), E), subscribe: t.subscribe, stiffness: n, damping: a, precision: o };
  return D;
}
const {
  SvelteComponent: Fr,
  append_hydration: Pe,
  attr: P,
  children: Ie,
  claim_element: wr,
  claim_svg_element: Ue,
  component_subscribe: Qi,
  detach: Te,
  element: $r,
  init: kr,
  insert_hydration: Er,
  noop: Ji,
  safe_not_equal: Ar,
  set_style: gn,
  svg_element: He,
  toggle_class: ea
} = window.__gradio__svelte__internal, { onMount: Cr } = window.__gradio__svelte__internal;
function Sr(i) {
  let e, t, n, a, o, l, r, s, u, c, h, d;
  return {
    c() {
      e = $r("div"), t = He("svg"), n = He("g"), a = He("path"), o = He("path"), l = He("path"), r = He("path"), s = He("g"), u = He("path"), c = He("path"), h = He("path"), d = He("path"), this.h();
    },
    l(f) {
      e = wr(f, "DIV", { class: !0 });
      var v = Ie(e);
      t = Ue(v, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var D = Ie(t);
      n = Ue(D, "g", { style: !0 });
      var b = Ie(n);
      a = Ue(b, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ie(a).forEach(Te), o = Ue(b, "path", { d: !0, fill: !0, class: !0 }), Ie(o).forEach(Te), l = Ue(b, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ie(l).forEach(Te), r = Ue(b, "path", { d: !0, fill: !0, class: !0 }), Ie(r).forEach(Te), b.forEach(Te), s = Ue(D, "g", { style: !0 });
      var E = Ie(s);
      u = Ue(E, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ie(u).forEach(Te), c = Ue(E, "path", { d: !0, fill: !0, class: !0 }), Ie(c).forEach(Te), h = Ue(E, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ie(h).forEach(Te), d = Ue(E, "path", { d: !0, fill: !0, class: !0 }), Ie(d).forEach(Te), E.forEach(Te), D.forEach(Te), v.forEach(Te), this.h();
    },
    h() {
      P(a, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), P(a, "fill", "#FF7C00"), P(a, "fill-opacity", "0.4"), P(a, "class", "svelte-43sxxs"), P(o, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), P(o, "fill", "#FF7C00"), P(o, "class", "svelte-43sxxs"), P(l, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), P(l, "fill", "#FF7C00"), P(l, "fill-opacity", "0.4"), P(l, "class", "svelte-43sxxs"), P(r, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), P(r, "fill", "#FF7C00"), P(r, "class", "svelte-43sxxs"), gn(n, "transform", "translate(" + /*$top*/
      i[1][0] + "px, " + /*$top*/
      i[1][1] + "px)"), P(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), P(u, "fill", "#FF7C00"), P(u, "fill-opacity", "0.4"), P(u, "class", "svelte-43sxxs"), P(c, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), P(c, "fill", "#FF7C00"), P(c, "class", "svelte-43sxxs"), P(h, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), P(h, "fill", "#FF7C00"), P(h, "fill-opacity", "0.4"), P(h, "class", "svelte-43sxxs"), P(d, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), P(d, "fill", "#FF7C00"), P(d, "class", "svelte-43sxxs"), gn(s, "transform", "translate(" + /*$bottom*/
      i[2][0] + "px, " + /*$bottom*/
      i[2][1] + "px)"), P(t, "viewBox", "-1200 -1200 3000 3000"), P(t, "fill", "none"), P(t, "xmlns", "http://www.w3.org/2000/svg"), P(t, "class", "svelte-43sxxs"), P(e, "class", "svelte-43sxxs"), ea(
        e,
        "margin",
        /*margin*/
        i[0]
      );
    },
    m(f, v) {
      Er(f, e, v), Pe(e, t), Pe(t, n), Pe(n, a), Pe(n, o), Pe(n, l), Pe(n, r), Pe(t, s), Pe(s, u), Pe(s, c), Pe(s, h), Pe(s, d);
    },
    p(f, [v]) {
      v & /*$top*/
      2 && gn(n, "transform", "translate(" + /*$top*/
      f[1][0] + "px, " + /*$top*/
      f[1][1] + "px)"), v & /*$bottom*/
      4 && gn(s, "transform", "translate(" + /*$bottom*/
      f[2][0] + "px, " + /*$bottom*/
      f[2][1] + "px)"), v & /*margin*/
      1 && ea(
        e,
        "margin",
        /*margin*/
        f[0]
      );
    },
    i: Ji,
    o: Ji,
    d(f) {
      f && Te(e);
    }
  };
}
function Tr(i, e, t) {
  let n, a;
  var o = this && this.__awaiter || function(f, v, D, b) {
    function E(m) {
      return m instanceof D ? m : new D(function(_) {
        _(m);
      });
    }
    return new (D || (D = Promise))(function(m, _) {
      function g(C) {
        try {
          w(b.next(C));
        } catch (I) {
          _(I);
        }
      }
      function F(C) {
        try {
          w(b.throw(C));
        } catch (I) {
          _(I);
        }
      }
      function w(C) {
        C.done ? m(C.value) : E(C.value).then(g, F);
      }
      w((b = b.apply(f, v || [])).next());
    });
  };
  let { margin: l = !0 } = e;
  const r = Ki([0, 0]);
  Qi(i, r, (f) => t(1, n = f));
  const s = Ki([0, 0]);
  Qi(i, s, (f) => t(2, a = f));
  let u;
  function c() {
    return o(this, void 0, void 0, function* () {
      yield Promise.all([r.set([125, 140]), s.set([-125, -140])]), yield Promise.all([r.set([-125, 140]), s.set([125, -140])]), yield Promise.all([r.set([-125, 0]), s.set([125, -0])]), yield Promise.all([r.set([125, 0]), s.set([-125, 0])]);
    });
  }
  function h() {
    return o(this, void 0, void 0, function* () {
      yield c(), u || h();
    });
  }
  function d() {
    return o(this, void 0, void 0, function* () {
      yield Promise.all([r.set([125, 0]), s.set([-125, 0])]), h();
    });
  }
  return Cr(() => (d(), () => u = !0)), i.$$set = (f) => {
    "margin" in f && t(0, l = f.margin);
  }, [l, n, a, r, s];
}
class Br extends Fr {
  constructor(e) {
    super(), kr(this, e, Tr, Sr, Ar, { margin: 0 });
  }
}
const {
  SvelteComponent: Rr,
  append_hydration: At,
  attr: Ve,
  binding_callbacks: ta,
  check_outros: ni,
  children: it,
  claim_component: _l,
  claim_element: at,
  claim_space: xe,
  claim_text: te,
  create_component: dl,
  create_slot: fl,
  destroy_component: pl,
  destroy_each: hl,
  detach: R,
  element: lt,
  empty: qe,
  ensure_array_like: An,
  get_all_dirty_from_scope: ml,
  get_slot_changes: gl,
  group_outros: ii,
  init: Ir,
  insert_hydration: z,
  mount_component: vl,
  noop: ai,
  safe_not_equal: Lr,
  set_data: Ne,
  set_style: Ft,
  space: Oe,
  text: ne,
  toggle_class: Le,
  transition_in: je,
  transition_out: ot,
  update_slot_base: Dl
} = window.__gradio__svelte__internal, { tick: xr } = window.__gradio__svelte__internal, { onDestroy: Or } = window.__gradio__svelte__internal, { createEventDispatcher: qr } = window.__gradio__svelte__internal, Nr = (i) => ({}), na = (i) => ({}), zr = (i) => ({}), ia = (i) => ({});
function aa(i, e, t) {
  const n = i.slice();
  return n[40] = e[t], n[42] = t, n;
}
function la(i, e, t) {
  const n = i.slice();
  return n[40] = e[t], n;
}
function Mr(i) {
  let e, t, n, a, o = (
    /*i18n*/
    i[1]("common.error") + ""
  ), l, r, s;
  t = new dr({
    props: {
      Icon: vr,
      label: (
        /*i18n*/
        i[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    i[32]
  );
  const u = (
    /*#slots*/
    i[30].error
  ), c = fl(
    u,
    i,
    /*$$scope*/
    i[29],
    na
  );
  return {
    c() {
      e = lt("div"), dl(t.$$.fragment), n = Oe(), a = lt("span"), l = ne(o), r = Oe(), c && c.c(), this.h();
    },
    l(h) {
      e = at(h, "DIV", { class: !0 });
      var d = it(e);
      _l(t.$$.fragment, d), d.forEach(R), n = xe(h), a = at(h, "SPAN", { class: !0 });
      var f = it(a);
      l = te(f, o), f.forEach(R), r = xe(h), c && c.l(h), this.h();
    },
    h() {
      Ve(e, "class", "clear-status svelte-17v219f"), Ve(a, "class", "error svelte-17v219f");
    },
    m(h, d) {
      z(h, e, d), vl(t, e, null), z(h, n, d), z(h, a, d), At(a, l), z(h, r, d), c && c.m(h, d), s = !0;
    },
    p(h, d) {
      const f = {};
      d[0] & /*i18n*/
      2 && (f.label = /*i18n*/
      h[1]("common.clear")), t.$set(f), (!s || d[0] & /*i18n*/
      2) && o !== (o = /*i18n*/
      h[1]("common.error") + "") && Ne(l, o), c && c.p && (!s || d[0] & /*$$scope*/
      536870912) && Dl(
        c,
        u,
        h,
        /*$$scope*/
        h[29],
        s ? gl(
          u,
          /*$$scope*/
          h[29],
          d,
          Nr
        ) : ml(
          /*$$scope*/
          h[29]
        ),
        na
      );
    },
    i(h) {
      s || (je(t.$$.fragment, h), je(c, h), s = !0);
    },
    o(h) {
      ot(t.$$.fragment, h), ot(c, h), s = !1;
    },
    d(h) {
      h && (R(e), R(n), R(a), R(r)), pl(t), c && c.d(h);
    }
  };
}
function Pr(i) {
  let e, t, n, a, o, l, r, s, u, c = (
    /*variant*/
    i[8] === "default" && /*show_eta_bar*/
    i[18] && /*show_progress*/
    i[6] === "full" && oa(i)
  );
  function h(_, g) {
    if (
      /*progress*/
      _[7]
    ) return Gr;
    if (
      /*queue_position*/
      _[2] !== null && /*queue_size*/
      _[3] !== void 0 && /*queue_position*/
      _[2] >= 0
    ) return Hr;
    if (
      /*queue_position*/
      _[2] === 0
    ) return Ur;
  }
  let d = h(i), f = d && d(i), v = (
    /*timer*/
    i[5] && ua(i)
  );
  const D = [Zr, Wr], b = [];
  function E(_, g) {
    return (
      /*last_progress_level*/
      _[15] != null ? 0 : (
        /*show_progress*/
        _[6] === "full" ? 1 : -1
      )
    );
  }
  ~(o = E(i)) && (l = b[o] = D[o](i));
  let m = !/*timer*/
  i[5] && ma(i);
  return {
    c() {
      c && c.c(), e = Oe(), t = lt("div"), f && f.c(), n = Oe(), v && v.c(), a = Oe(), l && l.c(), r = Oe(), m && m.c(), s = qe(), this.h();
    },
    l(_) {
      c && c.l(_), e = xe(_), t = at(_, "DIV", { class: !0 });
      var g = it(t);
      f && f.l(g), n = xe(g), v && v.l(g), g.forEach(R), a = xe(_), l && l.l(_), r = xe(_), m && m.l(_), s = qe(), this.h();
    },
    h() {
      Ve(t, "class", "progress-text svelte-17v219f"), Le(
        t,
        "meta-text-center",
        /*variant*/
        i[8] === "center"
      ), Le(
        t,
        "meta-text",
        /*variant*/
        i[8] === "default"
      );
    },
    m(_, g) {
      c && c.m(_, g), z(_, e, g), z(_, t, g), f && f.m(t, null), At(t, n), v && v.m(t, null), z(_, a, g), ~o && b[o].m(_, g), z(_, r, g), m && m.m(_, g), z(_, s, g), u = !0;
    },
    p(_, g) {
      /*variant*/
      _[8] === "default" && /*show_eta_bar*/
      _[18] && /*show_progress*/
      _[6] === "full" ? c ? c.p(_, g) : (c = oa(_), c.c(), c.m(e.parentNode, e)) : c && (c.d(1), c = null), d === (d = h(_)) && f ? f.p(_, g) : (f && f.d(1), f = d && d(_), f && (f.c(), f.m(t, n))), /*timer*/
      _[5] ? v ? v.p(_, g) : (v = ua(_), v.c(), v.m(t, null)) : v && (v.d(1), v = null), (!u || g[0] & /*variant*/
      256) && Le(
        t,
        "meta-text-center",
        /*variant*/
        _[8] === "center"
      ), (!u || g[0] & /*variant*/
      256) && Le(
        t,
        "meta-text",
        /*variant*/
        _[8] === "default"
      );
      let F = o;
      o = E(_), o === F ? ~o && b[o].p(_, g) : (l && (ii(), ot(b[F], 1, 1, () => {
        b[F] = null;
      }), ni()), ~o ? (l = b[o], l ? l.p(_, g) : (l = b[o] = D[o](_), l.c()), je(l, 1), l.m(r.parentNode, r)) : l = null), /*timer*/
      _[5] ? m && (ii(), ot(m, 1, 1, () => {
        m = null;
      }), ni()) : m ? (m.p(_, g), g[0] & /*timer*/
      32 && je(m, 1)) : (m = ma(_), m.c(), je(m, 1), m.m(s.parentNode, s));
    },
    i(_) {
      u || (je(l), je(m), u = !0);
    },
    o(_) {
      ot(l), ot(m), u = !1;
    },
    d(_) {
      _ && (R(e), R(t), R(a), R(r), R(s)), c && c.d(_), f && f.d(), v && v.d(), ~o && b[o].d(_), m && m.d(_);
    }
  };
}
function oa(i) {
  let e, t = `translateX(${/*eta_level*/
  (i[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = lt("div"), this.h();
    },
    l(n) {
      e = at(n, "DIV", { class: !0 }), it(e).forEach(R), this.h();
    },
    h() {
      Ve(e, "class", "eta-bar svelte-17v219f"), Ft(e, "transform", t);
    },
    m(n, a) {
      z(n, e, a);
    },
    p(n, a) {
      a[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (n[17] || 0) * 100 - 100}%)`) && Ft(e, "transform", t);
    },
    d(n) {
      n && R(e);
    }
  };
}
function Ur(i) {
  let e;
  return {
    c() {
      e = ne("processing |");
    },
    l(t) {
      e = te(t, "processing |");
    },
    m(t, n) {
      z(t, e, n);
    },
    p: ai,
    d(t) {
      t && R(e);
    }
  };
}
function Hr(i) {
  let e, t = (
    /*queue_position*/
    i[2] + 1 + ""
  ), n, a, o, l;
  return {
    c() {
      e = ne("queue: "), n = ne(t), a = ne("/"), o = ne(
        /*queue_size*/
        i[3]
      ), l = ne(" |");
    },
    l(r) {
      e = te(r, "queue: "), n = te(r, t), a = te(r, "/"), o = te(
        r,
        /*queue_size*/
        i[3]
      ), l = te(r, " |");
    },
    m(r, s) {
      z(r, e, s), z(r, n, s), z(r, a, s), z(r, o, s), z(r, l, s);
    },
    p(r, s) {
      s[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      r[2] + 1 + "") && Ne(n, t), s[0] & /*queue_size*/
      8 && Ne(
        o,
        /*queue_size*/
        r[3]
      );
    },
    d(r) {
      r && (R(e), R(n), R(a), R(o), R(l));
    }
  };
}
function Gr(i) {
  let e, t = An(
    /*progress*/
    i[7]
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = sa(la(i, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = qe();
    },
    l(a) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(a);
      e = qe();
    },
    m(a, o) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, o);
      z(a, e, o);
    },
    p(a, o) {
      if (o[0] & /*progress*/
      128) {
        t = An(
          /*progress*/
          a[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const r = la(a, t, l);
          n[l] ? n[l].p(r, o) : (n[l] = sa(r), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && R(e), hl(n, a);
    }
  };
}
function ra(i) {
  let e, t = (
    /*p*/
    i[40].unit + ""
  ), n, a, o = " ", l;
  function r(c, h) {
    return (
      /*p*/
      c[40].length != null ? Vr : jr
    );
  }
  let s = r(i), u = s(i);
  return {
    c() {
      u.c(), e = Oe(), n = ne(t), a = ne(" | "), l = ne(o);
    },
    l(c) {
      u.l(c), e = xe(c), n = te(c, t), a = te(c, " | "), l = te(c, o);
    },
    m(c, h) {
      u.m(c, h), z(c, e, h), z(c, n, h), z(c, a, h), z(c, l, h);
    },
    p(c, h) {
      s === (s = r(c)) && u ? u.p(c, h) : (u.d(1), u = s(c), u && (u.c(), u.m(e.parentNode, e))), h[0] & /*progress*/
      128 && t !== (t = /*p*/
      c[40].unit + "") && Ne(n, t);
    },
    d(c) {
      c && (R(e), R(n), R(a), R(l)), u.d(c);
    }
  };
}
function jr(i) {
  let e = Ot(
    /*p*/
    i[40].index || 0
  ) + "", t;
  return {
    c() {
      t = ne(e);
    },
    l(n) {
      t = te(n, e);
    },
    m(n, a) {
      z(n, t, a);
    },
    p(n, a) {
      a[0] & /*progress*/
      128 && e !== (e = Ot(
        /*p*/
        n[40].index || 0
      ) + "") && Ne(t, e);
    },
    d(n) {
      n && R(t);
    }
  };
}
function Vr(i) {
  let e = Ot(
    /*p*/
    i[40].index || 0
  ) + "", t, n, a = Ot(
    /*p*/
    i[40].length
  ) + "", o;
  return {
    c() {
      t = ne(e), n = ne("/"), o = ne(a);
    },
    l(l) {
      t = te(l, e), n = te(l, "/"), o = te(l, a);
    },
    m(l, r) {
      z(l, t, r), z(l, n, r), z(l, o, r);
    },
    p(l, r) {
      r[0] & /*progress*/
      128 && e !== (e = Ot(
        /*p*/
        l[40].index || 0
      ) + "") && Ne(t, e), r[0] & /*progress*/
      128 && a !== (a = Ot(
        /*p*/
        l[40].length
      ) + "") && Ne(o, a);
    },
    d(l) {
      l && (R(t), R(n), R(o));
    }
  };
}
function sa(i) {
  let e, t = (
    /*p*/
    i[40].index != null && ra(i)
  );
  return {
    c() {
      t && t.c(), e = qe();
    },
    l(n) {
      t && t.l(n), e = qe();
    },
    m(n, a) {
      t && t.m(n, a), z(n, e, a);
    },
    p(n, a) {
      /*p*/
      n[40].index != null ? t ? t.p(n, a) : (t = ra(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && R(e), t && t.d(n);
    }
  };
}
function ua(i) {
  let e, t = (
    /*eta*/
    i[0] ? `/${/*formatted_eta*/
    i[19]}` : ""
  ), n, a;
  return {
    c() {
      e = ne(
        /*formatted_timer*/
        i[20]
      ), n = ne(t), a = ne("s");
    },
    l(o) {
      e = te(
        o,
        /*formatted_timer*/
        i[20]
      ), n = te(o, t), a = te(o, "s");
    },
    m(o, l) {
      z(o, e, l), z(o, n, l), z(o, a, l);
    },
    p(o, l) {
      l[0] & /*formatted_timer*/
      1048576 && Ne(
        e,
        /*formatted_timer*/
        o[20]
      ), l[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      o[0] ? `/${/*formatted_eta*/
      o[19]}` : "") && Ne(n, t);
    },
    d(o) {
      o && (R(e), R(n), R(a));
    }
  };
}
function Wr(i) {
  let e, t;
  return e = new Br({
    props: { margin: (
      /*variant*/
      i[8] === "default"
    ) }
  }), {
    c() {
      dl(e.$$.fragment);
    },
    l(n) {
      _l(e.$$.fragment, n);
    },
    m(n, a) {
      vl(e, n, a), t = !0;
    },
    p(n, a) {
      const o = {};
      a[0] & /*variant*/
      256 && (o.margin = /*variant*/
      n[8] === "default"), e.$set(o);
    },
    i(n) {
      t || (je(e.$$.fragment, n), t = !0);
    },
    o(n) {
      ot(e.$$.fragment, n), t = !1;
    },
    d(n) {
      pl(e, n);
    }
  };
}
function Zr(i) {
  let e, t, n, a, o, l = `${/*last_progress_level*/
  i[15] * 100}%`, r = (
    /*progress*/
    i[7] != null && ca(i)
  );
  return {
    c() {
      e = lt("div"), t = lt("div"), r && r.c(), n = Oe(), a = lt("div"), o = lt("div"), this.h();
    },
    l(s) {
      e = at(s, "DIV", { class: !0 });
      var u = it(e);
      t = at(u, "DIV", { class: !0 });
      var c = it(t);
      r && r.l(c), c.forEach(R), n = xe(u), a = at(u, "DIV", { class: !0 });
      var h = it(a);
      o = at(h, "DIV", { class: !0 }), it(o).forEach(R), h.forEach(R), u.forEach(R), this.h();
    },
    h() {
      Ve(t, "class", "progress-level-inner svelte-17v219f"), Ve(o, "class", "progress-bar svelte-17v219f"), Ft(o, "width", l), Ve(a, "class", "progress-bar-wrap svelte-17v219f"), Ve(e, "class", "progress-level svelte-17v219f");
    },
    m(s, u) {
      z(s, e, u), At(e, t), r && r.m(t, null), At(e, n), At(e, a), At(a, o), i[31](o);
    },
    p(s, u) {
      /*progress*/
      s[7] != null ? r ? r.p(s, u) : (r = ca(s), r.c(), r.m(t, null)) : r && (r.d(1), r = null), u[0] & /*last_progress_level*/
      32768 && l !== (l = `${/*last_progress_level*/
      s[15] * 100}%`) && Ft(o, "width", l);
    },
    i: ai,
    o: ai,
    d(s) {
      s && R(e), r && r.d(), i[31](null);
    }
  };
}
function ca(i) {
  let e, t = An(
    /*progress*/
    i[7]
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = ha(aa(i, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = qe();
    },
    l(a) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(a);
      e = qe();
    },
    m(a, o) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, o);
      z(a, e, o);
    },
    p(a, o) {
      if (o[0] & /*progress_level, progress*/
      16512) {
        t = An(
          /*progress*/
          a[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const r = aa(a, t, l);
          n[l] ? n[l].p(r, o) : (n[l] = ha(r), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && R(e), hl(n, a);
    }
  };
}
function _a(i) {
  let e, t, n, a, o = (
    /*i*/
    i[42] !== 0 && Yr()
  ), l = (
    /*p*/
    i[40].desc != null && da(i)
  ), r = (
    /*p*/
    i[40].desc != null && /*progress_level*/
    i[14] && /*progress_level*/
    i[14][
      /*i*/
      i[42]
    ] != null && fa()
  ), s = (
    /*progress_level*/
    i[14] != null && pa(i)
  );
  return {
    c() {
      o && o.c(), e = Oe(), l && l.c(), t = Oe(), r && r.c(), n = Oe(), s && s.c(), a = qe();
    },
    l(u) {
      o && o.l(u), e = xe(u), l && l.l(u), t = xe(u), r && r.l(u), n = xe(u), s && s.l(u), a = qe();
    },
    m(u, c) {
      o && o.m(u, c), z(u, e, c), l && l.m(u, c), z(u, t, c), r && r.m(u, c), z(u, n, c), s && s.m(u, c), z(u, a, c);
    },
    p(u, c) {
      /*p*/
      u[40].desc != null ? l ? l.p(u, c) : (l = da(u), l.c(), l.m(t.parentNode, t)) : l && (l.d(1), l = null), /*p*/
      u[40].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[42]
      ] != null ? r || (r = fa(), r.c(), r.m(n.parentNode, n)) : r && (r.d(1), r = null), /*progress_level*/
      u[14] != null ? s ? s.p(u, c) : (s = pa(u), s.c(), s.m(a.parentNode, a)) : s && (s.d(1), s = null);
    },
    d(u) {
      u && (R(e), R(t), R(n), R(a)), o && o.d(u), l && l.d(u), r && r.d(u), s && s.d(u);
    }
  };
}
function Yr(i) {
  let e;
  return {
    c() {
      e = ne(" /");
    },
    l(t) {
      e = te(t, " /");
    },
    m(t, n) {
      z(t, e, n);
    },
    d(t) {
      t && R(e);
    }
  };
}
function da(i) {
  let e = (
    /*p*/
    i[40].desc + ""
  ), t;
  return {
    c() {
      t = ne(e);
    },
    l(n) {
      t = te(n, e);
    },
    m(n, a) {
      z(n, t, a);
    },
    p(n, a) {
      a[0] & /*progress*/
      128 && e !== (e = /*p*/
      n[40].desc + "") && Ne(t, e);
    },
    d(n) {
      n && R(t);
    }
  };
}
function fa(i) {
  let e;
  return {
    c() {
      e = ne("-");
    },
    l(t) {
      e = te(t, "-");
    },
    m(t, n) {
      z(t, e, n);
    },
    d(t) {
      t && R(e);
    }
  };
}
function pa(i) {
  let e = (100 * /*progress_level*/
  (i[14][
    /*i*/
    i[42]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = ne(e), n = ne("%");
    },
    l(a) {
      t = te(a, e), n = te(a, "%");
    },
    m(a, o) {
      z(a, t, o), z(a, n, o);
    },
    p(a, o) {
      o[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (a[14][
        /*i*/
        a[42]
      ] || 0)).toFixed(1) + "") && Ne(t, e);
    },
    d(a) {
      a && (R(t), R(n));
    }
  };
}
function ha(i) {
  let e, t = (
    /*p*/
    (i[40].desc != null || /*progress_level*/
    i[14] && /*progress_level*/
    i[14][
      /*i*/
      i[42]
    ] != null) && _a(i)
  );
  return {
    c() {
      t && t.c(), e = qe();
    },
    l(n) {
      t && t.l(n), e = qe();
    },
    m(n, a) {
      t && t.m(n, a), z(n, e, a);
    },
    p(n, a) {
      /*p*/
      n[40].desc != null || /*progress_level*/
      n[14] && /*progress_level*/
      n[14][
        /*i*/
        n[42]
      ] != null ? t ? t.p(n, a) : (t = _a(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && R(e), t && t.d(n);
    }
  };
}
function ma(i) {
  let e, t, n, a;
  const o = (
    /*#slots*/
    i[30]["additional-loading-text"]
  ), l = fl(
    o,
    i,
    /*$$scope*/
    i[29],
    ia
  );
  return {
    c() {
      e = lt("p"), t = ne(
        /*loading_text*/
        i[9]
      ), n = Oe(), l && l.c(), this.h();
    },
    l(r) {
      e = at(r, "P", { class: !0 });
      var s = it(e);
      t = te(
        s,
        /*loading_text*/
        i[9]
      ), s.forEach(R), n = xe(r), l && l.l(r), this.h();
    },
    h() {
      Ve(e, "class", "loading svelte-17v219f");
    },
    m(r, s) {
      z(r, e, s), At(e, t), z(r, n, s), l && l.m(r, s), a = !0;
    },
    p(r, s) {
      (!a || s[0] & /*loading_text*/
      512) && Ne(
        t,
        /*loading_text*/
        r[9]
      ), l && l.p && (!a || s[0] & /*$$scope*/
      536870912) && Dl(
        l,
        o,
        r,
        /*$$scope*/
        r[29],
        a ? gl(
          o,
          /*$$scope*/
          r[29],
          s,
          zr
        ) : ml(
          /*$$scope*/
          r[29]
        ),
        ia
      );
    },
    i(r) {
      a || (je(l, r), a = !0);
    },
    o(r) {
      ot(l, r), a = !1;
    },
    d(r) {
      r && (R(e), R(n)), l && l.d(r);
    }
  };
}
function Xr(i) {
  let e, t, n, a, o;
  const l = [Pr, Mr], r = [];
  function s(u, c) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = s(i)) && (n = r[t] = l[t](i)), {
    c() {
      e = lt("div"), n && n.c(), this.h();
    },
    l(u) {
      e = at(u, "DIV", { class: !0 });
      var c = it(e);
      n && n.l(c), c.forEach(R), this.h();
    },
    h() {
      Ve(e, "class", a = "wrap " + /*variant*/
      i[8] + " " + /*show_progress*/
      i[6] + " svelte-17v219f"), Le(e, "hide", !/*status*/
      i[4] || /*status*/
      i[4] === "complete" || /*show_progress*/
      i[6] === "hidden" || /*status*/
      i[4] == "streaming"), Le(
        e,
        "translucent",
        /*variant*/
        i[8] === "center" && /*status*/
        (i[4] === "pending" || /*status*/
        i[4] === "error") || /*translucent*/
        i[11] || /*show_progress*/
        i[6] === "minimal"
      ), Le(
        e,
        "generating",
        /*status*/
        i[4] === "generating" && /*show_progress*/
        i[6] === "full"
      ), Le(
        e,
        "border",
        /*border*/
        i[12]
      ), Ft(
        e,
        "position",
        /*absolute*/
        i[10] ? "absolute" : "static"
      ), Ft(
        e,
        "padding",
        /*absolute*/
        i[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, c) {
      z(u, e, c), ~t && r[t].m(e, null), i[33](e), o = !0;
    },
    p(u, c) {
      let h = t;
      t = s(u), t === h ? ~t && r[t].p(u, c) : (n && (ii(), ot(r[h], 1, 1, () => {
        r[h] = null;
      }), ni()), ~t ? (n = r[t], n ? n.p(u, c) : (n = r[t] = l[t](u), n.c()), je(n, 1), n.m(e, null)) : n = null), (!o || c[0] & /*variant, show_progress*/
      320 && a !== (a = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-17v219f")) && Ve(e, "class", a), (!o || c[0] & /*variant, show_progress, status, show_progress*/
      336) && Le(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden" || /*status*/
      u[4] == "streaming"), (!o || c[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && Le(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!o || c[0] & /*variant, show_progress, status, show_progress*/
      336) && Le(
        e,
        "generating",
        /*status*/
        u[4] === "generating" && /*show_progress*/
        u[6] === "full"
      ), (!o || c[0] & /*variant, show_progress, border*/
      4416) && Le(
        e,
        "border",
        /*border*/
        u[12]
      ), c[0] & /*absolute*/
      1024 && Ft(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), c[0] & /*absolute*/
      1024 && Ft(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      o || (je(n), o = !0);
    },
    o(u) {
      ot(n), o = !1;
    },
    d(u) {
      u && R(e), ~t && r[t].d(), i[33](null);
    }
  };
}
var Kr = function(i, e, t, n) {
  function a(o) {
    return o instanceof t ? o : new t(function(l) {
      l(o);
    });
  }
  return new (t || (t = Promise))(function(o, l) {
    function r(c) {
      try {
        u(n.next(c));
      } catch (h) {
        l(h);
      }
    }
    function s(c) {
      try {
        u(n.throw(c));
      } catch (h) {
        l(h);
      }
    }
    function u(c) {
      c.done ? o(c.value) : a(c.value).then(r, s);
    }
    u((n = n.apply(i, e || [])).next());
  });
};
let vn = [], Hn = !1;
const Qr = typeof window < "u", bl = Qr ? window.requestAnimationFrame : (i) => {
};
function Jr(i) {
  return Kr(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (vn.push(e), !Hn) Hn = !0;
      else return;
      yield xr(), bl(() => {
        let n = [0, 0];
        for (let a = 0; a < vn.length; a++) {
          const l = vn[a].getBoundingClientRect();
          (a === 0 || l.top + window.scrollY <= n[0]) && (n[0] = l.top + window.scrollY, n[1] = a);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), Hn = !1, vn = [];
      });
    }
  });
}
function es(i, e, t) {
  let n, { $$slots: a = {}, $$scope: o } = e;
  const l = qr();
  let { i18n: r } = e, { eta: s = null } = e, { queue_position: u } = e, { queue_size: c } = e, { status: h } = e, { scroll_to_output: d = !1 } = e, { timer: f = !0 } = e, { show_progress: v = "full" } = e, { message: D = null } = e, { progress: b = null } = e, { variant: E = "default" } = e, { loading_text: m = "Loading..." } = e, { absolute: _ = !0 } = e, { translucent: g = !1 } = e, { border: F = !1 } = e, { autoscroll: w } = e, C, I = !1, S = 0, O = 0, q = null, H = null, ke = 0, re = null, ae, se = null, Se = !0;
  const K = () => {
    t(0, s = t(27, q = t(19, $ = null))), t(25, S = performance.now()), t(26, O = 0), I = !0, ue();
  };
  function ue() {
    bl(() => {
      t(26, O = (performance.now() - S) / 1e3), I && ue();
    });
  }
  function he() {
    t(26, O = 0), t(0, s = t(27, q = t(19, $ = null))), I && (I = !1);
  }
  Or(() => {
    I && he();
  });
  let $ = null;
  function le(A) {
    ta[A ? "unshift" : "push"](() => {
      se = A, t(16, se), t(7, b), t(14, re), t(15, ae);
    });
  }
  const X = () => {
    l("clear_status");
  };
  function _e(A) {
    ta[A ? "unshift" : "push"](() => {
      C = A, t(13, C);
    });
  }
  return i.$$set = (A) => {
    "i18n" in A && t(1, r = A.i18n), "eta" in A && t(0, s = A.eta), "queue_position" in A && t(2, u = A.queue_position), "queue_size" in A && t(3, c = A.queue_size), "status" in A && t(4, h = A.status), "scroll_to_output" in A && t(22, d = A.scroll_to_output), "timer" in A && t(5, f = A.timer), "show_progress" in A && t(6, v = A.show_progress), "message" in A && t(23, D = A.message), "progress" in A && t(7, b = A.progress), "variant" in A && t(8, E = A.variant), "loading_text" in A && t(9, m = A.loading_text), "absolute" in A && t(10, _ = A.absolute), "translucent" in A && t(11, g = A.translucent), "border" in A && t(12, F = A.border), "autoscroll" in A && t(24, w = A.autoscroll), "$$scope" in A && t(29, o = A.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (s === null && t(0, s = q), s != null && q !== s && (t(28, H = (performance.now() - S) / 1e3 + s), t(19, $ = H.toFixed(1)), t(27, q = s))), i.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, ke = H === null || H <= 0 || !O ? null : Math.min(O / H, 1)), i.$$.dirty[0] & /*progress*/
    128 && b != null && t(18, Se = !1), i.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (b != null ? t(14, re = b.map((A) => {
      if (A.index != null && A.length != null)
        return A.index / A.length;
      if (A.progress != null)
        return A.progress;
    })) : t(14, re = null), re ? (t(15, ae = re[re.length - 1]), se && (ae === 0 ? t(16, se.style.transition = "0", se) : t(16, se.style.transition = "150ms", se))) : t(15, ae = void 0)), i.$$.dirty[0] & /*status*/
    16 && (h === "pending" ? K() : he()), i.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && C && d && (h === "pending" || h === "complete") && Jr(C, w), i.$$.dirty[0] & /*status, message*/
    8388624, i.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, n = O.toFixed(1));
  }, [
    s,
    r,
    u,
    c,
    h,
    f,
    v,
    b,
    E,
    m,
    _,
    g,
    F,
    C,
    re,
    ae,
    se,
    ke,
    Se,
    $,
    n,
    l,
    d,
    D,
    w,
    S,
    O,
    q,
    H,
    o,
    a,
    le,
    X,
    _e
  ];
}
class ts extends Rr {
  constructor(e) {
    super(), Ir(
      this,
      e,
      es,
      Xr,
      Lr,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
/*! @license DOMPurify 3.2.6 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.2.6/LICENSE */
const {
  entries: yl,
  setPrototypeOf: ga,
  isFrozen: ns,
  getPrototypeOf: is,
  getOwnPropertyDescriptor: as
} = Object;
let {
  freeze: we,
  seal: ze,
  create: Fl
} = Object, {
  apply: li,
  construct: oi
} = typeof Reflect < "u" && Reflect;
we || (we = function(e) {
  return e;
});
ze || (ze = function(e) {
  return e;
});
li || (li = function(e, t, n) {
  return e.apply(t, n);
});
oi || (oi = function(e, t) {
  return new e(...t);
});
const Dn = $e(Array.prototype.forEach), ls = $e(Array.prototype.lastIndexOf), va = $e(Array.prototype.pop), jt = $e(Array.prototype.push), os = $e(Array.prototype.splice), wn = $e(String.prototype.toLowerCase), Gn = $e(String.prototype.toString), Da = $e(String.prototype.match), Vt = $e(String.prototype.replace), rs = $e(String.prototype.indexOf), ss = $e(String.prototype.trim), Ge = $e(Object.prototype.hasOwnProperty), be = $e(RegExp.prototype.test), Wt = us(TypeError);
function $e(i) {
  return function(e) {
    e instanceof RegExp && (e.lastIndex = 0);
    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), a = 1; a < t; a++)
      n[a - 1] = arguments[a];
    return li(i, e, n);
  };
}
function us(i) {
  return function() {
    for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++)
      t[n] = arguments[n];
    return oi(i, t);
  };
}
function M(i, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : wn;
  ga && ga(i, null);
  let n = e.length;
  for (; n--; ) {
    let a = e[n];
    if (typeof a == "string") {
      const o = t(a);
      o !== a && (ns(e) || (e[n] = o), a = o);
    }
    i[a] = !0;
  }
  return i;
}
function cs(i) {
  for (let e = 0; e < i.length; e++)
    Ge(i, e) || (i[e] = null);
  return i;
}
function pt(i) {
  const e = Fl(null);
  for (const [t, n] of yl(i))
    Ge(i, t) && (Array.isArray(n) ? e[t] = cs(n) : n && typeof n == "object" && n.constructor === Object ? e[t] = pt(n) : e[t] = n);
  return e;
}
function Zt(i, e) {
  for (; i !== null; ) {
    const n = as(i, e);
    if (n) {
      if (n.get)
        return $e(n.get);
      if (typeof n.value == "function")
        return $e(n.value);
    }
    i = is(i);
  }
  function t() {
    return null;
  }
  return t;
}
const ba = we(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), jn = we(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), Vn = we(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), _s = we(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), Wn = we(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), ds = we(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), ya = we(["#text"]), Fa = we(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), Zn = we(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), wa = we(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), bn = we(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), fs = ze(/\{\{[\w\W]*|[\w\W]*\}\}/gm), ps = ze(/<%[\w\W]*|[\w\W]*%>/gm), hs = ze(/\$\{[\w\W]*/gm), ms = ze(/^data-[\-\w.\u00B7-\uFFFF]+$/), gs = ze(/^aria-[\-\w]+$/), wl = ze(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), vs = ze(/^(?:\w+script|data):/i), Ds = ze(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), $l = ze(/^html$/i), bs = ze(/^[a-z][.\w]*(-[.\w]+)+$/i);
var $a = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: gs,
  ATTR_WHITESPACE: Ds,
  CUSTOM_ELEMENT: bs,
  DATA_ATTR: ms,
  DOCTYPE_NAME: $l,
  ERB_EXPR: ps,
  IS_ALLOWED_URI: wl,
  IS_SCRIPT_OR_DATA: vs,
  MUSTACHE_EXPR: fs,
  TMPLIT_EXPR: hs
});
const Yt = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, ys = function() {
  return typeof window > "u" ? null : window;
}, Fs = function(e, t) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let n = null;
  const a = "data-tt-policy-suffix";
  t && t.hasAttribute(a) && (n = t.getAttribute(a));
  const o = "dompurify" + (n ? "#" + n : "");
  try {
    return e.createPolicy(o, {
      createHTML(l) {
        return l;
      },
      createScriptURL(l) {
        return l;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + o + " could not be created."), null;
  }
}, ka = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function kl() {
  let i = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : ys();
  const e = (B) => kl(B);
  if (e.version = "3.2.6", e.removed = [], !i || !i.document || i.document.nodeType !== Yt.document || !i.Element)
    return e.isSupported = !1, e;
  let {
    document: t
  } = i;
  const n = t, a = n.currentScript, {
    DocumentFragment: o,
    HTMLTemplateElement: l,
    Node: r,
    Element: s,
    NodeFilter: u,
    NamedNodeMap: c = i.NamedNodeMap || i.MozNamedAttrMap,
    HTMLFormElement: h,
    DOMParser: d,
    trustedTypes: f
  } = i, v = s.prototype, D = Zt(v, "cloneNode"), b = Zt(v, "remove"), E = Zt(v, "nextSibling"), m = Zt(v, "childNodes"), _ = Zt(v, "parentNode");
  if (typeof l == "function") {
    const B = t.createElement("template");
    B.content && B.content.ownerDocument && (t = B.content.ownerDocument);
  }
  let g, F = "";
  const {
    implementation: w,
    createNodeIterator: C,
    createDocumentFragment: I,
    getElementsByTagName: S
  } = t, {
    importNode: O
  } = n;
  let q = ka();
  e.isSupported = typeof yl == "function" && typeof _ == "function" && w && w.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: H,
    ERB_EXPR: ke,
    TMPLIT_EXPR: re,
    DATA_ATTR: ae,
    ARIA_ATTR: se,
    IS_SCRIPT_OR_DATA: Se,
    ATTR_WHITESPACE: K,
    CUSTOM_ELEMENT: ue
  } = $a;
  let {
    IS_ALLOWED_URI: he
  } = $a, $ = null;
  const le = M({}, [...ba, ...jn, ...Vn, ...Wn, ...ya]);
  let X = null;
  const _e = M({}, [...Fa, ...Zn, ...wa, ...bn]);
  let A = Object.seal(Fl(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), Ee = null, We = null, gt = !0, vt = !0, Dt = !1, st = !0, Ze = !1, Ye = !0, ut = !1, zt = !1, Mt = !1, y = !1, L = !1, W = !1, oe = !0, Re = !1;
  const kt = "user-content-";
  let bt = !0, Et = !1, yt = {}, Xe = null;
  const Ke = M({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let Bt = null;
  const hi = M({}, ["audio", "video", "img", "source", "image", "track"]);
  let Bn = null;
  const mi = M({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), on = "http://www.w3.org/1998/Math/MathML", rn = "http://www.w3.org/2000/svg", ct = "http://www.w3.org/1999/xhtml";
  let Rt = ct, Rn = !1, In = null;
  const Il = M({}, [on, rn, ct], Gn);
  let sn = M({}, ["mi", "mo", "mn", "ms", "mtext"]), un = M({}, ["annotation-xml"]);
  const Ll = M({}, ["title", "style", "font", "a", "script"]);
  let Pt = null;
  const xl = ["application/xhtml+xml", "text/html"], Ol = "text/html";
  let de = null, It = null;
  const ql = t.createElement("form"), gi = function(p) {
    return p instanceof RegExp || p instanceof Function;
  }, Ln = function() {
    let p = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(It && It === p)) {
      if ((!p || typeof p != "object") && (p = {}), p = pt(p), Pt = // eslint-disable-next-line unicorn/prefer-includes
      xl.indexOf(p.PARSER_MEDIA_TYPE) === -1 ? Ol : p.PARSER_MEDIA_TYPE, de = Pt === "application/xhtml+xml" ? Gn : wn, $ = Ge(p, "ALLOWED_TAGS") ? M({}, p.ALLOWED_TAGS, de) : le, X = Ge(p, "ALLOWED_ATTR") ? M({}, p.ALLOWED_ATTR, de) : _e, In = Ge(p, "ALLOWED_NAMESPACES") ? M({}, p.ALLOWED_NAMESPACES, Gn) : Il, Bn = Ge(p, "ADD_URI_SAFE_ATTR") ? M(pt(mi), p.ADD_URI_SAFE_ATTR, de) : mi, Bt = Ge(p, "ADD_DATA_URI_TAGS") ? M(pt(hi), p.ADD_DATA_URI_TAGS, de) : hi, Xe = Ge(p, "FORBID_CONTENTS") ? M({}, p.FORBID_CONTENTS, de) : Ke, Ee = Ge(p, "FORBID_TAGS") ? M({}, p.FORBID_TAGS, de) : pt({}), We = Ge(p, "FORBID_ATTR") ? M({}, p.FORBID_ATTR, de) : pt({}), yt = Ge(p, "USE_PROFILES") ? p.USE_PROFILES : !1, gt = p.ALLOW_ARIA_ATTR !== !1, vt = p.ALLOW_DATA_ATTR !== !1, Dt = p.ALLOW_UNKNOWN_PROTOCOLS || !1, st = p.ALLOW_SELF_CLOSE_IN_ATTR !== !1, Ze = p.SAFE_FOR_TEMPLATES || !1, Ye = p.SAFE_FOR_XML !== !1, ut = p.WHOLE_DOCUMENT || !1, y = p.RETURN_DOM || !1, L = p.RETURN_DOM_FRAGMENT || !1, W = p.RETURN_TRUSTED_TYPE || !1, Mt = p.FORCE_BODY || !1, oe = p.SANITIZE_DOM !== !1, Re = p.SANITIZE_NAMED_PROPS || !1, bt = p.KEEP_CONTENT !== !1, Et = p.IN_PLACE || !1, he = p.ALLOWED_URI_REGEXP || wl, Rt = p.NAMESPACE || ct, sn = p.MATHML_TEXT_INTEGRATION_POINTS || sn, un = p.HTML_INTEGRATION_POINTS || un, A = p.CUSTOM_ELEMENT_HANDLING || {}, p.CUSTOM_ELEMENT_HANDLING && gi(p.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (A.tagNameCheck = p.CUSTOM_ELEMENT_HANDLING.tagNameCheck), p.CUSTOM_ELEMENT_HANDLING && gi(p.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (A.attributeNameCheck = p.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), p.CUSTOM_ELEMENT_HANDLING && typeof p.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (A.allowCustomizedBuiltInElements = p.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), Ze && (vt = !1), L && (y = !0), yt && ($ = M({}, ya), X = [], yt.html === !0 && (M($, ba), M(X, Fa)), yt.svg === !0 && (M($, jn), M(X, Zn), M(X, bn)), yt.svgFilters === !0 && (M($, Vn), M(X, Zn), M(X, bn)), yt.mathMl === !0 && (M($, Wn), M(X, wa), M(X, bn))), p.ADD_TAGS && ($ === le && ($ = pt($)), M($, p.ADD_TAGS, de)), p.ADD_ATTR && (X === _e && (X = pt(X)), M(X, p.ADD_ATTR, de)), p.ADD_URI_SAFE_ATTR && M(Bn, p.ADD_URI_SAFE_ATTR, de), p.FORBID_CONTENTS && (Xe === Ke && (Xe = pt(Xe)), M(Xe, p.FORBID_CONTENTS, de)), bt && ($["#text"] = !0), ut && M($, ["html", "head", "body"]), $.table && (M($, ["tbody"]), delete Ee.tbody), p.TRUSTED_TYPES_POLICY) {
        if (typeof p.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw Wt('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof p.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw Wt('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        g = p.TRUSTED_TYPES_POLICY, F = g.createHTML("");
      } else
        g === void 0 && (g = Fs(f, a)), g !== null && typeof F == "string" && (F = g.createHTML(""));
      we && we(p), It = p;
    }
  }, vi = M({}, [...jn, ...Vn, ..._s]), Di = M({}, [...Wn, ...ds]), Nl = function(p) {
    let k = _(p);
    (!k || !k.tagName) && (k = {
      namespaceURI: Rt,
      tagName: "template"
    });
    const T = wn(p.tagName), ee = wn(k.tagName);
    return In[p.namespaceURI] ? p.namespaceURI === rn ? k.namespaceURI === ct ? T === "svg" : k.namespaceURI === on ? T === "svg" && (ee === "annotation-xml" || sn[ee]) : !!vi[T] : p.namespaceURI === on ? k.namespaceURI === ct ? T === "math" : k.namespaceURI === rn ? T === "math" && un[ee] : !!Di[T] : p.namespaceURI === ct ? k.namespaceURI === rn && !un[ee] || k.namespaceURI === on && !sn[ee] ? !1 : !Di[T] && (Ll[T] || !vi[T]) : !!(Pt === "application/xhtml+xml" && In[p.namespaceURI]) : !1;
  }, Qe = function(p) {
    jt(e.removed, {
      element: p
    });
    try {
      _(p).removeChild(p);
    } catch {
      b(p);
    }
  }, Lt = function(p, k) {
    try {
      jt(e.removed, {
        attribute: k.getAttributeNode(p),
        from: k
      });
    } catch {
      jt(e.removed, {
        attribute: null,
        from: k
      });
    }
    if (k.removeAttribute(p), p === "is")
      if (y || L)
        try {
          Qe(k);
        } catch {
        }
      else
        try {
          k.setAttribute(p, "");
        } catch {
        }
  }, bi = function(p) {
    let k = null, T = null;
    if (Mt)
      p = "<remove></remove>" + p;
    else {
      const ce = Da(p, /^[\r\n\t ]+/);
      T = ce && ce[0];
    }
    Pt === "application/xhtml+xml" && Rt === ct && (p = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + p + "</body></html>");
    const ee = g ? g.createHTML(p) : p;
    if (Rt === ct)
      try {
        k = new d().parseFromString(ee, Pt);
      } catch {
      }
    if (!k || !k.documentElement) {
      k = w.createDocument(Rt, "template", null);
      try {
        k.documentElement.innerHTML = Rn ? F : ee;
      } catch {
      }
    }
    const me = k.body || k.documentElement;
    return p && T && me.insertBefore(t.createTextNode(T), me.childNodes[0] || null), Rt === ct ? S.call(k, ut ? "html" : "body")[0] : ut ? k.documentElement : me;
  }, yi = function(p) {
    return C.call(
      p.ownerDocument || p,
      p,
      // eslint-disable-next-line no-bitwise
      u.SHOW_ELEMENT | u.SHOW_COMMENT | u.SHOW_TEXT | u.SHOW_PROCESSING_INSTRUCTION | u.SHOW_CDATA_SECTION,
      null
    );
  }, xn = function(p) {
    return p instanceof h && (typeof p.nodeName != "string" || typeof p.textContent != "string" || typeof p.removeChild != "function" || !(p.attributes instanceof c) || typeof p.removeAttribute != "function" || typeof p.setAttribute != "function" || typeof p.namespaceURI != "string" || typeof p.insertBefore != "function" || typeof p.hasChildNodes != "function");
  }, Fi = function(p) {
    return typeof r == "function" && p instanceof r;
  };
  function _t(B, p, k) {
    Dn(B, (T) => {
      T.call(e, p, k, It);
    });
  }
  const wi = function(p) {
    let k = null;
    if (_t(q.beforeSanitizeElements, p, null), xn(p))
      return Qe(p), !0;
    const T = de(p.nodeName);
    if (_t(q.uponSanitizeElement, p, {
      tagName: T,
      allowedTags: $
    }), Ye && p.hasChildNodes() && !Fi(p.firstElementChild) && be(/<[/\w!]/g, p.innerHTML) && be(/<[/\w!]/g, p.textContent) || p.nodeType === Yt.progressingInstruction || Ye && p.nodeType === Yt.comment && be(/<[/\w]/g, p.data))
      return Qe(p), !0;
    if (!$[T] || Ee[T]) {
      if (!Ee[T] && ki(T) && (A.tagNameCheck instanceof RegExp && be(A.tagNameCheck, T) || A.tagNameCheck instanceof Function && A.tagNameCheck(T)))
        return !1;
      if (bt && !Xe[T]) {
        const ee = _(p) || p.parentNode, me = m(p) || p.childNodes;
        if (me && ee) {
          const ce = me.length;
          for (let Ae = ce - 1; Ae >= 0; --Ae) {
            const dt = D(me[Ae], !0);
            dt.__removalCount = (p.__removalCount || 0) + 1, ee.insertBefore(dt, E(p));
          }
        }
      }
      return Qe(p), !0;
    }
    return p instanceof s && !Nl(p) || (T === "noscript" || T === "noembed" || T === "noframes") && be(/<\/no(script|embed|frames)/i, p.innerHTML) ? (Qe(p), !0) : (Ze && p.nodeType === Yt.text && (k = p.textContent, Dn([H, ke, re], (ee) => {
      k = Vt(k, ee, " ");
    }), p.textContent !== k && (jt(e.removed, {
      element: p.cloneNode()
    }), p.textContent = k)), _t(q.afterSanitizeElements, p, null), !1);
  }, $i = function(p, k, T) {
    if (oe && (k === "id" || k === "name") && (T in t || T in ql))
      return !1;
    if (!(vt && !We[k] && be(ae, k))) {
      if (!(gt && be(se, k))) {
        if (!X[k] || We[k]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(ki(p) && (A.tagNameCheck instanceof RegExp && be(A.tagNameCheck, p) || A.tagNameCheck instanceof Function && A.tagNameCheck(p)) && (A.attributeNameCheck instanceof RegExp && be(A.attributeNameCheck, k) || A.attributeNameCheck instanceof Function && A.attributeNameCheck(k)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            k === "is" && A.allowCustomizedBuiltInElements && (A.tagNameCheck instanceof RegExp && be(A.tagNameCheck, T) || A.tagNameCheck instanceof Function && A.tagNameCheck(T)))
          ) return !1;
        } else if (!Bn[k]) {
          if (!be(he, Vt(T, K, ""))) {
            if (!((k === "src" || k === "xlink:href" || k === "href") && p !== "script" && rs(T, "data:") === 0 && Bt[p])) {
              if (!(Dt && !be(Se, Vt(T, K, "")))) {
                if (T)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, ki = function(p) {
    return p !== "annotation-xml" && Da(p, ue);
  }, Ei = function(p) {
    _t(q.beforeSanitizeAttributes, p, null);
    const {
      attributes: k
    } = p;
    if (!k || xn(p))
      return;
    const T = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: X,
      forceKeepAttr: void 0
    };
    let ee = k.length;
    for (; ee--; ) {
      const me = k[ee], {
        name: ce,
        namespaceURI: Ae,
        value: dt
      } = me, Ut = de(ce), On = dt;
      let ge = ce === "value" ? On : ss(On);
      if (T.attrName = Ut, T.attrValue = ge, T.keepAttr = !0, T.forceKeepAttr = void 0, _t(q.uponSanitizeAttribute, p, T), ge = T.attrValue, Re && (Ut === "id" || Ut === "name") && (Lt(ce, p), ge = kt + ge), Ye && be(/((--!?|])>)|<\/(style|title)/i, ge)) {
        Lt(ce, p);
        continue;
      }
      if (T.forceKeepAttr)
        continue;
      if (!T.keepAttr) {
        Lt(ce, p);
        continue;
      }
      if (!st && be(/\/>/i, ge)) {
        Lt(ce, p);
        continue;
      }
      Ze && Dn([H, ke, re], (Ci) => {
        ge = Vt(ge, Ci, " ");
      });
      const Ai = de(p.nodeName);
      if (!$i(Ai, Ut, ge)) {
        Lt(ce, p);
        continue;
      }
      if (g && typeof f == "object" && typeof f.getAttributeType == "function" && !Ae)
        switch (f.getAttributeType(Ai, Ut)) {
          case "TrustedHTML": {
            ge = g.createHTML(ge);
            break;
          }
          case "TrustedScriptURL": {
            ge = g.createScriptURL(ge);
            break;
          }
        }
      if (ge !== On)
        try {
          Ae ? p.setAttributeNS(Ae, ce, ge) : p.setAttribute(ce, ge), xn(p) ? Qe(p) : va(e.removed);
        } catch {
          Lt(ce, p);
        }
    }
    _t(q.afterSanitizeAttributes, p, null);
  }, zl = function B(p) {
    let k = null;
    const T = yi(p);
    for (_t(q.beforeSanitizeShadowDOM, p, null); k = T.nextNode(); )
      _t(q.uponSanitizeShadowNode, k, null), wi(k), Ei(k), k.content instanceof o && B(k.content);
    _t(q.afterSanitizeShadowDOM, p, null);
  };
  return e.sanitize = function(B) {
    let p = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, k = null, T = null, ee = null, me = null;
    if (Rn = !B, Rn && (B = "<!-->"), typeof B != "string" && !Fi(B))
      if (typeof B.toString == "function") {
        if (B = B.toString(), typeof B != "string")
          throw Wt("dirty is not a string, aborting");
      } else
        throw Wt("toString is not a function");
    if (!e.isSupported)
      return B;
    if (zt || Ln(p), e.removed = [], typeof B == "string" && (Et = !1), Et) {
      if (B.nodeName) {
        const dt = de(B.nodeName);
        if (!$[dt] || Ee[dt])
          throw Wt("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (B instanceof r)
      k = bi("<!---->"), T = k.ownerDocument.importNode(B, !0), T.nodeType === Yt.element && T.nodeName === "BODY" || T.nodeName === "HTML" ? k = T : k.appendChild(T);
    else {
      if (!y && !Ze && !ut && // eslint-disable-next-line unicorn/prefer-includes
      B.indexOf("<") === -1)
        return g && W ? g.createHTML(B) : B;
      if (k = bi(B), !k)
        return y ? null : W ? F : "";
    }
    k && Mt && Qe(k.firstChild);
    const ce = yi(Et ? B : k);
    for (; ee = ce.nextNode(); )
      wi(ee), Ei(ee), ee.content instanceof o && zl(ee.content);
    if (Et)
      return B;
    if (y) {
      if (L)
        for (me = I.call(k.ownerDocument); k.firstChild; )
          me.appendChild(k.firstChild);
      else
        me = k;
      return (X.shadowroot || X.shadowrootmode) && (me = O.call(n, me, !0)), me;
    }
    let Ae = ut ? k.outerHTML : k.innerHTML;
    return ut && $["!doctype"] && k.ownerDocument && k.ownerDocument.doctype && k.ownerDocument.doctype.name && be($l, k.ownerDocument.doctype.name) && (Ae = "<!DOCTYPE " + k.ownerDocument.doctype.name + `>
` + Ae), Ze && Dn([H, ke, re], (dt) => {
      Ae = Vt(Ae, dt, " ");
    }), g && W ? g.createHTML(Ae) : Ae;
  }, e.setConfig = function() {
    let B = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    Ln(B), zt = !0;
  }, e.clearConfig = function() {
    It = null, zt = !1;
  }, e.isValidAttribute = function(B, p, k) {
    It || Ln({});
    const T = de(B), ee = de(p);
    return $i(T, ee, k);
  }, e.addHook = function(B, p) {
    typeof p == "function" && jt(q[B], p);
  }, e.removeHook = function(B, p) {
    if (p !== void 0) {
      const k = ls(q[B], p);
      return k === -1 ? void 0 : os(q[B], k, 1)[0];
    }
    return va(q[B]);
  }, e.removeHooks = function(B) {
    q[B] = [];
  }, e.removeAllHooks = function() {
    q = ka();
  }, e;
}
kl();
const {
  HtmlTagHydration: Wk,
  SvelteComponent: Zk,
  add_render_callback: Yk,
  append_hydration: Xk,
  attr: Kk,
  bubble: Qk,
  check_outros: Jk,
  children: eE,
  claim_component: tE,
  claim_element: nE,
  claim_html_tag: iE,
  claim_space: aE,
  claim_text: lE,
  create_component: oE,
  create_in_transition: rE,
  create_out_transition: sE,
  destroy_component: uE,
  detach: cE,
  element: _E,
  get_svelte_dataset: dE,
  group_outros: fE,
  init: pE,
  insert_hydration: hE,
  listen: mE,
  mount_component: gE,
  run_all: vE,
  safe_not_equal: DE,
  set_data: bE,
  space: yE,
  stop_propagation: FE,
  text: wE,
  toggle_class: $E,
  transition_in: kE,
  transition_out: EE
} = window.__gradio__svelte__internal, { createEventDispatcher: AE, onMount: CE } = window.__gradio__svelte__internal, {
  SvelteComponent: SE,
  append_hydration: TE,
  attr: BE,
  bubble: RE,
  check_outros: IE,
  children: LE,
  claim_component: xE,
  claim_element: OE,
  claim_space: qE,
  create_animation: NE,
  create_component: zE,
  destroy_component: ME,
  detach: PE,
  element: UE,
  ensure_array_like: HE,
  fix_and_outro_and_destroy_block: GE,
  fix_position: jE,
  group_outros: VE,
  init: WE,
  insert_hydration: ZE,
  mount_component: YE,
  noop: XE,
  safe_not_equal: KE,
  set_style: QE,
  space: JE,
  transition_in: eA,
  transition_out: tA,
  update_keyed_each: nA
} = window.__gradio__svelte__internal, {
  SvelteComponent: iA,
  attr: aA,
  children: lA,
  claim_element: oA,
  detach: rA,
  element: sA,
  empty: uA,
  init: cA,
  insert_hydration: _A,
  noop: dA,
  safe_not_equal: fA,
  set_style: pA
} = window.__gradio__svelte__internal, {
  SvelteComponent: ws,
  append_hydration: U,
  assign: $s,
  attr: N,
  binding_callbacks: ks,
  check_outros: Es,
  children: ie,
  claim_component: El,
  claim_element: G,
  claim_space: ye,
  claim_text: ht,
  create_component: Al,
  destroy_block: Cl,
  destroy_component: Sl,
  destroy_each: As,
  detach: x,
  element: j,
  empty: wt,
  ensure_array_like: Nt,
  get_spread_object: Cs,
  get_spread_update: Ss,
  get_svelte_dataset: Tl,
  group_outros: Ts,
  init: Bs,
  insert_hydration: J,
  listen: pe,
  mount_component: Bl,
  run_all: ln,
  safe_not_equal: Rs,
  select_option: Ea,
  set_data: $t,
  set_input_value: rt,
  set_style: Cn,
  space: Fe,
  stop_propagation: Is,
  text: mt,
  to_number: ri,
  toggle_class: Ce,
  transition_in: en,
  transition_out: Sn,
  update_keyed_each: Rl
} = window.__gradio__svelte__internal, { onMount: Ls, tick: xs } = window.__gradio__svelte__internal;
function Aa(i, e, t) {
  const n = i.slice();
  return n[51] = e[t], n;
}
function Ca(i, e, t) {
  const n = i.slice();
  n[54] = e[t], n[56] = e, n[57] = t;
  const a = (
    /*interactive*/
    n[11] && /*prop*/
    (n[54].interactive_if ? (
      /*get_prop_value*/
      n[21](
        /*prop*/
        n[54].interactive_if.field
      ) === /*prop*/
      n[54].interactive_if.value
    ) : !0)
  );
  return n[55] = a, n;
}
function Sa(i, e, t) {
  const n = i.slice();
  return n[58] = e[t], n;
}
function Ta(i) {
  let e, t;
  const n = [
    {
      autoscroll: (
        /*gradio*/
        i[12].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      i[12].i18n
    ) },
    /*loading_status*/
    i[10]
  ];
  let a = {};
  for (let o = 0; o < n.length; o += 1)
    a = $s(a, n[o]);
  return e = new ts({ props: a }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    i[28]
  ), {
    c() {
      Al(e.$$.fragment);
    },
    l(o) {
      El(e.$$.fragment, o);
    },
    m(o, l) {
      Bl(e, o, l), t = !0;
    },
    p(o, l) {
      const r = l[0] & /*gradio, loading_status*/
      5120 ? Ss(n, [
        l[0] & /*gradio*/
        4096 && {
          autoscroll: (
            /*gradio*/
            o[12].autoscroll
          )
        },
        l[0] & /*gradio*/
        4096 && { i18n: (
          /*gradio*/
          o[12].i18n
        ) },
        l[0] & /*loading_status*/
        1024 && Cs(
          /*loading_status*/
          o[10]
        )
      ]) : {};
      e.$set(r);
    },
    i(o) {
      t || (en(e.$$.fragment, o), t = !0);
    },
    o(o) {
      Sn(e.$$.fragment, o), t = !1;
    },
    d(o) {
      Sl(e, o);
    }
  };
}
function Ba(i) {
  let e, t;
  return {
    c() {
      e = j("span"), t = mt(
        /*label*/
        i[2]
      ), this.h();
    },
    l(n) {
      e = G(n, "SPAN", { class: !0 });
      var a = ie(e);
      t = ht(
        a,
        /*label*/
        i[2]
      ), a.forEach(x), this.h();
    },
    h() {
      N(e, "class", "label");
    },
    m(n, a) {
      J(n, e, a), U(e, t);
    },
    p(n, a) {
      a[0] & /*label*/
      4 && $t(
        t,
        /*label*/
        n[2]
      );
    },
    d(n) {
      n && x(e);
    }
  };
}
function Ra(i) {
  let e, t = Array.isArray(
    /*value*/
    i[0]
  ), n = t && Ia(i);
  return {
    c() {
      e = j("div"), n && n.c(), this.h();
    },
    l(a) {
      e = G(a, "DIV", { class: !0, style: !0 });
      var o = ie(e);
      n && n.l(o), o.forEach(x), this.h();
    },
    h() {
      N(e, "class", "container svelte-1nz1lmm"), Cn(
        e,
        "--sheet-max-height",
        /*height*/
        i[9] ? `${/*height*/
        i[9]}px` : "none"
      );
    },
    m(a, o) {
      J(a, e, o), n && n.m(e, null);
    },
    p(a, o) {
      o[0] & /*value*/
      1 && (t = Array.isArray(
        /*value*/
        a[0]
      )), t ? n ? n.p(a, o) : (n = Ia(a), n.c(), n.m(e, null)) : n && (n.d(1), n = null), o[0] & /*height*/
      512 && Cn(
        e,
        "--sheet-max-height",
        /*height*/
        a[9] ? `${/*height*/
        a[9]}px` : "none"
      );
    },
    d(a) {
      a && x(e), n && n.d();
    }
  };
}
function Ia(i) {
  let e = [], t = /* @__PURE__ */ new Map(), n, a = Nt(
    /*value*/
    i[0]
  );
  const o = (l) => (
    /*group*/
    l[51].group_name
  );
  for (let l = 0; l < a.length; l += 1) {
    let r = Aa(i, a, l), s = o(r);
    t.set(s, e[l] = Pa(s, r));
  }
  return {
    c() {
      for (let l = 0; l < e.length; l += 1)
        e[l].c();
      n = wt();
    },
    l(l) {
      for (let r = 0; r < e.length; r += 1)
        e[r].l(l);
      n = wt();
    },
    m(l, r) {
      for (let s = 0; s < e.length; s += 1)
        e[s] && e[s].m(l, r);
      J(l, n, r);
    },
    p(l, r) {
      r[0] & /*value, interactive, get_prop_value, initialValues, handle_reset_prop, dispatch_update, validationState, validate_prop, sliderElements, handle_dropdown_change, groupVisibility, toggleGroup*/
      32892929 && (a = Nt(
        /*value*/
        l[0]
      ), e = Rl(e, r, o, 1, l, a, t, n.parentNode, Cl, Pa, n, Aa));
    },
    d(l) {
      l && x(n);
      for (let r = 0; r < e.length; r += 1)
        e[r].d(l);
    }
  };
}
function La(i) {
  let e, t = Array.isArray(
    /*group*/
    i[51].properties
  ), n, a = t && xa(i);
  return {
    c() {
      e = j("div"), a && a.c(), n = Fe(), this.h();
    },
    l(o) {
      e = G(o, "DIV", { class: !0 });
      var l = ie(e);
      a && a.l(l), n = ye(l), l.forEach(x), this.h();
    },
    h() {
      N(e, "class", "properties-grid svelte-1nz1lmm");
    },
    m(o, l) {
      J(o, e, l), a && a.m(e, null), U(e, n);
    },
    p(o, l) {
      l[0] & /*value*/
      1 && (t = Array.isArray(
        /*group*/
        o[51].properties
      )), t ? a ? a.p(o, l) : (a = xa(o), a.c(), a.m(e, n)) : a && (a.d(1), a = null);
    },
    d(o) {
      o && x(e), a && a.d();
    }
  };
}
function xa(i) {
  let e = [], t = /* @__PURE__ */ new Map(), n, a = Nt(
    /*group*/
    i[51].properties
  );
  const o = (l) => (
    /*prop*/
    l[54].name
  );
  for (let l = 0; l < a.length; l += 1) {
    let r = Ca(i, a, l), s = o(r);
    t.set(s, e[l] = Ma(s, r));
  }
  return {
    c() {
      for (let l = 0; l < e.length; l += 1)
        e[l].c();
      n = wt();
    },
    l(l) {
      for (let r = 0; r < e.length; r += 1)
        e[r].l(l);
      n = wt();
    },
    m(l, r) {
      for (let s = 0; s < e.length; s += 1)
        e[s] && e[s].m(l, r);
      J(l, n, r);
    },
    p(l, r) {
      r[0] & /*interactive, value, get_prop_value, initialValues, handle_reset_prop, dispatch_update, validationState, validate_prop, sliderElements, handle_dropdown_change*/
      31836161 && (a = Nt(
        /*group*/
        l[51].properties
      ), e = Rl(e, r, o, 1, l, a, t, n.parentNode, Cl, Ma, n, Ca));
    },
    d(l) {
      l && x(n);
      for (let r = 0; r < e.length; r += 1)
        e[r].d(l);
    }
  };
}
function Oa(i) {
  let e, t, n = "?", a, o, l = (
    /*prop*/
    i[54].help + ""
  ), r;
  return {
    c() {
      e = j("div"), t = j("span"), t.textContent = n, a = Fe(), o = j("span"), r = mt(l), this.h();
    },
    l(s) {
      e = G(s, "DIV", { class: !0 });
      var u = ie(e);
      t = G(u, "SPAN", { class: !0, "data-svelte-h": !0 }), Tl(t) !== "svelte-fzek5l" && (t.textContent = n), a = ye(u), o = G(u, "SPAN", { class: !0 });
      var c = ie(o);
      r = ht(c, l), c.forEach(x), u.forEach(x), this.h();
    },
    h() {
      N(t, "class", "tooltip-icon svelte-1nz1lmm"), N(o, "class", "tooltip-text svelte-1nz1lmm"), N(e, "class", "tooltip-container svelte-1nz1lmm");
    },
    m(s, u) {
      J(s, e, u), U(e, t), U(e, a), U(e, o), U(o, r);
    },
    p(s, u) {
      u[0] & /*value*/
      1 && l !== (l = /*prop*/
      s[54].help + "") && $t(r, l);
    },
    d(s) {
      s && x(e);
    }
  };
}
function Os(i) {
  let e, t, n = Array.isArray(
    /*prop*/
    i[54].choices
  ), a, o, l, r, s, u, c = n && qa(i);
  function h(...d) {
    return (
      /*change_handler_5*/
      i[44](
        /*prop*/
        i[54],
        ...d
      )
    );
  }
  return {
    c() {
      e = j("div"), t = j("select"), c && c.c(), l = Fe(), r = j("div"), this.h();
    },
    l(d) {
      e = G(d, "DIV", { class: !0 });
      var f = ie(e);
      t = G(f, "SELECT", { class: !0 });
      var v = ie(t);
      c && c.l(v), v.forEach(x), l = ye(f), r = G(f, "DIV", { class: !0 }), ie(r).forEach(x), f.forEach(x), this.h();
    },
    h() {
      t.disabled = a = !/*is_interactive*/
      i[55], N(t, "class", "svelte-1nz1lmm"), N(r, "class", "dropdown-arrow-icon svelte-1nz1lmm"), N(e, "class", "dropdown-wrapper svelte-1nz1lmm"), Ce(e, "disabled", !/*is_interactive*/
      i[55]);
    },
    m(d, f) {
      J(d, e, f), U(e, t), c && c.m(t, null), Ea(
        t,
        /*prop*/
        i[54].value
      ), U(e, l), U(e, r), s || (u = pe(t, "change", h), s = !0);
    },
    p(d, f) {
      i = d, f[0] & /*value*/
      1 && (n = Array.isArray(
        /*prop*/
        i[54].choices
      )), n ? c ? c.p(i, f) : (c = qa(i), c.c(), c.m(t, null)) : c && (c.d(1), c = null), f[0] & /*interactive, value*/
      2049 && a !== (a = !/*is_interactive*/
      i[55]) && (t.disabled = a), f[0] & /*value*/
      1 && o !== (o = /*prop*/
      i[54].value) && Ea(
        t,
        /*prop*/
        i[54].value
      ), f[0] & /*interactive, value, get_prop_value*/
      2099201 && Ce(e, "disabled", !/*is_interactive*/
      i[55]);
    },
    d(d) {
      d && x(e), c && c.d(), s = !1, u();
    }
  };
}
function qs(i) {
  let e, t, n, a, o, l = (
    /*prop*/
    i[54].value + ""
  ), r, s, u;
  function c() {
    i[42].call(
      t,
      /*each_value_1*/
      i[56],
      /*prop_index*/
      i[57]
    );
  }
  function h() {
    return (
      /*change_handler_4*/
      i[43](
        /*prop*/
        i[54]
      )
    );
  }
  return {
    c() {
      e = j("div"), t = j("input"), a = Fe(), o = j("span"), r = mt(l), this.h();
    },
    l(d) {
      e = G(d, "DIV", { class: !0 });
      var f = ie(e);
      t = G(f, "INPUT", { type: !0, class: !0 }), a = ye(f), o = G(f, "SPAN", { class: !0 });
      var v = ie(o);
      r = ht(v, l), v.forEach(x), f.forEach(x), this.h();
    },
    h() {
      N(t, "type", "color"), N(t, "class", "color-picker-input svelte-1nz1lmm"), t.disabled = n = !/*is_interactive*/
      i[55], N(o, "class", "color-picker-value svelte-1nz1lmm"), N(e, "class", "color-picker-container svelte-1nz1lmm"), Ce(e, "disabled", !/*is_interactive*/
      i[55]);
    },
    m(d, f) {
      J(d, e, f), U(e, t), rt(
        t,
        /*prop*/
        i[54].value
      ), U(e, a), U(e, o), U(o, r), s || (u = [
        pe(t, "input", c),
        pe(t, "change", h)
      ], s = !0);
    },
    p(d, f) {
      i = d, f[0] & /*interactive, value*/
      2049 && n !== (n = !/*is_interactive*/
      i[55]) && (t.disabled = n), f[0] & /*value*/
      1 && rt(
        t,
        /*prop*/
        i[54].value
      ), f[0] & /*value*/
      1 && l !== (l = /*prop*/
      i[54].value + "") && $t(r, l), f[0] & /*interactive, value, get_prop_value*/
      2099201 && Ce(e, "disabled", !/*is_interactive*/
      i[55]);
    },
    d(d) {
      d && x(e), s = !1, ln(u);
    }
  };
}
function Ns(i) {
  let e, t, n, a, o, l, r = (
    /*prop*/
    i[54]
  ), s, u, c = (
    /*prop*/
    i[54].value + ""
  ), h, d, f;
  function v() {
    i[38].call(
      t,
      /*each_value_1*/
      i[56],
      /*prop_index*/
      i[57]
    );
  }
  const D = () => (
    /*input_binding*/
    i[39](t, r)
  ), b = () => (
    /*input_binding*/
    i[39](null, r)
  );
  function E() {
    return (
      /*input_handler_2*/
      i[40](
        /*prop*/
        i[54]
      )
    );
  }
  function m() {
    return (
      /*change_handler_3*/
      i[41](
        /*prop*/
        i[54]
      )
    );
  }
  return {
    c() {
      e = j("div"), t = j("input"), s = Fe(), u = j("span"), h = mt(c), this.h();
    },
    l(_) {
      e = G(_, "DIV", { class: !0 });
      var g = ie(e);
      t = G(g, "INPUT", {
        type: !0,
        min: !0,
        max: !0,
        step: !0,
        class: !0
      }), s = ye(g), u = G(g, "SPAN", { class: !0 });
      var F = ie(u);
      h = ht(F, c), F.forEach(x), g.forEach(x), this.h();
    },
    h() {
      N(t, "type", "range"), N(t, "min", n = /*prop*/
      i[54].minimum), N(t, "max", a = /*prop*/
      i[54].maximum), N(t, "step", o = /*prop*/
      i[54].step || 1), t.disabled = l = !/*is_interactive*/
      i[55], N(t, "class", "svelte-1nz1lmm"), N(u, "class", "slider-value svelte-1nz1lmm"), N(e, "class", "slider-container svelte-1nz1lmm"), Ce(e, "disabled", !/*is_interactive*/
      i[55]);
    },
    m(_, g) {
      J(_, e, g), U(e, t), rt(
        t,
        /*prop*/
        i[54].value
      ), D(), U(e, s), U(e, u), U(u, h), d || (f = [
        pe(t, "change", v),
        pe(t, "input", v),
        pe(t, "input", E),
        pe(t, "change", m)
      ], d = !0);
    },
    p(_, g) {
      i = _, g[0] & /*value*/
      1 && n !== (n = /*prop*/
      i[54].minimum) && N(t, "min", n), g[0] & /*value*/
      1 && a !== (a = /*prop*/
      i[54].maximum) && N(t, "max", a), g[0] & /*value*/
      1 && o !== (o = /*prop*/
      i[54].step || 1) && N(t, "step", o), g[0] & /*interactive, value*/
      2049 && l !== (l = !/*is_interactive*/
      i[55]) && (t.disabled = l), g[0] & /*value*/
      1 && rt(
        t,
        /*prop*/
        i[54].value
      ), r !== /*prop*/
      i[54] && (b(), r = /*prop*/
      i[54], D()), g[0] & /*value*/
      1 && c !== (c = /*prop*/
      i[54].value + "") && $t(h, c), g[0] & /*interactive, value, get_prop_value*/
      2099201 && Ce(e, "disabled", !/*is_interactive*/
      i[55]);
    },
    d(_) {
      _ && x(e), b(), d = !1, ln(f);
    }
  };
}
function zs(i) {
  let e, t, n, a, o;
  function l() {
    i[35].call(
      e,
      /*each_value_1*/
      i[56],
      /*prop_index*/
      i[57]
    );
  }
  function r() {
    return (
      /*change_handler_2*/
      i[36](
        /*prop*/
        i[54]
      )
    );
  }
  function s() {
    return (
      /*input_handler_1*/
      i[37](
        /*prop*/
        i[54]
      )
    );
  }
  return {
    c() {
      e = j("input"), this.h();
    },
    l(u) {
      e = G(u, "INPUT", { type: !0, step: !0, class: !0 }), this.h();
    },
    h() {
      N(e, "type", "number"), N(e, "step", t = /*prop*/
      i[54].step || 1), e.disabled = n = !/*is_interactive*/
      i[55], N(e, "class", "svelte-1nz1lmm"), Ce(
        e,
        "invalid",
        /*validationState*/
        i[15][
          /*prop*/
          i[54].name
        ] === !1
      ), Ce(e, "disabled", !/*is_interactive*/
      i[55]);
    },
    m(u, c) {
      J(u, e, c), rt(
        e,
        /*prop*/
        i[54].value
      ), a || (o = [
        pe(e, "input", l),
        pe(e, "change", r),
        pe(e, "input", s)
      ], a = !0);
    },
    p(u, c) {
      i = u, c[0] & /*value*/
      1 && t !== (t = /*prop*/
      i[54].step || 1) && N(e, "step", t), c[0] & /*interactive, value*/
      2049 && n !== (n = !/*is_interactive*/
      i[55]) && (e.disabled = n), c[0] & /*value*/
      1 && ri(e.value) !== /*prop*/
      i[54].value && rt(
        e,
        /*prop*/
        i[54].value
      ), c[0] & /*validationState, value*/
      32769 && Ce(
        e,
        "invalid",
        /*validationState*/
        i[15][
          /*prop*/
          i[54].name
        ] === !1
      ), c[0] & /*interactive, value, get_prop_value*/
      2099201 && Ce(e, "disabled", !/*is_interactive*/
      i[55]);
    },
    d(u) {
      u && x(e), a = !1, ln(o);
    }
  };
}
function Ms(i) {
  let e, t, n, a;
  function o() {
    i[33].call(
      e,
      /*each_value_1*/
      i[56],
      /*prop_index*/
      i[57]
    );
  }
  function l() {
    return (
      /*change_handler_1*/
      i[34](
        /*prop*/
        i[54]
      )
    );
  }
  return {
    c() {
      e = j("input"), this.h();
    },
    l(r) {
      e = G(r, "INPUT", { type: !0, class: !0 }), this.h();
    },
    h() {
      N(e, "type", "checkbox"), e.disabled = t = !/*is_interactive*/
      i[55], N(e, "class", "svelte-1nz1lmm");
    },
    m(r, s) {
      J(r, e, s), e.checked = /*prop*/
      i[54].value, n || (a = [
        pe(e, "change", o),
        pe(e, "change", l)
      ], n = !0);
    },
    p(r, s) {
      i = r, s[0] & /*interactive, value*/
      2049 && t !== (t = !/*is_interactive*/
      i[55]) && (e.disabled = t), s[0] & /*value*/
      1 && (e.checked = /*prop*/
      i[54].value);
    },
    d(r) {
      r && x(e), n = !1, ln(a);
    }
  };
}
function Ps(i) {
  let e, t, n, a;
  function o() {
    i[30].call(
      e,
      /*each_value_1*/
      i[56],
      /*prop_index*/
      i[57]
    );
  }
  function l() {
    return (
      /*change_handler*/
      i[31](
        /*prop*/
        i[54]
      )
    );
  }
  function r() {
    return (
      /*input_handler*/
      i[32](
        /*prop*/
        i[54]
      )
    );
  }
  return {
    c() {
      e = j("input"), this.h();
    },
    l(s) {
      e = G(s, "INPUT", { type: !0, class: !0 }), this.h();
    },
    h() {
      N(e, "type", "text"), e.disabled = t = !/*is_interactive*/
      i[55], N(e, "class", "svelte-1nz1lmm");
    },
    m(s, u) {
      J(s, e, u), rt(
        e,
        /*prop*/
        i[54].value
      ), n || (a = [
        pe(e, "input", o),
        pe(e, "change", l),
        pe(e, "input", r)
      ], n = !0);
    },
    p(s, u) {
      i = s, u[0] & /*interactive, value*/
      2049 && t !== (t = !/*is_interactive*/
      i[55]) && (e.disabled = t), u[0] & /*value*/
      1 && e.value !== /*prop*/
      i[54].value && rt(
        e,
        /*prop*/
        i[54].value
      );
    },
    d(s) {
      s && x(e), n = !1, ln(a);
    }
  };
}
function qa(i) {
  let e, t = Nt(
    /*prop*/
    i[54].choices
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = Na(Sa(i, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = wt();
    },
    l(a) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(a);
      e = wt();
    },
    m(a, o) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, o);
      J(a, e, o);
    },
    p(a, o) {
      if (o[0] & /*value*/
      1) {
        t = Nt(
          /*prop*/
          a[54].choices
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const r = Sa(a, t, l);
          n[l] ? n[l].p(r, o) : (n[l] = Na(r), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && x(e), As(n, a);
    }
  };
}
function Na(i) {
  let e, t = (
    /*choice*/
    i[58] + ""
  ), n, a, o, l;
  return {
    c() {
      e = j("option"), n = mt(t), a = Fe(), this.h();
    },
    l(r) {
      e = G(r, "OPTION", { class: !0 });
      var s = ie(e);
      n = ht(s, t), a = ye(s), s.forEach(x), this.h();
    },
    h() {
      e.__value = o = /*choice*/
      i[58], rt(e, e.__value), e.selected = l = /*prop*/
      i[54].value === /*choice*/
      i[58], N(e, "class", "svelte-1nz1lmm");
    },
    m(r, s) {
      J(r, e, s), U(e, n), U(e, a);
    },
    p(r, s) {
      s[0] & /*value*/
      1 && t !== (t = /*choice*/
      r[58] + "") && $t(n, t), s[0] & /*value*/
      1 && o !== (o = /*choice*/
      r[58]) && (e.__value = o, rt(e, e.__value)), s[0] & /*value*/
      1 && l !== (l = /*prop*/
      r[54].value === /*choice*/
      r[58]) && (e.selected = l);
    },
    d(r) {
      r && x(e);
    }
  };
}
function za(i) {
  let e, t, n, a, o;
  function l() {
    return (
      /*click_handler_1*/
      i[45](
        /*prop*/
        i[54]
      )
    );
  }
  return {
    c() {
      e = j("button"), t = mt("↺"), this.h();
    },
    l(r) {
      e = G(r, "BUTTON", { class: !0, title: !0 });
      var s = ie(e);
      t = ht(s, "↺"), s.forEach(x), this.h();
    },
    h() {
      N(e, "class", "reset-button-prop svelte-1nz1lmm"), N(e, "title", "Reset to default"), e.disabled = n = !/*is_interactive*/
      i[55], Ce(
        e,
        "visible",
        /*initialValues*/
        i[16][
          /*prop*/
          i[54].name
        ] !== /*prop*/
        i[54].value
      );
    },
    m(r, s) {
      J(r, e, s), U(e, t), a || (o = pe(e, "click", Is(l)), a = !0);
    },
    p(r, s) {
      i = r, s[0] & /*interactive, value*/
      2049 && n !== (n = !/*is_interactive*/
      i[55]) && (e.disabled = n), s[0] & /*initialValues, value*/
      65537 && Ce(
        e,
        "visible",
        /*initialValues*/
        i[16][
          /*prop*/
          i[54].name
        ] !== /*prop*/
        i[54].value
      );
    },
    d(r) {
      r && x(e), a = !1, o();
    }
  };
}
function Ma(i, e) {
  let t, n, a, o = (
    /*prop*/
    e[54].label + ""
  ), l, r, s, u, c, h, d, f = (
    /*prop*/
    e[54].help && Oa(e)
  );
  function v(m, _) {
    if (
      /*prop*/
      m[54].component === "string"
    ) return Ps;
    if (
      /*prop*/
      m[54].component === "checkbox"
    ) return Ms;
    if (
      /*prop*/
      m[54].component === "number_integer" || /*prop*/
      m[54].component === "number_float"
    ) return zs;
    if (
      /*prop*/
      m[54].component === "slider"
    ) return Ns;
    if (
      /*prop*/
      m[54].component === "colorpicker"
    ) return qs;
    if (
      /*prop*/
      m[54].component === "dropdown"
    ) return Os;
  }
  let D = v(e), b = D && D(e), E = (
    /*prop*/
    e[54].component !== "checkbox" && za(e)
  );
  return {
    key: i,
    first: null,
    c() {
      t = j("label"), n = j("div"), a = j("span"), l = mt(o), r = Fe(), f && f.c(), u = Fe(), c = j("div"), b && b.c(), h = Fe(), E && E.c(), d = Fe(), this.h();
    },
    l(m) {
      t = G(m, "LABEL", { class: !0, for: !0 });
      var _ = ie(t);
      n = G(_, "DIV", { class: !0 });
      var g = ie(n);
      a = G(g, "SPAN", {});
      var F = ie(a);
      l = ht(F, o), F.forEach(x), r = ye(g), f && f.l(g), g.forEach(x), _.forEach(x), u = ye(m), c = G(m, "DIV", { class: !0 });
      var w = ie(c);
      b && b.l(w), h = ye(w), E && E.l(w), d = ye(w), w.forEach(x), this.h();
    },
    h() {
      N(n, "class", "prop-label-wrapper svelte-1nz1lmm"), N(t, "class", "prop-label svelte-1nz1lmm"), N(t, "for", s = /*prop*/
      e[54].name), N(c, "class", "prop-control svelte-1nz1lmm"), this.first = t;
    },
    m(m, _) {
      J(m, t, _), U(t, n), U(n, a), U(a, l), U(n, r), f && f.m(n, null), J(m, u, _), J(m, c, _), b && b.m(c, null), U(c, h), E && E.m(c, null), U(c, d);
    },
    p(m, _) {
      e = m, _[0] & /*value*/
      1 && o !== (o = /*prop*/
      e[54].label + "") && $t(l, o), /*prop*/
      e[54].help ? f ? f.p(e, _) : (f = Oa(e), f.c(), f.m(n, null)) : f && (f.d(1), f = null), _[0] & /*value*/
      1 && s !== (s = /*prop*/
      e[54].name) && N(t, "for", s), D === (D = v(e)) && b ? b.p(e, _) : (b && b.d(1), b = D && D(e), b && (b.c(), b.m(c, h))), /*prop*/
      e[54].component !== "checkbox" ? E ? E.p(e, _) : (E = za(e), E.c(), E.m(c, d)) : E && (E.d(1), E = null);
    },
    d(m) {
      m && (x(t), x(u), x(c)), f && f.d(), b && b.d(), E && E.d();
    }
  };
}
function Pa(i, e) {
  let t, n, a = (
    /*group*/
    e[51].group_name + ""
  ), o, l, r, s = (
    /*groupVisibility*/
    e[13][
      /*group*/
      e[51].group_name
    ] ? "−" : "+"
  ), u, c, h, d, f;
  function v() {
    return (
      /*click_handler*/
      e[29](
        /*group*/
        e[51]
      )
    );
  }
  let D = (
    /*groupVisibility*/
    e[13][
      /*group*/
      e[51].group_name
    ] && La(e)
  );
  return {
    key: i,
    first: null,
    c() {
      t = j("button"), n = j("span"), o = mt(a), l = Fe(), r = j("span"), u = mt(s), c = Fe(), D && D.c(), h = wt(), this.h();
    },
    l(b) {
      t = G(b, "BUTTON", { class: !0 });
      var E = ie(t);
      n = G(E, "SPAN", { class: !0 });
      var m = ie(n);
      o = ht(m, a), m.forEach(x), l = ye(E), r = G(E, "SPAN", { class: !0 });
      var _ = ie(r);
      u = ht(_, s), _.forEach(x), E.forEach(x), c = ye(b), D && D.l(b), h = wt(), this.h();
    },
    h() {
      N(n, "class", "group-title"), N(r, "class", "group-toggle-icon"), N(t, "class", "group-header svelte-1nz1lmm"), this.first = t;
    },
    m(b, E) {
      J(b, t, E), U(t, n), U(n, o), U(t, l), U(t, r), U(r, u), J(b, c, E), D && D.m(b, E), J(b, h, E), d || (f = pe(t, "click", v), d = !0);
    },
    p(b, E) {
      e = b, E[0] & /*value*/
      1 && a !== (a = /*group*/
      e[51].group_name + "") && $t(o, a), E[0] & /*groupVisibility, value*/
      8193 && s !== (s = /*groupVisibility*/
      e[13][
        /*group*/
        e[51].group_name
      ] ? "−" : "+") && $t(u, s), /*groupVisibility*/
      e[13][
        /*group*/
        e[51].group_name
      ] ? D ? D.p(e, E) : (D = La(e), D.c(), D.m(h.parentNode, h)) : D && (D.d(1), D = null);
    },
    d(b) {
      b && (x(t), x(c), x(h)), D && D.d(b), d = !1, f();
    }
  };
}
function Us(i) {
  let e, t, n, a, o = "▼", l, r, s, u, c, h = (
    /*loading_status*/
    i[10] && Ta(i)
  ), d = (
    /*label*/
    i[2] && Ba(i)
  ), f = (
    /*open*/
    i[1] && Ra(i)
  );
  return {
    c() {
      h && h.c(), e = Fe(), t = j("button"), d && d.c(), n = Fe(), a = j("span"), a.textContent = o, l = Fe(), r = j("div"), f && f.c(), this.h();
    },
    l(v) {
      h && h.l(v), e = ye(v), t = G(v, "BUTTON", { class: !0 });
      var D = ie(t);
      d && d.l(D), n = ye(D), a = G(D, "SPAN", { class: !0, "data-svelte-h": !0 }), Tl(a) !== "svelte-zp2qne" && (a.textContent = o), D.forEach(x), l = ye(v), r = G(v, "DIV", { class: !0 });
      var b = ie(r);
      f && f.l(b), b.forEach(x), this.h();
    },
    h() {
      N(a, "class", "accordion-icon"), Cn(
        a,
        "transform",
        /*open*/
        i[1] ? "rotate(0)" : "rotate(-90deg)"
      ), N(t, "class", "accordion-header svelte-1nz1lmm"), N(r, "class", "content-wrapper svelte-1nz1lmm"), Ce(r, "closed", !/*open*/
      i[1]);
    },
    m(v, D) {
      h && h.m(v, D), J(v, e, D), J(v, t, D), d && d.m(t, null), U(t, n), U(t, a), J(v, l, D), J(v, r, D), f && f.m(r, null), s = !0, u || (c = pe(
        t,
        "click",
        /*handle_toggle*/
        i[19]
      ), u = !0);
    },
    p(v, D) {
      /*loading_status*/
      v[10] ? h ? (h.p(v, D), D[0] & /*loading_status*/
      1024 && en(h, 1)) : (h = Ta(v), h.c(), en(h, 1), h.m(e.parentNode, e)) : h && (Ts(), Sn(h, 1, 1, () => {
        h = null;
      }), Es()), /*label*/
      v[2] ? d ? d.p(v, D) : (d = Ba(v), d.c(), d.m(t, n)) : d && (d.d(1), d = null), D[0] & /*open*/
      2 && Cn(
        a,
        "transform",
        /*open*/
        v[1] ? "rotate(0)" : "rotate(-90deg)"
      ), /*open*/
      v[1] ? f ? f.p(v, D) : (f = Ra(v), f.c(), f.m(r, null)) : f && (f.d(1), f = null), (!s || D[0] & /*open*/
      2) && Ce(r, "closed", !/*open*/
      v[1]);
    },
    i(v) {
      s || (en(h), s = !0);
    },
    o(v) {
      Sn(h), s = !1;
    },
    d(v) {
      v && (x(e), x(t), x(l), x(r)), h && h.d(v), d && d.d(), f && f.d(), u = !1, c();
    }
  };
}
function Hs(i) {
  let e, t;
  return e = new ao({
    props: {
      visible: (
        /*visible*/
        i[3]
      ),
      elem_id: (
        /*elem_id*/
        i[4]
      ),
      elem_classes: (
        /*final_classes*/
        i[17]
      ),
      container: (
        /*container*/
        i[5]
      ),
      scale: (
        /*scale*/
        i[6]
      ),
      min_width: (
        /*min_width*/
        i[7]
      ),
      width: (
        /*width*/
        i[8]
      ),
      $$slots: { default: [Us] },
      $$scope: { ctx: i }
    }
  }), {
    c() {
      Al(e.$$.fragment);
    },
    l(n) {
      El(e.$$.fragment, n);
    },
    m(n, a) {
      Bl(e, n, a), t = !0;
    },
    p(n, a) {
      const o = {};
      a[0] & /*visible*/
      8 && (o.visible = /*visible*/
      n[3]), a[0] & /*elem_id*/
      16 && (o.elem_id = /*elem_id*/
      n[4]), a[0] & /*final_classes*/
      131072 && (o.elem_classes = /*final_classes*/
      n[17]), a[0] & /*container*/
      32 && (o.container = /*container*/
      n[5]), a[0] & /*scale*/
      64 && (o.scale = /*scale*/
      n[6]), a[0] & /*min_width*/
      128 && (o.min_width = /*min_width*/
      n[7]), a[0] & /*width*/
      256 && (o.width = /*width*/
      n[8]), a[0] & /*open, height, value, interactive, initialValues, validationState, sliderElements, groupVisibility, label, gradio, loading_status*/
      130567 | a[1] & /*$$scope*/
      1073741824 && (o.$$scope = { dirty: a, ctx: n }), e.$set(o);
    },
    i(n) {
      t || (en(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Sn(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Sl(e, n);
    }
  };
}
function Ua(i, e) {
  var t, n;
  if (!e) return;
  const a = (t = i.minimum) !== null && t !== void 0 ? t : 0, o = (n = i.maximum) !== null && n !== void 0 ? n : 100, l = Number(i.value), r = l <= a ? 0 : (l - a) * 100 / (o - a);
  e.style.setProperty("--slider-progress", `${r}%`);
}
function Gs(i, e, t) {
  let n;
  var a = this && this.__awaiter || function(y, L, W, oe) {
    function Re(kt) {
      return kt instanceof W ? kt : new W(function(bt) {
        bt(kt);
      });
    }
    return new (W || (W = Promise))(function(kt, bt) {
      function Et(Ke) {
        try {
          Xe(oe.next(Ke));
        } catch (Bt) {
          bt(Bt);
        }
      }
      function yt(Ke) {
        try {
          Xe(oe.throw(Ke));
        } catch (Bt) {
          bt(Bt);
        }
      }
      function Xe(Ke) {
        Ke.done ? kt(Ke.value) : Re(Ke.value).then(Et, yt);
      }
      Xe((oe = oe.apply(y, L || [])).next());
    });
  }, o;
  let { value: l = [] } = e, { label: r = void 0 } = e, { visible: s = !0 } = e, { open: u = !0 } = e, { elem_id: c = "" } = e, { elem_classes: h = [] } = e, { container: d = !1 } = e, { scale: f = null } = e, { min_width: v = void 0 } = e, { width: D = void 0 } = e, { height: b = void 0 } = e, { loading_status: E = void 0 } = e, { interactive: m = !0 } = e, { gradio: _ } = e, g = {}, F = {}, w = {}, C = null, I = !1, S = {};
  function O(y) {
    if (y.minimum === void 0 && y.maximum === void 0) {
      w[y.name] !== !0 && (t(15, w[y.name] = !0, w), t(15, w = Object.assign({}, w)));
      return;
    }
    const L = Number(y.value);
    let W = !0;
    y.minimum !== void 0 && L < y.minimum && (W = !1), y.maximum !== void 0 && L > y.maximum && (W = !1), w[y.name] !== W && (t(15, w[y.name] = W, w), t(15, w = Object.assign({}, w)));
  }
  function q() {
    if (Array.isArray(l)) {
      for (const y of l)
        if (Array.isArray(y.properties))
          for (const L of y.properties)
            L.component === "slider" && F[L.name] && Ua(L, F[L.name]);
    }
  }
  function H() {
    t(1, u = !u), u ? _.dispatch("expand") : _.dispatch("collapse");
  }
  function ke(y) {
    t(13, g[y] = !g[y], g);
  }
  function re(y) {
    if (Array.isArray(l))
      for (const L of l) {
        if (!Array.isArray(L.properties)) continue;
        const W = L.properties.find((oe) => oe.name === y);
        if (W) return W.value;
      }
  }
  function ae(y, L) {
    var W;
    if (w[L.name] === !1)
      return;
    const oe = {};
    let Re = L.value;
    !((W = L.component) === null || W === void 0) && W.startsWith("number") || L.component === "slider" ? Re = Number(L.value) : L.component === "checkbox" && (Re = L.value), oe[L.name] = Re, _.dispatch(y, oe);
  }
  function se(y, L) {
    return a(this, void 0, void 0, function* () {
      const W = y.target.value;
      t(0, l = l.map((oe) => oe.properties ? Object.assign(Object.assign({}, oe), {
        properties: oe.properties.map((Re) => Re.name === L.name ? Object.assign(Object.assign({}, Re), { value: W }) : Re)
      }) : oe)), yield xs(), _.dispatch("change", l);
    });
  }
  function Se(y) {
    if (I) return;
    if (I = !0, !(y in S)) {
      I = !1;
      return;
    }
    let L = l.map((W) => (W.properties && (W.properties = W.properties.map((oe) => oe.name === y ? Object.assign(Object.assign({}, oe), { value: S[y] }) : oe)), W));
    t(0, l = L), _.dispatch("change", L), setTimeout(
      () => {
        I = !1;
      },
      100
    );
  }
  function K() {
    t(27, C = JSON.stringify(l)), Array.isArray(l) && l.forEach((y) => {
      Array.isArray(y.properties) && y.properties.forEach((L) => {
        t(16, S[L.name] = L.value, S);
      });
    }), setTimeout(q, 50);
  }
  Ls(() => {
    K();
  });
  const ue = () => _.dispatch("clear_status"), he = (y) => ke(y.group_name);
  function $(y, L) {
    y[L].value = this.value, t(0, l);
  }
  const le = (y) => ae("change", y), X = (y) => ae("input", y);
  function _e(y, L) {
    y[L].value = this.checked, t(0, l);
  }
  const A = (y) => ae("change", y);
  function Ee(y, L) {
    y[L].value = ri(this.value), t(0, l);
  }
  const We = (y) => ae("change", y), gt = (y) => {
    O(y), ae("input", y);
  };
  function vt(y, L) {
    y[L].value = ri(this.value), t(0, l);
  }
  function Dt(y, L) {
    ks[y ? "unshift" : "push"](() => {
      F[L.name] = y, t(14, F);
    });
  }
  const st = (y) => {
    O(y), Ua(y, F[y.name]), ae("input", y);
  }, Ze = (y) => ae("change", y);
  function Ye(y, L) {
    y[L].value = this.value, t(0, l);
  }
  const ut = (y) => ae("change", y), zt = (y, L) => se(L, y), Mt = (y) => Se(y.name);
  return i.$$set = (y) => {
    "value" in y && t(0, l = y.value), "label" in y && t(2, r = y.label), "visible" in y && t(3, s = y.visible), "open" in y && t(1, u = y.open), "elem_id" in y && t(4, c = y.elem_id), "elem_classes" in y && t(25, h = y.elem_classes), "container" in y && t(5, d = y.container), "scale" in y && t(6, f = y.scale), "min_width" in y && t(7, v = y.min_width), "width" in y && t(8, D = y.width), "height" in y && t(9, b = y.height), "loading_status" in y && t(10, E = y.loading_status), "interactive" in y && t(11, m = y.interactive), "gradio" in y && t(12, _ = y.gradio);
  }, i.$$.update = () => {
    if (i.$$.dirty[0] & /*elem_classes*/
    33554432 && t(17, n = ["propertysheet-wrapper", ...h]), i.$$.dirty[0] & /*open, height*/
    514, i.$$.dirty[0] & /*value, lastValue, groupVisibility, _a*/
    201334785 && Array.isArray(l) && JSON.stringify(l) !== C) {
      t(27, C = JSON.stringify(l));
      for (const y of l)
        if (g[y.group_name] === void 0 && t(13, g[y.group_name] = !0, g), Array.isArray(y.properties))
          for (const L of y.properties)
            (!(t(26, o = L.component) === null || o === void 0) && o.startsWith("number") || L.component === "slider") && O(L);
      q();
    }
  }, [
    l,
    u,
    r,
    s,
    c,
    d,
    f,
    v,
    D,
    b,
    E,
    m,
    _,
    g,
    F,
    w,
    S,
    n,
    O,
    H,
    ke,
    re,
    ae,
    se,
    Se,
    h,
    o,
    C,
    ue,
    he,
    $,
    le,
    X,
    _e,
    A,
    Ee,
    We,
    gt,
    vt,
    Dt,
    st,
    Ze,
    Ye,
    ut,
    zt,
    Mt
  ];
}
class hA extends ws {
  constructor(e) {
    super(), Bs(
      this,
      e,
      Gs,
      Hs,
      Rs,
      {
        value: 0,
        label: 2,
        visible: 3,
        open: 1,
        elem_id: 4,
        elem_classes: 25,
        container: 5,
        scale: 6,
        min_width: 7,
        width: 8,
        height: 9,
        loading_status: 10,
        interactive: 11,
        gradio: 12
      },
      null,
      [-1, -1]
    );
  }
}
export {
  hA as default
};
