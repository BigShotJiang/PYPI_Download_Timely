OPENAPI_HANDLER_METADATA = "__openapi_handler__"
