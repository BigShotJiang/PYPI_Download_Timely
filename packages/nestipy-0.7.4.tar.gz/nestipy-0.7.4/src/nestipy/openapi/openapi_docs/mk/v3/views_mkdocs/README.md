# Views for MkDocs

This folder contains views to generate output suitable for MkDocs, using
these extensions from [PyMdown](https://facelessuser.github.io/pymdown-extensions/):

```yaml
  - pymdownx.details
  - pymdownx.superfences
  - pymdownx.tabbed:
      alternate_style: true
```
