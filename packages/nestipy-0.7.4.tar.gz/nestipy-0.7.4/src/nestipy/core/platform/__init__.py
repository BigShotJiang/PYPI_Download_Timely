class FastApiApplication:
    pass


class BlackSheepApplication:
    pass
