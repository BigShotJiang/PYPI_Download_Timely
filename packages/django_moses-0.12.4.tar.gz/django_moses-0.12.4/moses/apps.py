from django.apps import AppConfig


class MosesConfig(AppConfig):
    name = 'moses'
