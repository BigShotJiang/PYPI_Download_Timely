# admin.py for myapp
