class ValidationError(Exception):
    """Erro para validação de contratos."""

    pass


class DLManagerError(Exception):
    """Erro ao tentar enviar dados ao DL Manager."""

    pass
