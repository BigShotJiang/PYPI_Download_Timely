def main():
    print("Hello from mcp-deadmansnitch!")


if __name__ == "__main__":
    main()
