"""Tests for mcp-deadmansnitch."""
