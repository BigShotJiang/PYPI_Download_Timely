"""MCP server for Dead Man's Snitch monitoring service."""

__version__ = "0.1.0"
