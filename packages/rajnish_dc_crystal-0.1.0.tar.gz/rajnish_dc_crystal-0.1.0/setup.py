"""
Setup script for rajnish-dc-crystal package.
This is provided for backward compatibility and uses setuptools.
"""
from setuptools import setup

if __name__ == "__main__":
    # This file is kept for backward compatibility and uses setuptools.
    # The package is configured in pyproject.toml.
    setup()
