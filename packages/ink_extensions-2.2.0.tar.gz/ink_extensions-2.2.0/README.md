# ink_extensions
Python dependencies for running [Inkscape](https://inkscape.org) extensions outside of Inkscape

Use pip to install:
pip install ink_extensions

https://pypi.org/project/ink-extensions/

----

Files in the `ink_extensions` dir were initially forked from Inkscape 0.91,
and modified slightly to allow operation under both python 2.x and 3.x.

Files in `ink_extensions_utils` are written for this package.

License: GPL v2.
