from pralekh.extractor import extract

__all__ = ["extract"]
