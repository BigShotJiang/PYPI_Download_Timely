# ner-util
Just another ner utils class, use at your own risk. I just vibe coded it 🥲
cause I was sick of converting between different ner output formats & doing some common ops.
Not well documented and not planned for future. It is just for personal use. & opinionated.
I might maintain if I like it. 
For now it is just a very very basic setup just to push on pypi

```
from ner_util import EntityList
```
