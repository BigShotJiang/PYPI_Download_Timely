# your_package/module.py

def greet(name: str) -> str:
    """
    Return a friendly greeting.
    """
    return f"Hello, {name}!"
