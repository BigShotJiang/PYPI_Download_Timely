Módulo que busca a inscrição estadual referente ao CNPJ pesquisado ao
clicar no botão de busca de cnpj do módulo l10n_br_cnpj_search, assim
preenchendo o campo State Tax Number.
