CREWAI_COMPONENTS = {"Crew": "MultiAgent", "Task": "Task", "Agent": "Agent"}
