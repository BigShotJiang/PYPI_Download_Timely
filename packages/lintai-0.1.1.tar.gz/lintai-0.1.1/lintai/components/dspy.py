DSPY_COMPONENTS = {"dspy.Module": "Chain", "dspy.Predict": "Predictor"}
