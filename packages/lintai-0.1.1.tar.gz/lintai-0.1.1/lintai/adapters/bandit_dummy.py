"""Placeholder adapter – implement real Bandit integration."""
