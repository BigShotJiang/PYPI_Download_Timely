This module makes the timezone of Ethiopia the default timezone for users and partners.
