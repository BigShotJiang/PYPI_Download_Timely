This is a glue module between sale_order_import_ubl and
sale_order_requested_delivery. It extracts the RequestedDeliveryPeriod
from the UBL order.
