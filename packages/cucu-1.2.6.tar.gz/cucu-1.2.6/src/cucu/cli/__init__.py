# flake8: noqa
# nopycln: file
from cucu.cli.core import main
