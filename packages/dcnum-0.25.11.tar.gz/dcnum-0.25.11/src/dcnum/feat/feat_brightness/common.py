brightness_names = [
    "bg_med",
    "bright_avg",
    "bright_sd",
    "bright_bc_avg",
    "bright_bc_sd",
    "bright_perc_10",
    "bright_perc_90"
]
