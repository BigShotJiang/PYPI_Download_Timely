"""Top-level API for the llamabot prompt library."""
