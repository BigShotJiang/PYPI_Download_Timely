# SPDX-FileCopyrightText: 2025 German Aerospace Center <fame@dlr.de>
#
# SPDX-License-Identifier: Apache-2.0
"""Parsing of the scripts' command line options."""

from fameio.cli.parser import update_default_config  # noqa: F401
