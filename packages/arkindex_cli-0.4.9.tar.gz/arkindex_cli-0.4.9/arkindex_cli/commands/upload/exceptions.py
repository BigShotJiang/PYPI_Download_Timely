class UploadProcessingError(Exception):
    """
    Raised when there has been an error in the upload processing
    """
