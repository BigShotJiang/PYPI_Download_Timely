# sf_label_skew

A Python package for generating Same Features, Different Label Skew datasets using KMeans clustering and Davies-Bouldin Score for optimal `k`.
