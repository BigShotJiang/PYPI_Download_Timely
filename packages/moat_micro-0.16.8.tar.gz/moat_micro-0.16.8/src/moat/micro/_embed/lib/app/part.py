"""
Random parts
"""

from __future__ import annotations

from moat.micro.part.pin import Pin  # noqa:F401 pylint:disable=unused-import
from moat.micro.part.relay import Relay  # noqa:F401 pylint:disable=unused-import
