# An infamous TODO list

convert to cbor

allow for resilient apps (restart on error)

cfg is now an attrdict, so are the messages. Use that fact.

forward client-side non-command app errors to the server
(default raise)

go through the client code and shrink stuff

figure out how to control dtr/rts initially

remove more non-micro stuff
