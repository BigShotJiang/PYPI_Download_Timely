=========================
MoaT Application Handlers
=========================

MoaT comes with a significant number of built-in apps, i.e. 
