__author__ = 'andriy'

from django.contrib import admin

from . import models


admin.site.register(models.Object)