from r3l3453 import app

if __name__ == '__main__':
    app()
