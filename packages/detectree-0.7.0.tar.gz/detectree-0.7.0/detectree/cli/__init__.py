"""detectree CLI init."""
