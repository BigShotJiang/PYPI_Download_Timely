Once the survey is configured, the users can fill them up as usual. The
quotations will be generated according to the survey users' choices.
