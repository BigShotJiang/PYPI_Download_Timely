This module allows to generate quotations from surveys submits.
