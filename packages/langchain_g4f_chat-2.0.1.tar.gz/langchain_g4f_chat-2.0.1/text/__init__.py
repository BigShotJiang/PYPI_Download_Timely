"""Text generation capabilities for langchain-g4f."""

from .base import ChatG4F

__all__ = ['ChatG4F']
