class Zunno:
    def ask(self, prompt):
        return f"Echo from Zunno: {prompt}"
