"""
Created on 2025-07-23

@author: wf
"""

from basemkit.basetest import Basetest


class TestGraphNavigator(Basetest):
    """
    test the graph navigator
    """

    def setUp(self, debug=False, profile=True):
        Basetest.setUp(self, debug=debug, profile=profile)

    def testGraphNavigator(self):
        """
        test the graph navigator
        """
        pass
