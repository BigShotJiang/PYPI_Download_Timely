import time

time.sleep(1)
x = 99
