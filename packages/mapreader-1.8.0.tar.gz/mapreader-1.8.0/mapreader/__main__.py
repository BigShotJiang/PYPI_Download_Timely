from __future__ import annotations

from . import print_version

if __name__ == "__main__":
    print_version()
