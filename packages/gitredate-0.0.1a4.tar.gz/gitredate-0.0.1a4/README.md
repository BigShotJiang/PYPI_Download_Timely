# GitRedate

Rewrite dates in your git commits, to hide the actual time at which you were working.

Features:
- sets date during working hours
- keeps more or less delta time between commits
- preserves consistency with merge commits
- preserves commits in master

## Install

The package is not yet available on PyPi. You can however install from Github directly.

```
pip install -e git+ssh://git@github.com/olivierdalang/gitredate.git#egg=gitredate
```

## Usage
```
python -m gitredate [-h] [--initial_datetime INITIAL_DATETIME] [--src SRC]
                    [--workdays WORKDAYS] [--workstart WORKSTART]
                    [--workend WORKEND] [--mindelta MINDELTA]
                    [--maxdelta MAXDELTA] [--jitter_mindelta JITTER_MINDELTA]
                    [--jitter_maxdelta JITTER_MAXDELTA]
                    [--main_branch MAIN_BRANCH]
                    base

positional arguments:
  base                  commit after which dates will be rewritten

options:
  -h, --help            show this help message and exit
  --initial_datetime INITIAL_DATETIME
                        time of the oldest commit in dateutil parsable format
                        (if unset, the date of the base commit will be used)
                        (default: None)
  --src SRC             path to the repository (default: .)
  --workdays WORKDAYS   comma separated list of working week days (monday=1)
                        (default: 1,2,3,4,5)
  --workstart WORKSTART
                        time of day at which work starts (default: 08:30)
  --workend WORKEND     time of day at which work ends (default: 18:30)
  --mindelta MINDELTA   minimum time between commits (default: 00:01)
  --maxdelta MAXDELTA   maximum time between commits (default: 01:00)
  --jitter_mindelta JITTER_MINDELTA
                        time to randomly add/substract from minimum time
                        between commits (default: 00:00:15)
  --jitter_maxdelta JITTER_MAXDELTA
                        time to randomly add/substract from maximum time
                        between commits (default: 00:15)
  --main_branch MAIN_BRANCH
                        branch in which commits are not redated (example: if
                        your feature branch merged back master, set this to
                        master) (default: None)

```
