"""Public documentation connector."""

from qdrant_loader.connectors.publicdocs.connector import PublicDocsConnector

__all__ = ["PublicDocsConnector"]
