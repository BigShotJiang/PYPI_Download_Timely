"""
team-query: A Python clone of sqlc with YAML-based SQL queries and multi-language compilation.
"""

__version__ = "0.1.0"
