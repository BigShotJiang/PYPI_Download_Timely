from .core import evaluate_folder
from .logging_config import setup_logging
