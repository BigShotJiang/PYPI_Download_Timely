"""Wanyi Today - A FastMCP demo server."""

__version__ = "0.1.6"

from .main import mcp as server

__all__ = ["server", "__version__"]