def main():
    print("Hello from brushable-widget!")


if __name__ == "__main__":
    main()
