"""A command-line FITS header editor."""

__version__ = "0.4.0"
