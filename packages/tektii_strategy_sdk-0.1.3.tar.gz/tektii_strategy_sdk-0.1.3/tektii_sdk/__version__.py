# tektii_sdk/__version__.py
"""Version information for tektii-strategy-sdk."""

__version__ = "0.1.0"
