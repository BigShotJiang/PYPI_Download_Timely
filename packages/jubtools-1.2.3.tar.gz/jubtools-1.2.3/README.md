# jubtools

Shared tools for my own work

## Package

* Update version number in pyproject.toml
* `pip install build twine`
* `rm -r dist`
* `python -m build`
* `twine upload dist/*`
