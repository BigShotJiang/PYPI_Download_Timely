import asyncio

from mcp_scan.cli import main


def run():
    asyncio.run(main())


if __name__ == "__main__":
    run()
