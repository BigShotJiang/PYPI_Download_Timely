# types-idlelib
Typing stubs for the stdlib `idlelib` module

<!-- BADGIE TIME -->

[![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit)](https://github.com/pre-commit/pre-commit)

<!-- END BADGIE TIME -->

## Description
This is project supplies typing stubs for the stdlib `idlelib` module

### Links
* Source Code - https://github.com/CoolCat467/types-idlelib.git
* Issues      - https://github.com/CoolCat467/types-idlelib/issues

### License
-------
Code and documentation are available according to the MIT License (see [LICENSE](https://github.com/CoolCat467/types-idlelib/blob/HEAD/LICENSE)).
