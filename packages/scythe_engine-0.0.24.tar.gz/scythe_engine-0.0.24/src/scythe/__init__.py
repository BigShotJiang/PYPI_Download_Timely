"""A library for managing embarassingly parallel experiments with Hatchet."""
