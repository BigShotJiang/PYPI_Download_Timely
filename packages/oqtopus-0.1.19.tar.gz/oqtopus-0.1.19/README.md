# oQtopus

<img src="oqtopus/icons/oqtopus-logo.png" alt="logo" width="250"/>

Front-end application to manage [PUM](https://github.com/opengisch/pum) modules.

Read the docs: https://opengisch.github.io/oqtopus/
