# These version placeholders will be replaced during build.
__version__ = '0.4.5'
__version_tuple__ = (0, 4, 5)
