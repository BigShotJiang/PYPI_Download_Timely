__version__ = "1.2.11"
from .solweig_gpu import thermal_comfort
