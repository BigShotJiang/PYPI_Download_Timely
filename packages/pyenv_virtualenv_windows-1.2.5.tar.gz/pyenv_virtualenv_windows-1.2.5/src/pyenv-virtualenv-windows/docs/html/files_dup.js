var files_dup =
[
    [ "bin", "dir_2ea30aa2956a8db99dd22aa5e597f384.html", "dir_2ea30aa2956a8db99dd22aa5e597f384" ],
    [ "docs", "dir_49e56c817e5e54854c35e136979f97ca.html", "dir_49e56c817e5e54854c35e136979f97ca" ],
    [ "libexec", "dir_0f5f9c5c154936a133cc37516cd09744.html", "dir_0f5f9c5c154936a133cc37516cd09744" ],
    [ "patch", "dir_9c2061b0d0eda1357436d388a4b6e24a.html", "dir_9c2061b0d0eda1357436d388a4b6e24a" ],
    [ "shims", "dir_f1046f2aafff60c47cc00d61d6b6c1a1.html", "dir_f1046f2aafff60c47cc00d61d6b6c1a1" ],
    [ "install.bat", "install_8bat.html", null ],
    [ "README.bat", "_r_e_a_d_m_e_8bat.html", null ]
];