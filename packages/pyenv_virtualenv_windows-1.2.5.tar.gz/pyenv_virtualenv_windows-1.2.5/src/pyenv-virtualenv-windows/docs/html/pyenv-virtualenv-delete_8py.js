var pyenv_virtualenv_delete_8py =
[
    [ "pyenv-virtualenv-delete.run", "namespacepyenv-virtualenv-delete.html#a54345dadd9fe447f0552a4c824ab607d", null ],
    [ "pyenv-virtualenv-delete.parseCliArguments", "namespacepyenv-virtualenv-delete.html#ab9aa5fc6026c42896b2282a92bfda78c", null ],
    [ "pyenv-virtualenv-delete.main", "namespacepyenv-virtualenv-delete.html#a318ccbab89114f68c3d46f7285544d9b", null ]
];