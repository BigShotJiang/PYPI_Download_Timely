var searchData=
[
  ['virtualenv_20for_20windows_0',['Plugin &apos;pyenv-virtualenv&apos; for Windows',['../index.html',1,'']]]
];
