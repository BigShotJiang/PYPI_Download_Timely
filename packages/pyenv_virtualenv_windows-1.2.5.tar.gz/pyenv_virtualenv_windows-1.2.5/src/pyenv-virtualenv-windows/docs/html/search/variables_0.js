var searchData=
[
  ['_5fis_5finitialized_0',['_is_initialized',['../namespacelog.html#a561883ec3a2fe5749ac6a1bedb099fc7',1,'log']]]
];
