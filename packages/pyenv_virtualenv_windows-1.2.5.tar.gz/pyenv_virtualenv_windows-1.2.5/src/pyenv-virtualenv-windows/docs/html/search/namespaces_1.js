var searchData=
[
  ['log_0',['log',['../namespacelog.html',1,'']]]
];
