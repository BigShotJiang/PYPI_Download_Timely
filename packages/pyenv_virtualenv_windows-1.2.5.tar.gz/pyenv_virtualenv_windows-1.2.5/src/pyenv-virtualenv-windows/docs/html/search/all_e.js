var searchData=
[
  ['name_0',['Create with Version and Name',['../index.html#autotoc_md21',1,'']]],
  ['name_20only_1',['Create With Name Only',['../index.html#autotoc_md22',1,'']]],
  ['new_20version_2',['Engineer a New Version',['../index.html#autotoc_md97',1,'']]],
  ['notepad_3',['Notepad++',['../index.html#autotoc_md48',1,'']]],
  ['notice_4',['notice',['../namespacelog.html#a349710df917e1d634ca25f7fe22c95bc',1,'log']]]
];
