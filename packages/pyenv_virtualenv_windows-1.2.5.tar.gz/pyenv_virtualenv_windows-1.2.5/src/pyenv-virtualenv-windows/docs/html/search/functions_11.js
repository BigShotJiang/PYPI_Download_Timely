var searchData=
[
  ['warning_0',['warning',['../namespacelog.html#a2e4b8c734690147ccd29c6f6bf88515a',1,'log']]]
];
