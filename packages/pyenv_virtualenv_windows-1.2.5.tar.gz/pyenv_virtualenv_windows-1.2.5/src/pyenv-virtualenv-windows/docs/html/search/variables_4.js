var searchData=
[
  ['header_0',['HEADER',['../namespacetbl.html#ad604c01ac0d936209f07464971fa345d',1,'tbl']]],
  ['header_5fcolor_1',['header_color',['../classtbl_1_1_simple_table.html#a4512e9d1f075a104c4d6d0c238a00fcb',1,'tbl::SimpleTable']]],
  ['headline_2',['headline',['../classtbl_1_1_simple_table.html#aa9368582c0c34b96b6434669f1f33e47',1,'tbl::SimpleTable']]],
  ['headline_5fcolor_3',['headline_color',['../classtbl_1_1_simple_table.html#ad0d0cb4d1c72501ad5691981e6efe53c',1,'tbl::SimpleTable']]]
];
