from core.database import Base

from .conversation_model import Conversations
from .user_model import User
from .message_model import Messages