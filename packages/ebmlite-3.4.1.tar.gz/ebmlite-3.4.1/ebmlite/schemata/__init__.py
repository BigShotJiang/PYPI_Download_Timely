"""
ebmlite.schemata: Submodule containing the default schema XML files. It doesn't
contain any code; it's just for storage. Making it a module makes it easy to
find.

For the definition of the `Schema` class, see `ebmlite.core`.
"""
