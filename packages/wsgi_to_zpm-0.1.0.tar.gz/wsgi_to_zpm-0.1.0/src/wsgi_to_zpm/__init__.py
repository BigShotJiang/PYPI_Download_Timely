"""Generate ZPM/IPM module.xml from an existing WSGI project."""
__version__ = '0.1.0'
