=====
Usage
=====

To use ai-marketplace-monitor in a project::

    import ai_marketplace_monitor
