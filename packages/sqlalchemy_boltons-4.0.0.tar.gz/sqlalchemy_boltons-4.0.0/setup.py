from setuptools import setup

setup(name="sqlalchemy_boltons", version="0.0.0.1")
