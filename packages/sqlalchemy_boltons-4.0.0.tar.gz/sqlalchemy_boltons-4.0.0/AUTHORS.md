# Credits

## Development Lead

- Eduard Christian Dumitrescu <eduard.c.dumitrescu@gmail.com>

## Contributors

None yet. Why not be the first?
