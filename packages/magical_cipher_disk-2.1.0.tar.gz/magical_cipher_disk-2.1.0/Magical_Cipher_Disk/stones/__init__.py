from .base import BaseStone

from .yellow import YellowStone
from .red_green import RedGreenStone
from .blue import BlueStone