dict_of_parts = {
    "4-ch-transceiver": "",
}
