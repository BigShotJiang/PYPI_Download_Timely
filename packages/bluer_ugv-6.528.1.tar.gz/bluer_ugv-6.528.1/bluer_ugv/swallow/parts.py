dict_of_parts = {
    "rpi3bp": "",
    "dc-motor-12-VDC-45W": "2 x rear + steering",
    "SLA-Battery": "",
    "XL4015": "",
    "BTS7960": "rear drive (2 motors) & steering drive (1 motor)",
    "470-mF": "",
    "Polyfuse": "",
    "TVS-diode": "",
    "330-ohm": "",
    "LED": "",
    "rpi-camera": "",
}
