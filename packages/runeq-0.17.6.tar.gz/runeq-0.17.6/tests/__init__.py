"""
Tests for the Rune SDK.

"""
