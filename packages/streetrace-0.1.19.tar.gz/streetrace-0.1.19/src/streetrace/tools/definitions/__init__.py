"""StreetRace🚗💨 built-in tools definitions."""
