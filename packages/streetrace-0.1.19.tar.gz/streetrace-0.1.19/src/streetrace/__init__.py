"""StreetRace🚗💨 - Agentic AI coding partner for the command line."""
