"""Interfaces for all LLM calls in StreetRace🚗💨."""
