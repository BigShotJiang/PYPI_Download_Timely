

## How to make a release
From the development environment:
```
bumpver update --patch --dry
```

