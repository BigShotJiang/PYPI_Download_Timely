# Surface Command API

The **r7-surcom-api** is a lightweight Python library that Surface Command uses to run Connectors. To learn more about Connectors, see the [documentation](https://docs.rapid7.com/surface-command/connectors).
