def kasane_testo():
    print("teto x zundamon yuri detected ❗❗❗ the Fumo has been sent to your location.")
