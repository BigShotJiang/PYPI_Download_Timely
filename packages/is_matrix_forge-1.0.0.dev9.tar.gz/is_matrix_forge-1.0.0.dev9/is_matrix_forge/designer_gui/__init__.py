"""
Author: Taylor B. tayjaybabee@gmail.com
Date: 2025-04-30 16:01:10
LastEditors: Taylor B. tayjaybabee@gmail.com
LastEditTime: 2025-04-30 16:01:49
FilePath: is_matrix_forge/designer_gui/grid.py
Description: 这是默认设置,可以在设置》工具》File Description中进行配置
"""
