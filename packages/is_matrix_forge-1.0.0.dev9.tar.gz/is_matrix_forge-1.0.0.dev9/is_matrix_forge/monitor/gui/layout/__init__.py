"""
Author: Taylor B. tayjaybabee@gmail.com
Date: 2025-05-02 16:04:13
LastEditors: Taylor B. tayjaybabee@gmail.com
LastEditTime: 2025-05-02 16:13:48
FilePath: is_matrix_forge/monitor/gui/layout/grid.py
Description: 这是默认设置,可以在设置》工具》File Description中进行配置
"""
