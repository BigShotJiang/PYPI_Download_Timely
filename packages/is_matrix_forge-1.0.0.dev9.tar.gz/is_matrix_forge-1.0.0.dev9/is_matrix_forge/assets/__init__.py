"""
Author: Taylor B. tayjaybabee@gmail.com
Date: 2025-04-15 09:15:37
LastEditors: Taylor B. tayjaybabee@gmail.com
LastEditTime: 2025-04-15 09:24:40
FilePath: is_matrix_forge/assets/grid.py
Description: 这是默认设置,可以在设置》工具》File Description中进行配置
"""
