"""
Author: Taylor B. tayjaybabee@gmail.com
Date: 2025-05-05 15:02:58
LastEditors: Taylor B. tayjaybabee@gmail.com
LastEditTime: 2025-05-05 15:24:08
FilePath: is_matrix_forge/dev_tools/grid.py
Description: 这是默认设置,可以在设置》工具》File Description中进行配置
"""
