"""
Author: Taylor B. tayjaybabee@gmail.com
Date: 2025-05-12 22:17:04
LastEditors: Taylor B. tayjaybabee@gmail.com
LastEditTime: 2025-05-12 22:17:28
FilePath: is_matrix_forge/led_matrix/tools/grid.py
Description: 这是默认设置,可以在设置》工具》File Description中进行配置
"""
