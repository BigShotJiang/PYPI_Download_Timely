from is_matrix_forge.
