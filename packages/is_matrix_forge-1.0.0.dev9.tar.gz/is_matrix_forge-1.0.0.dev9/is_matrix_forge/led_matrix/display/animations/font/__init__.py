"""


Author:
    Inspyre Softworks

Project:
    led-matrix-battery

File:
    is_matrix_forge/led_matrix/display/animations/font/grid.py


Description:


"""
