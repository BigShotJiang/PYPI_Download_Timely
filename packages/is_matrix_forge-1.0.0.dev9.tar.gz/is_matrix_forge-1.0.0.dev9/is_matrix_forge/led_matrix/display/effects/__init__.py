"""


Author: 
    Inspyre Softworks

Project:
    led-matrix-battery

File: 
    is_matrix_forge/led_matrix/display/effects/grid.py
 

Description:
    

"""
