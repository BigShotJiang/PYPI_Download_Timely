"""
Fake `grid.py` to make the Scripts directory a sub-package.
"""

