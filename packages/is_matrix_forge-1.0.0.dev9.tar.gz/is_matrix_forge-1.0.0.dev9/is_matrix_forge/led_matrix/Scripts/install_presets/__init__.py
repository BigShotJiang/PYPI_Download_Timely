from .main import main as install_presets

