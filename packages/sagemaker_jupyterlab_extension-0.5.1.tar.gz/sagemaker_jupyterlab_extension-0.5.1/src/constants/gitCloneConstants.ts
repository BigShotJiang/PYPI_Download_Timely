type GitRepositoriesType = Array<string>;

type GitCloneRepositoriesResponse = {
  GitCodeRepositories: GitRepositoriesType;
};

export { GitRepositoriesType, GitCloneRepositoriesResponse };
