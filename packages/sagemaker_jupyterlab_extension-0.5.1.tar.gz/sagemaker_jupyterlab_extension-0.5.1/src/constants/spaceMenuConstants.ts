export const spaceTestIds = {
  menu: {
    header: 'spaceMenuHeader',
  },
};
