from pathlib import Path
default_path = Path.home().joinpath('peegy')
test_data_path = Path.home().joinpath('peegy').joinpath('test_data')
