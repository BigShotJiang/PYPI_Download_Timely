"""
Mediascope API library
"""
version = '1.3.1'
