# Copyright 2020-2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0


"""openfl version information."""

__version__ = "1.9.0.dev"
