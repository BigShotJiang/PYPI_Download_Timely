#include "baz_global.h"

BAZ_DLL struct baz_initialized_global baz_initialized_global = {
/*
 * prolongation_pattern
 */
  {(char *) 0}
};
