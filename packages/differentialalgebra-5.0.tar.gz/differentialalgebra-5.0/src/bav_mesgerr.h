#if !defined (BAV_MESGERR_H)
#   define BAV_MESGERR_H 1

#   include "bav_common.h"

BEGIN_C_DECLS

extern BAV_DLL char BAV_ERRUSY[];

extern BAV_DLL char BAV_ERRDSY[];

extern BAV_DLL char BAV_ERRRIG[];

extern BAV_DLL char BAV_ERRBSD[];

extern BAV_DLL char BAV_ERRPAO[];

extern BAV_DLL char BAV_ERRPAR[];

extern BAV_DLL char BAV_ERRDIF[];

extern BAV_DLL char BAV_ERRDVR[];

extern BAV_DLL char BAV_ERRSPY[];

extern BAV_DLL char BAV_ERRDFV[];

extern BAV_DLL char BAV_ERRBLO[];

extern BAV_DLL char BAV_ERRBOR[];

extern BAV_DLL char BAV_ERRTER[];

extern BAV_DLL char BAV_ERRRGZ[];

extern BAV_DLL char BAV_ERRTEU[];

extern BAV_DLL char BAV_EXEXQO[];

END_C_DECLS
#endif /* !BAV_MESGERR_H */
