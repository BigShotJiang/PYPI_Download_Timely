#if !defined (BMI_PREM_H)
#   define BMI_PREM_H 1

#   include <blad.h>
#   include "bmi_callback.h"

BEGIN_C_DECLS

extern ALGEB bmi_prem (
    struct bmi_callback *);

END_C_DECLS
#endif /*! BMI_PREM_H */
