#if !defined (BAV_OPERATOR_H)
#   define BAV_OPERATOR_H 1

#   include "bav_common.h"
#   include "bav_variable.h"


BEGIN_C_DECLS

END_C_DECLS
#endif /* !BAV_OPERATOR_H */
