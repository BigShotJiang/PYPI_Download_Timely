#if !defined (BMI_DELTA_POLYNOMIAL_H)
#   define BMI_DELTA_POLYNOMIAL_H 1

#   include <blad.h>
#   include "bmi_callback.h"

BEGIN_C_DECLS

extern ALGEB bmi_delta_polynomial (
    struct bmi_callback *);

END_C_DECLS
#endif /*! BMI_DELTA_POLYNOMIAL_H */
