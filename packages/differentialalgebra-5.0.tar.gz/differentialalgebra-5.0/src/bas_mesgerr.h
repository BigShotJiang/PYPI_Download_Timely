#if !defined (BAS_MESGERR_H)
#   define BAS_MESGERR_H 1

#   include "bas_common.h"

BEGIN_C_DECLS

extern BAS_DLL char BAS_ERRPAT[];

extern BAS_DLL char BAS_ERRSTR[];

END_C_DECLS
#endif /* !BAS_MESGERR_H */
