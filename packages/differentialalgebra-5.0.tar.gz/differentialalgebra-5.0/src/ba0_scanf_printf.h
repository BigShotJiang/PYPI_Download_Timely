#if !defined (BA0_SCANF_PRINTF_H)
#   define BA0_SCANF_PRINTF_H 1

#   include "ba0_common.h"

BEGIN_C_DECLS

extern BA0_DLL void ba0_scanf_printf (
    char *,
    char *,
    ...);

END_C_DECLS
#endif /* !BA0_SCANF_PRINTF_H */
