#include "bad_mesgerr.h"

BAD_DLL char BAD_EXREDZ[] = "reduction to zero";
BAD_DLL char BAD_EXNRDZ[] = "reduction to nonzero";
BAD_DLL char BAD_EXRNUL[] = "regularization of zero";
BAD_DLL char BAD_EXRDDZ[] = "regularization of a zero divisor";
BAD_DLL char BAD_EXRCNC[] = "consistent triangular set expected";
BAD_DLL char BAD_EXQUNC[] = "consistent quadruple expected";
BAD_DLL char BAD_ERRCRI[] = "correct critical pair expected";
BAD_DLL char BAD_ERRDEL[] = "error while computing a delta-polynomial";
BAD_DLL char BAD_ERRNAC[] = "not an attribute of a regular chain";
BAD_DLL char BAD_ERRIAC[] = "compatible regular chain attributes expected";
BAD_DLL char BAD_ERRCRC[] = "compatible regular chains expected";
BAD_DLL char BAD_ERRNRC[] = "not a regular chain";
BAD_DLL char BAD_ERRIRC[] = "coherent intersection of regular chains expected";
BAD_DLL char BAD_ERRMPT[] = "nonempty regular chain expected";
BAD_DLL char BAD_ERRIBF[] = "compatible base field expected";
BAD_DLL char BAD_ERRBAS[] = "bad base field syntax";
BAD_DLL char BAD_ERRBFD[] = "unexpected differential flag";
BAD_DLL char BAD_ERRIND[] = "dependent variable expected";
BAD_DLL char BAD_ERRIPT[] = "complete point expected";
BAD_DLL char BAD_ERRSFV[] = "separant with finite valuation expected";
