#if !defined (BMI_IS_REDUCED_H)
#   define BMI_IS_REDUCED_H 1

#   include <blad.h>
#   include "bmi_callback.h"

BEGIN_C_DECLS

extern ALGEB bmi_is_reduced (
    struct bmi_callback *);

END_C_DECLS
#endif /*! BMI_IS_REDUCED_H */
