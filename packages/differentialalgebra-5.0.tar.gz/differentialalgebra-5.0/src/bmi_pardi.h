#if !defined (BMI_PARDI_H)
#   define BMI_PARDI_H 1

#   include <blad.h>
#   include "bmi_callback.h"

BEGIN_C_DECLS

extern ALGEB bmi_pardi (
    struct bmi_callback *);

END_C_DECLS
#endif /*! BMI_PARDI_H */
