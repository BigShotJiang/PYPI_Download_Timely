#if !defined (BA0_COPY_H)
#   define BA0_COPY_H 1

#   include "ba0_common.h"

BEGIN_C_DECLS

extern BA0_DLL void *ba0_copy (
    char *,
    void *);

END_C_DECLS
#endif /* !BA0_COPY_H */
