#if !defined (BMI_NORMAL_FORM_H)
#   define BMI_NORMAL_FORM_H 1

#   include <blad.h>
#   include "bmi_callback.h"

BEGIN_C_DECLS

extern ALGEB bmi_normal_form (
    struct bmi_callback *);

END_C_DECLS
#endif /*! BMI_NORMAL_FORM_H */
