#if !defined (BAI_MESGERR_H)
#   define BAI_MESGERR_H 1

#   include "bai_common.h"

BEGIN_C_DECLS

extern BAI_DLL char BAI_ERRUNK[];

extern BAI_DLL char BAI_ERRDOW[];

extern BAI_DLL char BAI_EXEVAL[];

extern BAI_DLL char BAI_EXSSIZ[];

extern BAI_DLL char BAI_EXMAXS[];

extern BAI_DLL char BAI_EXSTIF[];

extern BAI_DLL char BAI_ERROXS[];

END_C_DECLS
#endif /* !BAI_MESGERR_H */
