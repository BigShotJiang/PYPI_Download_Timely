#if !defined (BMI_PROCESS_EXPANSION_POINT_H)
#   define BMI_PROCESS_EXPANSION_POINT_H 1

#   include <blad.h>
#   include "bmi_callback.h"

BEGIN_C_DECLS

extern ALGEB bmi_process_expansion_point (
    struct bmi_callback *);

END_C_DECLS
#endif /*! BMI_PROCESS_EXPANSION_POINT_H */
