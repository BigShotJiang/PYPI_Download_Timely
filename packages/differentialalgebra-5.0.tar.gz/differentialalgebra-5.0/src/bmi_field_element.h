#if !defined (BMI_FIELD_ELEMENT_H)
#   define BMI_FIELD_ELEMENT_H 1

#   include <blad.h>
#   include "bmi_callback.h"

BEGIN_C_DECLS

extern ALGEB bmi_field_element (
    struct bmi_callback *);

END_C_DECLS
#endif /*! BMI_FIELD_ELEMENT_H */
