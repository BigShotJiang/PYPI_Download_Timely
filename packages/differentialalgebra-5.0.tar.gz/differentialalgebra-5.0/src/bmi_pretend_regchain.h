#if !defined (BMI_PRETEND_REGCHAIN_H)
#   define BMI_PRETEND_REGCHAIN_H 1

#   include <blad.h>
#   include "bmi_callback.h"

BEGIN_C_DECLS

extern ALGEB bmi_pretend_regchain (
    struct bmi_callback *);

END_C_DECLS
#endif /*! BMI_PRETEND_REGCHAIN_H */
