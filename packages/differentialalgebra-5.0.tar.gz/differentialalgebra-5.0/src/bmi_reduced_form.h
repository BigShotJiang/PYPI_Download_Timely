#if !defined (BMI_REDUCED_FORM_H)
#   define BMI_REDUCED_FORM_H 1

#   include <blad.h>
#   include "bmi_callback.h"

BEGIN_C_DECLS

extern ALGEB bmi_reduced_form (
    struct bmi_callback *);

END_C_DECLS
#endif /*! BMI_REDUCED_FORM_H */
