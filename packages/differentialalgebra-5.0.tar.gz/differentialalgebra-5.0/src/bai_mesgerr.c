#include "bai_mesgerr.h"

BAI_DLL char BAI_ERRUNK[] = "unknown variable";
BAI_DLL char BAI_ERRDOW[] = "variable not prepared for dense output";

BAI_DLL char BAI_EXEVAL[] = "error while evaluating the function to integrate";
BAI_DLL char BAI_EXSSIZ[] = "too small step size";
BAI_DLL char BAI_EXMAXS[] = "maximum number of steps exceeded";
BAI_DLL char BAI_EXSTIF[] = "stiff problem";

BAI_DLL char BAI_ERROXS[] = "inconsistent odex system";
