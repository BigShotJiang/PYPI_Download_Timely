#if !defined (BMI_DIFFERENTIATE_H)
#   define BMI_DIFFERENTIATE_H 1

#   include <blad.h>
#   include "bmi_callback.h"

BEGIN_C_DECLS

extern ALGEB bmi_differentiate (
    struct bmi_callback *);

END_C_DECLS
#endif /*! BMI_DIFFERENTIATE_H */
