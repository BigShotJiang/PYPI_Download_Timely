#if !defined (BMI_IS_ORTHONOMIC_H)
#   define BMI_IS_ORTHONOMIC_H 1

#   include <blad.h>
#   include "bmi_callback.h"

BEGIN_C_DECLS

extern ALGEB bmi_is_orthonomic (
    struct bmi_callback *);

END_C_DECLS
#endif /*! BMI_IS_ORTHONOMIC_H */
