#include "bas_mesgerr.h"

BAS_DLL char BAS_ERRPAT[] = "wrong prolongation pattern";

BAS_DLL char BAS_ERRSTR[] = "wrong splitting tree";
