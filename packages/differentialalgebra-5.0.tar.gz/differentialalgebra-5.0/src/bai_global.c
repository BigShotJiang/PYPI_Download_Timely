#include "bai_global.h"

BAI_DLL struct bai_global bai_global;
