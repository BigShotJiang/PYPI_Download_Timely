#if !defined (BAP_MESGERR_H)
#   define BAP_MESGERR_H 1

#   include "bap_common.h"

BEGIN_C_DECLS

extern BAP_DLL char BAP_ERRNUL[];

extern BAP_DLL char BAP_ERRCST[];

extern BAP_DLL char BAP_ERRIND[];

extern BAP_DLL char BAP_ERRTGS[];

extern BAP_DLL char BAP_EXHNCP[];

END_C_DECLS
#endif /* !BAP_MESGERR_H */
