#if !defined (BMI_PREPARATION_EQUATION_H)
#   define BMI_PREPARATION_EQUATION_H 1

#   include <blad.h>
#   include "bmi_callback.h"

BEGIN_C_DECLS

extern ALGEB bmi_preparation_equation (
    struct bmi_callback *);

END_C_DECLS
#endif /*! BMI_PREPARATION_EQUATION_H */
