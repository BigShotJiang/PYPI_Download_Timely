#if !defined (BAD_MESGERR_H)
#   define BAD_MESGERR_H 1

#   include "bad_common.h"

BEGIN_C_DECLS

extern BAD_DLL char BAD_EXREDZ[];

extern BAD_DLL char BAD_EXNRDZ[];

extern BAD_DLL char BAD_EXRNUL[];

extern BAD_DLL char BAD_EXRDDZ[];

extern BAD_DLL char BAD_EXRCNC[];

extern BAD_DLL char BAD_EXQUNC[];

extern BAD_DLL char BAD_ERRCRI[];

extern BAD_DLL char BAD_ERRDEL[];

extern BAD_DLL char BAD_ERRNAC[];

extern BAD_DLL char BAD_ERRIAC[];

extern BAD_DLL char BAD_ERRCRC[];

extern BAD_DLL char BAD_ERRNRC[];

extern BAD_DLL char BAD_ERRIRC[];

extern BAD_DLL char BAD_ERRMPT[];

extern BAD_DLL char BAD_ERRIBF[];

extern BAD_DLL char BAD_ERRBAS[];

extern BAD_DLL char BAD_ERRBFD[];

extern BAD_DLL char BAD_ERRIND[];

extern BAD_DLL char BAD_ERRIPT[];

extern BAD_DLL char BAD_ERRSFV[];

END_C_DECLS
#endif /* !BAD_MESGERR_H */
