#if !defined (BMI_RESULTANT_H)
#   define BMI_RESULTANT_H 1

#   include <blad.h>
#   include "bmi_callback.h"

BEGIN_C_DECLS

extern ALGEB bmi_resultant (
    struct bmi_callback *);

END_C_DECLS
#endif /*! BMI_RESULTANT_H */
