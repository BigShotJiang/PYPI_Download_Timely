#include "bap_mesgerr.h"

BAP_DLL char BAP_ERRNUL[] = "nonzero polynomial expected";
BAP_DLL char BAP_ERRCST[] = "non numeric polynomial expected";
BAP_DLL char BAP_ERRIND[] = "dependent polynomial expected";
BAP_DLL char BAP_ERRTGS[] = "term manager: bad term";
BAP_DLL char BAP_EXHNCP[] = "Hensel lifting: non coprime polynomials";
