#if !defined (BMI_PARAMETERS_H)
#   define BMI_PARAMETERS_H 1

#   include <blad.h>
#   include "bmi_callback.h"

BEGIN_C_DECLS

extern ALGEB bmi_parameters (
    struct bmi_callback *);

END_C_DECLS
#endif /*! BMI_PARAMETERS_H */
