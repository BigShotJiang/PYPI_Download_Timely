#include "baz_mesgerr.h"

BAZ_DLL char BAZ_ERRNHL[] =
    "numerator with higher leader than the denominator expected";
BAZ_DLL char BAZ_ERRVPD[] = "denominator free of the passed variable expected";
BAZ_DLL char BAZ_ERRGCD[] = "gcd: fail";
BAZ_DLL char BAZ_ERRHEU[] = "heuristic gcd: fail";
BAZ_DLL char BAZ_EXHDIS[] = "Hensel lifting: distribution error";
BAZ_DLL char BAZ_EXHENS[] = "Hensel lifting: fail";
