#if !defined (BMI_INDETS_H)
#   define BMI_INDETS_H 1

#   include <blad.h>
#   include "bmi_callback.h"

BEGIN_C_DECLS

extern ALGEB bmi_indets (
    struct bmi_callback *);

END_C_DECLS
#endif /*! BMI_INDETS_H */
