# woshicado_pypi_test/__init__.py
__version__ = "0.0.6"

from woshicado_pypi_test.main import hello

__all__ = ["hello"]
