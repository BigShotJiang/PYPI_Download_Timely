# Safe dummy package: libnvjpeg
