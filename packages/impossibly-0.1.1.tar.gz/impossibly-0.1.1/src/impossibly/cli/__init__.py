"""
Command-line interface for Impossibly.
"""

from impossibly.cli.test_commands import tests

__all__ = ["tests"] 