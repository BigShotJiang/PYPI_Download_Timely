PHONE_CODES = {
    "Côte d'Ivoire": "+225",
    "France": "+33",
    "États-Unis": "+1",
    "Sénégal": "+221",
    "Allemagne": "+49",
    "Maroc": "+212",
    "Canada": "+1",
    "Italie": "+39",
    "Mali": "+223",
}
