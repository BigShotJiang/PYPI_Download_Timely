class ControlVector:
    def __init__(self, vector, layer, method=None):
        self.vector = vector
        self.layer = layer
        self.method = method 