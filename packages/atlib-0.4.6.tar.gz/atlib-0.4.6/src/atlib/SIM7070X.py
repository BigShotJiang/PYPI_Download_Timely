from GSM_Device import GSM_Device


class SIM7070X(GSM_Device):
    pass
