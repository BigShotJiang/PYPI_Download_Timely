"""GPULab common models."""

from imecilabt.gpulab.schemas.job2 import Job, JobStatus

__all__ = ["Job", "JobStatus"]
