from .outlook import Outlook

def main():
    print("outlooklib is a library for interacting with Outlook.")

if __name__ == "__main__":
    main()
