from ._gitfame import main  # pragma: no cover, yapf: disable

main()        # pragma: no cover
