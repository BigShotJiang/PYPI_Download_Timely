from ._gitfame import (__author__, __copyright__, __date__, __licence__, __license__, __version__,
                       main)

__all__ = [
    'main', '__author__', '__date__', '__licence__', '__copyright__', '__version__', '__license__']
