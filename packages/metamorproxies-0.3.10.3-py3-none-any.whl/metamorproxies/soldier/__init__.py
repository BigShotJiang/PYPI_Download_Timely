from metamorproxies.soldier.print import PrintWeb

all = ["PrintWeb"]
# Compare this snippet from metamorproxies/soldier/__init__.py:
# from metamorproxies.soldier import print_web
# import os
