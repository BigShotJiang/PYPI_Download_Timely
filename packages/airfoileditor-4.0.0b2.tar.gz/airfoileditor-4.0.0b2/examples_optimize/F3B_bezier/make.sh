# xoptfoil2 must be in the search path

xoptfoil2 -i F3B_bezier.xo2