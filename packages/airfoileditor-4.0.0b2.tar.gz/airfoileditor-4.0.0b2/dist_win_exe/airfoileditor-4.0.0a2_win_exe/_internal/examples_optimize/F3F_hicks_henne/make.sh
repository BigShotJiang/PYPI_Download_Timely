
localXoptfoil2="../../linux/bin/Xoptfoil2"

$localXoptfoil2 -i F3F_hicks_henne.xo2
