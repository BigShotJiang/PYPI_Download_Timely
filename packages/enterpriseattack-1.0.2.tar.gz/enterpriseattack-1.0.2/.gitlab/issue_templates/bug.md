#### Description
<!-- Also tell us what you expected to happen? -->

#### Versions
<!-- What version of enterpriseattack are you running? -->

- enterpriseattack version:
- MITRE ATT&CK Enterprise version:

#### Logs or Screenshots
<!-- Attach any relevant logs -->

/labels ~"bug" ~"priority::3"
/assign @xakepnz
