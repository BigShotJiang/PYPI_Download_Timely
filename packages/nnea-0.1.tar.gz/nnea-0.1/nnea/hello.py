def greet():
    print("Hello, World!")