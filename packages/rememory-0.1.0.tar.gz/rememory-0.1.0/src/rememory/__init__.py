from .sharedDict import RememoryDict as RMDict
from .sharedDict import RememoryDict as Dict
from .sharedDict import RememoryDict

from .sharedList import RememoryList as RMList
from .sharedList import RememoryList as List
from .sharedList import RememoryList