#!/usr/bin/env python3

from .__main__ import *
