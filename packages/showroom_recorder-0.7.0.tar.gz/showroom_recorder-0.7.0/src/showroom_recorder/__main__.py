#!/usr/bin/env python3

def main(**kwargs):
    """Main entry point.
    you-get (legacy)
    """
    from .common import main
    main(**kwargs)

if __name__ == '__main__':
    main()
