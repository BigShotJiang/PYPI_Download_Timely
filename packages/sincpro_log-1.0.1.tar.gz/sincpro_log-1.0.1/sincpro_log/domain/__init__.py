"""Domain layer for sincpro_logger."""
