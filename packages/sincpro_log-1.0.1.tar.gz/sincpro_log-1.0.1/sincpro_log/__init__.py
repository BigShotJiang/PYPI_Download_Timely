"""sincpro_logger: A logging library for sending logs to Loki."""

from .logger import configure_global_logging, create_logger
