from .log_capture import TeeIO
from .config import config

__all__ = ["TeeIO", "config"]
