from .client import Session

session = Session()
