```{include} ../README.md

```

```{toctree}
:maxdepth: 1
:hidden:

guide
reference
changelog
```
