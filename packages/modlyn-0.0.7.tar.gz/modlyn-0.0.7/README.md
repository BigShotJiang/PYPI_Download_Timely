# Modlyn: Feature selection for large count matrices

Read the [quickstart](https://modlyn.lamin.ai/quickstart).

## Contributing

Please run `pre-commit install` and `gitmoji -i` on the CLI before starting to work on this repository!
