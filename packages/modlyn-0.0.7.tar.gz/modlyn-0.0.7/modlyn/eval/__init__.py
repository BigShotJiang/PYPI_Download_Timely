"""Evaluation.

.. autosummary::
   :toctree: .

   CompareScores

"""
from ._jaccard import CompareScores

CompareScoresJaccard = CompareScores  # backward compat
