"""Models.

.. autosummary::
   :toctree: .

   SimpleLogReg

"""
from ._simple_logreg_model import SimpleLogReg
