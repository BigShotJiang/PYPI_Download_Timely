This module allows to get all attachments of a bill of materials (all
levels) on a view. This module allows to get all attachments of a work
orders products to produce on a view.
