API Reference
=============

.. automodule:: recipies.ingredients
   :members:
   :undoc-members:
   :show-inheritance:
.. automodule:: recipies.recipe
   :members:
   :undoc-members:
   :show-inheritance:
.. automodule:: recipies.step
   :members:
   :undoc-members:
   :show-inheritance:
.. automodule:: recipies.selector
   :members:
   :undoc-members:
   :show-inheritance:

