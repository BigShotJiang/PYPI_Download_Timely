from enum import Enum


class Backend(Enum):
    POLARS = "polars"
    PANDAS = "pandas"
