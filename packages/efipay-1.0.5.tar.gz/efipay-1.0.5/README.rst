A python library for integration of your backend with the payment services
provided by https://sejaefi.com.br/

More info visit our github page: https://github.com/efipay/sdk-python-apis-efi
