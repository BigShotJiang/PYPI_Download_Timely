"""Configuration used by other modules.
"""

USER_AGENT = "airflow-fastetl/0.1 (+https://github.com/gestaogovbr/FastETL)"
