# Safe dummy package: libcurand
