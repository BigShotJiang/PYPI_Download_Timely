# Cloudability API
 - IBM Documentation : https://www.ibm.com/docs/en/cloudability-commercial/cloudability-enterprise/saas?topic=cloudability

# License
 - I selected GNU General Public License v3.0
 - I wanted to be able to share the library, but not necessarily support folks going off the open source path.
 - Used this helpful selector --> https://choosealicense.com/ --> https://choosealicense.com/licenses/gpl-3.0/#