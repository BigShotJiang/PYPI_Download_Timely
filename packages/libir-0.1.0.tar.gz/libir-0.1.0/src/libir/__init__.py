def main() -> None:
    print("Hello from libir!")
