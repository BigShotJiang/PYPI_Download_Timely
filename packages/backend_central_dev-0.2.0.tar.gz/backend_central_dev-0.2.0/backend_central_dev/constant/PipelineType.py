
training_pipeline = 'training_pipeline'
xai_pipeline = 'xai_pipeline'
xai_evaluation_pipeline = 'xai_evaluation_pipeline'
training_xai_pipeline = 'training_xai_pipeline'
