"""Main entry point for running the aviationstack_mcp package as a script."""
from . import main

if __name__ == "__main__":
    main()
