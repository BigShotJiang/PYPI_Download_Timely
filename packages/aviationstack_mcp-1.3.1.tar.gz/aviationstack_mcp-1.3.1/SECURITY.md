## Reporting a Vulnerability

Please don't raise an issue that can be more vulnerable to put out in public. Instead, report via http://pradumnasaraf.dev/contact.
