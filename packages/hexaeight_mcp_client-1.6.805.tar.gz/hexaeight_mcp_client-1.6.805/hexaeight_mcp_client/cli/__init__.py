"""
HexaEight MCP Client CLI Tools
"""

__version__ = "1.0.0"
