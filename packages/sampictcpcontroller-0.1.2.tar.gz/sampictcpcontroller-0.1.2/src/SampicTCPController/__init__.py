#!/usr/bin/python

from .SampicTCPController import SampicTCPController

__version__ = "0.1.2"
