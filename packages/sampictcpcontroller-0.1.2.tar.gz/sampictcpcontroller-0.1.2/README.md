# TCP controller for Sampic modules

This Python module introduces a TCP controller to launch, fetch stream, and stop the acquisition of a [Sampic](https://arxiv.org/abs/1503.04625) digitiser.
It requires the LabView GUI to be started on the readout computer, with the TCP server enabled.
