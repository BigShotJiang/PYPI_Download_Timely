Errors
======

.. currentmodule:: wialon.api

.. py:exception:: WialonError

    `Wialon API Reference <https://sdk.wialon.com/wiki/en/sidebar/remoteapi/apiref/errors/errors>`_

    Raised when something goes wrong calling the Wialon API.
