AWS API
=======

:py:mod:`terminusgps` offers the :py:mod:`aws` package; a Python library that makes it simple to operate within the AWS API.

.. toctree::
    :maxdepth: 2
    :caption: Contents:

    secrets.rst
