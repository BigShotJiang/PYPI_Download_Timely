declare module 'base/js/namespace';
declare module 'base/js/events';
declare module 'notebook/js/codecell';
declare let __webpack_public_path__: string;
