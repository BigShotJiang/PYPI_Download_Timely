from vivarium.exceptions import VivariumError


class DynamicValueError(VivariumError):
    """Indicates an improperly configured value was invoked."""

    pass
