.. automodule:: vivarium.framework.components.parser
