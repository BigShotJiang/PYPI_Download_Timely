.. _data_concept:

======================
Data in the Simulation
======================

.. contents::
   :depth: 2
   :local:
   :backlinks: none

Outline
-------
 - The 3 different kinds of data.
 - Model inputs and the value system
 - State information and the population system
 - Model parameters and the configuration system.
