# todo add tests of boids model
import pytest


@pytest.mark.skip("TODO - MIC-5411: Add tests for boids model")
def test_boids_model() -> None:
    pass