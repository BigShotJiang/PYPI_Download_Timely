from my_package_himanshi import Zunno

bot = Zunno()
print(bot.ask("Hello"))  # ✅ This works!
