"""
MissEnsemble: A scikit-learn compatible package for missing data imputation using ensemble methods.
"""

from .miss_ensemble import MissEnsemble
