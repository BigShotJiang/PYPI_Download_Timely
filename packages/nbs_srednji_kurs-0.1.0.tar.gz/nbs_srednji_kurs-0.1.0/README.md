# NBS srednji kurs

## About

Ovo je jednostavni paket koji ima za cilj da prikupi informacije o zvanicnom srednjom kursu u Srbiji.