# code-dictionary
Generated dicts of programming languages’ classes, fields, and methods.
