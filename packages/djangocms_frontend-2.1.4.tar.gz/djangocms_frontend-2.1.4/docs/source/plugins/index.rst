.. index::
    single: Pre-Built Components

#####################
 Built-in Components
#####################

Find the available built-in components for Boostrap 5 in the following sections:

.. toctree::
   :maxdepth: 1

   common
   grid
   components
   toc