How to create a theme app
=========================

``djangocms-frontend`` is designed to be "themable". A theme typically will do one or
more of the following:

- Style the appearance using css
- Extend standard plugins
- Add custom plugins
- Add custom templates
