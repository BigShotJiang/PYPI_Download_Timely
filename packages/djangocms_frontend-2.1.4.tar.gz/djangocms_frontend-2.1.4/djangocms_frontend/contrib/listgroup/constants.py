from django.utils.translation import gettext_lazy as _

LISTGROUP_STATE_CHOICES = (
    ("active", _("Active")),
    ("disabled", _("Disabled")),
)
