from .pair_column_equality import PairColumnEquality

__all__ = [
    "PairColumnEquality",
]
