from enum import Enum


class FlagType(Enum):
    BOOLEAN = "BOOLEAN"
    STRING = "STRING"
    FLOAT = "FLOAT"
    INTEGER = "INTEGER"
    OBJECT = "OBJECT"
