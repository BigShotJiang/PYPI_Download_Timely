from enum import Enum


class BuildType(Enum):
    OneFile = "onefile"
    OneDir = "onedir"
