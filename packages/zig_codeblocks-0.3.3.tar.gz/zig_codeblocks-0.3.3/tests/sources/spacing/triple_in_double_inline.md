This code block starts with `` ```zig``!
```py
print(1)
```
```zig
const std = @import("std");
```
