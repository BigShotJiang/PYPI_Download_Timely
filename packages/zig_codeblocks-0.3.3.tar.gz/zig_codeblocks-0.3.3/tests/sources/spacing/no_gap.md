foo
```py
print(1)
``````zig
const std = @import("std");
```
bar