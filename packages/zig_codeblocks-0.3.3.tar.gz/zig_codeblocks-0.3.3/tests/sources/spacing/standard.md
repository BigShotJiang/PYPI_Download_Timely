foo
```py
print(1)
```
bar
```zig
const std = @import("std");
```
baz