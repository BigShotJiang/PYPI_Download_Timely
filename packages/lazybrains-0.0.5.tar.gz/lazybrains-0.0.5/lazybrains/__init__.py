from .core import Lazy_Work

__all__ = ['Lazy_Work']