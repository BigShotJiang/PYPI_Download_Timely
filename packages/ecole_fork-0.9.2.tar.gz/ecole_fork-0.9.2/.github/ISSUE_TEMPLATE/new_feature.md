---
name: 🚀 New feature
about: Suggest a change to improve Ecole user experience
title: ''
labels: 'type/enhancement 🚀'
assignees: ''

---

## Describe the problem or improvement suggested
<!-- A clear and concise description of what the feature is. -->

## Describe the solution you would like
<!-- A clear and concise description of what you want to happen. -->

## Describe alternatives you have considered
<!-- A clear and concise description of any alternative solutions or features you've considered. -->

## Additional context
<!-- Add any other context or screenshots about the feature request here. -->
