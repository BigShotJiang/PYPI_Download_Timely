from ecole.core.scip import *
