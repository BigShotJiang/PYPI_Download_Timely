from ecole.core.version import *
