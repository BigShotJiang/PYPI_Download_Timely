# Codeit🧑‍💻
Codeit vertion:0.1
<div style="text-align: center;">
  <img src="images\codeit.png" alt="codeit">
</div>

## Requirements
- Python 3.10 only

## Getting started
### Pip

```shell script
$ pip install codeit
```

### Ecode

```shell script
$ pip install Ecode==3.1
$ Ecode pip:codeit
```
## Who is Codeit useful for?
Codeit is made for those who are on the Codeit.ir site and learn Python from there.

## What features does Codeit have?
Codeit is not a package. Codeit is a folder created and uploaded to pypi.org so that all the people
<br> 
who learn Python from Codeit can use it for various tasks.

### What features does version 0.1 have?
- PyCraft (Python + Minecraft) 🌎🧑‍💻
- Micropython 🧑‍💻🧰
- Photograming (Python coding with cv2, pillow, and mediapipe) 📸🧑‍💻

