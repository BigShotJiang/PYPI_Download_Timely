class Codeit:
    def __init__(self):
        pass
    def __vertion__(self):
        print("0.1")

print("Welcome to the codeit!")
