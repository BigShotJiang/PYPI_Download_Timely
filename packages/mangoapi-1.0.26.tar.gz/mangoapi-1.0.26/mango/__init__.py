from .client import Mango

__version__ = "1.0.26"
