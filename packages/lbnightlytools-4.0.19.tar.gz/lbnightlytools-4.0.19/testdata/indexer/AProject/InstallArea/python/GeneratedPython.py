"Generated Python file"
