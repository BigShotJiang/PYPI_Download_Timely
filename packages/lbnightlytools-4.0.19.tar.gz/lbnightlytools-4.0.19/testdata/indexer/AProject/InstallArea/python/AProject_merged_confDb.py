"merged Configurables Db"
