// generated C++ header
