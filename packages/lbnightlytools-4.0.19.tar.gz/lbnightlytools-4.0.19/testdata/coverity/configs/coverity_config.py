from LbNightlyTools.Configuration import Project, Slot

Slot("test-slot", projects=[Project("Test", "HEAD")])
