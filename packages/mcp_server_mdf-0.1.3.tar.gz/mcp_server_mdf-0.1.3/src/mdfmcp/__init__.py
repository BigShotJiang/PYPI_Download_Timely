"""MDF MCP Server - AI-powered MDF file analysis"""

__version__ = "0.1.3"

from .server import MdfMcpServer

__all__ = ["MdfMcpServer"]