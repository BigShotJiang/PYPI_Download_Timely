::: pynspd.errors.PynspdError

::: pynspd.errors.UnknownLayer

::: pynspd.errors.AmbiguousSearchError

::: pynspd.errors.BlockedIP