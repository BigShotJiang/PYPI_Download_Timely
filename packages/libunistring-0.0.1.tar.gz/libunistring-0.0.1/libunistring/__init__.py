# Safe dummy package: libunistring
