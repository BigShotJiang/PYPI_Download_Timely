"""
Description
===========

Base classes for the Abstract Space Project

"""

from .abstr import Abstr

__all__ = [
    "Abstr",
]
