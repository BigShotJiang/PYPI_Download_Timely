
class ActionNotFoundError(Exception):
    pass

class HandlerNotFoundError(Exception):
    pass

class MessageDataNotFoundError(Exception):
    pass
