"""Code generation CLI functions."""

from hera._cli.generate import yaml

__all__ = [
    "yaml",
]
