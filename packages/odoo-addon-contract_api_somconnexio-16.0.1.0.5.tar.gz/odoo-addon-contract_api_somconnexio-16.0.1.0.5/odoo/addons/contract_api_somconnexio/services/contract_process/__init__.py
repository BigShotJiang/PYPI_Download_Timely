from . import (
    base,
    mobile,
    ba,
    adsl,
    fiber,
    router4g,
    switchboard,
)
