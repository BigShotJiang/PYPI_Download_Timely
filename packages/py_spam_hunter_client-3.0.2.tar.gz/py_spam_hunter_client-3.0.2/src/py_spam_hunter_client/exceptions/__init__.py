from .check_exception import CheckException

__all__ = ["CheckException"]
