from robust_gymnasium.envs.robosuite.models.tasks.task import Task


class ManipulationTask(Task):
    """
    A manipulation-specific task. This is currently a future-proofing placeholder.
    """
