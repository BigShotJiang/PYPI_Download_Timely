# Test file for integration tests

# This is a simple test block
print("Hello from main.py")

# Another block with some computation
x = 10
y = 20
print(f"Sum: {x + y}")
