from ._version import __version__
# __init__.py