# buildapi-client
This is a safe dummy PoC package.