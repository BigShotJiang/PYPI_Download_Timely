from antlr4 import Parser


class AtoParserBase(Parser): ...
