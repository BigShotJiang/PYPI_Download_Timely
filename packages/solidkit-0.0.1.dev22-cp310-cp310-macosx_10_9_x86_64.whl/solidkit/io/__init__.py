from ase.io import read, write, Trajectory
