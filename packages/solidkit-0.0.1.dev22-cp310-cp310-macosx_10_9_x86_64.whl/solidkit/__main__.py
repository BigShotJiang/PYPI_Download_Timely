# PYTHON_ARGCOMPLETE_OK
from solidkit.cli.main import main

main()
