# Note: submission_metadata is my designation, not SEC for the header of the Submission tag

document_submission_metadata_dict = {
    'accession':'accession',
    'type':'type',
    'sequence' : 'sequence',
    'filename' : 'filename', 
    'description':'description'
}