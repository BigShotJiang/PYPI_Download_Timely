"""Estructuras de memoria simbólica, subsimbólica y narrativa."""

