from .adapter import EducationAdapter
