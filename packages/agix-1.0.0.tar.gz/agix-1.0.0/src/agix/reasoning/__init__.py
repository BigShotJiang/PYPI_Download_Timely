"""Módulos de razonamiento simbólico y neuro-simbólico."""

