# text_outputter

一个简单的命令行工具，运行后输出预设文本。

## 安装

```bash
pip install .

