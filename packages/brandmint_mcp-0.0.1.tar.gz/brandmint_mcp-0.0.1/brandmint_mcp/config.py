import os
from dotenv import load_dotenv

load_dotenv()

SELLER_WALLET = os.environ["SELLER_WALLET"]