#!/usr/bin/env python3
"""Enable running ctenv as python -m ctenv"""

from ctenv.ctenv import main

if __name__ == "__main__":
    main()
