# Sentence Gestalt Model Library (SGMLIB)

This repository contains a Python implementation of the Sentence Gestalt Model Library (SGMLIB) introduced in St. John & McClelland (1990).

More information to be added.


