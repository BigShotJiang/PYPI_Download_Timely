#
# Copyright 2020, Xiaomi.
# All rights reserved.
# Author: huyumei@xiaomi.com
# 
 

class MessageProcessorFactory:

    def create_processor(self):
        pass
