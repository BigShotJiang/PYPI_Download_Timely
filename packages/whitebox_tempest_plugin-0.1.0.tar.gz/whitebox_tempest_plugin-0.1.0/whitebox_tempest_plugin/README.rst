======================
Whitebox Tempest Tests
======================

This directory contains tests to validate behavior against
TripleO/Director-based deployments.

See the Tempest plugin documentation for information about creating a plugin,
stable API interface, ``TempestPlugin`` class interface, plugin structure, and
how to use plugins: https://docs.openstack.org/tempest/latest/plugin.html
