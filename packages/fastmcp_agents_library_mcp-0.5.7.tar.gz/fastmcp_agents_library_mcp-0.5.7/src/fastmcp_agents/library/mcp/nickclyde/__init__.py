from fastmcp_agents.library.mcp.nickclyde.duckduckgo import duckduckgo_mcp

__all__ = ["duckduckgo_mcp"]
