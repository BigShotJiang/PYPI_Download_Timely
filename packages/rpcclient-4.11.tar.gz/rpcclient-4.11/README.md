# rpcclient

For details about this project please review:
https://github.com/doronz88/rpc-project