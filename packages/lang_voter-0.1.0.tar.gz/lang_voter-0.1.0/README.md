# LANG_VOTER

Voting-based Indian language identification using SVM, RF, SGD, etc.  
Each model uses its own pre-trained TF-IDF vectorizer.

## Installation

```bash
pip install lang-voter
