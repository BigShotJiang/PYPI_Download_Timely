"""Entry point for the micoo application."""
