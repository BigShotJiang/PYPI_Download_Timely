[2025/07/27]

- light mode fixed for mac terminal
- aaa mode added for chat with clipboard copied context

[2025/07/26]

- initial implementation
- terminal with special commands
- rich formatting and console printing
- code generation
- chat
- smart error fixing terminal
- configuration
- arize integration
- optimization for light color mode
