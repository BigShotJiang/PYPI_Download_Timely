# Set up logging configuration with RichHandler for colorful output
