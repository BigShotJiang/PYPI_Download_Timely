from .client import gauge, metric, set_metric, get_metric, get_metrics, get_slugs  # NOQA
