from .page import *  # noqa: F401, F403
# from .faq import *  # noqa: F401, F403
# from .wiki_revision import *  # noqa: F401, F403
