# DEPRECATION WARNING!! DO NOT USE THIS

from ws4redis.client import *

