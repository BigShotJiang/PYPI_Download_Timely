class MissingParametersException(Exception):
    ''' Use it when all parameters are required and there a missing one '''
    pass
