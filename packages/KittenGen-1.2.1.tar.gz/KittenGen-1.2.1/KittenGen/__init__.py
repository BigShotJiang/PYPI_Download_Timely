version = '1.2.1'
author = 'stripe-python'
