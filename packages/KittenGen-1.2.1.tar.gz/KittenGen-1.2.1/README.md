这是一个基于 python3.8 中 flask 框架为自己打造的一个自动造数据机。

下载方法：

```cmd
pip install KittenGen
```

使用方法：

```cmd
python -m KittenGen
```

运行后，访问 [http://127.0.0.1:2025/](http://127.0.0.1:2025/) 即可体验。
