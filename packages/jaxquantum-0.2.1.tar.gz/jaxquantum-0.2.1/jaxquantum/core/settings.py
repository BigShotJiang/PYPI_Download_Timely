"""Core settings."""

SETTINGS = {"auto_tidyup_atol": 1e-14}
