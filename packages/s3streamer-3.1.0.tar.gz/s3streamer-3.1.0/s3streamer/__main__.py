#!/usr/bin/env python3
# -*- coding: latin-1 -*-

"""Stream files to AWS S3 using multipart upload."""
import __init__

if __name__ == "__main__":
    __init__.main()
