__authors__ = ", ".join([
    "Henning Bahl",
    "Johannes Braathen",
    "Martin Gabelmann",
    "Georg Weiglein"
])

__version__ = "0.3.3"
