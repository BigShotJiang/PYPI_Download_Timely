"""
This module defines the version number of the ModelHub SDK.
"""

__version__ = "1.0.3"
