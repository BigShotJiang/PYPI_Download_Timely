# Youtube Autonomous Audio Editor Module

The Audio editor module.

Please, check the 'pyproject.toml' file to see the dependencies.