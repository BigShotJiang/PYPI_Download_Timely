# Testing and deployment utilities for EO4EU

This module is intended to be used for configuring automated test and deployments of components. It is very much work-in-progress at the moment.
