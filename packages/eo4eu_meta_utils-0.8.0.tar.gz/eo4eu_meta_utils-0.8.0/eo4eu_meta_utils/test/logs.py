import logging

logging.basicConfig()
logger = logging.getLogger("eo-test")
logger.setLevel(logging.INFO)