API_BASE_URL = "https://profilage-api.holmium-consulting.com"
HEADERS = {
    "Accept": "application/json",
    "Content-Type": "application/json",
}
