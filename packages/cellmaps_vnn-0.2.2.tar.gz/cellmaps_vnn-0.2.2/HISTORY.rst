=======
History
=======

0.2.2 (2025-07-25)
------------------

* Bug fixes: fixed hyperparameter optimization and generation of config file with optimal parameters

0.2.1 (2025-07-01)
------------------

* Bug fixes: fixed _annotate_interactomes_of_systems method's return value and fix hierarchy annotations

0.2.0 (2025-06-26)
------------------

* Add annotation in hierarchy nodes of which gene have data for VNN (train)
* Add fake generator of gene importance scores in interactomes of hierarchy system (the real generator will be
  implemented in the future)

0.1.0 (2024-12-26)
------------------

* First release on PyPI.
