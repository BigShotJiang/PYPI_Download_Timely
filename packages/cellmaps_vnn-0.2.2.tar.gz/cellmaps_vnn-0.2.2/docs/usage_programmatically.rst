In a project
--------------

To use cellmaps_vnn in a project::

    import cellmaps_vnn

