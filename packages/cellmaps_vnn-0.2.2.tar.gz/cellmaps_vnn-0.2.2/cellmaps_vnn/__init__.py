# -*- coding: utf-8 -*-

"""Top-level package for cellmaps_vnn."""

__author__ = """Cell Maps team"""
__email__ = 'tools@cm4ai.org'
__version__ = '0.2.2'
__repo_url__ = 'https://github.com/idekerlab/cellmaps_vnn'
__description__ = 'Cell Maps Visual Neural Network Toolkit'
