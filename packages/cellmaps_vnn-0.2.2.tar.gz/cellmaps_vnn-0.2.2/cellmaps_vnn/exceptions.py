# -*- coding: utf-8 -*-


class CellmapsvnnError(Exception):
    """
    Base exception for cellmaps_vnn
    """
    pass
