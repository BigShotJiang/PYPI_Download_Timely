"""
Staran Examples Module
包含各种完整的特征工程示例
"""

from .aum_longtail import AUMLongtailExample, create_aum_example, run_aum_example

__all__ = ['AUMLongtailExample', 'create_aum_example', 'run_aum_example']
