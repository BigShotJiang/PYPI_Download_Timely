#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.systemcoupling.core.adaptor.impl.types import *


class get_supported_participant_types(Command):
    """
    Returns a list of participant types that are supported by System Coupling.
    """

    syc_name = "GetSupportedParticipantTypes"
