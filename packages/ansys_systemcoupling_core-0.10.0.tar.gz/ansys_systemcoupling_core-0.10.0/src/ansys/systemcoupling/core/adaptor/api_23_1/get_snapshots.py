#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.systemcoupling.core.adaptor.impl.types import *


class get_snapshots(Command):
    """
    Return a dictionary of available snapshots and metadata associated with
    them.
    """

    syc_name = "GetSnapshots"
