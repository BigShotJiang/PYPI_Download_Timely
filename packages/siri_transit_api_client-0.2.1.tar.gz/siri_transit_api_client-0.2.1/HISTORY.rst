=======
History
=======

0.1.0 (2022-05-20)
------------------

* First version of the code.

0.2.1 (2025-07-27)
------------------

* First release on PyPI.
