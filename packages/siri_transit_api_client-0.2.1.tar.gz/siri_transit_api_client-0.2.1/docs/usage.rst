=====
Usage
=====

To use SIRI Transit API Client in a project::

    import siri_transit_api_client
