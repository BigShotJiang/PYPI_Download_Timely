siri\_transit\_api\_client package
==================================

Submodules
----------

siri\_transit\_api\_client.exceptions module
--------------------------------------------

.. automodule:: siri_transit_api_client.exceptions
   :members:
   :undoc-members:
   :show-inheritance:

siri\_transit\_api\_client.holidays module
------------------------------------------

.. automodule:: siri_transit_api_client.holidays
   :members:
   :undoc-members:
   :show-inheritance:

siri\_transit\_api\_client.lines module
---------------------------------------

.. automodule:: siri_transit_api_client.lines
   :members:
   :undoc-members:
   :show-inheritance:

siri\_transit\_api\_client.operators module
-------------------------------------------

.. automodule:: siri_transit_api_client.operators
   :members:
   :undoc-members:
   :show-inheritance:

siri\_transit\_api\_client.patterns module
------------------------------------------

.. automodule:: siri_transit_api_client.patterns
   :members:
   :undoc-members:
   :show-inheritance:

siri\_transit\_api\_client.siri\_client module
----------------------------------------------

.. automodule:: siri_transit_api_client.siri_client
   :members:
   :undoc-members:
   :show-inheritance:

siri\_transit\_api\_client.stop\_monitoring module
--------------------------------------------------

.. automodule:: siri_transit_api_client.stop_monitoring
   :members:
   :undoc-members:
   :show-inheritance:

siri\_transit\_api\_client.stop\_places module
----------------------------------------------

.. automodule:: siri_transit_api_client.stop_places
   :members:
   :undoc-members:
   :show-inheritance:

siri\_transit\_api\_client.stop\_timetable module
-------------------------------------------------

.. automodule:: siri_transit_api_client.stop_timetable
   :members:
   :undoc-members:
   :show-inheritance:

siri\_transit\_api\_client.stops module
---------------------------------------

.. automodule:: siri_transit_api_client.stops
   :members:
   :undoc-members:
   :show-inheritance:

siri\_transit\_api\_client.timetable module
-------------------------------------------

.. automodule:: siri_transit_api_client.timetable
   :members:
   :undoc-members:
   :show-inheritance:

siri\_transit\_api\_client.vehicle\_monitoring module
-----------------------------------------------------

.. automodule:: siri_transit_api_client.vehicle_monitoring
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: siri_transit_api_client
   :members:
   :undoc-members:
   :show-inheritance:
