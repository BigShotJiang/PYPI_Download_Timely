a = "v1"
print(a.split("v1"))