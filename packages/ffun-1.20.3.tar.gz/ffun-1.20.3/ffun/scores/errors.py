from ffun.core import errors


class Error(errors.Error):
    pass


class NoRuleFound(Error):
    pass


class TagsIntersection(Error):
    pass
