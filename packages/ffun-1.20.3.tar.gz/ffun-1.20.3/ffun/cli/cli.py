# TODO: refactor these commands and move them to application.py

from ffun.cli.application import app  # noqa: F401
from ffun.cli.commands import configs  # noqa: F401
from ffun.cli.commands import entries  # noqa: F401
from ffun.cli.commands import failed_entries  # noqa: F401
from ffun.cli.commands import supertokens  # noqa: F401
from ffun.cli.commands import workers  # noqa: F401
from ffun.cli.commands import yoyo  # noqa: F401

__all__ = ["app"]
