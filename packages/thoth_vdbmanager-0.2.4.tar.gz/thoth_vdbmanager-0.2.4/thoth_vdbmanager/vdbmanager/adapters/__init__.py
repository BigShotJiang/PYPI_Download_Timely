"""Haystack adapters for different vector store implementations."""
