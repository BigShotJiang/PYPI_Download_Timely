from .chain import DependsChain as DependsChain
