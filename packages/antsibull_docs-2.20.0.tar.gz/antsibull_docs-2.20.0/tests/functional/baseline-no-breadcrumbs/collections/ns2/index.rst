:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. _list_of_collections_ns2:

Collections in the Ns2 Namespace
================================

These are the collections documented here in the **ns2** namespace.

* :anscollection:`ns2.col <ns2.col>`
* :anscollection:`ns2.flatcol <ns2.flatcol>`
