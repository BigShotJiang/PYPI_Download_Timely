:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. _list_of_role_plugins:

Index of all Roles
==================

ns2.col
-------

* :ansplugin:`ns2.col.foo#role` -- Foo role :ansdeprecatedmarker:`{"date": "2020-01-01", "version": ""}`
