.. Document meta

:orphan:

.. Anchors

.. _ansible_collections.ns2.col.foo_3_redirect_module:

.. Title

ns2.col.foo_3_redirect module
+++++++++++++++++++++++++++++

.. Collection note

.. note::
    This redirect is part of the `ns2.col collection <https://galaxy.ansible.com/ui/repo/published/ns2/col/>`_ (version 2.1.0).

    To use it in a playbook, specify: :code:`ns2.col.foo_3_redirect`.

- This is a redirect to the :ansplugin:`ns2.col.foo2 module <ns2.col.foo2#module>`.
- This redirect does **not** work with Ansible 2.9.
