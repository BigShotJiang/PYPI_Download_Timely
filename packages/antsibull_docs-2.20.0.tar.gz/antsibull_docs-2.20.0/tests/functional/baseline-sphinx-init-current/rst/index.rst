.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>

.. _docsite_root_index:

Welcome to my Ansible collection documentation
==============================================

This docsite contains documentation of some collections.


.. toctree::
   :maxdepth: 2
   :caption: Collections:

   collections/index


.. toctree::
   :maxdepth: 1
   :caption: Plugin indexes:
   :glob:

   collections/index_*


.. toctree::
   :maxdepth: 1
   :caption: Reference indexes:

   collections/environment_variables
