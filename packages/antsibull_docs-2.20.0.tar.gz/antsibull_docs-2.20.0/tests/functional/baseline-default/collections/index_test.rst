:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. _list_of_test_plugins:

Index of all Test Plugins
=========================

ns.col2
-------

* :ansplugin:`ns.col2.extra#test` --

ns2.col
-------

* :ansplugin:`ns2.col.bar#test` -- Is something a bar
* :ansplugin:`ns2.col.foo#test` -- Is something a foo :ansopt:`ns2.col.foo#test:bar`
