:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. _list_of_stdout_callback_plugins:

Index of all Stdout Callback Plugins
====================================

See :ref:`list_of_callback_plugins` for the list of *all* callback plugins.

ns2.col
-------

* :ansplugin:`ns2.col.foo#callback` -- Foo output :ansopt:`ns2.col.foo#callback:bar`
