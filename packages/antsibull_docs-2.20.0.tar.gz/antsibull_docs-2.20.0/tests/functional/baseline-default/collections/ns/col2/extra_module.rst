.. Document meta section

:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. Document body

.. Anchors

.. _ansible_collections.ns.col2.extra_module:

.. Title

ns.col2.extra module
++++++++++++++++++++


The documentation for the module plugin, ns.col2.extra,  was malformed.

The errors were:

* .. code-block:: text

        82 validation errors for ModuleDocSchema
        doc -> seealso -> 0 -> description
          Field required (type=missing)
        doc -> seealso -> 0 -> link
          Field required (type=missing)
        doc -> seealso -> 0 -> name
          Field required (type=missing)
        doc -> seealso -> 0 -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 0 -> module
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 0 -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 0 -> plugin
          Field required (type=missing)
        doc -> seealso -> 0 -> plugin_type
          Field required (type=missing)
        doc -> seealso -> 0 -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 0 -> module
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 0 -> description
          Field required (type=missing)
        doc -> seealso -> 0 -> ref
          Field required (type=missing)
        doc -> seealso -> 0 -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 0 -> module
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 1 -> description
          Field required (type=missing)
        doc -> seealso -> 1 -> link
          Field required (type=missing)
        doc -> seealso -> 1 -> name
          Field required (type=missing)
        doc -> seealso -> 1 -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 1 -> plugin
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 1 -> plugin_type
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 1 -> module
          Field required (type=missing)
        doc -> seealso -> 1 -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 1 -> plugin
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 1 -> plugin_type
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 1 -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 1 -> description
          Field required (type=missing)
        doc -> seealso -> 1 -> ref
          Field required (type=missing)
        doc -> seealso -> 1 -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 1 -> plugin
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 1 -> plugin_type
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 2 -> link
          Field required (type=missing)
        doc -> seealso -> 2 -> name
          Field required (type=missing)
        doc -> seealso -> 2 -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 2 -> module
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 2 -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 2 -> plugin
          Field required (type=missing)
        doc -> seealso -> 2 -> plugin_type
          Field required (type=missing)
        doc -> seealso -> 2 -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 2 -> module
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 2 -> ref
          Field required (type=missing)
        doc -> seealso -> 2 -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 2 -> module
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 3 -> link
          Field required (type=missing)
        doc -> seealso -> 3 -> name
          Field required (type=missing)
        doc -> seealso -> 3 -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 3 -> plugin
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 3 -> plugin_type
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 3 -> module
          Field required (type=missing)
        doc -> seealso -> 3 -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 3 -> plugin
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 3 -> plugin_type
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 3 -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 3 -> ref
          Field required (type=missing)
        doc -> seealso -> 3 -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 3 -> plugin
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> seealso -> 3 -> plugin_type
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> attributes -> action_group -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> attributes -> action_group -> membership
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> attributes -> action_group -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> attributes -> action_group -> platforms
          Field required (type=missing)
        doc -> attributes -> action_group -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> attributes -> action_group -> membership
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> attributes -> check_mode -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> attributes -> check_mode -> membership
          Field required (type=missing)
        doc -> attributes -> check_mode -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> attributes -> check_mode -> platforms
          Field required (type=missing)
        doc -> attributes -> check_mode -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> attributes -> diff_mode -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> attributes -> diff_mode -> membership
          Field required (type=missing)
        doc -> attributes -> diff_mode -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> attributes -> diff_mode -> platforms
          Field required (type=missing)
        doc -> attributes -> diff_mode -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> attributes -> platform -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> attributes -> platform -> platforms
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> attributes -> platform -> membership
          Field required (type=missing)
        doc -> attributes -> platform -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> attributes -> platform -> platforms
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> attributes -> platform -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> options -> foo -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> options -> subfoo -> suboptions -> foo -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> options -> subfoo -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> extra
          Extra inputs are not permitted (type=extra_forbidden)


File a bug with the `ns.col2 collection <https://galaxy.ansible.com/ui/repo/published/ns/col2/>`_ in order to have it corrected.
