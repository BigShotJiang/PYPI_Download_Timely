.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>


.. _plugins_in_ns.col1:

Ns.Col1
=======


.. contents::
   :local:
   :depth: 1

Description
-----------

A short description.

**Authors:**

* Ansible (https://github.com/ansible)
* Foo Bar (@ansible)
* Test <foo@example.com>





.. toctree::
    :maxdepth: 1

.. _changelog_section_for_ns.col1:

Changelog
---------

.. toctree::
    :maxdepth: 1

    changelog

.. _plugin_index_for_ns.col1:

Plugin Index
------------

There are no plugins in the ns.col1 collection with automatically generated documentation.



.. seealso::

    List of :ref:`collections <list_of_collections>` with docs hosted here.
