:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. _list_of_become_plugins:

Index of all Become Plugins
===========================

ns.col2
-------

* :ansplugin:`ns.col2.extra#become` --

ns2.col
-------

* :ansplugin:`ns2.col.foo#become` -- Use foo :ansopt:`ns2.col.foo#become:bar` :ansdeprecatedmarker:`{"date": "", "version": "5.0.0"}`
