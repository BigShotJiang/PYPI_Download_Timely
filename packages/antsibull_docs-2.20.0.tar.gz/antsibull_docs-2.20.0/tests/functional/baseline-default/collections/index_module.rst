:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. _list_of_module_plugins:

Index of all Modules
====================

ns.col2
-------

* :ansplugin:`ns.col2.extra#module` --
* :ansplugin:`ns.col2.foo#module` --
* :ansplugin:`ns.col2.foo2#module` -- Foo two
* :ansplugin:`ns.col2.foo3#module` -- Foo III
* :ansplugin:`ns.col2.foo4#module` -- Markup reference linting test

ns2.col
-------

* :ansplugin:`ns2.col.foo#module` -- Do some foo :ansopt:`ns2.col.foo#module:bar`
* :ansplugin:`ns2.col.foo2#module` -- Another foo
* :ansplugin:`ns2.col.sub.foo3#module` -- A sub-foo

ns2.flatcol
-----------

* :ansplugin:`ns2.flatcol.foo#module` -- Do some foo :ansopt:`ns2.flatcol.foo#module:bar`
* :ansplugin:`ns2.flatcol.foo2#module` -- Another foo
