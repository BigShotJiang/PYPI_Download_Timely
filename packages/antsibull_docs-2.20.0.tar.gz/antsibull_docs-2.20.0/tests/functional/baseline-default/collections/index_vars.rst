:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. _list_of_vars_plugins:

Index of all Vars Plugins
=========================

ns.col2
-------

* :ansplugin:`ns.col2.extra#vars` --

ns2.col
-------

* :ansplugin:`ns2.col.foo#vars` -- Load foo :ansopt:`ns2.col.foo#vars:bar`
