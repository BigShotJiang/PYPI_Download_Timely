.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>


.. _list_of_collections_ns2:

Collections in the Ns2 Namespace
================================

These are the collections documented here in the **ns2** namespace.

* `ns2.col <namespace/index.rst>`_
* `ns2.flatcol <namespace/index.rst>`_
