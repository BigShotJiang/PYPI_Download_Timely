.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>

Index of all Cliconf Plugins
============================

ns.col2
-------

* `ns.col2.extra <ns/col2/extra_cliconf.rst>`_ --

ns2.col
-------

* `ns2.col.foo <ns2/col/foo_cliconf.rst>`_ -- Foo router CLI config
