.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>

Index of all Vars Plugins
=========================

ns.col2
-------

* `ns.col2.extra <ns/col2/extra_vars.rst>`_ --

ns2.col
-------

* `ns2.col.foo <ns2/col/foo_vars.rst>`_ -- Load foo :literal:`bar` (of vars plugin `ns2.col.foo <foo_vars.rst>`__)
