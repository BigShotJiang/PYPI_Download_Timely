.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>

Index of all Cache Plugins
==========================

ns.col2
-------

* `ns.col2.extra <ns/col2/extra_cache.rst>`_ --

ns2.col
-------

* `ns2.col.foo <ns2/col/foo_cache.rst>`_ -- Foo files :literal:`bar` (of cache plugin `ns2.col.foo <foo_cache.rst>`__)
