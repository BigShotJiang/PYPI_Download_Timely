.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>

Index of all Inventory Plugins
==============================

ns.col2
-------

* `ns.col2.extra <ns/col2/extra_inventory.rst>`_ --

ns2.col
-------

* `ns2.col.foo <ns2/col/foo_inventory.rst>`_ -- The foo inventory :literal:`bar` (of inventory plugin `ns2.col.foo <foo_inventory.rst>`__)
