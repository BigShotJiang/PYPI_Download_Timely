.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>

ns.col2.extra filter
++++++++++++++++++++

The documentation for the filter plugin, ns.col2.extra, was malformed.

The errors were:

* ::

        2 validation errors for PositionalDocSchema
        doc -> options -> _input -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> extra
          Extra inputs are not permitted (type=extra_forbidden)


File a bug with the `ns.col2 collection <https://galaxy.ansible.com/ui/repo/published/ns/col2/>`_ in order to have it corrected.
