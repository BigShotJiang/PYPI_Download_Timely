.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>

ns.col2.extra strategy
++++++++++++++++++++++

The documentation for the strategy plugin, ns.col2.extra, was malformed.

The errors were:

* ::

        1 validation error for PluginDocSchema
        doc -> extra
          Extra inputs are not permitted (type=extra_forbidden)


File a bug with the `ns.col2 collection <https://galaxy.ansible.com/ui/repo/published/ns/col2/>`_ in order to have it corrected.
