.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>

Index of all Become Plugins
===========================

ns.col2
-------

* `ns.col2.extra <ns/col2/extra_become.rst>`_ --

ns2.col
-------

* `ns2.col.foo <ns2/col/foo_become.rst>`_ -- Use foo :literal:`bar` (of become plugin `ns2.col.foo <foo_become.rst>`__) **(DEPRECATED)**
