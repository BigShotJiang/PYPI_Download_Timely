.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>

Index of all Filter Plugins
===========================

ns.col2
-------

* `ns.col2.extra <ns/col2/extra_filter.rst>`_ --

ns2.col
-------

* `ns2.col.bar <ns2/col/bar_filter.rst>`_ -- The bar filter
* `ns2.col.foo <ns2/col/foo_filter.rst>`_ -- The foo filter :literal:`bar` (of filter plugin `ns2.col.foo <foo_filter.rst>`__)
