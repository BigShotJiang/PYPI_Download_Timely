.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>

Index of all Lookup Plugins
===========================

ns.col2
-------

* `ns.col2.extra <ns/col2/extra_lookup.rst>`_ --

ns2.col
-------

* `ns2.col.foo <ns2/col/foo_lookup.rst>`_ -- Look up some foo :literal:`bar` (of lookup plugin `ns2.col.foo <foo_lookup.rst>`__)
