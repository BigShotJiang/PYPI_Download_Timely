.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>

Index of all Stdout Callback Plugins
====================================

See `List of all Callback Plugins <index_callback.rst>`_ for the list of *all* callback plugins.

ns2.col
-------

* `ns2.col.foo <ns2/col/foo_callback.rst>`_ -- Foo output :literal:`bar` (of callback plugin `ns2.col.foo <foo_callback.rst>`__)
