.. Created with antsibull-docs <ANTSIBULL_DOCS_VERSION>

Index of all Connection Plugins
===============================

ns.col2
-------

* `ns.col2.extra <ns/col2/extra_connection.rst>`_ --

ns2.col
-------

* `ns2.col.foo <ns2/col/foo_connection.rst>`_ -- Foo connection :literal:`bar` (of connection plugin `ns2.col.foo <foo_connection.rst>`__)
