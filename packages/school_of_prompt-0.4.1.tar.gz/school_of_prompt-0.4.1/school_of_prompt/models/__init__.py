"""Model integration and auto-detection."""
