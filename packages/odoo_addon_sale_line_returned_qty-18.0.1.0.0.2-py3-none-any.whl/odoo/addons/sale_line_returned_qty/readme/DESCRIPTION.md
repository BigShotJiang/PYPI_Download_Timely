This module adds the quantity returned field in the lines of the sale.
The quantity appears if a return delivery note is created and validated.
