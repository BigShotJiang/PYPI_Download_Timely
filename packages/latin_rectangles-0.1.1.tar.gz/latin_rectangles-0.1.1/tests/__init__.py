"""Tests for the latin_rectangles package."""
