# wing-carrier
Used to send commands between dcc applications with build-in support for the wing-ide.

This will soon be intergrated in my wing-ide-maya project.  If you're looking to get up and running with Maya, please check:
https://github.com/Nathanieljla/wing-ide-maya

If you implement your own DCC Pigeon I'd love collab, to grow this repository. 
