from calita.calita_cli import main

main()