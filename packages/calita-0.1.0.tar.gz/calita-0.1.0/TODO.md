# TODO
- [ ] Add planning in brainstormming phase
- [x] Support MCP for every agent
    - [x] Add GitHub Search MCP Server
    - [x] Add Pypi Search MCP Server
    - [x] Use Exa Search via MCP Server
- [ ] Make information retrieval agentic
- [ ] Accompany unit test for invented MCP Servers