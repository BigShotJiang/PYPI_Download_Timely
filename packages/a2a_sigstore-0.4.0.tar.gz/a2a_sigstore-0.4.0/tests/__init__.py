"""Tests for a2a-sigstore library."""
