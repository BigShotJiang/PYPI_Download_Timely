To use this module, follow these steps:

1.  Navigate to the Calendar App.
2.  Go to Configuration.
3.  Select Export to ICS File.

When exporting, you have two options:

- Specify the maximum date of the calendar you want to export.
- Leave the date field empty to export all events from your calendar.
