This module adds a new wizard that allows you to export odoo calendar
into an .ics file.
