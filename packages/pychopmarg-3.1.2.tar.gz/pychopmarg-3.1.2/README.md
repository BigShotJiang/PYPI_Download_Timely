# PyChOpMarg

Python implementation of COM, as per IEEE 802.3-22 Annex 93A/178A.

- [Documentation](https://pychopmarg.readthedocs.io/en/latest/index.html)
