"""
Various COM parameter configurations used by *PyChOpMarg*.

Original author: David Banas <capn.freako@gmail.com>

Original date:   November 6, 2024

Copyright (c) 2024 David Banas; all rights reserved World wide.
"""
