"""
Execute PyChOpMarg, according to command line arguments given.

Original Author: David Banas <capn.freako@gmail.com>

Original Date:   27 August 2024

Copyright (c) 2024 David Banas; all rights reserved World wide.
"""

# from pychopmarg.cli import cli
# cli()
print("Sorry, the PyChOpMarg package is currently only usable as a library.")
print("It's GUI is currently broken.")
