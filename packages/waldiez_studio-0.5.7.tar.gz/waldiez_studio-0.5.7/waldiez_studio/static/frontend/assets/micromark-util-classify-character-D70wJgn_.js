import{j as r,u as a,a as o}from"./micromark-util-character-DUwsRT9L.js";function t(t){return null===t||r(t)||a(t)?1:o(t)?2:void 0}export{t as c};
