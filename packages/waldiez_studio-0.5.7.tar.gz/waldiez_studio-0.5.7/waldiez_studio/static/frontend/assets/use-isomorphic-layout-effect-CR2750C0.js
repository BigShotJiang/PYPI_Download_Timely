import{r}from"./react-DnjLh4X0.js";var a=r.useLayoutEffect;export{a as i};
