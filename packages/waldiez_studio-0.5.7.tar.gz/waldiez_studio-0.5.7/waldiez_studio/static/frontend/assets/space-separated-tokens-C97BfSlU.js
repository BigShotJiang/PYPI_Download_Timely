function n(n){return n.join(" ").trim()}export{n as s};
