# One template

A **decision record**, created on **July 19, 2025**, about **using just the complex template**

## Status

Accepted, in progress

## Problem

I thought it would be nice to have multiple document types, but every time I pick the simple template, I wish I had all of the extra stuff in the complex template so I can optionally just remove what I don't need.

## Solution

Simplify to just use the complex template.

### Rationale

This probably simplifies things. If not, I can revert.

## Plan

Remove the template option, let it break things, then fix those things.
