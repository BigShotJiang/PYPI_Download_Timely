# <!-- long title (as opposed to short title, which is in the file name) -->

A(n) **<!-- doc type -->**, created on **<!-- date -->**, about **<!-- summary -->**

<!--

Possible doc types include:

- ADR
- Task
- Notes
- Refactor
- Idea
- Bug
- Research task
- Anything else

Not all sections in this template will be necessary for all documents. For simple docs needing only one substantive section, consider using "Description" in lieu of "Prerequisites", "Problem", etc.

-->

## Status

<!--

This could be one or more of the following:

- A draft
- Proposed
- Accepted
- Accepted but not started
- Accepted and in progress
- Completed
- Superseded
- Rescinded
- Anything else

-->

## Prerequisites

<!--

List the other docs that need to be addressed before this one can be addressed.

-->

## Problem



## Solution



### Rationale



### Alternatives considered

<!--

Present ironmen as opposed to strawmen --- the strongest alternatives or dissenting opinions to the chosen solution and rationale. Be sure to thoroughly explain these alternatives --- they might become the chosen solution in the future!

Once these ironmen have been well described, explain why they were not chosen.

-->

## Plan

<!--

The steps required to reach the completion conditions

-->

## Completion conditions

<!--

How will I know this is done?

-->
