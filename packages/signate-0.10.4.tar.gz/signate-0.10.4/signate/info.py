#!/usr/bin/python

NAME = 'SIGNATE CLI'
VERSION = '0.10.4'
