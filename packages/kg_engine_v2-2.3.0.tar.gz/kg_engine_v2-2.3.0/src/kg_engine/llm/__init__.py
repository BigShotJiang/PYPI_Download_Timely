"""LLM interface for Knowledge Graph Engine"""
from .llm_interface import LLMInterface

__all__ = ["LLMInterface"]