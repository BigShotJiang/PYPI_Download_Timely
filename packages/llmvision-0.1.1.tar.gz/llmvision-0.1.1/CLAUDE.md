goal: define a function that takes a string and returns a string broken into tokenized pieces.

then print out the tokenized pieces with a unicode bar separator between each piece to show how an LLM "sees".

make the tokenizer pluggable but provide a default.