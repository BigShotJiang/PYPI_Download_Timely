# License: MIT
# Copyright © 2025 Frequenz Energy-as-a-Service GmbH

"""Package for CLI tool to interact with the trading API."""
