# Frequenz Electricity Trading API Client Release Notes

## Bug Fixes

* Fixed a public order book stream bug where a stream was reused for requests with different start and stop time parameters.
