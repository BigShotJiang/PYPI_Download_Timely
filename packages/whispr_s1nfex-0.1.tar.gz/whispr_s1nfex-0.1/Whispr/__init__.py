def sakyk_labas():
    return "Labas iš PyPI!"
