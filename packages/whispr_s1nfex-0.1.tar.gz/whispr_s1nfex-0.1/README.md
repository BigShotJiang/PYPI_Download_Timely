# Mano pip paketas
Pirmas testinis paketas, kuris sako labas.
