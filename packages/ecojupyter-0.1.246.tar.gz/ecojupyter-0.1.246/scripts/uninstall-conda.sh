rm -rf anaconda3
rm -rf ~/anaconda3
sudo rm -rf /opt/anaconda3
