
AUTH_TOKEN="eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJySUJPYjZZY3p2ZE4xNVpuNHFkUTRLdEQ5VUhyY1dwNWJCT3NaLXpYbXM0In0.eyJleHAiOjE3NTAyMjMyMjMsImlhdCI6MTc1MDE1ODQyMywiYXV0aF90aW1lIjoxNzUwMTU4NDA0LCJqdGkiOiJiNWRkODJhMC1hZTlkLTQ2MTAtODdlOC0yNWI0MzU0OGMzMDQiLCJpc3MiOiJodHRwczovL2FjY291bnRzLmQ0c2NpZW5jZS5vcmcvYXV0aC9yZWFsbXMvZDRzY2llbmNlIiwiYXVkIjoiJTJGZDRzY2llbmNlLnJlc2VhcmNoLWluZnJhc3RydWN0dXJlcy5ldSUyRkQ0UmVzZWFyY2glMkZHcmVlbkRJR0lUIiwic3ViIjoiOWVkMzU2MzgtODY4ZC00NjIwLWEyYmMtZTVlNWQwOTMxMGU5IiwidHlwIjoiQmVhcmVyIiwiYXpwIjoidG9rZW4tZXhjaGFuZ2UtZGVkaWNhdGVkIiwic2Vzc2lvbl9zdGF0ZSI6ImZjZmRhMDA0LTA5MmEtNDQxNS1iZTVjLTk1OTkwYzU2NDI3MSIsImFjciI6IjEiLCJyZWFsbV9hY2Nlc3MiOnsicm9sZXMiOlsiZGVmYXVsdC1yb2xlcy1kNHNjaWVuY2UiLCJvZmZsaW5lX2FjY2VzcyIsInVtYV9hdXRob3JpemF0aW9uIl19LCJyZXNvdXJjZV9hY2Nlc3MiOnsiJTJGZDRzY2llbmNlLnJlc2VhcmNoLWluZnJhc3RydWN0dXJlcy5ldSUyRkQ0UmVzZWFyY2glMkZHcmVlbkRJR0lUIjp7InJvbGVzIjpbIkNhdGFsb2d1ZS1FZGl0b3IiLCJNZW1iZXIiXX19LCJzY29wZSI6Im9wZW5pZCBwcm9maWxlIGVtYWlsIiwic2lkIjoiZmNmZGEwMDQtMDkyYS00NDE1LWJlNWMtOTU5OTBjNTY0MjcxIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsIm5hbWUiOiJHb27Dp2FsbyBGZXJyZWlyYSIsInByZWZlcnJlZF91c2VybmFtZSI6ImdvbmNhbG8uZmVycmVpcmE1MzhhNCIsImdpdmVuX25hbWUiOiJHb27Dp2FsbyIsImZhbWlseV9uYW1lIjoiRmVycmVpcmEiLCJlbWFpbCI6ImdvbmNhbG8uZmVycmVpcmFAc3R1ZGVudC51dmEubmwifQ.Nu2-r1-vbvjwEQ1s7Q1jQpq6YRrhJjBsgCGT66USI4wLPu-k4bhKUl5bU2VEoPS7_7HtPaO8d_hIQ_5NtOhA5WyyCWz2_ayuKtn5l-MsAwFb-DjUyYoBtYxGsDXSQ-8EQs4zg0m5QuEGbeNxtvST-5Y_VAMiSv_bSadu_ySimgNOu_E4f5cRfW2b_baeCZzLS_O6ZgDD8FwrvhaUOLpBKznhkaRXjq8CO_wAaUR-q_F3JDLpyj2HUOkZ99HICkV6QG4fpr-5d4gwAYl8HEfo7IZXB66wYDEImmdHsqTX6ijN_JwydN5_qN-Uiudt7UKT44qa4CvnK3lZAu3wOULu9A.eyJleHAiOjE3NDk2ODkzMjUsImlhdCI6MTc0OTYyNDcyMywiYXV0aF90aW1lIjoxNzQ5NjI0NTY3LCJqdGkiOiI2ZDYyNGMxOS1hMmVhLTQ4NmEtODJkNi1hYzg4YjI4YThlNzgiLCJpc3MiOiJodHRwczovL2FjY291bnRzLmQ0c2NpZW5jZS5vcmcvYXV0aC9yZWFsbXMvZDRzY2llbmNlIiwiYXVkIjoiJTJGZDRzY2llbmNlLnJlc2VhcmNoLWluZnJhc3RydWN0dXJlcy5ldSUyRkQ0UmVzZWFyY2glMkZHcmVlbkRJR0lUIiwic3ViIjoiOWVkMzU2MzgtODY4ZC00NjIwLWEyYmMtZTVlNWQwOTMxMGU5IiwidHlwIjoiQmVhcmVyIiwiYXpwIjoidG9rZW4tZXhjaGFuZ2UtZGVkaWNhdGVkIiwic2Vzc2lvbl9zdGF0ZSI6ImMzNDE2YzgyLTM5MDMtNDUyMy04NzY1LWEyYmM3Y2Y5OGFiNiIsImFjciI6IjEiLCJyZWFsbV9hY2Nlc3MiOnsicm9sZXMiOlsiZGVmYXVsdC1yb2xlcy1kNHNjaWVuY2UiLCJvZmZsaW5lX2FjY2VzcyIsInVtYV9hdXRob3JpemF0aW9uIl19LCJyZXNvdXJjZV9hY2Nlc3MiOnsiJTJGZDRzY2llbmNlLnJlc2VhcmNoLWluZnJhc3RydWN0dXJlcy5ldSUyRkQ0UmVzZWFyY2glMkZHcmVlbkRJR0lUIjp7InJvbGVzIjpbIkNhdGFsb2d1ZS1FZGl0b3IiLCJNZW1iZXIiXX19LCJzY29wZSI6Im9wZW5pZCBwcm9maWxlIGVtYWlsIiwic2lkIjoiYzM0MTZjODItMzkwMy00NTIzLTg3NjUtYTJiYzdjZjk4YWI2IiwiZW1haWxfdmVyaWZpZWQiOnRydWUsIm5hbWUiOiJHb27Dp2FsbyBGZXJyZWlyYSIsInByZWZlcnJlZF91c2VybmFtZSI6ImdvbmNhbG8uZmVycmVpcmE1MzhhNCIsImdpdmVuX25hbWUiOiJHb27Dp2FsbyIsImZhbWlseV9uYW1lIjoiRmVycmVpcmEiLCJlbWFpbCI6ImdvbmNhbG8uZmVycmVpcmFAc3R1ZGVudC51dmEubmwifQ.fNU2cGhBP0aDope7zStAY5zms1yU4l4FUXqZOzeL3mCOYa6i-mA-URNz1gX2AcbXiKyHxNp7F_yS_Z3RDRDFh3ZgwqfhY75WyuBygqWiTl50Cy4DU4VhvLbfL1Cae6jqVOvqxEsfcVAdVwUn4vfNg6S57tabwDJjuYMcaw2MRTLBdvbdvs2Zb5dBp5kaxrUP76Q4SWm5smQjBcdT4TNEMOCA_IAl27WHaT1djkTf0Kllvh0HKCeW5rGE7pk2O2KeaC1WatnsZG5c-5tzYyx5pcmL_nNJWvW8kw8t6DCNsoFcpVTRGskTCrmAvPBTZGiOkT6cU4ItKU4J8tkbN5eI-w"

curl \
--header "Content-Type: application/json" \
--header "Authorization: Bearer $AUTH_TOKEN" \
--location "https://api.d4science.org/gcat/items" \
--data-raw '
{
    "name": "test_goncalo_nb_001",
    "title": "Test Experiment Notebook",
    "license_id": "AFL-3.0",
    "private": "False",
    "notes": "Testing call from environment",
    "url": "None",
    "tags": [
        {
            "name": "Test"
        }
    ],
    "resources": [
        {
            "name": "RO-Crate metadata",
            "url": "https://link-to-metadata",
            "format": "zip"
        }],
    "extras": [
        {
            "key": "Creation Date",
            "value": "2025-06-11"
        },
        {
            "key": "Creator",
            "value": "Gonçalo Ferreira"
        },
        {
            "key": "Creator Email",
            "value": "goncalo.ferreira@student.uva.nl"
        },
        {
            "key": "Creator Name PI (Principal Investigator)",
            "value": "my_orcid"
        },
        {
            "key": "Environment OS",
            "value": "MacOS"
        },
        {
            "key": "Environment Platform",
            "value": "GreenDIGIT"
        },
        {
            "key": "Experiment Dependencies",
            "value": null
        },
        {
            "key": "Experiment ID",
            "value": "experiment_id"
        },
        {
            "key": "GreenDIGIT Node",
            "value": "node_01"
        },
        {
            "key": "Programming Language",
            "value": "python"
        },
        {
            "key": "Project ID",
            "value": "project_id"
        },
        {
            "key": "Session reading metrics",
            "value": "session_reading_metrics"
        },
        {
            "key": "system:type",
            "value": "Experiment"
        }
    ]
}'
