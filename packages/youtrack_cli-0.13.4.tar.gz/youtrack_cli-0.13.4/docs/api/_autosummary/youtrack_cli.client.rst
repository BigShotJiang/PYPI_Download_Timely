youtrack\_cli.client
====================

.. automodule:: youtrack_cli.client


   .. rubric:: Functions

   .. autosummary::

      cleanup_client_manager
      get_client_manager
      reset_client_manager
      reset_client_manager_sync

   .. rubric:: Classes

   .. autosummary::

      HTTPClientManager
