from .fewshotlib import FewShotClassifier
