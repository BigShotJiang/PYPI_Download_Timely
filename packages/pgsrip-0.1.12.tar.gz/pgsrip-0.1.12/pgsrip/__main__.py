from pgsrip.cli import pgsrip

if __name__ == '__main__':
    pgsrip()
