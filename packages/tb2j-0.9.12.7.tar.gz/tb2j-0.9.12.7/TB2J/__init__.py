import importlib.metadata
import TB2J

__version__ = importlib.metadata.version("TB2J")

