def explain(x, y):
    return y - x
