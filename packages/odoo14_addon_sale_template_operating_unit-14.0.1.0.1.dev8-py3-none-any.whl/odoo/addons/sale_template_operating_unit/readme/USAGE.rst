Follow these steps:

#. Create a Sale Order Template.
#. The Default Operating Unit of the User is assigned to the Sale Order Template.
