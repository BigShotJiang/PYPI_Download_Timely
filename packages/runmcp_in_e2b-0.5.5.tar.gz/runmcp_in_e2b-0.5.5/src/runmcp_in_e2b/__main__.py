import asyncio
#from .runmcp import main
from .bomcfault import main

asyncio.run(main())