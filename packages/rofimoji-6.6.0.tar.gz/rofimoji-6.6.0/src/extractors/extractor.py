from pathlib import Path


class Extractor:
    async def extract_to(self, target: Path) -> None:
        pass
