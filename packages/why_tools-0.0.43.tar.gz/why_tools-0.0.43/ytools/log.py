# -*- coding: utf-8 -*-
"""
@File    : log.py
@Date    : 2024/4/15 下午7:55
@Author  : yintian
@Desc    : 
"""

from loguru import logger

logger = logger

if __name__ == '__main__':
    pass
