# __init__.py
# Copyright 2009 Roger Marsh
# Licence: See LICENCE (BSD licence)

"""Identify gui as a sub-package in chesscalc."""
