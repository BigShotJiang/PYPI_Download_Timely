# __init__.py
# Copyright 2023 Roger Marsh
# Licence: See LICENCE (BSD licence)

"""Identify basecore as a sub-package in chesscalc."""
