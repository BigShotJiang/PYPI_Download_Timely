# __init__.py
# Copyright 2024 Roger Marsh
# Licence: See LICENCE (BSD licence)

"""Identify core as a sub-package in chesscalc/legacy."""
