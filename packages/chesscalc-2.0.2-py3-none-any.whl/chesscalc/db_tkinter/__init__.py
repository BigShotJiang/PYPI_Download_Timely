# __init__.py
# Copyright 2023 Roger Marsh
# Licence: See LICENCE (BSD licence)

"""Identify db_tkinter as a sub-package in chesscalc."""
