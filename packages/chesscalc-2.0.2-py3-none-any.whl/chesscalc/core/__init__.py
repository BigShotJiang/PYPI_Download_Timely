# __init__.py
# Copyright 2009 Roger Marsh
# Licence: See LICENCE (BSD licence)

"""Identify core as a sub-package in chesscalc."""
