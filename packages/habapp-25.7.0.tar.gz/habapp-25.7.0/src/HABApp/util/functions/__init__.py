from HABApp.util.functions.min_max import max, min
