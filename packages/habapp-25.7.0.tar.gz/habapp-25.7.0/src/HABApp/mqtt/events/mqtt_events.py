import HABApp


class MqttValueUpdateEvent(HABApp.core.events.ValueUpdateEvent):
    pass


class MqttValueChangeEvent(HABApp.core.events.ValueChangeEvent):
    pass
