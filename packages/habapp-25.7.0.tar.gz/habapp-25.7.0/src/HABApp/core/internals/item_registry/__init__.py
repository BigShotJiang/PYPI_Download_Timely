from .item_registry_item import ItemRegistryItem

# isort: split

from .item_registry import ItemRegistry
