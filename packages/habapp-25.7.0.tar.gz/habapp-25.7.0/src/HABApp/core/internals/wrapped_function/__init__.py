from HABApp.core.internals.wrapped_function.base import WrappedFunctionBase


# isort: split

from HABApp.core.internals.wrapped_function.wrapper import wrap_func
