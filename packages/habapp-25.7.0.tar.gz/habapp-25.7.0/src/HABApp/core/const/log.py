from typing import Final


TOPIC_EVENTS: Final = 'HABApp.EventBus'
