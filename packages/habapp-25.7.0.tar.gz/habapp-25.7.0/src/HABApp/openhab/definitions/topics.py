from typing import Final as _Final


TOPIC_ITEMS: _Final = 'openHAB.Items'
TOPIC_THINGS: _Final = 'openHAB.Things'
