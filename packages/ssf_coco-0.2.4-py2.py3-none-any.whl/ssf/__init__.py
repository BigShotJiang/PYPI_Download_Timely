"""Top-level package for ssf."""

__author__ = """Joe Cool"""
__email__ = 'snoopyjc@gmail.com'
__version__ = '0.2.2'

from .ssf import SSF
