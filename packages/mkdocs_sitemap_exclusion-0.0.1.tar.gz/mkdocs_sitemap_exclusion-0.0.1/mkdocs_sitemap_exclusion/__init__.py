"""This package provides a MkDocs plugin for excluding specific URLs from the generated
sitemap.xml.
"""
