Alpha Input/Output Components
==================================================

API Documentation
---------------------------------------------------------

.. autofunction:: pyterrier_alpha.io.finalized_open

.. autofunction:: pyterrier_alpha.io.finalized_directory

.. autofunction:: pyterrier_alpha.io.download

.. autofunction:: pyterrier_alpha.io.download_stream

.. autofunction:: pyterrier_alpha.io.open_or_download_stream

.. autofunction:: pyterrier_alpha.io.entry_points

.. autofunction:: pyterrier_alpha.io.pyterrier_home

.. autoclass:: pyterrier_alpha.io.HashReader

.. autoclass:: pyterrier_alpha.io.HashWriter

.. autoclass:: pyterrier_alpha.io.TqdmReader

.. autoclass:: pyterrier_alpha.io.CallbackReader

.. autoclass:: pyterrier_alpha.io.MultiReader
