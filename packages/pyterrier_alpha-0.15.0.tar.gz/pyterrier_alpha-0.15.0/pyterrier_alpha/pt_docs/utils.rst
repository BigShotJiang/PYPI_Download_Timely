Other Alpha Utils
==================================================

API Documentation
---------------------------------------------------------

.. autofunction:: pyterrier_alpha.utils.peekable

.. autofunction:: pyterrier_alpha.transformer_repr
