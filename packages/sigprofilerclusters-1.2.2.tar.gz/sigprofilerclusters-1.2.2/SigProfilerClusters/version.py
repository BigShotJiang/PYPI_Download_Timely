
# THIS FILE IS GENERATED FROM SIGPROFILECLUSTERS SETUP.PY
short_version = '1.2.2'
version = '1.2.2'
Update = 'v1.2.2: Updates to variant_caller parameter and plotting improvements'
	
	