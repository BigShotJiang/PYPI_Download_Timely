
Orfs: Open Reading Frames
-------------------------

Utilities to work with open reading frames and coding sequences (e.g. CDS features in gene annotation files).

.. automodule:: pyranges.orfs
    :members:
    :imported-members:

