RangeFrame
----------

The RangeFrame is the parent class of PyRanges. It supports interval-based operations that do not require the data
to contain Chromosome and Strand information. It is a subclass of pandas.DataFrame.

.. autoclass:: pyranges.RangeFrame
   :members:
