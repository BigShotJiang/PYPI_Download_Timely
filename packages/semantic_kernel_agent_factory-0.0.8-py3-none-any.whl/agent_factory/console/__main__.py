from .commands import console

if __name__ == "__main__":
    console()
