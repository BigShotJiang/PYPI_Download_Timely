# evrima.py
The Isle: Evrima RCON made easy, for Python 3.11+.

## Description

A Python package to interact with The Isle: Evrima game servers through RCON protocol.

## Installation

```bash
pip install evrima.py
```

## Usage

This is a placeholder package. Future versions will include functionality for RCON operations.

```python
import evrima.py

# Example usage will be provided in future releases
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.
