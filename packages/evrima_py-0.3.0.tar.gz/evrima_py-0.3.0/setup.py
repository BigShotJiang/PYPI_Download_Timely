"""Setup script for evrima.py package."""

from setuptools import setup

if __name__ == "__main__":
    setup()
