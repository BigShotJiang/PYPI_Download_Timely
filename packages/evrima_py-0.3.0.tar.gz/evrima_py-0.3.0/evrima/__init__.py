"""
evrima.py - The Isle: Evrima RCON made easy for Python
"""

__version__ = "0.3.0"

from .rcon import Client
