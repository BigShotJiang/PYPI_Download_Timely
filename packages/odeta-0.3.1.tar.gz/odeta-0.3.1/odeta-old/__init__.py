# odeta/__init__.py
from .a import database

from .localbase import LocalBase as localbase
from .cloudbase import CloudBase as cloudbase
