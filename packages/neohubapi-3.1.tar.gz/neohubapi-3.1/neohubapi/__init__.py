# SPDX-FileCopyrightText: 2020 Andrius Štikonas <andrius@stikonas.eu>
# SPDX-License-Identifier: LGPL-3.0-or-later
"""neohubapi package."""

from . import neohub  # noqa: F401 # flake8 should ignore this.
