from enum import Enum


class DatabaseType(Enum):
    COSMOSDB = "CosmosDB"
    POSTGRESQL = "PostgreSQL"
