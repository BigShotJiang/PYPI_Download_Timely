# password-generator-kamax

Un petit outil Python pour générer des mots de passe sécurisés, utilisable en ligne de commande ou dans un script Python.

## Fonctionnalités

- Génère des mots de passe sécurisés automatiquement.
- Disponible en ligne de commande.


## Installation

Si tu es dans le dossier du projet :

```bash
pip install password-generator-kamax

rajouter  aux installed apps `'password_generator.apps.PasswordGeneratorConfig',` 
rajouter aux urls   ` path('password/', include('password_generator.urls')),` 
