__version__ = "1.1.2"  # pragma: no cover
