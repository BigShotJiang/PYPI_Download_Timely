SELECT
  st_astext(`t0`.`geog`) AS `tmp`
FROM `t` AS `t0`