SELECT
  COVAR_SAMP(`t0`.`double_col`, `t0`.`double_col`) AS `Covariance_double_col_double_col`
FROM `functional_alltypes` AS `t0`