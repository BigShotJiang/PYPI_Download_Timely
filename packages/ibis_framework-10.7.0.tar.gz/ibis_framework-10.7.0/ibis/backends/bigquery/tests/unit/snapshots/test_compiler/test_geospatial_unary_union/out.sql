SELECT
  st_union_agg(`t0`.`geog`) AS `tmp`
FROM `t` AS `t0`