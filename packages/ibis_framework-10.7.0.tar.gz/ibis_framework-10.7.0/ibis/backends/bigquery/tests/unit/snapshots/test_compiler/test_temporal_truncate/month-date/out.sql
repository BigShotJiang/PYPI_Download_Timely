SELECT
  DATE_TRUNC(`t0`.`a`, MONTH) AS `tmp`
FROM `t` AS `t0`