SELECT
  BIT_XOR(`t0`.`int_col`) AS `BitXor_int_col`
FROM `functional_alltypes` AS `t0`