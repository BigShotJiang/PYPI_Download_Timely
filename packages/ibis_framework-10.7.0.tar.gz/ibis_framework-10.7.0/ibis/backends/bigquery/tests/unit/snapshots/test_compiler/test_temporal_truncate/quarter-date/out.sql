SELECT
  DATE_TRUNC(`t0`.`a`, QUARTER) AS `tmp`
FROM `t` AS `t0`