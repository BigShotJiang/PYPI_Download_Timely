SELECT
  SHA512('test') AS `tmp`