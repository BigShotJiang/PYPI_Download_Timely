SELECT
  DATE_TRUNC(`t0`.`a`, YEAR) AS `tmp`
FROM `t` AS `t0`