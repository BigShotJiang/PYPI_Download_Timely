function f(...args) {
    return sum(...args);
}