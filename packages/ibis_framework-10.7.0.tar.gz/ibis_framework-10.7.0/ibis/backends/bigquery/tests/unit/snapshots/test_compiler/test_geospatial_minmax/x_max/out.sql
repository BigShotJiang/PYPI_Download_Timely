SELECT
  st_boundingbox(`t0`.`geog`).xmax AS `tmp`
FROM `t` AS `t0`