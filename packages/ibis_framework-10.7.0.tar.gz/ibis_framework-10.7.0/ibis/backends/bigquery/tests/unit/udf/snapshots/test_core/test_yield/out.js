function* f(_) {
    yield* [1, 2, 3];
}