SELECT
  DAYOFYEAR(`t0`.`i`) AS `tmp`
FROM `table` AS `t0`