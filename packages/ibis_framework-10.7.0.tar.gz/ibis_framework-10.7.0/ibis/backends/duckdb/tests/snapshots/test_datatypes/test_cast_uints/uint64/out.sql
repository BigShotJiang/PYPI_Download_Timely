SELECT
  CAST("t0"."a" AS UBIGINT) AS "Cast(a, uint64)"
FROM "t" AS "t0"