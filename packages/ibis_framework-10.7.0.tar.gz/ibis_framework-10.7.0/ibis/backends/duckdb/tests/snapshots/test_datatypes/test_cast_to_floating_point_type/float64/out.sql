SELECT
  CAST('1.0' AS DOUBLE) AS "Cast('1.0', float64)"