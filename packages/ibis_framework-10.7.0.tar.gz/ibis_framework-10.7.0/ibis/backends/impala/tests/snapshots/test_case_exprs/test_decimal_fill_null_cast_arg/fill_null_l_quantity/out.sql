SELECT
  COALESCE(`t0`.`l_quantity`, 0) AS `Coalesce((l_quantity, 0))`
FROM `tpch_lineitem` AS `t0`