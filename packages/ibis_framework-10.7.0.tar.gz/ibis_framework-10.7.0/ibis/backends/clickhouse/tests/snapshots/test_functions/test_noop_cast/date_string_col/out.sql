SELECT
  "t0"."date_string_col" AS "date_string_col"
FROM "functional_alltypes" AS "t0"