SELECT
  1 + 2 AS "Add(1, 2)"