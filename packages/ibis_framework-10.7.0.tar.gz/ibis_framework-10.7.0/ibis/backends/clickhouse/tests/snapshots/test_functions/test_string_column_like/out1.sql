SELECT
  "t0"."string_col" LIKE 'foo%' AS "StringSQLLike(string_col, 'foo%')"
FROM "functional_alltypes" AS "t0"