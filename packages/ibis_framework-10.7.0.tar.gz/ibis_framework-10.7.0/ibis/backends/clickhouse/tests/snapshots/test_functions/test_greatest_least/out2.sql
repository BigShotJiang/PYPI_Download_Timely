SELECT
  GREATEST("t0"."int_col", "t0"."bigint_col") AS "Greatest((int_col, bigint_col))"
FROM "functional_alltypes" AS "t0"