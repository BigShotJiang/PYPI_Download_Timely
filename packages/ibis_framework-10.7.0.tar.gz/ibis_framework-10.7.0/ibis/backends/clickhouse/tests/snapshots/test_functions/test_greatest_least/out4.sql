SELECT
  LEAST("t0"."int_col", "t0"."bigint_col") AS "Least((int_col, bigint_col))"
FROM "functional_alltypes" AS "t0"