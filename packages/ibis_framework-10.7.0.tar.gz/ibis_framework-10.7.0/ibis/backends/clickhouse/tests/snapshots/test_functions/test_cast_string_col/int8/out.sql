SELECT
  CAST("t0"."string_col" AS Nullable(Int8)) AS "Cast(string_col, int8)"
FROM "functional_alltypes" AS "t0"