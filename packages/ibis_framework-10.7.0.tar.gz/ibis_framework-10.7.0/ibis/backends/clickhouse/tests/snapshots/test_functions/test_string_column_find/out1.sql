SELECT
  position("t0"."string_col", 'a') - 1 AS "StringFind(string_col, 'a')"
FROM "functional_alltypes" AS "t0"