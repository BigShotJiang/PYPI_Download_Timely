SELECT
  CAST("t0"."string_col" AS String) AS "Cast(string_col, !string)"
FROM "functional_alltypes" AS "t0"