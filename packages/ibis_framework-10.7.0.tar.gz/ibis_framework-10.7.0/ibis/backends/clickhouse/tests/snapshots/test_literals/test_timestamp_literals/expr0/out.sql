SELECT
  parseDateTimeBestEffort('2015-01-01T12:34:56') AS "datetime.datetime(2015, 1, 1, 12, 34, 56)"