SELECT
  -(
    "t0"."float_col"
  ) AS "Negate(float_col)"
FROM "functional_alltypes" AS "t0"