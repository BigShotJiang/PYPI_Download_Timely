SELECT
  'I can''t' AS """I can't"""