SELECT
  *
FROM "functional_alltypes" AS "t0"
WHERE
  "t0"."string_col" IN ('foo', 'bar')