SELECT
  CAST("t0"."timestamp_col" AS DateTime) AS "Cast(timestamp_col, !timestamp)"
FROM "functional_alltypes" AS "t0"