SELECT
  "t0"."id" AS "id"
FROM "functional_alltypes" AS "t0"