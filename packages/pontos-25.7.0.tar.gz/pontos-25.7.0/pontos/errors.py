# SPDX-FileCopyrightText: 2022-2023 Greenbone AG
#
# SPDX-License-Identifier: GPL-3.0-or-later
#


class PontosError(Exception):
    """Base class for all errors originating in pontos"""
