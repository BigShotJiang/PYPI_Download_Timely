"""
Entry point for NIA MCP Server
"""
from .server import run

def main():
    """Main entry point."""
    run()

if __name__ == "__main__":
    main()