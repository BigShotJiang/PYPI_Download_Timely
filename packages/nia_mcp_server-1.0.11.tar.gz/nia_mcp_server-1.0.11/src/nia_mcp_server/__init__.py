"""
NIA MCP Server - Proxy server for NIA Knowledge Agent
"""

__version__ = "1.0.11"