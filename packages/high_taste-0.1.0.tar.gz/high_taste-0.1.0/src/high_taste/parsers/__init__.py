"""AST and diff parsing for taste analysis."""
