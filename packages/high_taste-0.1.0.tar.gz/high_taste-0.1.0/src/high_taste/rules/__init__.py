"""Rule management and pattern matching for taste."""
