"""High-Taste - MCP server for enforcing coding style decisions based on taste and convention."""

__version__ = "0.1.0"
