"""Utility functions for taste."""
