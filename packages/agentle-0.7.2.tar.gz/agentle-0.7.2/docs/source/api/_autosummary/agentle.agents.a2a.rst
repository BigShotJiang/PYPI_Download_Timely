agentle.agents.a2a
==================

.. automodule:: agentle.agents.a2a

   
   .. rubric:: Classes

   .. autosummary::
   
      A2AInterface
   
.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   a2a_interface
   a2a_interface_options
   message_parts
   messages
   models
   notifications
   resources
   tasks
