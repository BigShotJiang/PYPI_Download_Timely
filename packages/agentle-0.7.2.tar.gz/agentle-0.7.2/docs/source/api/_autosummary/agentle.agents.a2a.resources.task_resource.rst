agentle.agents.a2a.resources.task\_resource
===========================================

.. automodule:: agentle.agents.a2a.resources.task_resource

   
   .. rubric:: Functions

   .. autosummary::
   
      run_sync
   
   .. rubric:: Classes

   .. autosummary::
   
      Any
      BaseModel
      ConfigDict
      JSONRPCResponse
      PushNotificationResource
      Task
      TaskGetResult
      TaskManager
      TaskQueryParams
      TaskResource
      TaskSendParams
   