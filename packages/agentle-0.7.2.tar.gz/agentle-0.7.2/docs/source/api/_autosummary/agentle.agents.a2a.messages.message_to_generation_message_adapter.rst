agentle.agents.a2a.messages.message\_to\_generation\_message\_adapter
=====================================================================

.. automodule:: agentle.agents.a2a.messages.message_to_generation_message_adapter

   
   .. rubric:: Classes

   .. autosummary::
   
      Adapter
      AgentPartToGenerationPartAdapter
      AssistantMessage
      Message
      MessageToGenerationMessageAdapter
      UserMessage
   