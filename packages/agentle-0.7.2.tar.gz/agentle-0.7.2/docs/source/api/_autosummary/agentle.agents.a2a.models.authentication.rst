agentle.agents.a2a.models.authentication
========================================

.. automodule:: agentle.agents.a2a.models.authentication

   
   .. rubric:: Functions

   .. autosummary::
   
      Field
   
   .. rubric:: Classes

   .. autosummary::
   
      Authentication
      BaseModel
      Sequence
   