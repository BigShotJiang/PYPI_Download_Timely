agentle.agents.a2a.notifications.task\_push\_notification\_config
=================================================================

.. automodule:: agentle.agents.a2a.notifications.task_push_notification_config

   
   .. rubric:: Classes

   .. autosummary::
   
      BaseModel
      PushNotificationConfig
      TaskPushNotificationConfig
   