agentle.agents.a2a.a2a\_interface\_options
==========================================

.. automodule:: agentle.agents.a2a.a2a_interface_options

   
   .. rubric:: Classes

   .. autosummary::
   
      A2AInterfaceOptions
      BaseModel
   