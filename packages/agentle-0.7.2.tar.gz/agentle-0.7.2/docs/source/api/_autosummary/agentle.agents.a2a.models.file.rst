agentle.agents.a2a.models.file
==============================

.. automodule:: agentle.agents.a2a.models.file

   
   .. rubric:: Functions

   .. autosummary::
   
      Field
      model_validator
   
   .. rubric:: Classes

   .. autosummary::
   
      BaseModel
      File
   