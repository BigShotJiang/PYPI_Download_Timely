agentle.agents.a2a.message\_parts.text\_part
============================================

.. automodule:: agentle.agents.a2a.message_parts.text_part

   
   .. rubric:: Functions

   .. autosummary::
   
      Field
   
   .. rubric:: Classes

   .. autosummary::
   
      BaseModel
      Prompt
      TextPart
   