agentle.agents.a2a.tasks.managment.in\_memory
=============================================

.. automodule:: agentle.agents.a2a.tasks.managment.in_memory

   
   .. rubric:: Functions

   .. autosummary::
   
      cast
      get_or_create_eventloop
      run_coroutine_sync
   
   .. rubric:: Classes

   .. autosummary::
   
      Agent
      AgentPipeline
      AgentTeam
      Any
      AssistantMessage
      GenerationMessageToMessageAdapter
      InMemoryTaskManager
      JSONRPCError
      JSONRPCResponse
      Message
      MessageToGenerationMessageAdapter
      MutableSequence
      Task
      TaskGetResult
      TaskManager
      TaskQueryParams
      TaskSendParams
      TaskState
      TypeVar
      UserMessage
   