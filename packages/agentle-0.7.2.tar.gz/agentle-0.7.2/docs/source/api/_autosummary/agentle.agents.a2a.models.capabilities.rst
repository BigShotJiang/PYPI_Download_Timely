agentle.agents.a2a.models.capabilities
======================================

.. automodule:: agentle.agents.a2a.models.capabilities

   
   .. rubric:: Functions

   .. autosummary::
   
      Field
   
   .. rubric:: Classes

   .. autosummary::
   
      BaseModel
      Capabilities
   