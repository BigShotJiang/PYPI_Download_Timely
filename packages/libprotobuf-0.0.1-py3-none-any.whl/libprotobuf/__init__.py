# Safe dummy package: libprotobuf
