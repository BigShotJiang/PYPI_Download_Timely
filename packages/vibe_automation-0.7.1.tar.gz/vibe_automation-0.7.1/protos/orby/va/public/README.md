All protos in this directory are shared between the SDK and the monorepo. Therefore, only include those that are commonly used to keep the directory clean.
