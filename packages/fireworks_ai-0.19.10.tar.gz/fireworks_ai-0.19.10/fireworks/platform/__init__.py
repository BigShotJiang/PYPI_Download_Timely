from .platform import FireworksPlatform

__all__ = ["FireworksPlatform"]
