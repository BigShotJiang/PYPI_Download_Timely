from .zipapps.download_python import download_python

__all__ = ["download_python"]


if __name__ == "__main__":
    download_python()
