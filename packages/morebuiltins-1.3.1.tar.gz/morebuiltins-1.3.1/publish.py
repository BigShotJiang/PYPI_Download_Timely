import os
import time

os.system("flit publish")
time.sleep(3)
