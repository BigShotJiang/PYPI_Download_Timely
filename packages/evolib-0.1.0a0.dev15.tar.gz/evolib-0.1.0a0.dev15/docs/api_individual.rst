Indiv-Class
============

.. automodule:: evolib.core.individual
   :members:
   :undoc-members:
   :show-inheritance:
