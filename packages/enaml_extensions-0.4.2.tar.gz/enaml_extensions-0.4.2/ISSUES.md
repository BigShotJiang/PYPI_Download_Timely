1. Column should transparently work if object is a dict (use the key as a dict key)
1. if no columns given to the Table, columns should be generated automatically given the first object's attributes or keys(in case of list of dicts)
1. application bootstrap
1. FIX: Column object should be refactored outside the qt subpackage

