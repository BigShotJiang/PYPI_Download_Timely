from moonfish.lib import search_move

__all__ = ["search_move"]
