from leximpact_dotations_back.main import logger  # noqa: F401 (called outside)
