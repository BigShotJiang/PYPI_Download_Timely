import zxsecurity
import zxsecurity.initializer
import zxsecurity.modules
import zxsecurity.modules.utils
import zxsecurity.modules.utils.auto_hook

zxsecurity.modules.utils.auto_hook.inject()