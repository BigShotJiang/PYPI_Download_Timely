# memegen/__init__.py

from .meme import to_meme_case

__all__ = ['to_meme_case']
