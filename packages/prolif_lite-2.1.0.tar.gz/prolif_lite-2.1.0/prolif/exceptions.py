class RunRequiredError(RuntimeError):
    pass
