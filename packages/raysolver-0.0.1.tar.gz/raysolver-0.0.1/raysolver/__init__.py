# Placeholder module for the RaySolver project
__version__ = "0.0.1"
