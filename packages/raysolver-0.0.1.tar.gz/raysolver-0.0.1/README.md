# RaySolver

RaySolver is a forthcoming open-source Python package for ray tracing and optical analysis.

This is a placeholder release to reserve the name on PyPI.
