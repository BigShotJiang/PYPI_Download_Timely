
from . import cli

cli()
