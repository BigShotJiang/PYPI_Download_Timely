# PyDunk
A package for communicating with Apple's Grand Slam Authentication.

Heavily based off [JJTech0130's](https://github.com/JJTech0130) [grandslam](https://github.com/JJTech0130/grandslam) library that I personally cleaned up.
