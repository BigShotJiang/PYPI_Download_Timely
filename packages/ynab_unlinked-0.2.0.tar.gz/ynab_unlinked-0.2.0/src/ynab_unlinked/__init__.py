# SPDX-FileCopyrightText: 2025-present Juanpe Araque <juanpe@committhatline.com>
#
# SPDX-License-Identifier: MIT

import typer

app = typer.Typer(no_args_is_help=True)
