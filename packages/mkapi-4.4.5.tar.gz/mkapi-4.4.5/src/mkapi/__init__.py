"""MkAPI is a plugin for MkDocs, designed to generate API documentation."""
