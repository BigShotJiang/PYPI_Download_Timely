=======
Credits
=======

Development Lead
----------------

* Joe Cool <snoopyjc@gmail.com>

Based on the work done by SheetJSDev (https://sheetjs.com/) community edition
SpreadSheet Format (https://github.com/SheetJS/ssf).

Contributors
------------

None yet. Why not be the first?
