dataclass\_wizard.wizard\_cli package
=====================================

Submodules
----------

dataclass\_wizard.wizard\_cli.cli module
----------------------------------------

.. automodule:: dataclass_wizard.wizard_cli.cli
   :members:
   :undoc-members:
   :show-inheritance:

dataclass\_wizard.wizard\_cli.schema module
-------------------------------------------

.. automodule:: dataclass_wizard.wizard_cli.schema
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: dataclass_wizard.wizard_cli
   :members:
   :undoc-members:
   :show-inheritance:
