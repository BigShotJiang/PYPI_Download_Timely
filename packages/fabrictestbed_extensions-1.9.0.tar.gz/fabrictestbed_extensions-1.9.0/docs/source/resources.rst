resources
=========

.. automodule:: fabrictestbed_extensions.fablib.resources
   :members:

.. autoclass:: fabrictestbed_extensions.fablib.resources.Resources
   :members:
   :no-index:
   :special-members: __str__

.. autoclass:: fabrictestbed_extensions.fablib.resources.Links
   :members:
   :no-index:
   :special-members: __str__

.. autoclass:: fabrictestbed_extensions.fablib.resources.FacilityPorts
   :members:
   :no-index:
   :special-members: __str__
