fablib
======

.. automodule:: fabrictestbed_extensions.fablib.fablib
   :members:

.. autoclass:: fabrictestbed_extensions.fablib.fablib.FablibManager
   :members:
   :no-index:
   :special-members: __str__
