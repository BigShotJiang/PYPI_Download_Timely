artifact
========

.. automodule:: fabrictestbed_extensions.fablib.artifact
   :members:

.. autoclass:: fabrictestbed_extensions.fablib.artifact.Artifact
   :members:
   :no-index:
   :special-members: __str__
