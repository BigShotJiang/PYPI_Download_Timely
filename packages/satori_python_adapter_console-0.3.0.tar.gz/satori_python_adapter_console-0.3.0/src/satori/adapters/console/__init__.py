from .main import ConsoleAdapter as ConsoleAdapter
