# Trelia

Trelia is a Python package developed by Aegletek to rate submission code by submitting to different llms. It analyzes code and provides a score out of 5, along with concise feedback.

## Features

- Uses llms to evaluate code quality
- Gives a rating out of 5
- Provides short feedback (10–15 letters)

## Installation

```bash
pip install trelia
