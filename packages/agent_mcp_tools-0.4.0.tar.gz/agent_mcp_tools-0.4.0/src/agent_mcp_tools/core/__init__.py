"""Core business logic for Agent MCP Tools.

This package contains the core business logic separated from interface/transport layers.
"""
