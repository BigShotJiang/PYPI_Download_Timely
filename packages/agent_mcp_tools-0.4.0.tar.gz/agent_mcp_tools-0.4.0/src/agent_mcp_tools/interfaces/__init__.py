"""Interface layers for Agent MCP Tools.

This package contains CLI, server, and other interface implementations.
"""
