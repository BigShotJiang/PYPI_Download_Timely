import json
import sys

from jl95terceira.pytools import jsonbeau

if __name__ == '__main__': jsonbeau.main(indent=None)
