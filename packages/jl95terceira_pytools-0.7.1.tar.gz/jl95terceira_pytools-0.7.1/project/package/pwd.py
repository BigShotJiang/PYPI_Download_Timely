import os

def main():
    print(os.getcwd(),end='')

if __name__ == '__main__': main()
