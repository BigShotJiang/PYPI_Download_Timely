DOCUMENTED_ROUTES = []

def register_route(meta: dict):
    DOCUMENTED_ROUTES.append(meta)
