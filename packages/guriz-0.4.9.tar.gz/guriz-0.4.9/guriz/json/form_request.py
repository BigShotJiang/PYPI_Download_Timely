from pydantic import BaseModel

class FormRequest(BaseModel):
    """Classe base para requests, usada nas rotas/documentação."""
    pass
