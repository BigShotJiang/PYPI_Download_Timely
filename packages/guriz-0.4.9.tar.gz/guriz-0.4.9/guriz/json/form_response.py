from pydantic import BaseModel

class FormResponse(BaseModel):
    """Classe base para respostas, para padronizar retornos."""
    pass
