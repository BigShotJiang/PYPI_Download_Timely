"""Zeus legacy batch size optimizer.

In order to reproduce the paper's result, use this legacy code.
To actually use the batch size optimizer, use the `zeus.optimizer.batch_size`
"""
