from lfo._lfo import LFO  # noqa: F401
