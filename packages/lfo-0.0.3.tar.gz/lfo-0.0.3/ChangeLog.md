# v0.0.3

- when misunderstanding return data leads to a memory leak

# v0.0.2

lfo - A low frequency oscillator for python, to control all kinds of things
(mostly in game projects)


