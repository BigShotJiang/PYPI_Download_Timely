## Workflow to assemble and sort COVID sequencing reads

### Long form description here
