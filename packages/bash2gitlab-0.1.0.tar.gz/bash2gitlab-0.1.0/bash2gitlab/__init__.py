__all__ = ["process_uncompiled_directory"]

from bash2gitlab.compile_all import process_uncompiled_directory
