"""AI Bootstrap - A CLI tool for scaffolding AI/ML projects."""

__version__ = "0.1.0"
__author__ = "Soham Chaudhari"
__email__ = "sohamrc08@gmail.com"