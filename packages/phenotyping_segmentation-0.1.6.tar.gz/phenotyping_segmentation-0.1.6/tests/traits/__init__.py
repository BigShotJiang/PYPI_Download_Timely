import tests.traits
