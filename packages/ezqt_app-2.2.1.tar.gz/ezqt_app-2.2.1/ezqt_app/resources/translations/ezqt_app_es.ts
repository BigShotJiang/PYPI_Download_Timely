<?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="es_ES">
<context>
    <name>EzQt_App</name>
    <message>
        <source>Home</source>
        <translation>Inicio</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <source>Theme</source>
        <translation>Tema</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <source>Notifications</source>
        <translation>Notificaciones</translation>
    </message>
    <message>
        <source>Auto Save</source>
        <translation>Guardado automático</translation>
    </message>
    <message>
        <source>Save Interval</source>
        <translation>Intervalo de guardado</translation>
    </message>
    <message>
        <source>minutes</source>
        <translation>minutos</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Claro</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Oscuro</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Inglés</translation>
    </message>
    <message>
        <source>Français</source>
        <translation>Francés</translation>
    </message>
    <message>
        <source>Español</source>
        <translation>Español</translation>
    </message>
    <message>
        <source>Choose the application theme</source>
        <translation>Elegir el tema de la aplicación</translation>
    </message>
    <message>
        <source>Interface language</source>
        <translation>Idioma de la interfaz</translation>
    </message>
    <message>
        <source>Enable system notifications</source>
        <translation>Activar notificaciones del sistema</translation>
    </message>
    <message>
        <source>Automatically save modifications</source>
        <translation>Guardar automáticamente las modificaciones</translation>
    </message>
    <message>
        <source>Interval between automatic saves</source>
        <translation>Intervalo entre guardados automáticos</translation>
    </message>
    <message>
        <source>Active Theme</source>
        <translation>Tema activo</translation>
    </message>
    <message>
        <source>MyApplication</source>
        <translation>MiAplicación</translation>
    </message>
    <message>
        <source>This is an example description</source>
        <translation>Esta es una descripción de ejemplo</translation>
    </message>
</context>
</TS>