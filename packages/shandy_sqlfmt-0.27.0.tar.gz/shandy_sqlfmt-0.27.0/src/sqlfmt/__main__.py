from sqlfmt.cli import sqlfmt

sqlfmt()
