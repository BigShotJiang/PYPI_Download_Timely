"""Exceptions for the Dana sandbox."""


class SandboxError(Exception):
    """Base exception for Dana sandbox errors."""

    pass
