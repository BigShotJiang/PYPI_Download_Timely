=======
Credits
=======

Development Lead
----------------

* Adam Friedman <tintoy@tintoy.io>

Contributors
------------

* Piotr Maślanka <pmaslanka@smok.co>
* Vacant0mens
