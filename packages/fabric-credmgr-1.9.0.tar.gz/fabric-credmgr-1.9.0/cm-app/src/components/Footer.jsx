import React from "react";

const Footer = () => {
  return <div className="app-footer bg-light">© FABRIC {new Date().getFullYear()}</div>;
}

export default Footer;