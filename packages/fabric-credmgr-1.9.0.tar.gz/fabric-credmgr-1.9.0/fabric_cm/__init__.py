__version__ = "1.9.0"
__API_REFERENCE__ = "https://github.com/fabric-testbed/CredentialManager"
