"""REPL module for aceiot-models-cli."""

from .core import AceIoTRepl

__all__ = ["AceIoTRepl"]
