"""ACE IoT Models CLI - Command line interface for ACE IoT API."""

from .cli import main

__version__ = "0.1.0"

__all__ = ["main"]
