DEFAULT_TAXONOMY_URL = "https://dev.api.agrobiota.biotrop.agr.br/v1/gw/biotax/taxids"

DEFAULT_CONNECTION_STRING_HEADER = "x-mycelium-connection-string"

DEFAULT_CUSTOMERS_API_URL = (
    "https://dev.api.agrobiota.biotrop.agr.br/v1/gw/customers-api"
)
