# aluratemp
**aluratemp** é um simples conversor de temperatura
Celsius-Fahrenheit (e vice-versa) escrito em Python.
# Funções
* `celsius_para_fahrenheit(temp_em_celsius)` - Recebe valor float em Celsius e
retorna valor float em Fahrenheit
* `fahrenheit_para_celsius(temp_em_fahrenheit)` - Recebe valor float em Fahrenheit
e retorna valor em Celsius