from .svgutils import svg_to_points
