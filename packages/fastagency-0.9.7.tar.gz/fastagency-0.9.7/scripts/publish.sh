#!/usr/bin/env bash

hatch clean
hatch build
hatch publish
