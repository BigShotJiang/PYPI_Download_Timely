"""edi-cli: A modern, developer-friendly CLI for parsing and testing EDI files."""

__version__ = "0.1.0"