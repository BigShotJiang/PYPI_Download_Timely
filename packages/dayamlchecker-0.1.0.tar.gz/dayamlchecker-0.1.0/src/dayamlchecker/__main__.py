from .yaml_structure import main

main()
