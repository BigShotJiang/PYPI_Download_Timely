"""Hatchet client and configuration."""

from hatchet_sdk import Hatchet

hatchet = Hatchet()
