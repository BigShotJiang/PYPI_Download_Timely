"""Tests for the foo module."""


def test_foo() -> None:
    """Test the foo function."""
    assert True
