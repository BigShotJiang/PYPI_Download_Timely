import urllib.parse

from scloud_api.base import Client