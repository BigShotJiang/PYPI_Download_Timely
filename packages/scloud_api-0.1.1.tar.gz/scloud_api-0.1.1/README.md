# scloud_api

A python module to interface with the Seller Cloud API

## Installation

```bash
pip install scloud_api