# Documentation

This is documentation for the sample project used in testing.

## Features

- Context providers
- Source code analysis
- Conversation history management

## Testing

This project is designed to test SourceCodeProvider functionality with realistic project structures. 