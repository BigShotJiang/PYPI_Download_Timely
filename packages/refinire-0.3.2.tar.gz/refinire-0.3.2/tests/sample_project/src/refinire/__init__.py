"""
Refinire Package
Refinireパッケージ

This is a test package for SourceCodeProvider testing.
SourceCodeProviderのテスト用パッケージです。
"""

__version__ = "0.1.0" 