To publish new version on pypi:
```
uv build
uv publish
```
