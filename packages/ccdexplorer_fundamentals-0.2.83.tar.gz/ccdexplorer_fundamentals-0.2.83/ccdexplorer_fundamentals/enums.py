
from enum import Enum

class NET(Enum):
    MAINNET = 'mainnet'
    TESTNET = 'testnet'
