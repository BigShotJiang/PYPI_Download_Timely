"""Setup script for jsdoc-parser package."""

from setuptools import setup

setup()