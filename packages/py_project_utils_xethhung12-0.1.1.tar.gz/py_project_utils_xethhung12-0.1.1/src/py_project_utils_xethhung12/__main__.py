from py_project_utils_xethhung12._cmd import run
if __name__ == "__main__":
    run.main()