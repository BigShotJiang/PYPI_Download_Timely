from ___project_name___._cmd import run
if __name__ == "__main__":
    run.main()