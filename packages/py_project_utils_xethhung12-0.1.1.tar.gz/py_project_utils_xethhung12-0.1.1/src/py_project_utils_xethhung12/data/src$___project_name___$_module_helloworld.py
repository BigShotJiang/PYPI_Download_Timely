def hello(user: str):
    print(f"hello {user}!")