# version guidance from https://stackoverflow.com/a/56331414
from importlib.metadata import version

__version__ = version("punchpipe")
