Control Segment Design
=========================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   states
   configuration
