def init():
    """Initialize the chat history list as a global var"""
    global chat_history
    chat_history = []
