from maths_add.fraction import code
from maths_add.fraction import example_decimal

hf = code.Hf()
