#encoding:utf-8

import maths_add.geometry.two_dimensional_graphics.perimeter
import maths_add.geometry.two_dimensional_graphics.area
import maths_add.geometry.two_dimensional_graphics.circumference
import maths_add.geometry.three_dimensional_graphics.sum_of_edge_Lengths
import maths_add.geometry.three_dimensional_graphics.surface_area
import maths_add.geometry.three_dimensional_graphics.volume

