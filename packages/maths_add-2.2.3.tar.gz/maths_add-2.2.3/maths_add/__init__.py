# encoding:utf-8

from maths_add.advanced_computation import *
from maths_add.computation import *
from maths_add.geometry import *
import maths_add.advanced_computation
import maths_add.computation
import maths_add.geometry

__version__ = 2.0
__modelName__ = "maths_add"
