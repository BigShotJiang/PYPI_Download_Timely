from ..types.order import Order

#
# Constants
#

descending = Order()
ascending = Order()
