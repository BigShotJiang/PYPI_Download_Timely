from ..types.shape import Shape

#
# Constants
#

arrowdown = Shape()
arrowup = Shape()
circle = Shape()
cross = Shape()
diamond = Shape()
flag = Shape()
labeldown = Shape()
labelup = Shape()
square = Shape()
triangledown = Shape()
triangleup = Shape()
xcross = Shape()
