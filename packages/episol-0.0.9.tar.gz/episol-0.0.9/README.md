This is the Python interface for episol

Includes:
* setting up and running 3DRISM commands
* Placement of waters 
* post-processing and selection tools  

