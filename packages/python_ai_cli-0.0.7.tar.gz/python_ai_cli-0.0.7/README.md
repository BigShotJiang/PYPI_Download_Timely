# AI CLI

<img alt="AI CLI demo" src="docs/demo.gif" />
