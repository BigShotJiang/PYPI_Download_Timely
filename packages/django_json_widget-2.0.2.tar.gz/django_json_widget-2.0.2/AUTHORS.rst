=======
Credits
=======

Development Lead
----------------

* José Manuel Rivas (jmrivas86) <jmrivas86@gmail.com>

Contributors
------------

* Knut Hühne (k-nut)
* Qiying Wang (WqyJh)
* Erkin Çakar (travijuu)
* Vinay Pai (vinaypai)
* Pedro Miguel Correia (pedroma)
* Artur BarseghyanArtur Barseghyan (barseghyanartur)
* Alexandre Voiney (avoiney)
* Michał Bielawski (D3X)
* Arcuri Davide (dadokkio)
* Ling Li (lingster)
* Steven Mapes (StevenMapes)
* Stefan Wehrmeyer (stefanw)
* Michał Bielawski (D3X)
* Ashok Argent-Katwala (ashokdelphia)
* Chris Culhane (cfculhane)
* Amar Sahinovic (amarsahinovic)
* Erfan Arefmehr (erfan-rfmhr)
