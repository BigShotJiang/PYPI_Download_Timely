__version__ = "5.1.9"


VERSION = __version__.split(".")
