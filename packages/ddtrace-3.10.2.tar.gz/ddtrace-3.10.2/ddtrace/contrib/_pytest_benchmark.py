"""
The pytest-benchmark integration traces executions of pytest benchmarks.
"""
