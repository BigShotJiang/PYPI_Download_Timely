# ruff: noqa: F401
from .search import search
