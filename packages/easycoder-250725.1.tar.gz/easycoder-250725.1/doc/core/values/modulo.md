# modulo

## Syntax:
`modulo {value}`

## Examples:
`print Value modulo 10`

## Description:
Computes the remainder after dividing a numeric value by the value given.

Next: [newline](newline.md)  
Prev: [modification](modification.md)

[Back](../../README.md)
