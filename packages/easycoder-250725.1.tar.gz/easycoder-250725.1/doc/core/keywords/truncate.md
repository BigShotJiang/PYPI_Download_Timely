# truncate

## Syntax:
`truncate {file}`

## Example:
``open File `file.txt` for writing``
`truncate File`

## Description:
Truncate a file

Next: [unlock](variable.md)  
Prev: [toggle](toggle.md)

[Back](../../README.md)
