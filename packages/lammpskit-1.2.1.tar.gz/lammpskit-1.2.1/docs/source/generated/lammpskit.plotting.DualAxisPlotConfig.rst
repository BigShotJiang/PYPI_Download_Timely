lammpskit.plotting.DualAxisPlotConfig
=====================================

.. currentmodule:: lammpskit.plotting

.. autoclass:: DualAxisPlotConfig

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~DualAxisPlotConfig.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~DualAxisPlotConfig.alpha
      ~DualAxisPlotConfig.fontsize_labels
      ~DualAxisPlotConfig.fontsize_legend
      ~DualAxisPlotConfig.fontsize_ticks
      ~DualAxisPlotConfig.fontsize_title
      ~DualAxisPlotConfig.format
      ~DualAxisPlotConfig.legend_framealpha
      ~DualAxisPlotConfig.linewidth
      ~DualAxisPlotConfig.marker
      ~DualAxisPlotConfig.markersize
      ~DualAxisPlotConfig.primary_color
      ~DualAxisPlotConfig.primary_legend_loc
      ~DualAxisPlotConfig.secondary_color
      ~DualAxisPlotConfig.secondary_legend_loc
      ~DualAxisPlotConfig.tight_layout
   
   