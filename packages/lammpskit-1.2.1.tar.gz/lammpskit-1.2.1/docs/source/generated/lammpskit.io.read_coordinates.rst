lammpskit.io.read\_coordinates
==============================

.. currentmodule:: lammpskit.io

.. autofunction:: read_coordinates