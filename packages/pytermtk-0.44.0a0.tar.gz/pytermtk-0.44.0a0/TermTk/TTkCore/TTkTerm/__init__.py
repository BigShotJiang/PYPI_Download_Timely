from .inputkey   import *
from .inputmouse import *
# from .colors     import *
from .input      import *
from .term       import *
