"""
Service modules for various Ghana-based APIs.
"""

from .nalo_solutions import NaloSolutions

__all__ = [
    "NaloSolutions",
]
