# -*- coding: utf-8 -*-
# @Time    : 2025-07-24 16:49
# @Author  : luyi
from setuptools import setup

setup(
    name="utox",
    version="0.0.1",
    author="ly",
    author_email="2662017230@qq.com",
    description="my utils",
    url="https://github.com/bme6/utox",
    # 你要安装的包，通过 setuptools.find_packages 找到当前目录下有哪些包
    # packages=find_packages(exclude=['core', '__pycache__']),
    packages=["utox"],
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "License :: OSI Approved :: Apache Software License",
    ],
    zip_safe=False,
)
