#[doc(hidden)]
pub const _ALIGNBYTES: usize = 7;

pub const _MAX_PAGE_SHIFT: u32 = 14;
