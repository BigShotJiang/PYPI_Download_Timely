ENERGY_PLUS_LOCATION = "../../../../../Applications/EnergyPlus-22-2-0"
IDD_PATH = f"{ENERGY_PLUS_LOCATION}/Energy+.idd"
IDF_PATH = f"cases/base/01example/Minimal_AP.idf"  

# WEATHER_FILE = "weather/CA_PALO-ALTO-AP_724937S_20.epw"
WEATHER_FILE =  "weather_data/PALO_ALTO/CA_PALO-ALTO-AP_724937_23.EPW"
