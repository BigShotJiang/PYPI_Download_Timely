# zfnet

![PyPI version](https://img.shields.io/pypi/v/zfnet.svg)
[![Documentation Status](https://readthedocs.org/projects/zfnet/badge/?version=latest)](https://zfnet.readthedocs.io/en/latest/?version=latest)

Zebrafish functional connectivity toolkit

* Free software: MIT License
* Documentation: https://zfnet.readthedocs.io.

## Features

* TODO

## Credits

This package was created with [Cookiecutter](https://github.com/audreyfeldroy/cookiecutter) and the [audreyfeldroy/cookiecutter-pypackage](https://github.com/audreyfeldroy/cookiecutter-pypackage) project template.
