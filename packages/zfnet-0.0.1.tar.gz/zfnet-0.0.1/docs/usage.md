# Usage

To use zfnet in a project:

```python
import zfnet
```
