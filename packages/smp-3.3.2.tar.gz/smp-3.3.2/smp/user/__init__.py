"""Users may define their own management groups starting at GroupId 64."""
