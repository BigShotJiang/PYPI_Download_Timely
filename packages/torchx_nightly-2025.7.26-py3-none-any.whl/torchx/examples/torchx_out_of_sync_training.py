#!/usr/bin/env python3
# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the BSD-style license found in the
# LICENSE file in the root directory of this source tree.

# pyre-strict

# This file is for lex team to ramp up on torchX OSS. It's for training purpose.
# Please DO NOT modify this file unless you know what you are doing.
