FAASMCTL_VERSION = "0.1.16"


def get_version():
    return FAASMCTL_VERSION
