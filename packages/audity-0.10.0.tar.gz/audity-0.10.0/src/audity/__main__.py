# MIT License
# Copyright (c) 2025 espehon
import sys
from audity import main

if __name__ == "__main__":
    sys.exit(main())