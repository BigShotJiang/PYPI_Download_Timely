# audity
Audit, inspect, and survey data from the terminal.
