class Modeler:
    def __init__(self):
        self.version = None
