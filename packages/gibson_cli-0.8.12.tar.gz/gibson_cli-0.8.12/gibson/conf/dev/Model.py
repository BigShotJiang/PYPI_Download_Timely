class Model:
    def __init__(self, path=None):
        self.path = path
