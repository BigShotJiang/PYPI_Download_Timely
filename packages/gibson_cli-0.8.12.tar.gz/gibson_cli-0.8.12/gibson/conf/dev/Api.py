class Api:
    def __init__(self, path=None, prefix=None, version=None):
        self.path = path
        self.prefix = prefix
        self.version = version
