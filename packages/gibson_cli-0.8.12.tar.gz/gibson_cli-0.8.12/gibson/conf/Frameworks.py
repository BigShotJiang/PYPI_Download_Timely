class Frameworks:
    def __init__(self):
        self.api = None
        self.model = None
        self.revision = None
        self.schema = None
        self.test = None
