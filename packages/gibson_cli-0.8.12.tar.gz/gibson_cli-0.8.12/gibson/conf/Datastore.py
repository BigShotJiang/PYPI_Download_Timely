class Datastore:
    def __init__(self):
        self.type = None
        self.uri = None
