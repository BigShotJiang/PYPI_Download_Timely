class Api:
    def __init__(self):
        self.key = None
