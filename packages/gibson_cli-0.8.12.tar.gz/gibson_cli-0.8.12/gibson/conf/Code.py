from .Custom import Custom
from .Frameworks import Frameworks


class Code:
    def __init__(self):
        self.custom = Custom()
        self.frameworks = Frameworks()
        self.language = None
