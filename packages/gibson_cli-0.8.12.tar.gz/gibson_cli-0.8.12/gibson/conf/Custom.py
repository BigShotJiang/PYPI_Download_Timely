class Custom:
    def __init__(self):
        self.model_class = None
        self.model_path = None
