class ConfigPaths:
    def __init__(self):
        self.auth = None
        self.config = None
        self.top = None


class ProjectPaths:
    def __init__(self):
        self.config = None
        self.memory = None
        self.top = None
