This module introduces the following features:

* Adds the Operating Unit (OU) to the Employee Contract.

* Security rules are defined to ensure that users can only see the Contracts of that Operating Units in which they are allowed access to.
