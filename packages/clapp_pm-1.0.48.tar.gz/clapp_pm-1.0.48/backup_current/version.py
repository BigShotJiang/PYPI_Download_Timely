"""
Version information for clapp-pm package.
"""

__version__ = "1.0.1"
__author__ = "Melih Burak Memiş"
__email__ = "mburakmemiscy@gmail.com"
__description__ = "Lightweight cross-language app manager for Python and Lua" 