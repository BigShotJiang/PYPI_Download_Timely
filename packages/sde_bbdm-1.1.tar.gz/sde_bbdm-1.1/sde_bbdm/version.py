from torchmanager_core import Version


VERSION = Version("v1.1")
DESCRIPTION = f"Score-Based Image-to-Image Brownian Bridge ({VERSION})"
