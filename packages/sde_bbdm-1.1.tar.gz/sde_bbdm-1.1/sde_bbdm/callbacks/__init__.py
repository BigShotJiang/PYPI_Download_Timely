from torchmanager.callbacks import *  # type: ignore

from .lr import ReduceLROnPlateau