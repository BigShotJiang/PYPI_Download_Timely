.. _api:

Developer Interface
===================

Path Operations
================

.. automodule:: platform_utils.paths
    :members:

Clipboard Control
==================

.. automodule:: platform_utils.clipboard
    :members:

Retrieve Idle Time
===================

.. automodule:: platform_utils.idle
    :members:
