import setuptools

setuptools.setup(use_scm_version={"write_to": "arxiv_scan/_version.py"})
