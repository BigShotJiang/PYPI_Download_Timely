This module depends on *stock_picking_invoice_link* module that is
hosted on <https://github.com/OCA/stock-logistics-workflow.git>.
