from mcp.server.fastmcp import FastMCP

mcp = FastMCP(
    name="tessell-mcp",
    description="Tessell Model Context Protocol (MCP) server",
)