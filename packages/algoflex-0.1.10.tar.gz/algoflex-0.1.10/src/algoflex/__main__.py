from algoflex.home import HomeScreen

if __name__ == "__main__":
    HomeScreen().run()
