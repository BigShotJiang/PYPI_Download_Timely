__version__ = '2025.7.25'
git_version = 'fbfd8a87e4ee47687ade44c2733715e9d789ec2c'
pytorch_version = '2.9.0.dev20250725'
