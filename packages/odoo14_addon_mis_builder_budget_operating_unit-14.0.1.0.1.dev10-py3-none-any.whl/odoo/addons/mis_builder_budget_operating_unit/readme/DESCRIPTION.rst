Introduces the operating unit to MIS Builder Budget instances.
