Set the operating unit in an MIS Builder budget instance.
