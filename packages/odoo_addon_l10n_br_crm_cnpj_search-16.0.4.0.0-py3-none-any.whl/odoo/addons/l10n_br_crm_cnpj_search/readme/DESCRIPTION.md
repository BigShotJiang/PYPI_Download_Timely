Módulo que adiciona um botão para preencher automaticamente os campos de
um lead a partir do seu CNPJ.
