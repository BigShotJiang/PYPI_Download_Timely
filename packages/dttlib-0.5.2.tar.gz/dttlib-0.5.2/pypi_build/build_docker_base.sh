#!/bin/bash

PYVER=$1

docker build -t dtt-build:base dttbuild_base