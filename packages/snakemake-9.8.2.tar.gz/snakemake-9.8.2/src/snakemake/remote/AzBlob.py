from snakemake.remote import RemoteProviderBase


class RemoteProvider(RemoteProviderBase):
    pass
