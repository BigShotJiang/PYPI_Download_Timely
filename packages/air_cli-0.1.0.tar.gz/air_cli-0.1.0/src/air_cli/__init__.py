"""Top-level package for air-cli."""

__author__ = """Audrey M. Roy Greenfeld"""
__email__ = 'audrey@feldroy.com'
__version__ = '0.1.0'
