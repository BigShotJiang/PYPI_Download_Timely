# Welcome to air-cli's documentation!

## Contents

- [Readme](readme.md)
- [Installation](installation.md)
- [Usage](usage.md)
- [Modules](modules.md)
- [Contributing](contributing.md)
- [History](history.md)

## Indices and tables

- [Index](genindex)
- [Module Index](modindex)
- [Search](search)
