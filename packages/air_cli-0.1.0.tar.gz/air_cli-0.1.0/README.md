# air-cli

![PyPI version](https://img.shields.io/pypi/v/air_cli.svg)
[![Documentation Status](https://readthedocs.org/projects/air-cli/badge/?version=latest)](https://air-cli.readthedocs.io/en/latest/?version=latest)

Run and manage Air apps from the CLI.

* Free software: MIT License
* Documentation: https://air-cli.readthedocs.io.

## Features

* TODO

## Credits

This package was created with [Cookiecutter](https://github.com/audreyfeldroy/cookiecutter) and the [audreyfeldroy/cookiecutter-pypackage](https://github.com/audreyfeldroy/cookiecutter-pypackage) project template.
