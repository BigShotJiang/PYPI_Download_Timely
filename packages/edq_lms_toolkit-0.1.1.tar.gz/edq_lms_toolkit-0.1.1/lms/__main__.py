import sys

def main():
    print("You have invoked the `lms` package directly. You probably want the `lms.cli` package instead.")
    return 0

if (__name__ == '__main__'):
    sys.exit(main())
