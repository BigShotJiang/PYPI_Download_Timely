# [(lms key, title, pretty title), ...]
OUTPUT_KEYS = [
    ('email', 'email', 'Email'),
    ('name', 'name', 'Name'),
    ('id', 'lms_id', 'LMS ID'),
    ('sis_user_id', 'student_id', 'Student ID'),
]

ENROLLMENT_KEY = ('enrollment', 'role', 'Course Role')
