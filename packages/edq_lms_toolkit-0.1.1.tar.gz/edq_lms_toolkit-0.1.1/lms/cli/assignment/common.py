# [(lms key, title, pretty title), ...]
OUTPUT_KEYS = [
    ('name', 'name', 'Name'),
    ('id', 'lms_id', 'LMS ID'),
    ('points_possible', 'points_possible', 'Points Possible'),
    ('published', 'published', 'Published'),
    ('due_at', 'due_at', 'Due At'),
    ('description', 'description', 'Description'),
]
