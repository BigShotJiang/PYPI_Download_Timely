2025-02-08 Version: 1.1.2
- Update API ListInstances: add param Tag.


2025-01-16 Version: 1.1.1
- Update API GetInstance: update response param.


2024-12-23 Version: 1.1.0
- Support API CheckInstancePolicy.
- Support API DeleteInstancePolicy.
- Support API UpdateInstanceElasticVCUUpperLimit.
- Support API UpdateInstancePolicy.
- Update API GetInstance: update response param.
- Update API ListInstances: add param InstanceNameList.
- Update API ListInstances: update response param.


2024-04-24 Version: 1.0.1
- Update API CreateInstance: update param body.
- Update API GetInstance: update response param.
- Update API ListTagResources: update response param.


2024-01-25 Version: 1.0.0
- Generated python 2020-12-09 for Tablestore.

