from .IS_Score_GUI import runGUI

__all__ = ["runGUI"]
