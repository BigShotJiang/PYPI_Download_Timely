INTENSITY_PLT = "Intensity Penalized"
PEAKS_DIPS_PLT = "Peaks and Dips Penalized"
UNDERFITTING_PLT = "AUC Penalization"

PEAK_REGION_PLT = "Peak Region Penalization"
DIP_REGION_PLT = "Dip Region Penalization"

PLACEHOLDERS = {
    "lam": "Lambda",
    "p": "p",
    "poly_order": "Poly Order",
    "min_bubble_widths": "Min Bubble Width"
}