# `pympebm`


## Installation


```bash
pip install pympebm
```

## Change Log

- 2025-07-16 (V 0.0.6)
    - Added `mp_method = BT` in `algorithm.py` and `run.py`. 
    - Added `PL`. 
    - Fixed the bug in `generate_data.py`. 

- 2025-07-19 (V 0.0.7)
    - Added the class of `PlackettLuce`. 

- 2025-07-20 (V 0.0.15)
    - Updated the definition and implementation of conflict and certainty. 
    - Made sure `data` folder exists after uploading to pypi. 
    - Made sure `fixed_biomarker_order = True` if we use mixed patholgy in data generation. 
    - Fixed a bug in the calculation of `conflict`. 
    - Made sure the `algorithm.py` is using the correct energy calculation functions. 
    - Added entropy and certainty calculation in `MCMC` sampler. 
    - Made sure in `generate_data.py`, `certainty` is calculated based upon the `mp_method`.
    - Made sure in `generate_data.py`, we can tweak the paramter of `mcmc_iterations`, otherwise it will super slow. This is because the time complexity is `mcmc_iterations * sample_count`. 
    - Tested obtaining `ordering_array` from separate disease data files. Made some modifcations in `algorithm.py` to allow this. 

- 2025-07-23 (V 0.0.16)
    - Implemented the conflict version of using only discordant pairs. 

- 2025-07-25 (V 0.0.17)
    - Updated `algorithm.py` to reflect changes in the class of `PlackettLuce`. 