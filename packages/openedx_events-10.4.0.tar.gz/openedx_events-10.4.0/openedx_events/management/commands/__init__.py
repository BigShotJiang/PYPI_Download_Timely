"""
Management commands for the Openedx events.

(Django requires this package structure.)
"""
