"""Tests for the avro module."""
