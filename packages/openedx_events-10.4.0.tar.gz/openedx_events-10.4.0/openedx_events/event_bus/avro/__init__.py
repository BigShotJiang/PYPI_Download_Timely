"""Classes and utility methods for Avro de/serialization of event data."""
