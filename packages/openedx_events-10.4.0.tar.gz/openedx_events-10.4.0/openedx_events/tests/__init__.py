"""
Test package for openedx-events implementations.
"""
