# Authors

The following people contributed to the software in one way or another,
thank you so much. The list is alphabetically sorted.

## Development Leads

- [George Song](https://github.com/gsong)

## Maintainers

- [Andreas Motl](https://github.com/amotl)

## Contributors

- [Alexander Meinhardt Scheurer](https://github.com/BeneCollyridam)
- [Daniel Blasco](https://github.com/dablak)
- [fe60](https://github.com/fe60)
- [Felipe Eltermann](https://github.com/eltermann)
- [Geoffrey Cline](https://github.com/geoffcline)
- [Hiro Kobashi](https://github.com/kobaski)
- [Mike Matheson](https://github.com/mmath)
- [Roberto Faga](https://github.com/rfaga)
- [Sotiris Fragkiskos](https://github.com/sfranky)
