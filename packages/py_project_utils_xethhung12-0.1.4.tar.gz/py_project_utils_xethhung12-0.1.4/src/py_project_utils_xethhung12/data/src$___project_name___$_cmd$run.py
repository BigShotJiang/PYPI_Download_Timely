import ___project_name___ as project
from j_vault_http_client_xethhung12 import client
def main():
    client.load_to_env()
    project.hello("user")
