from swh.docs.sphinx.conf import *  # NoQA
