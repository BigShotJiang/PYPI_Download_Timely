========
Overview
========

A component-based software defined networking framework in OpenStack.

os-ken is a fork of the Ryu library tailored for OpenStack Neutron.

* License: Apache License, Version 2.0
* Documentation: https://docs.openstack.org/os-ken/latest/
* Source: https://opendev.org/openstack/os-ken/
* Bugs: https://storyboard.openstack.org/#!/project/openstack/os-ken
* Release Notes: https://docs.openstack.org/releasenotes/os-ken/
