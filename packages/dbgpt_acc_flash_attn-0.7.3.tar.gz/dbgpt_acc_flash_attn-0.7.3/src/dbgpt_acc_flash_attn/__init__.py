"""Flash Attention wrapper for DB-GPT."""

from ._version import version as __version__  # noqa: F401

__ALL__ = ["__version__"]
