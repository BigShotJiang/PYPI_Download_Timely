# DB-GPT-Accelerator for Flash Attention

Wrapper for the Flash Attention module in the DB-GPT-Accelerator.