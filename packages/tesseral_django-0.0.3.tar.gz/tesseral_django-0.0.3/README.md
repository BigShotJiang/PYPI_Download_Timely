# Tesseral Django SDK

[![pypi](https://img.shields.io/pypi/v/tesseral-django)](https://pypi.python.org/pypi/tesseral-django)

`tesseral_django` is the official Tesseral SDK for Django.

Documentation for this package is available
[here](https://tesseral.com/docs/sdks/serverside-sdks/tesseral-sdk-django).
