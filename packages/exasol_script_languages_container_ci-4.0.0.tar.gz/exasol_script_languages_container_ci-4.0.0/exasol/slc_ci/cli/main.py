#! /usr/bin/env python3

import exasol.slc_ci.cli.commands
from exasol.slc_ci.cli.cli import cli


def main():
    cli()


if __name__ == "__main__":
    main()
