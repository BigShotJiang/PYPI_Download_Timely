# __main__.py

from mcp_server_shu1l import main

main()