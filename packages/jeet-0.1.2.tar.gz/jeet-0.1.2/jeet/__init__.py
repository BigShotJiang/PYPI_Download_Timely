print("Jeet here — thanks for installing me! You've been pranked 😄")
