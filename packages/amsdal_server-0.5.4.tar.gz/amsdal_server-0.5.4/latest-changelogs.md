## [v0.5.4](https://pypi.org/project/amsdal_server/0.5.4/) - 2025-07-28

### Changes

- Adjustments to slack notifications
