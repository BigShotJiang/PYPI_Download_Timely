export default function Help() {
  return <h2 className="text-foreground text-lg">Help Page</h2>;
}
