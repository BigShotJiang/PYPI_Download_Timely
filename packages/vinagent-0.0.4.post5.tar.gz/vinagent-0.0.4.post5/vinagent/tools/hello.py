def hello_from_vinagent():
    """A greet of Vinagent to everyone"""
    return "Hello my cute cute friend, I'm vinagent and I am here to play with you 😄!"
