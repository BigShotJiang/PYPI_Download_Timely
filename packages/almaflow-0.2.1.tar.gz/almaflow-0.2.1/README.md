Almaflow

[PyPI package](https://pypi.org/project/almaflow/)