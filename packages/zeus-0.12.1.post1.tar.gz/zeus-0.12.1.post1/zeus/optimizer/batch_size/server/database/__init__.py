"""Manage database connection and define schema."""
