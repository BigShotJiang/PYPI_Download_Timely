# {octicon}`mortar-board` Getting started

```{toctree}
:caption: Installation

01_installation/01_installation
01_installation/02_setup
01_installation/03_migration_guide
```

```{toctree}
:caption: Quickstart

02_quickstart/00_intro_tutorial
02_quickstart/01_example_project
02_quickstart/02_first_steps
```
