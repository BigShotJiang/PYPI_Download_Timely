"""kedro-mlflow plugin constants"""

__version__ = "0.14.5"

import logging

logging.getLogger(__name__).setLevel(logging.INFO)
