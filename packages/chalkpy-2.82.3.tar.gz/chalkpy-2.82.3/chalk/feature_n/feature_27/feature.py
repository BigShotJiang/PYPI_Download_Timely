# AUTO-GENERATED FILE.
# Re-run /chalk/feature_n/codegen.py to regenerate contents.
from typing import TypeVar, Generic, Optional, Dict
from chalk.features.dataframe import DataFrameMeta


T1 = TypeVar("T1")
T2 = TypeVar("T2")
T3 = TypeVar("T3")
T4 = TypeVar("T4")
T5 = TypeVar("T5")
T6 = TypeVar("T6")
T7 = TypeVar("T7")
T8 = TypeVar("T8")
T9 = TypeVar("T9")
T10 = TypeVar("T10")
T11 = TypeVar("T11")
T12 = TypeVar("T12")
T13 = TypeVar("T13")
T14 = TypeVar("T14")
T15 = TypeVar("T15")
T16 = TypeVar("T16")
T17 = TypeVar("T17")
T18 = TypeVar("T18")
T19 = TypeVar("T19")
T20 = TypeVar("T20")
T21 = TypeVar("T21")
T22 = TypeVar("T22")
T23 = TypeVar("T23")
T24 = TypeVar("T24")
T25 = TypeVar("T25")
T26 = TypeVar("T26")
T27 = TypeVar("T27")


class Features(
    Generic[
        T1,
        T2,
        T3,
        T4,
        T5,
        T6,
        T7,
        T8,
        T9,
        T10,
        T11,
        T12,
        T13,
        T14,
        T15,
        T16,
        T17,
        T18,
        T19,
        T20,
        T21,
        T22,
        T23,
        T24,
        T25,
        T26,
        T27,
    ]
):
    pass


class DataFrame(
    Generic[
        T1,
        T2,
        T3,
        T4,
        T5,
        T6,
        T7,
        T8,
        T9,
        T10,
        T11,
        T12,
        T13,
        T14,
        T15,
        T16,
        T17,
        T18,
        T19,
        T20,
        T21,
        T22,
        T23,
        T24,
        T25,
        T26,
        T27,
    ],
    metaclass=DataFrameMeta,
):
    def __getitem__(self, item):
        pass
