Basic build instructions


* Create Python venv, or conda env
* pip install poetry
* poetry update
* poetry install -E doc -E dev -E test
* poetry run tox

Link to tutorial - https://cheeyeelim.github.io/cookiecutter-pypackage/latest/
