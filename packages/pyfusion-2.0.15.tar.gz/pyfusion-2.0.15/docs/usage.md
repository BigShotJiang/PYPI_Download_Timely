# Usage


## Import Fusion

```
from fusion import Fusion
```
## Fusion Object 
```
fusion = Fusion()
```
