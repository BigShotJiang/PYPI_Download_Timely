
__version__ = "3.3.1" if "{" not in "3.3.1" else "0.0.0"

#Exported functions
__all__ = []
