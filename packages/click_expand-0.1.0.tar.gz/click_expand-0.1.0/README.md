# Click Expand

Generate click group and command skeletons from simple comments.
