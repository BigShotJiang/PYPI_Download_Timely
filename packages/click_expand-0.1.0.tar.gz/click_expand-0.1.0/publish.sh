#!/bin/bash

twine upload --repository pypi dist/*
