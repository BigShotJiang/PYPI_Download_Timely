#!/bin/bash

. venv/bin/activate
