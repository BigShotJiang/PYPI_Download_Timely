#!/bin/bash

twine upload --repository testpypi dist/*
