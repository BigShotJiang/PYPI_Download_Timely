"""
Generate click group and command skeletons from simple comments.
"""
__version__ = "0.1.0"
