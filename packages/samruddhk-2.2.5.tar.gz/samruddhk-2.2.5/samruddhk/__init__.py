from .statistics import (
    program1,
    program2,
    program3,
    program4,
    program5,
    print_program1,
    print_program2,
    print_program3,
    print_program4,
    print_program5
)

__all__ = [
    "program1",
    "program2",
    "program3",
    "program4",
    "program5",
    "print_program1",
    "print_program2",
    "print_program3",
    "print_program4",
    "print_program5"
]
