mod arrow2_serde;
pub use arrow2_serde::{from_arrow2, into_arrow2, ARROW2_DDSKETCH_DTYPE};
