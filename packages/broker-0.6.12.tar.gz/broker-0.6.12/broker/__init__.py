"""Shortcuts for the broker module."""

from broker.broker import Broker  # noqa: F401
