Federal Income Tax Withholding tables for Ethiopia (revised 2008 EC).
