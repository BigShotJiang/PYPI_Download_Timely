# -*- coding: utf-8 -*-

PLUGIN_CREATOR_VERSION = "1.8.0"
