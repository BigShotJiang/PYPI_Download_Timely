
.. _usage:

Usage
=====

.. toctree::

   placement
   labels
   styles
   backends