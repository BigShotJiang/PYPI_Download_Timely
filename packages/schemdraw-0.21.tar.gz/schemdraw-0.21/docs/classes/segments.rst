
Segment Drawing Primitives
==========================

.. automodule:: schemdraw.segments
    :members:
    :exclude-members: roundcorners