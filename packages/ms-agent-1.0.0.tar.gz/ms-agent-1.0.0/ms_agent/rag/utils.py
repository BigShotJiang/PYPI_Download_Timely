# Copyright (c) Alibaba, Inc. and its affiliates.
rag_mapping = {}
