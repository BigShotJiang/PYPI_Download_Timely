# Copyright (c) Alibaba, Inc. and its affiliates.
from .base import Memory
from .utils import memory_mapping
