from .instrumentation import AWSBedrockInstrumentation

__all__ = ["AWSBedrockInstrumentation"]
