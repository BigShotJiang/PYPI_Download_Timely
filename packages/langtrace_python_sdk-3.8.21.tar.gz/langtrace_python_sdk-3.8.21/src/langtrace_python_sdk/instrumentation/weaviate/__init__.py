from .instrumentation import WeaviateInstrumentation

__all__ = [
    "WeaviateInstrumentation",
]
