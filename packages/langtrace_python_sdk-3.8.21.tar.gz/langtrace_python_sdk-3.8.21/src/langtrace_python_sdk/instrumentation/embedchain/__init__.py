from .instrumentation import EmbedchainInstrumentation

__all__ = [
    "EmbedchainInstrumentation",
]
