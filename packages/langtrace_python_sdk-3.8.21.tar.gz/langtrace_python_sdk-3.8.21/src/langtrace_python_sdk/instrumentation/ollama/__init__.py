from .instrumentation import OllamaInstrumentor

__all__ = ["OllamaInstrumentor"]
