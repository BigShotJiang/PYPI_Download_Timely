LANGTRACE_SDK_NAME = "langtrace-python-sdk"
SENTRY_DSN = "https://7f8eed3a1237fb2efef0f5e96ab407af@o1419498.ingest.us.sentry.io/4507929133056000"
