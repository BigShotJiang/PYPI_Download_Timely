APIS = {
    "GENERATE": {"METHOD": "generate", "ENDPOINT": "/api/generate"},
    "CHAT": {"METHOD": "chat", "ENDPOINT": "/api/chat"},
    "EMBEDDINGS": {"METHOD": "embeddings", "ENDPOINT": "/api/embeddings"},
}
