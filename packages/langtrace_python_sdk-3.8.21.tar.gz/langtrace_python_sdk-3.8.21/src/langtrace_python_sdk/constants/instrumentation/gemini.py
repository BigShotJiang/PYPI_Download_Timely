APIS = {
    "GENERATE_CONTENT": {
        "module": "google.generativeai.generative_models",
        "method": "GenerativeModel",
        "operation": "generate_content",
    },
    "AGENERATE_CONTENT": {
        "module": "google.generativeai.generative_models",
        "method": "GenerativeModel",
        "operation": "generate_content_async",
    },
}
