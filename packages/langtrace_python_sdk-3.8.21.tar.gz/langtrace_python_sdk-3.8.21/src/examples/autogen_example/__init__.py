from .main import main as autogen_main
from .main import comedy_show


class AutoGenRunner:
    def run(self):
        # autogen_main()
        comedy_show()
