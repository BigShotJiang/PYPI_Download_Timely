from .basic_route import root


class FastAPIRunner:
    def run(self):
        root()
