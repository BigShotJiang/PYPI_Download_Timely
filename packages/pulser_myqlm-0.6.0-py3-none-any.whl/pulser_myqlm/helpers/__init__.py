"""The helper functions."""
