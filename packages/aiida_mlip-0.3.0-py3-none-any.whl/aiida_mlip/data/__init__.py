"""Data types for MLIPs calculations."""
