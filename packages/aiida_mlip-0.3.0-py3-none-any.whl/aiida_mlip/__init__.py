"""Machine learning interatomic potentials aiida plugin."""

from __future__ import annotations

__version__ = "0.2.1"
