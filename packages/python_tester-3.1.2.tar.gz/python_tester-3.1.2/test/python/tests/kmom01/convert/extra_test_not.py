"""
Only to test that examiner imports correct files
"""
