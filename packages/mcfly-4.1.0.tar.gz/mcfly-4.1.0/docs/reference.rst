mcfly
=====
.. automodule:: mcfly
    :members:
    :undoc-members:
    :show-inheritance:

mcfly.models
------------------------------

.. automodule:: mcfly.models
    :members:
    :undoc-members:
    :show-inheritance:

mcfly.find_architecture module
------------------------------

.. automodule:: mcfly.find_architecture
    :members:
    :undoc-members:
    :show-inheritance:

mcfly.modelgen module
---------------------

.. automodule:: mcfly.modelgen
    :members:
    :undoc-members:
    :show-inheritance:


