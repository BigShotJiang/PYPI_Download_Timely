class Task:
    classification = 'classification'
    regression = 'regression'
