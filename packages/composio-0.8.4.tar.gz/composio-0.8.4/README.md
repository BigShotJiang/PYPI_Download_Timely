# Composio SDK

## Setup

```bash
make env
source .venv/bin/activate
```

## Usage

> 📌  **NOTE**
> Ensure you've set the `COMPOSIO_API_KEY` and the `OPENAI_API_KEY` for these examples to work.
