"""
CLI package for Metis Agent.

This package provides the command-line interface for the agent.
"""
from .commands import cli

__all__ = ['cli']