#ifndef EIGEN_POLYNOMIALS_MODULE_H
#error "Please include unsupported/Eigen/Polynomials instead of including headers inside the src directory directly."
#endif
