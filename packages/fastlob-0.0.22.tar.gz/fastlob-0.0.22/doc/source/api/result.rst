result package
======================

Submodules
----------

result.result module
----------------------------

.. automodule:: fastlob.result.result
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: fastlob.result
   :members:
   :show-inheritance:
   :undoc-members:
