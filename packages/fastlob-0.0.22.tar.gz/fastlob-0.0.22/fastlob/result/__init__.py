'''The result object is returned by the LOB after the client executes an operation.'''

from .result import ResultBuilder, ExecutionResult
