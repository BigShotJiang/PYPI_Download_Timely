'''The side is a collection of limits, whose ordering (by price) depends wether it is a bid or ask side.'''

from .side import Side, AskSide, BidSide
