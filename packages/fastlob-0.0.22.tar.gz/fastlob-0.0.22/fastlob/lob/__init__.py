'''Main module containing the Orderbook class.'''

from .orderbook import Orderbook
