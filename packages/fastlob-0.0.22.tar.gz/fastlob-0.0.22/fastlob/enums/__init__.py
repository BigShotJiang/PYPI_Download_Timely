'''All the project enumerations are grouped here for simplicity.'''

from .enums import OrderSide, OrderType, OrderStatus, ResultType
