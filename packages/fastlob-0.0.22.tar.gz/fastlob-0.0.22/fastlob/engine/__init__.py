'''The engine module is **only** responsible for executing market orders.'''

from .engine import execute
