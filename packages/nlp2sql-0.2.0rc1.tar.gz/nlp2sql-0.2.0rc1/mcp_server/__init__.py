"""nlp2sql MCP Server - Expose nlp2sql as MCP tools."""

__version__ = "0.2.0rc1"