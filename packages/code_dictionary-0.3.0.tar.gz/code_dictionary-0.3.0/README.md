# code-dictionary
Generated dicts of programming languages’ classes, fields, and methods.


# Install

```
pip install code-dictionary
```


# Usage

```
python -c "from code_dictionary.java.classes import JAVA_CLASSES; print(len(JAVA_CLASSES))"
```

```
from code_dictionary.java.classes import JAVA_CLASSES
print(LEN(JAVA_CLASSES))
```