#!/usr/bin/env python3
"""
Command-line interface for the DEBase enzyme analysis pipeline.
"""

from .wrapper import main

if __name__ == "__main__":
    main()