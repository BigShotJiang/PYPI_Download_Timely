"""
Setup script for offers-check-marketplaces package.
This file is kept for compatibility, but the main configuration is in pyproject.toml
"""

from setuptools import setup

# Configuration is in pyproject.toml
setup()