This repository is intended to be used as a GitHub template for creating Python MCP applications.

When creating a new repository from this template:

1. Update the project name in `pyproject.toml`
2. Update the README.md with your project details
3. Update the APP_ID in `hello_world/server.py`
4. Add your own tools to the `_register_tools` method
5. Update the LICENSE file with your copyright information
