"""Test suite for libpresign."""
