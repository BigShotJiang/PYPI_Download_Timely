__version__ = '0.3.3'


def get_version() -> str:
    return __version__


__all__ = [
    '__all__',
]