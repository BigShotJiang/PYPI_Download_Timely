from rubicon_ml.repository.utils.slugify import slugify

__all__ = ["slugify"]
