from django.apps import AppConfig


class PackageAramConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'package_aram'
 