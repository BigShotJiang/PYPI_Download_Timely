from wake.cli.detect import run_detect as detector

from .api import Detection, Detector, DetectorConfidence, DetectorImpact, DetectorResult
