class ThreadCancelledError(Exception):
    """Exception raised when a thread is cancelled."""

    pass
