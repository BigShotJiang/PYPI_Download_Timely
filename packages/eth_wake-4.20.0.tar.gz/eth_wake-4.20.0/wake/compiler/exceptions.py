class CompilationError(Exception):
    pass


class CompilationResolveError(Exception):
    pass
