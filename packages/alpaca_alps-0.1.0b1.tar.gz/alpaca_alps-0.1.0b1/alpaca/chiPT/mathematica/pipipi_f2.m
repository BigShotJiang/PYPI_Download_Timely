(gT^2*(-6*m23^2*mf2^4 + m12^2*(mf2^2 - 2*mpi0^2)*(ma^2 - mf2^2 + mpi0^2) + 
   6*m23*mf2^4*(ma^2 + 3*mpi0^2) - 4*mf2^2*mpi0^2*(ma^4 + 2*mf2^2*mpi0^2 + mpi0^4 + 
     2*ma^2*(mf2^2 - mpi0^2)) + m12*(-6*m23*mf2^4 + 3*mf2^4*mpi0^2 + mf2^2*mpi0^4 + 2*mpi0^6 - 
     ma^4*(mf2^2 - 2*mpi0^2) + ma^2*(mf2^4 + 4*mf2^2*mpi0^2 - 4*mpi0^4)))*
  (3*cg*(kappad - kappau) + deltaI*(Sqrt[3]*cg*(kappad + kappau) + thetaprALP)*
    (Sqrt[2]*thetapi + thetaprpi) + deltaI*thetaALP*(2*thetapi + Sqrt[2]*thetaprpi) - 3*thpiALP)*
  UnitStep[m12 - (Gammaf2 - mf2)^2])/(144*mf2^4*(-m12 + mf2*((-I)*Gammaf2 + mf2)))