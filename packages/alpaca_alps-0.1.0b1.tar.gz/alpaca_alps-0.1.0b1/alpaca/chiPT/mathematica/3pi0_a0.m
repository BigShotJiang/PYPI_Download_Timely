-1/24*(deltaI*(-(m23^2*ma^2*ma0^2) + m23*ma^4*ma0^2 + 2*m23^2*ma0^4 - 2*m23*ma^2*ma0^4 - 
    2*m23^2*ma^2*mpi0^2 + 2*m23*ma^4*mpi0^2 - 3*m23^2*ma0^2*mpi0^2 + 6*m23*ma^2*ma0^2*mpi0^2 - 
    4*ma^4*ma0^2*mpi0^2 - 6*m23*ma0^4*mpi0^2 + 6*ma^2*ma0^4*mpi0^2 - 2*m23^2*mpi0^4 + 
    8*m23*ma^2*mpi0^4 + 9*m23*ma0^2*mpi0^4 - 16*ma^2*ma0^2*mpi0^4 + 6*ma0^4*mpi0^4 + 6*m23*mpi0^6 - 
    12*ma0^2*mpi0^6 - 2*Gammaa0^2*ma0^2*(m23^2 + 3*mpi0^2*(ma^2 + mpi0^2) - m23*(ma^2 + 3*mpi0^2)) + 
    I*Gammaa0*ma0*(m23^2*(ma^2 - 4*ma0^2 + 3*mpi0^2) - m23*(ma^2 + 3*mpi0^2)*
       (ma^2 - 4*ma0^2 + 3*mpi0^2) + 4*mpi0^2*(ma^2 + mpi0^2)*(ma^2 - 3*ma0^2 + 3*mpi0^2)) + 
    m12^2*(-2*Gammaa0^2*ma0^2 - ma^2*ma0^2 + 2*ma0^4 - 2*ma^2*mpi0^2 - 3*ma0^2*mpi0^2 - 2*mpi0^4 + 
      I*Gammaa0*ma0*(ma^2 - 4*ma0^2 + 3*mpi0^2) + m23*(2*ma^2 + (3*I)*Gammaa0*ma0 - 3*ma0^2 + 
        6*mpi0^2)) + m12*(m23^2*(2*ma^2 + (3*I)*Gammaa0*ma0 - 3*ma0^2 + 6*mpi0^2) + 
      (ma^2 + 3*mpi0^2)*(2*Gammaa0^2*ma0^2 - 2*ma0^4 + 3*ma0^2*mpi0^2 + 2*mpi0^4 + 
        ma^2*(ma0^2 + 2*mpi0^2) - I*Gammaa0*ma0*(ma^2 - 4*ma0^2 + 3*mpi0^2)) - 
      2*m23*(ma^4 + Gammaa0^2*ma0^2 - ma0^4 - 3*ma0^2*mpi0^2 + 10*mpi0^4 + 
        ma^2*(I*Gammaa0*ma0 - ma0^2 + 7*mpi0^2) + I*Gammaa0*(2*ma0^3 + 3*ma0*mpi0^2))))*
   (2*Sqrt[2]*CoefA*thetapi + Sqrt[2]*CoefC*thetapi - 4*CoefA*thetaprpi + 4*CoefC*thetaprpi)*
   (cg*(CoefC*(6 + Sqrt[3]*deltaI*(kappad - kappau)*(Sqrt[2]*thetapi + 4*thetaprpi)) + 
      2*CoefA*(-6 + kappad*(6 + Sqrt[6]*deltaI*thetapi - 2*Sqrt[3]*deltaI*thetaprpi) + 
        kappau*(6 - Sqrt[6]*deltaI*thetapi + 2*Sqrt[3]*deltaI*thetaprpi))) + 
    Sqrt[3]*(2*CoefA*(Sqrt[2]*thetaALP - 2*thetaprALP + deltaI*(-(Sqrt[2]*thetapi) + 2*thetaprpi)*
         thpiALP) + CoefC*(Sqrt[2]*thetaALP + 4*thetaprALP - deltaI*(Sqrt[2]*thetapi + 4*thetaprpi)*
         thpiALP))))/(Sqrt[3]*(m12 + I*(Gammaa0 + I*ma0)*ma0)*(m23 + I*(Gammaa0 + I*ma0)*ma0)*
   (m12 + m23 - ma^2 - I*Gammaa0*ma0 + ma0^2 - 3*mpi0^2))