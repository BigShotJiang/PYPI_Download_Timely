(6*cg*mpi0^2*(kappad*(Sqrt[6] + deltaI*(Sqrt[6] - thetapi)) + 
    kappau*(Sqrt[6] + deltaI*(-Sqrt[6] + thetapi))) - 
  3*deltaI*thetapi*(cdhat*(3*m23 - ma^2 - 3*meta^2) + cuhat*(-3*m23 + ma^2 + 3*meta^2) + 
    2*(-3*m23 + ma^2 + meta^2 + 2*mpiplus^2)*thpiALP) + 
  2*mpi0^2*(6*thetaALP + 3*Sqrt[2]*thetaprALP - deltaI*(Sqrt[6] - 3*thetapi)*thpiALP))/(18*F0^2)