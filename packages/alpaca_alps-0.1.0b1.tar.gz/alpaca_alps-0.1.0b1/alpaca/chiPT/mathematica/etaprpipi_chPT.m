(6*cg*mpi0^2*(kappad*(Sqrt[3] + deltaI*(Sqrt[3] - thetaprpi)) + 
    kappau*(Sqrt[3] + deltaI*(-Sqrt[3] + thetaprpi))) - 
  3*deltaI*thetaprpi*(cdhat*(3*m23 - ma^2 - 3*metap^2) + cuhat*(-3*m23 + ma^2 + 3*metap^2) + 
    2*(-3*m23 + ma^2 + metap^2 + 2*mpiplus^2)*thpiALP) + 
  mpi0^2*(6*Sqrt[2]*thetaALP + 6*thetaprALP - 2*deltaI*(Sqrt[3] - 3*thetaprpi)*thpiALP))/(18*F0^2)