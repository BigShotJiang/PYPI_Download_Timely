(mrhoplus^2*(2*m12^2 + 2*m12*m23 + 2*m23^2 - 2*m23*(ma^2 + 3*mpi0^2) - 
   3*m12*(ma^2 + 3*mpi0^2 + I*(Gammarhoplus + I*mrhoplus)*mrhoplus) + 
   (ma^2 + 3*mpi0^2)*(ma^2 + 3*mpi0^2 + I*(Gammarhoplus + I*mrhoplus)*mrhoplus))*
  (cg*(kappad - kappau) - thpiALP))/(2*F0^2*(m23 + I*(Gammarhoplus + I*mrhoplus)*mrhoplus)*
  (m12 + m23 - ma^2 - 3*mpi0^2 - I*Gammarhoplus*mrhoplus + mrhoplus^2))