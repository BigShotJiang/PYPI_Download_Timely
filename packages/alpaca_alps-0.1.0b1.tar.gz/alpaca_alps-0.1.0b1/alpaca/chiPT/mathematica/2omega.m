((ma^4 - 4*ma^2*momega^2)*mrhoplus^4*(3*cg*(kappad + kappau) + Sqrt[3]*(Sqrt[2]*thetaALP + thetaprALP))^2)/
 (512*F0^6*Pi^4)