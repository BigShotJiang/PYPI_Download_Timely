((I/24)*(-(m23^2*ma^2*mf0^2) + m23*ma^4*mf0^2 + 2*m23^2*mf0^4 - 2*m23*ma^2*mf0^4 - 2*m23^2*ma^2*mpi0^2 + 
   2*m23*ma^4*mpi0^2 - 3*m23^2*mf0^2*mpi0^2 + 6*m23*ma^2*mf0^2*mpi0^2 - 4*ma^4*mf0^2*mpi0^2 - 
   6*m23*mf0^4*mpi0^2 + 6*ma^2*mf0^4*mpi0^2 - 2*m23^2*mpi0^4 + 8*m23*ma^2*mpi0^4 + 9*m23*mf0^2*mpi0^4 - 
   16*ma^2*mf0^2*mpi0^4 + 6*mf0^4*mpi0^4 + 6*m23*mpi0^6 - 12*mf0^2*mpi0^6 - 
   2*Gammaf0^2*mf0^2*(m23^2 + 3*mpi0^2*(ma^2 + mpi0^2) - m23*(ma^2 + 3*mpi0^2)) + 
   I*Gammaf0*mf0*(m23^2*(ma^2 - 4*mf0^2 + 3*mpi0^2) - m23*(ma^2 + 3*mpi0^2)*
      (ma^2 - 4*mf0^2 + 3*mpi0^2) + 4*mpi0^2*(ma^2 + mpi0^2)*(ma^2 - 3*mf0^2 + 3*mpi0^2)) + 
   m12^2*(-2*Gammaf0^2*mf0^2 - ma^2*mf0^2 + 2*mf0^4 - 2*ma^2*mpi0^2 - 3*mf0^2*mpi0^2 - 2*mpi0^4 + 
     I*Gammaf0*mf0*(ma^2 - 4*mf0^2 + 3*mpi0^2) + m23*(2*ma^2 + (3*I)*Gammaf0*mf0 - 3*mf0^2 + 
       6*mpi0^2)) + m12*(m23^2*(2*ma^2 + (3*I)*Gammaf0*mf0 - 3*mf0^2 + 6*mpi0^2) + 
     (ma^2 + 3*mpi0^2)*(2*Gammaf0^2*mf0^2 - 2*mf0^4 + 3*mf0^2*mpi0^2 + 2*mpi0^4 + 
       ma^2*(mf0^2 + 2*mpi0^2) - I*Gammaf0*mf0*(ma^2 - 4*mf0^2 + 3*mpi0^2)) - 
     2*m23*(ma^4 + Gammaf0^2*mf0^2 - mf0^4 - 3*mf0^2*mpi0^2 + 10*mpi0^4 + 
       ma^2*(I*Gammaf0*mf0 - mf0^2 + 7*mpi0^2) + I*Gammaf0*(2*mf0^3 + 3*mf0*mpi0^2))))*
  (2*CoefB*Cos[thetas] + Sqrt[2]*(-CoefA + CoefB)*Sin[thetas])*
  ((-8*CoefA*deltaI*thetaALP*thetapi + 12*CoefB*deltaI*thetaALP*thetapi + 
     4*CoefC*deltaI*thetaALP*thetapi + 4*CoefD*deltaI*thetaALP*thetapi + 
     2*Sqrt[2]*CoefA*deltaI*thetapi*thetaprALP + 5*Sqrt[2]*CoefC*deltaI*thetapi*thetaprALP + 
     8*Sqrt[2]*CoefD*deltaI*thetapi*thetaprALP + 2*Sqrt[2]*CoefA*deltaI*thetaALP*thetaprpi + 
     5*Sqrt[2]*CoefC*deltaI*thetaALP*thetaprpi + 8*Sqrt[2]*CoefD*deltaI*thetaALP*thetaprpi + 
     8*CoefA*deltaI*thetaprALP*thetaprpi + 12*CoefB*deltaI*thetaprALP*thetaprpi + 
     8*CoefC*deltaI*thetaprALP*thetaprpi + 32*CoefD*deltaI*thetaprALP*thetaprpi + 
     Sqrt[3]*cg*deltaI*(Sqrt[2]*CoefC*(2 + kappad + kappau)*thetapi - 
       2*Sqrt[2]*CoefA*(-2 + 3*kappad + 3*kappau)*thetapi + 4*CoefA*thetaprpi + 
       2*CoefC*(1 + 2*kappad + 2*kappau)*thetaprpi + 4*CoefD*(Sqrt[2]*thetapi + 4*thetaprpi)) + 
     4*cg*CoefB*(-(Sqrt[6]*deltaI*thetapi) + 2*Sqrt[3]*deltaI*thetaprpi + 
       kappau*(-3 + 2*Sqrt[6]*deltaI*thetapi - Sqrt[3]*deltaI*thetaprpi) + 
       kappad*(3 + 2*Sqrt[6]*deltaI*thetapi - Sqrt[3]*deltaI*thetaprpi)) - 12*CoefB*thpiALP)*
    Cos[thetas] + 2*(2*Sqrt[2]*CoefA*deltaI*thetaALP*thetapi + 3*Sqrt[2]*CoefB*deltaI*thetaALP*thetapi - 
     Sqrt[2]*CoefC*deltaI*thetaALP*thetapi + Sqrt[2]*CoefD*deltaI*thetaALP*thetapi + 
     2*CoefA*deltaI*thetapi*thetaprALP - CoefC*deltaI*thetapi*thetaprALP + 
     4*CoefD*deltaI*thetapi*thetaprALP + 2*CoefA*deltaI*thetaALP*thetaprpi - 
     CoefC*deltaI*thetaALP*thetaprpi + 4*CoefD*deltaI*thetaALP*thetaprpi + 
     Sqrt[2]*CoefA*deltaI*thetaprALP*thetaprpi + 3*Sqrt[2]*CoefB*deltaI*thetaprALP*thetaprpi + 
     4*Sqrt[2]*CoefC*deltaI*thetaprALP*thetaprpi + 8*Sqrt[2]*CoefD*deltaI*thetaprALP*thetaprpi + 
     cg*(-(CoefB*(3*Sqrt[2]*kappau + 2*Sqrt[3]*deltaI*thetapi - 4*Sqrt[3]*deltaI*kappau*thetapi - 
          2*Sqrt[6]*deltaI*thetaprpi + Sqrt[6]*deltaI*kappau*thetaprpi + 
          kappad*(-3*Sqrt[2] - 4*Sqrt[3]*deltaI*thetapi + Sqrt[6]*deltaI*thetaprpi))) + 
       CoefA*(kappad*(-3*Sqrt[2] + 2*Sqrt[3]*deltaI*thetapi + Sqrt[6]*deltaI*thetaprpi) + 
         kappau*(3*Sqrt[2] + 2*Sqrt[3]*deltaI*thetapi + Sqrt[6]*deltaI*thetaprpi)) + 
       Sqrt[3]*deltaI*(2*CoefD*(thetapi + 2*Sqrt[2]*thetaprpi) - 
         CoefC*(kappad*thetapi + kappau*thetapi - 3*Sqrt[2]*thetaprpi + 2*Sqrt[2]*kappad*thetaprpi + 
           2*Sqrt[2]*kappau*thetaprpi))) + 3*Sqrt[2]*CoefA*thpiALP - 3*Sqrt[2]*CoefB*thpiALP)*
    Sin[thetas]))/((m12 + I*(Gammaf0 + I*mf0)*mf0)*((-I)*m23 + (Gammaf0 + I*mf0)*mf0)*
  (m12 + m23 - ma^2 - I*Gammaf0*mf0 + mf0^2 - 3*mpi0^2))