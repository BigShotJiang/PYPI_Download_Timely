-1/3*(Sqrt[kfact]*mpi0^2*(deltaI*thetaprALP*(Sqrt[3] + 3*Sqrt[2]*thetapi + 3*thetaprpi) + 
    deltaI*thetaALP*(Sqrt[6] + 6*thetapi + 3*Sqrt[2]*thetaprpi) + 
    3*cg*(kappau*(-1 + deltaI + Sqrt[6]*deltaI*thetapi + Sqrt[3]*deltaI*thetaprpi) + 
      kappad*(1 + deltaI + Sqrt[6]*deltaI*thetapi + Sqrt[3]*deltaI*thetaprpi)) - 3*thpiALP)*
   UnitStep[-ma + metap])/F0^2