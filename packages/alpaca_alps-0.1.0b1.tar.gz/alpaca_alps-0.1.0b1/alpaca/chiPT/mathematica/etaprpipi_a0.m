((CoefA - CoefC)*(((m12 - ma^2 - mpiplus^2)*(m12 - metap^2 - mpiplus^2))/
    (m12 + I*(Gammaa0plus + I*ma0plus)*ma0plus) - 
   ((m12 + m23 - ma^2 - mpiplus^2)*(m12 + m23 - metap^2 - mpiplus^2))/
    (m12 + m23 - ma^2 - I*Gammaa0plus*ma0plus + ma0plus^2 - metap^2 - 2*mpiplus^2))*
  (6*cg*(CoefC + 2*CoefA*(-1 + kappad + kappau)) + 
   Sqrt[3]*(2*Sqrt[2]*CoefA*thetaALP + Sqrt[2]*CoefC*thetaALP - 4*CoefA*thetaprALP + 
     4*CoefC*thetaprALP)))/(12*Sqrt[3])