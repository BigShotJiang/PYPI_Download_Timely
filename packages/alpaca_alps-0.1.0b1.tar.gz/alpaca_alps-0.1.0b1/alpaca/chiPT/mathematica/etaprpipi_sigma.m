((m23 - ma^2 - metap^2)*(m23 - 2*mpiplus^2)*(Sqrt[2]*(CoefA - CoefB)*Cos[thetas] + 2*CoefB*Sin[thetas])*
  (2*(2*CoefA*thetaALP - CoefC*thetaALP + 4*CoefD*thetaALP + Sqrt[2]*CoefA*thetaprALP + 
     3*Sqrt[2]*CoefB*thetaprALP + 4*Sqrt[2]*CoefC*thetaprALP + 8*Sqrt[2]*CoefD*thetaprALP + 
     Sqrt[2]*cg*(4*Sqrt[3]*CoefD + Sqrt[3]*CoefA*kappad + Sqrt[3]*CoefC*(3 - 2*kappad - 2*kappau) + 
       Sqrt[3]*CoefA*kappau + 3*CoefA*deltaI*kappad*thetaprpi - 3*CoefA*deltaI*kappau*thetaprpi - 
       CoefB*(-2*Sqrt[3] + Sqrt[3]*kappau - 3*deltaI*kappau*thetaprpi + 
         kappad*(Sqrt[3] + 3*deltaI*thetaprpi))) - 3*Sqrt[2]*CoefA*deltaI*thetaprpi*thpiALP + 
     3*Sqrt[2]*CoefB*deltaI*thetaprpi*thpiALP)*Cos[thetas] - 
   (2*Sqrt[2]*CoefA*thetaALP + 5*Sqrt[2]*CoefC*thetaALP + 8*Sqrt[2]*CoefD*thetaALP + 
     8*CoefA*thetaprALP + 12*CoefB*thetaprALP + 8*CoefC*thetaprALP + 32*CoefD*thetaprALP + 
     2*cg*(2*Sqrt[3]*CoefA + Sqrt[3]*(CoefC + 8*CoefD + 2*CoefC*kappad + 2*CoefC*kappau) - 
       2*CoefB*(-2*Sqrt[3] + Sqrt[3]*kappad + Sqrt[3]*kappau + 3*deltaI*kappad*thetaprpi - 
         3*deltaI*kappau*thetaprpi)) + 12*CoefB*deltaI*thetaprpi*thpiALP)*Sin[thetas])*
  UnitStep[-m23 + 4*mK^2])/(24*(m23 + I*(Gammasigma + I*msigma)*msigma))