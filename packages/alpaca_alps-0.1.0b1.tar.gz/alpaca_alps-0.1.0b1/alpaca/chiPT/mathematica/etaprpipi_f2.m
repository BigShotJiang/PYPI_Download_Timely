-1/144*(gT^2*(m23^2*(ma^2 + metap^2 - mf2^2)*(mf2^2 - 2*mpiplus^2) - 
    2*mf2^2*(3*m12^2*mf2^2 + 2*ma^4*mpiplus^2 - 3*m12*mf2^2*(ma^2 + metap^2 + 2*mpiplus^2) + 
      mpiplus^2*(2*metap^4 + metap^2*mf2^2 + 3*mf2^2*mpiplus^2) + 
      ma^2*(mf2^2*mpiplus^2 + metap^2*(3*mf2^2 - 4*mpiplus^2))) + 
    m23*(-(ma^4*(mf2^2 - 2*mpiplus^2)) - metap^4*(mf2^2 - 2*mpiplus^2) + 2*mf2^4*(-3*m12 + mpiplus^2) + 
      metap^2*(mf2^4 + 2*mf2^2*mpiplus^2) + ma^2*(mf2^4 + 2*mf2^2*mpiplus^2 + 
        2*metap^2*(mf2^2 - 2*mpiplus^2))))*(Sqrt[2]*thetaALP + thetaprALP + 
    cg*kappad*(Sqrt[3] - 3*deltaI*thetaprpi) + cg*kappau*(Sqrt[3] + 3*deltaI*thetaprpi) + 
    3*deltaI*thetaprpi*thpiALP)*UnitStep[m23 - (Gammaf2 - mf2)^2])/
  (mf2^4*(-m23 + mf2*((-I)*Gammaf2 + mf2)))