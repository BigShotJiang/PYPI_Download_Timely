# Python another itertools.

## Installation

You can install from [pypi](https://pypi.org/project/python-iterutils/)

```console
pip install -U python-iterutils
```

## Usage

```python
import iterutils
```
