gRPC Python Reflection package
==============================

Reference package for reflection in GRPC Python.


Dependencies
------------

Depends on the `grpcio` package, available from PyPI via `pip install grpcio`.

