"""
Arazzo Workflow Test Fixtures

This package contains test fixtures for Arazzo workflows.
Each subdirectory contains a complete set of Arazzo and OpenAPI specs for testing.
"""
