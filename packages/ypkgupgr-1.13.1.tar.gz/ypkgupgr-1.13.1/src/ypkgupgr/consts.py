APP_NAME = "ypkgupgr"
AUTHOR_NAME = "Yesser Studios"
