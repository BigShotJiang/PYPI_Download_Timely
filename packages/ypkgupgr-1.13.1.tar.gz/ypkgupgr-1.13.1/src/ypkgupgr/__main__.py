from . import update_command

update_command()
