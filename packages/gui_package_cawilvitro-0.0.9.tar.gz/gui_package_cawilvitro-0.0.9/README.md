created using
https://packaging.python.org/en/latest/guides/distributing-packages-using-setuptools/
