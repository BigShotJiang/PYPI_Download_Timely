"""
Dana Dana Module System - Module Loader

This module provides the loader responsible for finding and loading Dana modules.

Copyright © 2025 Aitomatic, Inc.
MIT License
"""

from __future__ import annotations

from collections.abc import Sequence
from importlib.abc import Loader, MetaPathFinder
from importlib.machinery import ModuleSpec as PyModuleSpec
from pathlib import Path
from typing import TYPE_CHECKING

from dana.core.lang.parser.utils.parsing_utils import ParserCache

from .errors import ImportError, ModuleNotFoundError, SyntaxError
from .registry import ModuleRegistry
from .types import Module, ModuleSpec

if TYPE_CHECKING:
    from dana.core.lang.interpreter.dana_interpreter import DanaInterpreter
    from dana.core.lang.sandbox_context import SandboxContext


class ModuleLoader(MetaPathFinder, Loader):
    """Loader responsible for finding and loading Dana modules."""

    def __init__(self, search_paths: list[str], registry: ModuleRegistry):
        """Initialize a new module loader.

        Args:
            search_paths: List of paths to search for modules
            registry: Module registry instance
        """
        self.search_paths = [Path(p).resolve() for p in search_paths]
        self.registry = registry

    def find_spec(self, fullname: str, path: Sequence[str | bytes] | None = None, target: Module | None = None) -> PyModuleSpec | None:
        """Find a module specification.

        This implements the MetaPathFinder protocol for Python's import system.
        IMPORTANT: Only handles Dana modules (.na files). Returns None for all
        other modules to let Python's normal import system handle them.

        Args:
            fullname: Fully qualified module name
            path: Search path (unused, we use our own search paths)
            target: Module object if reload (unused)

        Returns:
            Module specification if found, None otherwise (does NOT raise)
        """
        # For internal use: extract importing module path from path if provided
        importing_module_path = None
        if path and isinstance(path, list) and len(path) > 0 and isinstance(path[0], str):
            # Check if the first element looks like a file path (internal convention)
            first_path = path[0]
            if first_path.startswith("__dana_importing_from__:"):
                importing_module_path = first_path[23:]  # Remove prefix

        return self._find_spec_with_context(fullname, importing_module_path)

    def _find_spec_with_context(self, fullname: str, importing_module_path: str | None = None) -> PyModuleSpec | None:
        """Find a module specification with optional context of importing module.

        Args:
            fullname: Fully qualified module name
            importing_module_path: Path of the module doing the import (if any)

        Returns:
            Module specification if found, None otherwise
        """
        # Only handle Dana module names (no internal Python modules)
        # Skip Python internal modules and standard library modules
        if (
            fullname.startswith("_")
            or "." in fullname
            and fullname.split(".")[0]
            in {
                "collections",
                "sys",
                "os",
                "json",
                "math",
                "datetime",
                "traceback",
                "importlib",
                "threading",
                "logging",
                "urllib",
                "http",
                "xml",
                "html",
                "email",
                "calendar",
                "time",
                "random",
                "hashlib",
                "pickle",
                "copy",
                "itertools",
                "functools",
                "operator",
                "pathlib",
                "re",
                "uuid",
                "base64",
                "binascii",
                "struct",
                "array",
                "weakref",
                "gc",
                "types",
                "inspect",
                "ast",
                "dis",
                "encodings",
                "codecs",
                "io",
                "tempfile",
                "shutil",
                "glob",
                "fnmatch",
                "subprocess",
                "signal",
                "socket",
                "select",
                "errno",
                "stat",
                "platform",
                "getpass",
                "pwd",
                "grp",
                "ctypes",
                "concurrent",
                "asyncio",
                "multiprocessing",
                "queue",
                "heapq",
                "bisect",
                "contextlib",
                "decimal",
                "fractions",
                "statistics",
                "zlib",
                "gzip",
                "bz2",
                "lzma",
                "zipfile",
                "tarfile",
                "csv",
                "configparser",
                "netrc",
                "xdrlib",
                "plistlib",
                "sqlite3",
                "dbm",
                "zoneinfo",
                "argparse",
                "getopt",
                "shlex",
                "readline",
                "rlcompleter",
                "cmd",
                "pdb",
                "profile",
                "pstats",
                "timeit",
                "trace",
                "cProfile",
                "unittest",
                "doctest",
                "test",
                "bdb",
                "faulthandler",
                "warnings",
                "dataclasses",
                "contextlib2",
                "typing_extensions",
                "packaging",
                "setuptools",
                "pip",
                "wheel",
                "distutils",
                "pkg_resources",
                "six",
                "certifi",
                "urllib3",
                "requests",
                "click",
                "jinja2",
                "werkzeug",
                "flask",
                "django",
                "lark",
                "pytest",
                "numpy",
                "pandas",
                "matplotlib",
                "scipy",
                "sklearn",
                "tensorflow",
                "torch",
                "boto3",
                "pydantic",
                "fastapi",
            }
        ):
            return None

        # Check if spec already exists in registry
        try:
            dana_spec = self.registry.get_spec(fullname)
            if dana_spec is not None:
                # Convert to Python spec
                py_spec = PyModuleSpec(name=dana_spec.name, loader=self, origin=dana_spec.origin)
                py_spec.has_location = dana_spec.has_location
                py_spec.submodule_search_locations = dana_spec.submodule_search_locations
                return py_spec
        except ModuleNotFoundError:
            pass  # Continue searching

        # Extract module name from fullname
        module_name = fullname.split(".")[-1]

        # If this is a submodule, check parent package's search paths
        if "." in fullname:
            parent_name = fullname.rsplit(".", 1)[0]
            try:
                parent_spec = self.find_spec(parent_name, None)
                if parent_spec is not None and parent_spec.submodule_search_locations:
                    # Search for module file in parent package's search paths
                    for search_path in parent_spec.submodule_search_locations:
                        module_file = Path(search_path) / f"{module_name}.na"
                        if module_file.is_file():
                            # Create and register Dana spec
                            dana_spec = ModuleSpec(name=fullname, loader=self, origin=str(module_file))
                            # Check if this module can also serve as a package
                            self._setup_package_attributes(dana_spec)
                            self.registry.register_spec(dana_spec)
                            # Convert to Python spec
                            py_spec = PyModuleSpec(name=dana_spec.name, loader=self, origin=dana_spec.origin)
                            py_spec.has_location = dana_spec.has_location
                            py_spec.submodule_search_locations = dana_spec.submodule_search_locations
                            return py_spec

                        # Also check for package/__init__.na in parent's search paths
                        init_file = Path(search_path) / module_name / "__init__.na"
                        if init_file.is_file():
                            # Create and register Dana spec
                            dana_spec = ModuleSpec(name=fullname, loader=self, origin=str(init_file))
                            self._setup_package_attributes(dana_spec)
                            self.registry.register_spec(dana_spec)
                            # Convert to Python spec
                            py_spec = PyModuleSpec(name=dana_spec.name, loader=self, origin=dana_spec.origin)
                            py_spec.has_location = dana_spec.has_location
                            py_spec.submodule_search_locations = dana_spec.submodule_search_locations
                            return py_spec
            except ModuleNotFoundError:
                pass  # Continue searching

        # Search for module file in search paths
        # First, try to find in the importing module's directory if available
        if importing_module_path:
            importing_dir = Path(importing_module_path).parent
            module_file = self._find_module_in_directory(module_name, importing_dir)
            if module_file is not None:
                # Create and register Dana spec
                dana_spec = ModuleSpec(name=fullname, loader=self, origin=str(module_file))
                # Check if this module can also serve as a package
                self._setup_package_attributes(dana_spec)
                self.registry.register_spec(dana_spec)
                # Convert to Python spec
                py_spec = PyModuleSpec(name=dana_spec.name, loader=self, origin=dana_spec.origin)
                py_spec.has_location = dana_spec.has_location
                py_spec.submodule_search_locations = dana_spec.submodule_search_locations
                return py_spec

        # Then search in regular search paths
        module_file = self._find_module_file(module_name)
        if module_file is not None:
            # Create and register Dana spec
            dana_spec = ModuleSpec(name=fullname, loader=self, origin=str(module_file))
            # Check if this module can also serve as a package
            self._setup_package_attributes(dana_spec)
            self.registry.register_spec(dana_spec)
            # Convert to Python spec
            py_spec = PyModuleSpec(name=dana_spec.name, loader=self, origin=dana_spec.origin)
            py_spec.has_location = dana_spec.has_location
            py_spec.submodule_search_locations = dana_spec.submodule_search_locations
            return py_spec

        # Module not found after checking all paths - return None to let Python handle it
        return None

    def _setup_package_attributes(self, spec: ModuleSpec) -> None:
        """Set up package attributes for a module spec.

        This allows both __init__.na files and regular .na files to serve as packages
        if they have subdirectories with modules.

        Args:
            spec: Module specification to set up
        """
        if not spec.origin:
            return

        origin_path = Path(spec.origin)

        # Case 1: __init__.na files are always packages
        if origin_path.name == "__init__.na":
            spec.submodule_search_locations = [str(origin_path.parent)]
            if "." in spec.name:
                spec.parent = spec.name.rsplit(".", 1)[0]
        else:
            # Case 2: Regular .na files can also be packages if they have a directory with the same name
            # This enables a.b.na to serve as a package for a.b.c modules
            module_dir = origin_path.parent / origin_path.stem
            if module_dir.is_dir():
                # Check if the directory contains any .na files or subdirectories with __init__.na
                has_submodules = any(f.suffix == ".na" for f in module_dir.iterdir() if f.is_file()) or any(
                    (subdir / "__init__.na").exists() for subdir in module_dir.iterdir() if subdir.is_dir()
                )
                if has_submodules:
                    spec.submodule_search_locations = [str(module_dir)]
                    if "." in spec.name:
                        spec.parent = spec.name.rsplit(".", 1)[0]

    def create_module(self, spec: PyModuleSpec) -> Module | None:
        """Create a new module object.

        Args:
            spec: Python module specification

        Returns:
            New module object, or None to use Python's default
        """
        if not spec.origin:
            raise ImportError(f"No origin specified for module {spec.name}")

        # If the input spec is a Dana spec, use it directly
        if isinstance(spec, ModuleSpec):
            dana_spec = spec
        else:
            # Get Dana spec from registry or create new one
            dana_spec = self.registry.get_spec(spec.name)
            if dana_spec is None:
                # Create new spec if not found
                dana_spec = ModuleSpec.from_py_spec(spec)
                self.registry.register_spec(dana_spec)

        # Create new module
        module = Module(__name__=spec.name, __file__=spec.origin)

        # Set up package attributes if this is a package
        if spec.origin.endswith("__init__.na"):
            module.__path__ = [str(Path(spec.origin).parent)]
            module.__package__ = spec.name
        elif "." in spec.name:
            # Submodule of a package
            module.__package__ = spec.name.rsplit(".", 1)[0]

        # Set spec
        module.__spec__ = dana_spec

        # Register module
        self.registry.register_module(module)

        return module

    def exec_module(self, module: Module) -> None:
        """Execute a module's code.

        Args:
            module: Module to execute
        """
        if not module.__file__:
            raise ImportError(f"No file path for module {module.__name__}")

        # Start loading
        self.registry.start_loading(module.__name__)
        try:
            # Read source
            source = Path(module.__file__).read_text()

            # Parse and compile
            from lark.exceptions import UnexpectedCharacters, UnexpectedToken

            parser = ParserCache.get_parser("dana")
            try:
                ast = parser.parse(source)
            except (UnexpectedToken, UnexpectedCharacters) as e:
                # Extract line number and source line from the error
                line_number = e.line
                source_line = source.splitlines()[line_number - 1] if line_number > 0 else None
                raise SyntaxError(str(e), module.__name__, module.__file__, line_number, source_line)

            # Execute
            from dana.core.lang.interpreter.dana_interpreter import DanaInterpreter
            from dana.core.lang.sandbox_context import SandboxContext

            interpreter = DanaInterpreter()
            context = SandboxContext()
            context._interpreter = interpreter  # Set the interpreter in the context

            # Set current module and package for relative import resolution
            context._current_module = module.__name__
            # Set current package for relative import resolution
            # Special case: for __init__.na files, the current package is the module itself
            # For regular modules, the current package is the parent package
            origin_path = Path(module.__file__) if module.__file__ else None
            if origin_path and origin_path.name == "__init__.na":
                # __init__.na file - current package is the module itself
                context._current_package = module.__name__
            elif "." in module.__name__:
                # Regular module - current package is parent package
                context._current_package = module.__name__.rsplit(".", 1)[0]
            else:
                # Top-level module has no package
                context._current_package = ""
            # Debug logging
            # print(f"DEBUG: Setting context for module {module.__name__}, package = {context._current_package}")

            # Initialize module dict with context
            for key, value in module.__dict__.items():
                context.set_in_scope(key, value, scope="local")

            # Execute the module
            interpreter._execute(ast, context)

            # Update module dict with local scope
            module.__dict__.update(context.get_scope("local"))

            # Also include public scope variables in the module namespace
            # Public variables should be accessible as module attributes
            public_vars = context.get_scope("public")
            module.__dict__.update(public_vars)

            # Include system scope variables for agent functionality
            # This allows modules with system:agent_name and system:agent_description to be used as agents
            system_vars = context.get_scope("system")
            for key, value in system_vars.items():
                # Store system variables with their scope prefix for easy identification
                module.__dict__[f"system:{key}"] = value

            # Handle exports
            if hasattr(context, "_exports"):
                # Explicit exports override underscore privacy - respect user's explicit choices
                module.__exports__ = context._exports
            else:
                # If no explicit exports, export all local and public variables
                local_vars = set(context.get_scope("local").keys())
                public_vars_set = set(public_vars.keys())
                all_vars = local_vars | public_vars_set

                # Apply underscore privacy rule: auto-export everything except names starting with '_'
                module.__exports__ = {name for name in all_vars if not name.startswith("_")}

            # Always remove internal Python variables (double underscore) from exports
            module.__exports__ = {name for name in module.__exports__ if not name.startswith("__")}

            # Post-process: Ensure DanaFunction objects can access each other for recursive calls
            self._setup_module_function_context(module, interpreter, context)

        finally:
            # Finish loading
            self.registry.finish_loading(module.__name__)

    def _setup_module_function_context(self, module: Module, interpreter: DanaInterpreter, context: SandboxContext) -> None:
        """Set up function contexts to enable recursive calls within the module.

        Args:
            module: The executed module
            interpreter: The interpreter used for execution
            context: The execution context
        """
        from dana.core.lang.interpreter.functions.dana_function import DanaFunction
        from dana.core.lang.interpreter.functions.function_registry import FunctionMetadata, FunctionType

        # Find all DanaFunction objects in the module
        dana_functions = {}
        for name, obj in module.__dict__.items():
            if isinstance(obj, DanaFunction):
                dana_functions[name] = obj

        # If we have DanaFunction objects, set up their contexts properly
        if dana_functions and interpreter.function_registry:
            # Register all module functions in a temporary registry context
            # This allows recursive calls within the module
            for func_name, func_obj in dana_functions.items():
                try:
                    # Create metadata for the function
                    metadata = FunctionMetadata(source_file=module.__file__ or f"<module {module.__name__}>")
                    metadata.context_aware = True
                    metadata.is_public = True
                    metadata.doc = f"Module function from {module.__name__}.{func_name}"

                    # Register the function in the interpreter's registry
                    interpreter.function_registry.register(
                        name=func_name, func=func_obj, namespace="local", func_type=FunctionType.DANA, metadata=metadata, overwrite=True
                    )

                    # Ensure the function's execution context has access to the interpreter
                    if func_obj.context is not None:
                        if not hasattr(func_obj.context, "_interpreter") or func_obj.context._interpreter is None:
                            func_obj.context._interpreter = interpreter

                except Exception as e:
                    # Non-fatal - log and continue
                    print(f"Warning: Could not register module function {func_name}: {e}")

    def _find_module_in_directory(self, module_name: str, directory: Path) -> Path | None:
        """Find a module file in a specific directory.

        Args:
            module_name: Module name to find
            directory: Directory to search in

        Returns:
            Path to module file if found, None otherwise
        """
        # Try .na file
        module_file = directory / f"{module_name}.na"
        if module_file.exists():
            return module_file

        # Try package/__init__.na
        init_file = directory / module_name / "__init__.na"
        if init_file.exists():
            return init_file

        return None

    def _find_module_file(self, module_name: str) -> Path | None:
        """Find a module file in the search paths.

        Args:
            module_name: Module name to find

        Returns:
            Path to module file if found, None otherwise
        """
        for search_path in self.search_paths:
            # Try .na file
            module_file = search_path / f"{module_name}.na"
            if module_file.exists():
                return module_file

            # Try package/__init__.na
            init_file = search_path / module_name / "__init__.na"
            if init_file.exists():
                return init_file

        return None
