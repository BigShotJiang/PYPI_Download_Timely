"""Top-level package for MDTerp."""

__author__ = """shams mehdi"""
__email__ = "shamsmehdi222@gmail.com"
__version__ = "0.1.3"
