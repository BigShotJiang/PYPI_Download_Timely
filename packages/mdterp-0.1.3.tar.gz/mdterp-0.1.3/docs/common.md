# common module

::: MDTerp.common