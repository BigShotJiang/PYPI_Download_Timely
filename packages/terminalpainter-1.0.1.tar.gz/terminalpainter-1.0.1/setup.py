from setuptools import setup, find_packages

setup(
    name='terminalpainter',
    version='1.0.1',
    packages=find_packages(),
    author='professionalincpp',
    author_email='griguchaev@yandex.ru',
    description='Terminal painter',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/professionsalincpp/terminalpainter',
    license='MIT',
    classifiers=[
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Topic :: Terminals',
        'Topic :: Utilities',
    ],
    python_requires='>=3.10',
    install_requires=[],
    tests_require=[],
    setup_requires=[],
)