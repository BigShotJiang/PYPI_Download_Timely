from .explosives import self_destruct
