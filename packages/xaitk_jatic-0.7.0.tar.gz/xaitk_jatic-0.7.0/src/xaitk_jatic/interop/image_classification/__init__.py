"""Implementations to use XAITK for image classifcation in a maite compliant way"""
