"""Jatic compliant dataset and model objects for using XAITK for object detection"""
