"""Model implementations and factory."""
