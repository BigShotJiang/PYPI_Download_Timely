# TouchLab Comm Python

The **TouchLab Comm Python** is the driver for reading data from Touchlab Sensors. This is a python wrapper of the c++ library.

Example usage:
```bash
cd <PATH_TO_TOUCHLAB_COMM_PY>
python3 examples/example.py <SERIAL_PORT> <CALIBRATION_FILE>
```
