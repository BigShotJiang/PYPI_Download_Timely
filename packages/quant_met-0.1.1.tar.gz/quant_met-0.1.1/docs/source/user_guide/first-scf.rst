

A first self-consistency calculation
====================================
