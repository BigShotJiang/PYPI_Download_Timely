

.. _bdg:

.. automodule:: quant_met.bdg
