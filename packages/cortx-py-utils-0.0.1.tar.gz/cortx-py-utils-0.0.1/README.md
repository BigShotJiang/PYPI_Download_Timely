# cortx-py-utils
This is a safe dummy PoC package.