{{cookiecutter.description}}

Requires Python {{cookiecutter.requires_python}}+
