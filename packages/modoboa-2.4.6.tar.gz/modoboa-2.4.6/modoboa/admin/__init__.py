default_app_config = "modoboa.admin.apps.AdminConfig"
