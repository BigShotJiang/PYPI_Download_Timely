"""DMARC related tools for Modoboa."""

default_app_config = "modoboa.dmarc.apps.DmarcConfig"
