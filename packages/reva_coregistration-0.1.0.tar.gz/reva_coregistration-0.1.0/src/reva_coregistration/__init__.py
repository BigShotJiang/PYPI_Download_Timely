"""
Reva Coregistration Package

A Python package for image coregistration and coordinate transformation.
"""

__version__ = "0.1.0"
__author__ = "Robert Toth, PhD"
__email__ = "robert.toth@thetatech.ai"
