# ModelProblemType


## Enum

* `REGRESSION` (value: `'regression'`)

* `BINARY_CLASSIFICATION` (value: `'binary_classification'`)

* `ARTHUR_SHIELD` (value: `'arthur_shield'`)

* `CUSTOM` (value: `'custom'`)

* `MULTICLASS_CLASSIFICATION` (value: `'multiclass_classification'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


