To use this module, you need to:

1.  Go to *Manufacturing \> Reporting \> BoM Current Stock Explosion*.
2.  Select Product, BoM and location and click on *Explode*.
3.  Set the proper location (if desired) for all the components
    displayed if you haven't done so in the related BoMs.
4.  Click *Print Report*.
