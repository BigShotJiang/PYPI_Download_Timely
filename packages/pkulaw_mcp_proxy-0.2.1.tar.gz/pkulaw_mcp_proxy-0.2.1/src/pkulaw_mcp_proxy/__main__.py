from pkulaw_mcp_proxy import main

main()

