from .research_data import ResearchData

__all__ = ['ResearchData']