from pathlib import Path

# Package directories
packagePath = Path(__file__).parent
# When published this should be something like:
# C:\path\to\project\.venv\Lib\site-packages\no
print("Package path:", packagePath)

# if the parent of the package is site-packages, take userProjectPath 4 levels up
if packagePath.parent.name == "site-packages":
    userProjectPath = packagePath.parent.parent.parent.parent
else:
    userProjectPath = packagePath.parent
# When published this should be something like:
# C:\path\to\project
print("User project path:", userProjectPath)


languagePath = userProjectPath / "no.language"