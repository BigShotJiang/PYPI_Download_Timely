from setuptools import setup, find_packages

setup(
    name="no-exceptions",
    version="0.1.0",
    description="A callable interface for structured exceptions",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Your Name",
    author_email="you@example.com",
    license="MIT",
    python_requires=">=3.11",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    include_package_data=True,
    package_data={
        "no": ["py.typed"],
        "noExceptions": []  # include the stub-only alias package
    },
    entry_points={
        "console_scripts": [
            "no-exceptions-test = test.__init__:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
)
