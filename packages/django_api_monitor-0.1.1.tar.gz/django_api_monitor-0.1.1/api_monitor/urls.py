# from django.urls import path
# from .views import usage_stats_view
#
# urlpatterns = [
#     path('stats/', usage_stats_view, name='api-usage-stats'),
# ]
