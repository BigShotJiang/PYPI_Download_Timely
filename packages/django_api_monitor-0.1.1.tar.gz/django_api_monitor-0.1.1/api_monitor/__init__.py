__title__ = "Django API Usage Monitor"
__version__ = "0.1.0"
__author__ = "anirudh_mk"
__license__ = "MIT"
__copyright__ = "Copyright (c) 2025 anirudh_mk.com"

VERSION = __version__

default_app_config = 'api_monitor.apps.ApiMonitorConfig'
