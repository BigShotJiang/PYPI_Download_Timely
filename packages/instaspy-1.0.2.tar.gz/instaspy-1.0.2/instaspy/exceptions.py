class CookieError(Exception):
    pass

class UserNotFound(Exception):
    pass
