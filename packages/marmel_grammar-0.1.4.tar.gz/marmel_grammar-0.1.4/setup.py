from setuptools import setup, find_packages

setup(
    name="marmel-grammar",
    version="0.1.4",
    description="Грамматика Marmel для Python.",
    author="Dev-Marmel",
    packages=find_packages(),
    python_requires=">=3.7",
)