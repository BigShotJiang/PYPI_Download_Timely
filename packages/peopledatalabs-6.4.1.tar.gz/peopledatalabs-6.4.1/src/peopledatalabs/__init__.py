"""
PeopleDataLabs Python Client.
"""

from .main import PDLPY


__version__ = "6.4.1"

__all__ = ["PDLPY"]
