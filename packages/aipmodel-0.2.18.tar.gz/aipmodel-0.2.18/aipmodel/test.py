def download_model(model_id):
    print(f"[SDK] Downloading model with ID: {model_id}")

def create_model(name):
    print(f"[SDK] Creating model with name: {name}")

def get_model(model_id):
    print(f"[SDK] Getting model with ID: {model_id}")
    return model_id

def list_models():
    print("[SDK] Listing all models test1")
    
