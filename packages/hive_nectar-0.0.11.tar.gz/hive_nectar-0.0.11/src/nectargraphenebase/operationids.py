#: Operation ids
operations = {}
operations["demooepration"] = 0
