nectar\.block
=============

.. automodule:: nectar.block
    :members:
    :undoc-members:
    :show-inheritance: