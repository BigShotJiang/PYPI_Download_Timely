nectar\.instance
================

.. automodule:: nectar.instance
    :members:
    :undoc-members:
    :show-inheritance: