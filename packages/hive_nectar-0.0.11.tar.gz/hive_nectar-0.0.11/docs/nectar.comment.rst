nectar\.comment
===============

.. automodule:: nectar.comment
    :members:
    :undoc-members:
    :show-inheritance: