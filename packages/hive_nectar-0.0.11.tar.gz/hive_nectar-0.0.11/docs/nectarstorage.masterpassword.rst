nectarstorage\.masterpassword
=============================

.. automodule:: nectarstorage.masterpassword
    :members:
    :undoc-members:
    :show-inheritance: