nectar\.witness
===============

.. automodule:: nectar.witness
    :members:
    :undoc-members:
    :show-inheritance:
   
