nectar\.rc
==========

.. automodule:: nectar.rc
    :members:
    :undoc-members:
    :show-inheritance:
