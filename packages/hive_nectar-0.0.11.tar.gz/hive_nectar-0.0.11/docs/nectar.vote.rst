nectar\.vote
============

.. automodule:: nectar.vote
    :members:
    :undoc-members:
    :show-inheritance: