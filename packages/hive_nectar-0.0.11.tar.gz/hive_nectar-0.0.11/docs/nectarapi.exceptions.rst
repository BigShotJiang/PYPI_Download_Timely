nectarapi\.exceptions
=====================

.. automodule:: nectarapi.exceptions
    :members:
    :undoc-members:
    :show-inheritance:
