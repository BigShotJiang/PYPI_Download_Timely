nectar\.exceptions
==================

.. automodule:: nectar.exceptions
    :members:
    :undoc-members:
    :show-inheritance: