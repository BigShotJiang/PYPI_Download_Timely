from __future__ import annotations

import importlib.metadata

VERSION = importlib.metadata.version("vortex_cli")
