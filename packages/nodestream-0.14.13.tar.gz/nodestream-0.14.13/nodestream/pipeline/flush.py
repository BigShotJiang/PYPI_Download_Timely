class Flush:
    pass
