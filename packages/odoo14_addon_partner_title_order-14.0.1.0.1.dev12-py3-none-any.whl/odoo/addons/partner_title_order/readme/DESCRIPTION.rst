Add sequence to partner title to be able to determine their order.
