* Simone Orsi <simone.orsi@camptocamp.com>
* `Trobz <https://trobz.com>`_:
    * Khoi Vo <khoivha@trobz.com>
