"""Package implementing formatting commands to normalize descriptor files."""
