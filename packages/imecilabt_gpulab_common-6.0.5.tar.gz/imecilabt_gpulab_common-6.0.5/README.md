GPULab Common
=============

Common code used by various GPULab components.

This contains a few data models, some config helpers, and some utils.

References: 
- GPULab Site: https://gpulab.ilabt.imec.be/
- GPULab Documentation: https://doc.ilabt.imec.be/ilabt/gpulab/
- GPULab Common Gitlab (currently private): https://gitlab.ilabt.imec.be/ilabt/gpulab/gpulab-common
- GPULab CLI Gitlab (currently private): https://gitlab.ilabt.imec.be/ilabt/gpulab/gpulab-cli
- PyPi: https://pypi.org/project/imecilabt-gpulab-common/
