class Coupling:
    def __init__(self, name, ref_node, surface):
        self.name = name
        self.ref_node = ref_node
        self.surface = surface
