from pybenutils.cli_tools import cli_main_for_class

from pybenparallels.parallels_utils import ParallelsCLI

cli_main_for_class(ParallelsCLI)