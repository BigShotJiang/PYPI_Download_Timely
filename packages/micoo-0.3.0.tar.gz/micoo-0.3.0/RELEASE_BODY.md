## [0.3.0] - 2025-07-27

### Fixed

- Versioning by @hasansezertasan

