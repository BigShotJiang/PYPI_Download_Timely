from enum import Enum


def enum_to_str(value: Enum) -> str:
    return value.value
