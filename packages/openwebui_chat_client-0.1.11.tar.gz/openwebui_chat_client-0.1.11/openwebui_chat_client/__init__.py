from .openwebui_chat_client import OpenWebUIClient

__version__ = "0.1.9"
__author__ = "fujie"
