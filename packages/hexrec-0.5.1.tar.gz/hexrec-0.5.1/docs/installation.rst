============
Installation
============

From *PyPI*
-----------

At the command line:

.. code-block:: sh

    $ pip install hexrec

The package found on *PyPI* might be outdated with respect to the source
repository.


From source
-----------

At the command line, at the root of the source directory:

.. code-block:: sh

    $ pip install .
