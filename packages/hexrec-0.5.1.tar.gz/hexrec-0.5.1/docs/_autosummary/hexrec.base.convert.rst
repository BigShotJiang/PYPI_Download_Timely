convert
=======

.. currentmodule:: hexrec.base

.. autofunction:: convert