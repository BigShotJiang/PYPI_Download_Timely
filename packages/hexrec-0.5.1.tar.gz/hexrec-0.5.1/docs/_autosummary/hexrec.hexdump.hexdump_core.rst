hexdump\_core
=============

.. currentmodule:: hexrec.hexdump

.. autofunction:: hexdump_core