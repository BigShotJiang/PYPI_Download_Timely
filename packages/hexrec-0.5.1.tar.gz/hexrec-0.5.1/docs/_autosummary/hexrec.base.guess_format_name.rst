guess\_format\_name
===================

.. currentmodule:: hexrec.base

.. autofunction:: guess_format_name