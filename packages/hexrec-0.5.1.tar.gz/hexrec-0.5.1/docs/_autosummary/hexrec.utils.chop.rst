chop
====

.. currentmodule:: hexrec.utils

.. autofunction:: chop