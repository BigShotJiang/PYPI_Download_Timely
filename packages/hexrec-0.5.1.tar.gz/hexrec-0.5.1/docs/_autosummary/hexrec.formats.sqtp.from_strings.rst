from\_strings
=============

.. currentmodule:: hexrec.formats.sqtp

.. autofunction:: from_strings