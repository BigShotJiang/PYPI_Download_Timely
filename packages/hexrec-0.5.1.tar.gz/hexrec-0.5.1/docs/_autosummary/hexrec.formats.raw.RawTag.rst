RawTag
======

.. currentmodule:: hexrec.formats.raw

.. autoclass:: RawTag
    :members:
    :inherited-members:
    :private-members:
    :special-members:




    .. rubric:: Attributes

    .. autosummary::

        ~RawTag.DATA






    .. rubric:: Methods

    .. autosummary::
        :nosignatures:

        ~RawTag.is_data
        ~RawTag.is_file_termination

