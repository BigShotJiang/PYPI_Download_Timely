SIZE\_TO\_ADDRESS\_FORMAT
=========================

.. currentmodule:: hexrec.formats.srec

.. autodata:: SIZE_TO_ADDRESS_FORMAT