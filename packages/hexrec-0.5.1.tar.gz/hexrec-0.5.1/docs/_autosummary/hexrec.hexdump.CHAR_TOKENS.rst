CHAR\_TOKENS
============

.. currentmodule:: hexrec.hexdump

.. autodata:: CHAR_TOKENS