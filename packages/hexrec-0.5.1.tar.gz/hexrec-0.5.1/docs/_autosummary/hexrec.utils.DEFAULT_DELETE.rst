DEFAULT\_DELETE
===============

.. currentmodule:: hexrec.utils

.. autodata:: DEFAULT_DELETE