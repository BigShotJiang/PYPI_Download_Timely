CHAR\_ASCII
===========

.. currentmodule:: hexrec.xxd

.. autodata:: CHAR_ASCII