TOKEN\_COLOR\_CODES
===================

.. currentmodule:: hexrec.base

.. autodata:: TOKEN_COLOR_CODES