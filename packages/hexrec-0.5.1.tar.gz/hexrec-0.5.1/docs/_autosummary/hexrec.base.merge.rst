merge
=====

.. currentmodule:: hexrec.base

.. autofunction:: merge