hexlify
=======

.. currentmodule:: hexrec.utils

.. autofunction:: hexlify