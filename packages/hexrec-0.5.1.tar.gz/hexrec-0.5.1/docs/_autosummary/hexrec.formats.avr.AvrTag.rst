AvrTag
======

.. currentmodule:: hexrec.formats.avr

.. autoclass:: AvrTag
    :members:
    :inherited-members:
    :private-members:
    :special-members:




    .. rubric:: Attributes

    .. autosummary::

        ~AvrTag.DATA






    .. rubric:: Methods

    .. autosummary::
        :nosignatures:

        ~AvrTag.is_data
        ~AvrTag.is_file_termination

