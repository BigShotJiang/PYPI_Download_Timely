unhexlify
=========

.. currentmodule:: hexrec.utils

.. autofunction:: unhexlify