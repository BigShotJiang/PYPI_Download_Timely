file\_types
===========

.. currentmodule:: hexrec.base

.. autodata:: file_types