xxd\_core
=========

.. currentmodule:: hexrec.xxd

.. autofunction:: xxd_core