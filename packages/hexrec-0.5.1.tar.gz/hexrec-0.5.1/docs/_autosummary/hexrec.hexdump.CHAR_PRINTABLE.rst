CHAR\_PRINTABLE
===============

.. currentmodule:: hexrec.hexdump

.. autodata:: CHAR_PRINTABLE