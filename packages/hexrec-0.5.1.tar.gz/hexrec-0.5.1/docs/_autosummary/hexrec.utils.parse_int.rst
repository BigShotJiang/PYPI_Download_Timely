parse\_int
==========

.. currentmodule:: hexrec.utils

.. autofunction:: parse_int