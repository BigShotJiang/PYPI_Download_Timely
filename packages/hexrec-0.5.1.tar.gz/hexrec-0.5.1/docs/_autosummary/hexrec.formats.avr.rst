﻿avr
===

.. automodule:: hexrec.formats.avr














    .. rubric:: Classes

    .. autosummary::
        :toctree:
        :template: custom-class-template.rst
        :nosignatures:

        AvrFile
        AvrRecord
        AvrTag












