﻿xxd
===

.. automodule:: hexrec.xxd




    .. rubric:: Attributes

    .. autosummary::
        :toctree:
        :template: custom-base-template.rst
        :nosignatures:

        ~CHAR_ASCII
        ~CHAR_EBCDIC






    .. rubric:: Functions

    .. autosummary::
        :toctree:
        :template: custom-base-template.rst
        :nosignatures:

        ~parse_seek
        ~xxd_core

















