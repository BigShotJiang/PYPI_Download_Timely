CHAR\_EBCDIC
============

.. currentmodule:: hexrec.xxd

.. autodata:: CHAR_EBCDIC