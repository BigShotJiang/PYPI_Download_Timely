parse\_seek
===========

.. currentmodule:: hexrec.xxd

.. autofunction:: parse_seek