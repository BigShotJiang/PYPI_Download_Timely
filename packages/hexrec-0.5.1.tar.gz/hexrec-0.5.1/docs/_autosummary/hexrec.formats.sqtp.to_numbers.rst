to\_numbers
===========

.. currentmodule:: hexrec.formats.sqtp

.. autofunction:: to_numbers