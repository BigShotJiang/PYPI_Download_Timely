colorize\_tokens
================

.. currentmodule:: hexrec.base

.. autofunction:: colorize_tokens