﻿utils
=====

.. automodule:: hexrec.utils




    .. rubric:: Attributes

    .. autosummary::
        :toctree:
        :template: custom-base-template.rst
        :nosignatures:

        ~SUFFIX_SCALE
        ~DEFAULT_DELETE






    .. rubric:: Functions

    .. autosummary::
        :toctree:
        :template: custom-base-template.rst
        :nosignatures:

        ~chop
        ~hexlify
        ~parse_int
        ~unhexlify






    .. rubric:: Classes

    .. autosummary::
        :toctree:
        :template: custom-class-template.rst
        :nosignatures:

        SparseMemoryIO












