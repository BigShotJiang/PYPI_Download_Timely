from\_numbers
=============

.. currentmodule:: hexrec.formats.sqtp

.. autofunction:: from_numbers