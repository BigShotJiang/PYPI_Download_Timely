BaseTag
=======

.. currentmodule:: hexrec.base

.. autoclass:: BaseTag
    :members:
    :inherited-members:
    :private-members:
    :special-members:









    .. rubric:: Methods

    .. autosummary::
        :nosignatures:

        ~BaseTag.__init__
        ~BaseTag.is_data
        ~BaseTag.is_file_termination

