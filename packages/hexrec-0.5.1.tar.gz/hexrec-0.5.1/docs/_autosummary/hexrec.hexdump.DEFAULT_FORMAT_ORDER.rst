DEFAULT\_FORMAT\_ORDER
======================

.. currentmodule:: hexrec.hexdump

.. autodata:: DEFAULT_FORMAT_ORDER