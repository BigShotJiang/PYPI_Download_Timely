guess\_format\_type
===================

.. currentmodule:: hexrec.base

.. autofunction:: guess_format_type