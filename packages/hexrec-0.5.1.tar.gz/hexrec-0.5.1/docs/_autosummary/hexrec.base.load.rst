load
====

.. currentmodule:: hexrec.base

.. autofunction:: load