SUFFIX\_SCALE
=============

.. currentmodule:: hexrec.utils

.. autodata:: SUFFIX_SCALE