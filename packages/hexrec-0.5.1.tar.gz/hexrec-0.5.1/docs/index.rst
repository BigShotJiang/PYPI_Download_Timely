========
Contents
========

.. toctree::
   :maxdepth: 3

   readme
   installation
   cli
   reference
   contributing
   authors
   changelog


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
