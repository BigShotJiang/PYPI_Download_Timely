======================
Command Line Interface
======================

.. click:: hexrec.cli:main
   :prog: hexrec
   :nested: full
