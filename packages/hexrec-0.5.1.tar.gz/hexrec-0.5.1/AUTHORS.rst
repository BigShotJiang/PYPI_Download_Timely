
Authors
=======

* Andrea Zoppi - main developer - https://github.com/TexZK


Special thanks
--------------

* Scott Finneran - main developer of the SRecord project - https://srecord.sourceforge.net/
