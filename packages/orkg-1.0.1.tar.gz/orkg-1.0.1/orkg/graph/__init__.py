from orkg.graph.subgraph import subgraph
