"""penteraction placeholder package

This initial release (v0.0.1) contains **no code**. It simply reserves the
`penteraction` package name on PyPI for future use.
""" 