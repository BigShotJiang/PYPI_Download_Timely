Authors
=======

Current maintainers
-------------------

* Swarag Thaikkandi
* K.M. Sharika


Core contributors
------------------

* Swarag Thaikkandi
* K.M. Sharika
* Miss Nivedita
