# Copyright (C) 2022 Intel Corporation
#
# SPDX-License-Identifier: MIT

from datumaro.plugins.synthetic_data.image_generator import FractalImageGenerator
