# Copyright (C) 2019-2020 Intel Corporation
#
# SPDX-License-Identifier: MIT

import sys

from datumaro.cli.__main__ import main

if __name__ == "__main__":
    sys.exit(main())
