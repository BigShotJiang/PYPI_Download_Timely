"""This module receives a config file which is included in the wheel."""
