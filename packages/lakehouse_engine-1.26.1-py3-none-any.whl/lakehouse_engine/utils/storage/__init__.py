"""Utilities to interact with storage systems."""
