"""Readers package to define reading behaviour."""
