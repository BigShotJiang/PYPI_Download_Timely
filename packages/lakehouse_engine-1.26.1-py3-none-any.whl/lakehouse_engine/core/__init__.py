"""Package with the core behaviour of the lakehouse engine."""
