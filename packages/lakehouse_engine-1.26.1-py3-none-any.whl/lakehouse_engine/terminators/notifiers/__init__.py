"""Notifications module."""
