"""Package to define algorithm terminators (e.g., vacuum, optimize, compute stats)."""
