import logging

# Disables the error about frameworks not installed
logging.getLogger("transformers").disabled = True
