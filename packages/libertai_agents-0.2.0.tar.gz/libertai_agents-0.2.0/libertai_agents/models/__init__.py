from .base import Model as Model
from .models import get_model as get_model
