# LibertAI Agents

<div align="center">

[![pypi](https://img.shields.io/pypi/v/libertai-agents.svg)](https://pypi.org/project/libertai-agents)
[![python](https://img.shields.io/pypi/pyversions/libertai-agents.svg)](https://pypi.org/project/libertai-agents)

</div>

Framework to create and deploy decentralized agents 🚀

> ⚠ This framework is in beta and might undergo some breaking changes before the stable release.

Take a look at [our documentation](https://docs.libertai.io/agents) to get started!