"""Runner package for ShadowSeal - secure code execution."""

from . import loader

__all__ = ['loader']
