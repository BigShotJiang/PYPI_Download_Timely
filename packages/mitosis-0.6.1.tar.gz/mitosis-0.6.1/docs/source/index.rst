``mitosis`` documentation
===================================

.. include:: ../../README.md
   :parser: myst
