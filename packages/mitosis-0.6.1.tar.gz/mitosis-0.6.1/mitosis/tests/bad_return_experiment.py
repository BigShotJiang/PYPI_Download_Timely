def run(**kwargs):
    return 1  # not a dict with key "main"


name = "MockModuleExperiment"
lookup_dict = {"foo": {"test": 2}}
