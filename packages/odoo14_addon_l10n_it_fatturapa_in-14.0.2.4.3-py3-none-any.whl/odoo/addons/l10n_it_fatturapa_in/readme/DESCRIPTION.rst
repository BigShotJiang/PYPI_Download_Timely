**Italiano**

Questo modulo consente di importare i file XML della fattura elettronica versione 1.2

http://www.fatturapa.gov.it/export/fatturazione/it/normativa/f-2.htm

ricevuti attraverso il Sistema di Interscambio (SdI).

http://www.fatturapa.gov.it/export/fatturazione/it/sdi.htm

**English**

This module allows to import Electronic Bill XML files version 1.2

http://www.fatturapa.gov.it/export/fatturazione/en/normativa/f-2.htm

received through the Exchange System (ES).

http://www.fatturapa.gov.it/export/fatturazione/en/sdi.htm
