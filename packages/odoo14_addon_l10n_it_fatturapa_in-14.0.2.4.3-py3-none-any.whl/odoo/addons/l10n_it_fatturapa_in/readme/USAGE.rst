**Italiano**

 * Andare in Contabilità →  Acquisti →  Fattura elettronica
 * Caricare un file XML
 * Visualizzare il contenuto della fattura facendo clic su "Mostra anteprima"
 * Eseguire la procedura guidata "Importa e-fattura" per creare una fattura in bozza oppure "Collega a fattura esistente" per collegare il file XML a una fattura già (automaticamente) creata

Nell'elenco file delle fatture elettroniche in ingresso saranno presenti, in modo predefinito, quelli da registrare. Sono i file che devono ancora essere collegati a una o più fatture fornitore.

**English**

 * Go to Accounting →  Purchases →  Electronic Bill
 * Upload XML file
 * View bill content clicking on 'Show preview'
 * Run 'Import e-bill' wizard to create a draft bill or run 'Link to existing bill' to link the XML file to an already (automatically) created bill

In the incoming electronic bill files list you will see, by default, files to be registered. These are files not yet linked to one or more bills.
