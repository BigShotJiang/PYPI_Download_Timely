**Italiano**

Questo modulo richiede asn1crypto

https://github.com/wbond/asn1crypto

**English**

This module requires asn1crypto

https://github.com/wbond/asn1crypto
