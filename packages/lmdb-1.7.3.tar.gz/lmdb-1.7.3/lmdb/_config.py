CONFIG = dict((('extra_compile_args', ['-DHAVE_PATCHED_LMDB=1', '-UNDEBUG', '-w']), ('extra_sources', ['/home/runner/work/py-lmdb/py-lmdb/build/lib/mdb.c', '/home/runner/work/py-lmdb/py-lmdb/build/lib/midl.c']), ('extra_library_dirs', []), ('extra_include_dirs', ['lib/py-lmdb', '/home/runner/work/py-lmdb/py-lmdb/build/lib', '/home/runner/work/py-lmdb/py-lmdb/lib/py-lmdb']), ('libraries', [])))

