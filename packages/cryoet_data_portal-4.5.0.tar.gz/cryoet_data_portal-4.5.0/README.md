# CryoET Portal api client

The `cryoet_data_portal` package provides a python client to facilitate the use of the Cryo-Electron Tomography Portal. For more information about the API and the project visit the [chanzuckerberg/cryoet-data-portal GitHub repo](https://github.com/chanzuckerberg/cryoet-data-portal/).


## For More Help
For more help, please file a issue on the repo, or contact us at <cryoetdataportal@chanzuckerberg.com>.

If you believe you have found a security issue, we would appreciate notification. Please send email to <security@chanzuckerberg.com>.
