# App Creator Location 🌍

Une application Django + CLI pour récupérer la géolocalisation de l'utilisateur via son adresse IP (`https://ipinfo.io`).

## 📦 Installation

```bash
pip install app-creator-location
Utilisation CLI
get-location
Utilisation Django
'app_creator',

