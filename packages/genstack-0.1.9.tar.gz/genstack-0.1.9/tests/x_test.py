class Sample:
    def __init__(self) -> None:
        timeout = 30
    @staticmethod
    def say(self) -> None:
        print(self.timeout)
        
sam = Sample()

sam.say()