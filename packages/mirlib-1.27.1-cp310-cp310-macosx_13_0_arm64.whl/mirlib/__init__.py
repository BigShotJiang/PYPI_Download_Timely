__version__ = '1.27.1'
__commit_hash__ = 'dd1084fb115a6ae18e4f72393dbb87ecbdede917'
findlibs_dependencies = ["eccodeslib", "eckitlib", "atlaslib_ecmwf"]
