"""Include grains in the metadata hash."""


def migrate(state_sync, **kwargs):  # type: ignore
    pass
