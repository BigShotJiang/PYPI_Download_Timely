"""Add the batch_concurrency attribute to the incremental model kinds.

This results in a change to the metadata hash.
"""


def migrate(state_sync, **kwargs):  # type: ignore
    pass
