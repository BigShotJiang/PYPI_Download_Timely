from .crc import CRC32C_TABLE, crc32c
