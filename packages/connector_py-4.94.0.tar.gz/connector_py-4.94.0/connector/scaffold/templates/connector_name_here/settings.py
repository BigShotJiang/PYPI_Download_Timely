from pydantic import BaseModel


class {pascal}Settings(BaseModel):
    account_id: str
