"""MCP (Model Context Protocol) server implementation for SQLSaber."""

from .mcp import mcp

__all__ = ["mcp"]
