from autogen_ext.tools.mcp._sse import SseMcpToolAdapter


class SseMcpToolAdapter(SseMcpToolAdapter):
    pass
