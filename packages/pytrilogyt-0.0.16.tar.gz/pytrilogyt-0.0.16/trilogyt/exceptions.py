class OptimizationError(Exception):
    # was unable to optimize imports
    pass
