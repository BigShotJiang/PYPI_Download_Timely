SUFFIX = "gen_model.py"

ALL_JOB_NAME = "__ASSET_JOB"

ENTRYPOINT_FILE = "definitions.py"
