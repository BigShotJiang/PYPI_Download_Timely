def rpm_to_second(rpm: int) -> float:
    seconds_in_a_minute = 60
    return rpm / seconds_in_a_minute
