from haupt.main import cli

cli(auto_envvar_prefix="HAUPT_CLI")
