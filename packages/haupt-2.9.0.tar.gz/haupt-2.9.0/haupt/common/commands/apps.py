from django.apps import AppConfig


class CommandsConfig(AppConfig):
    name = "haupt.common.commands"
    verbose_name = "commands"
