from haupt.background.celeryp.executions import TasksExecutions

TasksExecutions.register_tasks()
