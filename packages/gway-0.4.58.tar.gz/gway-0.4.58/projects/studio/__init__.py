"""Multimedia helpers grouped under studio."""
