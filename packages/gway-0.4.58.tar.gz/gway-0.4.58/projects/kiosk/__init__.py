"""Simple kiosk-style browser window launcher."""

from .window import show

__all__ = ["show"]
