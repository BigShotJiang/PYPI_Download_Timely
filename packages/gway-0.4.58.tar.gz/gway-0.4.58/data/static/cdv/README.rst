CDV Storage
-----------

Helpers for working with colon-delimited value files.
