Web Authentication
------------------

Basic account login example used by the website recipe.

JWT token authentication can be configured with ``web.auth.config_jwt``.
