Cookie Jar
----------

Demonstrates cookie-based preferences for the demo site.
