MTG Card Search
---------------

Frontend to query the Scryfall API for Magic cards.
