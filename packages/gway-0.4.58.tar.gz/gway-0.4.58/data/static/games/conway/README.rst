Conway's Game of Life
---------------------

Single-page JavaScript implementation.
