Evennia Integration
-------------------

Helpers to install and manage a local Evennia MUD server.

Use ``/games/fantastic-client`` once the server is running to launch the
web-based MUD client.

Recipes
-------

Run ``gway run recipes/gamebox.gwr`` to start a demo site including the
Evennia server and web client.
