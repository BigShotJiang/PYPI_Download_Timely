Toys & Games
------------

Shared helpers for simple demo games.
