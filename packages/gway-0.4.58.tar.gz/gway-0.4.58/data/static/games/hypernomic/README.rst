Hypernomic
----------

A minimal interface for playing a Nomic-style game. Players can submit
proposals, vote, and track rules or scores. Data is stored in ``.cdv``
files under ``work/games/``.
