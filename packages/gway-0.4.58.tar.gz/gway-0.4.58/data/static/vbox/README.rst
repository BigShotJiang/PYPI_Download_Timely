Virtual Box
-----------

Upload and download files through a secure web interface.
