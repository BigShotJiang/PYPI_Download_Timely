Studio Project
--------------

The ``studio`` project groups multimedia helpers under a single namespace. Subprojects include ``screen`` for screenshots and display tools, ``mic`` for audio recording, ``clip`` for clipboard utilities and ``qr`` for QR code generation.
