EVCS Simulator
--------------

Mock charge point that connects to the CSMS dashboard.
Launch it with ``gway ocpp.evcs simulate`` and open
``/ocpp/evcs/cp-simulator`` (``gw.ocpp.evcs.view_simulator``)
to start or stop sessions and view status. Use ``--pre-charge-delay`` to
postpone the start of charging while still exchanging Heartbeats.
