OCPP Data Helpers
-----------------

Database functions used to persist charging session information.
