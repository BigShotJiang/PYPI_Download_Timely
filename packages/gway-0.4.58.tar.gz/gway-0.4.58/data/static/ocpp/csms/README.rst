CSMS Dashboard
--------------

Central system server with a web status page.
