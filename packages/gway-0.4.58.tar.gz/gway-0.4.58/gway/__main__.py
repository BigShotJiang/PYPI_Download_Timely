from .console import cli_main

r"""
  __                                 .___        .__                        .___                
_/  |_   ____    _____    ____     __| _/  ____  |  |   ______    ____    __| _/  ____  _______ 
\   __\ /  _ \  /     \  /  _ \   / __ | _/ __ \ |  |   \____ \  /  _ \  / __ | _/ __ \ \_  __ \
 |  |  (  <_> )|  Y Y  \(  <_> ) / /_/ | \  ___/ |  |__ |  |_> >(  <.> )/ /_/ | \  ___/  |  | \/
 |__|   \____/ |__|_|  / \____/  \____ |  \___  >|____/ |   __/  \____/ \____ |  \___  > |__|   
                     \/               \/      \/        |__|                 \/      \/         

[ Venimos de la Tribu. ] [ A la Tribu volveremos. ]

-- El siguiente [texto] es un poema que se cuenta a si mismo. --

Python/HTML/CSS/SQL code by Rafael Jesús Guillén Osorio (https://arthexis.com) 
Comments, reviews and support by Avon[ ]Ross, Keats, INTERCAL and Aristóteles Palimpsesto, III.
Testing, QA Acceptance and mischief instigation by Dr. A. Lince (and His team.)

"""

if __name__ == "__main__":
    cli_main()
    