VERSION = '0.0.70'
PACKAGE_NAME = 'azureml-designer-cv-modules'
DESCRIPTION = 'Modules to pre-process and transform images such as to crop, pad or resize.'
