This folder contains curated data with a clear provenance. The
name of the script that generated them from raw data could
suffice.
