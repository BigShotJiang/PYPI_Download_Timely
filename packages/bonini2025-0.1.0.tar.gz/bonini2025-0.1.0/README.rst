========================
bonini2025
========================

.. {# pkglts, doc

.. image:: https://b326.gitlab.io/bonini2025/_images/badge_pkging_pip.svg
    :alt: PyPI version
    :target: https://pypi.org/project/bonini2025/0.1.0/

.. image:: https://b326.gitlab.io/bonini2025/_images/badge_pkging_conda.svg
    :alt: Conda version
    :target: https://anaconda.org/revesansparole/bonini2025

.. image:: https://b326.gitlab.io/bonini2025/_images/badge_doc.svg
    :alt: Documentation status
    :target: https://b326.gitlab.io/bonini2025/

.. image:: https://badge.fury.io/py/bonini2025.svg
    :alt: PyPI version
    :target: https://badge.fury.io/py/bonini2025

.. #}
.. {# pkglts, glabpkg_dev, after doc

main: |main_build|_ |main_coverage|_

.. |main_build| image:: https://gitlab.com/b326/bonini2025/badges/main/pipeline.svg
.. _main_build: https://gitlab.com/b326/bonini2025/commits/main

.. |main_coverage| image:: https://gitlab.com/b326/bonini2025/badges/main/coverage.svg
.. _main_coverage: https://gitlab.com/b326/bonini2025/commits/main
.. #}

Data and formalisms from Bonini et al. (2025)

