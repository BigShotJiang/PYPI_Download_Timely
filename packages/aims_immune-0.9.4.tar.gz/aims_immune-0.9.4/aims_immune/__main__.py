# Stealing this from jupyterlab
# currently main.py shouldn't really be doing much...
import sys

from aims_immune.aims import main

sys.exit(main())