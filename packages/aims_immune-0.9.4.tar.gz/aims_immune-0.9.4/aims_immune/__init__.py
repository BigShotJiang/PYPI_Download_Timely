# __init__.py

# GUI version adapted from AIMS:
__version__ = "0.9.3"