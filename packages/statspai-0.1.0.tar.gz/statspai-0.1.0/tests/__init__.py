"""
Test initialization
"""
