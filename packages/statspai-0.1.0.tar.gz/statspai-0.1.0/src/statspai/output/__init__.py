"""
Output utilities for regression results
"""

from .outreg2 import OutReg2, outreg2

__all__ = [
    "OutReg2",
    "outreg2",
]
