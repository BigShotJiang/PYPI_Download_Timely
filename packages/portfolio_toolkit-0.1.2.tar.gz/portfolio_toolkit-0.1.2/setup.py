from setuptools import setup

# Configuration is now primarily in pyproject.toml
# This minimal setup.py is kept for compatibility
setup()
