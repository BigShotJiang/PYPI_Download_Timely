my_module_menu = APP_NAVIGATION.append_page_group(
    PageGroup(
        name="my-module",
        caption="My Module",
    )
)
