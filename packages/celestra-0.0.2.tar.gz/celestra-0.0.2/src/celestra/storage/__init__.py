"""Storage module for Celestraa DSL."""

from .config_map import ConfigMap

__all__ = ["ConfigMap"] 