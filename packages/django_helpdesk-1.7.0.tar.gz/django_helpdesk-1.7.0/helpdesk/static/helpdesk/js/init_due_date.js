$(() => {
    $("#id_due_date").datepicker({dateFormat: 'yy-mm-dd 00:00:00'});
});