from .sharepoint import SharePoint

def main():
    print("sharepointlib is a library for interacting with SharePoint.")

if __name__ == "__main__":
    main()
