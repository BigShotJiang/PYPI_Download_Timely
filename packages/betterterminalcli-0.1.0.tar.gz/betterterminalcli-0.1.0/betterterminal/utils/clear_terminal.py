def clear():
    from os import system, name
    system('cls' if name == 'nt' else 'clear')