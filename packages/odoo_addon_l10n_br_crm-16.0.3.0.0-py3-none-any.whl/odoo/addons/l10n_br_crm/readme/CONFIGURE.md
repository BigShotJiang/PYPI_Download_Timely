Após a instalação deste módulo deve ser configurado o endereço da
empresa para que os campos de endereço tenha o formato utilizado no
brasil.
