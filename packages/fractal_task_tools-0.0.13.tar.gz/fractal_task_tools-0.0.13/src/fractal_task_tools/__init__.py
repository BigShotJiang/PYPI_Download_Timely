import logging

logging.basicConfig(level=logging.INFO)

__VERSION__ = "0.0.13"
