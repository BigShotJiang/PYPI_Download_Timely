class BlockException(Exception):
    pass


class CancelException(Exception):
    pass


class PassException(Exception):
    pass
