"""o7pdf - A collection of usefule tools & reports for PDF generation"""

__version__ = "1.1.0"
