﻿tests.hello
===========

.. currentmodule:: tests

.. autodata:: hello
