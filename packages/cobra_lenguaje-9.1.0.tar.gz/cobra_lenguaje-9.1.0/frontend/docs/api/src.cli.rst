src.cli package
===============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   src.cli.commands

Submodules
----------

src.cli.cli module
------------------

.. automodule:: src.cli.cli
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: src.cli
   :members:
   :undoc-members:
   :show-inheritance:
