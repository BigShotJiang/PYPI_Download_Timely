src.core.nativos.red module
---------------------------

.. automodule:: src.core.nativos.red
   :members:
   :undoc-members:
   :show-inheritance:
