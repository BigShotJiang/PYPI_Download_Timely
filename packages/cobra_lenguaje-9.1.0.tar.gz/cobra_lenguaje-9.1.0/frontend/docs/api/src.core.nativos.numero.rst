src.core.nativos.numero module
------------------------------

.. automodule:: src.core.nativos.numero
   :members:
   :undoc-members:
   :show-inheritance:
