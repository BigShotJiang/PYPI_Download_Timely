src.core.nativos.sistema module
-------------------------------

.. automodule:: src.core.nativos.sistema
   :members:
   :undoc-members:
   :show-inheritance:
