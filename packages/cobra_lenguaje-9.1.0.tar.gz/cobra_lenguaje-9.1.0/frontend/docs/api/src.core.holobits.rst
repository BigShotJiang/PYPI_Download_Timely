src.core.holobits package
=========================

Submodules
----------

src.core.holobits.graficar module
---------------------------------

.. automodule:: src.core.holobits.graficar
   :members:
   :undoc-members:
   :show-inheritance:

src.core.holobits.holobit module
--------------------------------

.. automodule:: src.core.holobits.holobit
   :members:
   :undoc-members:
   :show-inheritance:

src.core.holobits.proyection module
-----------------------------------

.. automodule:: src.core.holobits.proyection
   :members:
   :undoc-members:
   :show-inheritance:

src.core.holobits.transformacion module
---------------------------------------

.. automodule:: src.core.holobits.transformacion
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: src.core.holobits
   :members:
   :undoc-members:
   :show-inheritance:
