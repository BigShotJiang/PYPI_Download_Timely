src package
===========

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   src.cli
   src.core
   src.tests

Module contents
---------------

.. automodule:: src
   :members:
   :undoc-members:
   :show-inheritance:
