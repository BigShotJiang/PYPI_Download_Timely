src.core.nativos.coleccion module
---------------------------------

.. automodule:: src.core.nativos.coleccion
   :members:
   :undoc-members:
   :show-inheritance:
