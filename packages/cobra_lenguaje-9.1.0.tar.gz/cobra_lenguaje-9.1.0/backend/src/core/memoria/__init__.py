"""Submódulo con las estrategias y gestores de memoria utilizados por Cobra."""
