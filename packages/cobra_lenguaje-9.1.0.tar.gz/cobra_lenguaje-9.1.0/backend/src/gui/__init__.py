"""Componentes de la interfaz gráfica de Cobra."""
