"""Submódulos relacionados con el análisis sintáctico del lenguaje Cobra."""
