def visit_continuar(self, nodo):
    self.codigo += f"{self.obtener_indentacion()}continue\n"
