def visit_romper(self, nodo):
    self.agregar_linea("BREAK")
