def visit_pasar(self, nodo):
    self.agregar_linea(";")
