def visit_pasar(self, nodo):
    self.codigo += f"{self.obtener_indentacion()}pass\n"
