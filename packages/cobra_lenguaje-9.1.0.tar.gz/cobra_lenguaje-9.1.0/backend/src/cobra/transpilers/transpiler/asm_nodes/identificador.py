def visit_identificador(self, nodo):
    self.agregar_linea(nodo.nombre)
