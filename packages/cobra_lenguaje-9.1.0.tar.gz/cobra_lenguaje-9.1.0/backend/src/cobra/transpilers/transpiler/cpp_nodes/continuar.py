def visit_continuar(self, nodo):
    self.agregar_linea("continue;")
