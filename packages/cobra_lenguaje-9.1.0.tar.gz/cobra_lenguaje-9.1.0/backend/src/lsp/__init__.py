"""Servidor LSP sencillo basado en python-lsp-server."""
