Style Commandments
==================

Read the OpenStack Style Commandments in the following link

https://docs.openstack.org/hacking/latest/
