## **📦 SUWWP V0.2.3 - Speeding up Work with Python (SUW2P)**
# Create by Xwared Team and Dovintc, Project SUWWP - Speeding up Work with Python (SUW2P)

A tool for accelerated
data manipulation in Python

# Beta Version

# **Project SUWWP is being created by: *Xwared|Dovintc and Tooch1c*** 
**MIT License: *[LICENSE](https://github.com/Dovintc32/SUWWP?tab=MIT-1-ov-file)***
