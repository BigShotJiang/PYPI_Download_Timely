from wdoc.utils.tasks import query, summarize

__all__ = ["query", "summarize"]
