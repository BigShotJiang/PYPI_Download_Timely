from .top_queries_calc import PG_STAT_STATEMENTS
from .top_queries_calc import TopQueriesCalc

__all__ = ["PG_STAT_STATEMENTS", "TopQueriesCalc"]
