# SPDX-License-Identifier: Apache-2.0
"""Global version number for the cwl_utils package."""
__version__ = "0.39"
