"""Convenience module."""

from .cwl_v1_2 import *  # noqa: F401,F403
