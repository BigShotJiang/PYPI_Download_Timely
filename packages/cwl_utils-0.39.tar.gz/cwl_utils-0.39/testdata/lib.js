var foo = function(x) {
    return 2 * x
}

var bar = function(n, x) {
    return n + " engineers walk into a " + x
}
