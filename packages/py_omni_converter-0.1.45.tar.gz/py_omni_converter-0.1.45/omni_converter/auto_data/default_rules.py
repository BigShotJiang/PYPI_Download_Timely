from omni_converter.solver.rules import AutoRuleBook

DEFAULT_RULES = AutoRuleBook()#AutoImage.default_rules.copy())
