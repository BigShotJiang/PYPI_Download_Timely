# this is updated by .github/workflows/release.yaml
__version__ = "0.26.0"
