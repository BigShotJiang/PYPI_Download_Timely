from robusta.core.sinks.opsgenie.opsgenie_sink import OpsGenieSink
from robusta.core.sinks.opsgenie.opsgenie_sink_params import OpsGenieSinkConfigWrapper, OpsGenieSinkParams
