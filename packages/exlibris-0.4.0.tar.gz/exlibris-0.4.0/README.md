# ExLibris

**ExLibris** is a Python library that provides statistical comparisons between different binary classification models. This library is specifically designed to compare the GSGP classifier with other models.

## Installation

To install **ExLibris**, use `pip`:

```bash
pip install exlibris
