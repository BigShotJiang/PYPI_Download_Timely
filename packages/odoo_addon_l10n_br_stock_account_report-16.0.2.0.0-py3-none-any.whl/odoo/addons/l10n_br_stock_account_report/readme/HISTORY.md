## 16.0.1.0.0 (2025-02-27)

- \[MIG\] Migration to version 16.0

Incluída dependência do módulo [report_wkhtmltopdf_param](https://github.com/OCA/reporting-engine/tree/16.0/report_wkhtmltopdf_param) para que o **PDF** exiba os caractertes que **Não são ASCII** de forma correta, adicionando no comando **wkhtmltopdf** o parâmetro **--encodig UTF-8**.

## 14.0.1.0.0 (2023-07-28)

- \[MIG\] Migration to version 14.0

## 12.0.1.0.0 (2021-07-29)

- \[ADD\] First version.
