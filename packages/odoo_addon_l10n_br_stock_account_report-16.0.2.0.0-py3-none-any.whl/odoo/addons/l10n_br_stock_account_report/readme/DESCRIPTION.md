Esse módulo implementa o **Relatorio de Valorização do Estoque Modelo P7**.
