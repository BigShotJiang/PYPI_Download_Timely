Para usar esse módulo, vá em:

**Inventário > Relatórios > Valoração de Inventário - Modelo P7**
