"""
Solve functions for estimating ocean tides
"""
from .constants import *
