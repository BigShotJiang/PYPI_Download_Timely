## deqr

A python library for decoding QR codes. Implemented as a cython wrapper around
two different QR code decoding backends (quirc and qrdec).

### Install

```
pip install deqr
```

### [Documentation][documentation]

[documentation]: https://torque.github.io/deqr-docs/latest-dev/
