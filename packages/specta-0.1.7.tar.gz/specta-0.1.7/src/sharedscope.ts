import '@jupyterlab/logconsole';
import '@jupyterlite/server';
import '@jupyterlab/console';
