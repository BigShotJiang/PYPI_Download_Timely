import React from 'react';

export const Divider = () => {
  return <div className="specta-divider"></div>;
};
