# {{ general.slug }}

> [!NOTE]
> This project was generated using [Instant Python](https://github.com/dimanu-py/instant-python), a fast, easy and reliable project generator for Python projects.

## Description

{{ general.description }}
