from .GEO import *

# print('Thanks for using Geo. Visit https://www.youtube.com/@MrPsyghost for more information.')