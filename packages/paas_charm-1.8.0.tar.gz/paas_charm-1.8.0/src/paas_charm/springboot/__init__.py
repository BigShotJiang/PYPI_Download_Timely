# Copyright 2025 Canonical Ltd.
# See LICENSE file for licensing details.

"""Spring Boot module entrypoint."""

from .charm import Charm

__all__ = ["Charm"]
