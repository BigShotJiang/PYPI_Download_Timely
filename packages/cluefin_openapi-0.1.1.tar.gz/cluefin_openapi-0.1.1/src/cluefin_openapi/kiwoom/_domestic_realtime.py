class DomesticRealtime:
    pass


# 주문체결	OO	get_order_execution
# 잔고	04	get_balance
# 주식기세	OA	get_stock_momentum
# 주식체결	OB	get_stock_execution
# 주식우선호가	OC	get_stock_priority_quote
# 주식호가잔량	OD	get_stock_remaining_order_quantity
# 주식시간외호가	OE	get_stock_after_hours_quote
# 주식당일거래원	OF	get_stock_current_day_traders
# ETF NAV	OG	get_etf_nav
# 주식예상체결	OH	get_stock_expected_execution
# 업종지수	OJ	get_industry_index
# 업종등락	OU	get_industry_fluctuation
# 주식종목정보	Og	get_stock_item_info
# ELW 이론가	Om	get_elw_theoretical_price
# 장시작시간	Os	get_market_start_time
# ELW지표	Ou	get_elw_indicator
# 종목별프로그램매매	Ow	get_program_trading_by_stock
# VI발동/해제	1h	get_vi_activation_release
