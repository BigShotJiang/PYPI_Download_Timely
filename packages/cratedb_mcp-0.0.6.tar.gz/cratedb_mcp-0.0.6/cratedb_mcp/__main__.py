from cratedb_mcp.core import CrateDbMcp

# Is that a standard entrypoint that should be kept alive?
mcp = CrateDbMcp().mcp
