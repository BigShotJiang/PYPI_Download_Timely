from setuptools import setup

setup(
    name="vaultide",
    version="0.0.1",
    description="Vaultide is coming soon!",
    author="Meder Kamalov",
    author_email="meder@vaultide.com",
    packages=[],
)
