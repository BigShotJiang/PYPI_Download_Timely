---
hide:
- feedback
---

--8<-- "README.md"

<!-- Try to add a reference to autodoc: [get_single_series][efts_io.wrapper.EftsDataSet.get_single_series] -->
