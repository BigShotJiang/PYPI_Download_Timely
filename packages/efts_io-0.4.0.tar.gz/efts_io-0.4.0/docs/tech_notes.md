# tech notes

**These are notes for the package maintainer(s)**. Most users can ignore them.

August 2024 trialing package development using [this `copier-uv`template](https://pawamoy.github.io/copier-uv/work/). Note also the [blog post from Simon Wilson on uv](https://til.simonwillison.net/python/uv-cli-apps)

