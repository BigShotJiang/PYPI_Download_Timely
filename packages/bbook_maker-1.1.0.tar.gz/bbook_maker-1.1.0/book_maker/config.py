config = {
    "translator": {
        "chatgptapi": {
            "context_paragraph_limit": 3,
            "batch_context_update_interval": 50,
        }
    },
}
