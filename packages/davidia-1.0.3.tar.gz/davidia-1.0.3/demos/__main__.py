from .simple import run_all_demos

run_all_demos()
