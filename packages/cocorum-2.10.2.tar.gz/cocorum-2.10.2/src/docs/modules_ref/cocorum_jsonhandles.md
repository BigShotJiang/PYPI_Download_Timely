# cocorum.jsonhandles

This module provides abstract classes for wrapping JSON data blocks returned by the API in a Python object with attributes / properties.
This library does not contain any classes or functions meant to be used directly.

::: cocorum.jsonhandles

S.D.G.
